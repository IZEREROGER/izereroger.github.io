-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2022 at 11:45 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hdev_rent`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `auth_engine`
-- (See below for the actual view)
--
CREATE TABLE `auth_engine` (
`a_id` bigint(100)
,`a_username` text
,`a_email` text
,`a_password` text
,`a_role` text
,`a_status` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `auth_storage`
--

CREATE TABLE `auth_storage` (
  `a_id` bigint(100) NOT NULL,
  `a_nid` text NOT NULL,
  `a_name` text NOT NULL,
  `a_tel` text NOT NULL,
  `a_username` text NOT NULL,
  `a_sex` text NOT NULL,
  `a_email` text NOT NULL,
  `a_password` text NOT NULL,
  `a_role` text NOT NULL,
  `a_reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `a_status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_storage`
--

INSERT INTO `auth_storage` (`a_id`, `a_nid`, `a_name`, `a_tel`, `a_username`, `a_sex`, `a_email`, `a_password`, `a_role`, `a_reg_date`, `a_status`) VALUES
(1, '23456789', 'NKORERE Tresor', '0788788291', 'izere1', 'Male', 'tresor@gmail.com', '202cb962ac59075b964b07152d234b70', 'admin', '2022-05-07 21:44:28', 1),
(2, '73668326568', 'eric', '0788788291', 'eric', 'm', 'eric@gmail.com', '', 'agent', '2021-09-14 08:50:57', 0),
(3, '12508856324', 'NDUNGUTSE FIDEL', '07885569911', 'fidele', 'f', 'mumporeze@gmail.com', '202cb962ac59075b964b07152d234b70', 'agent', '2021-09-13 23:04:09', 1),
(4, '1122009876', 'MUMPOREZE Doliane', '07885569911', 'dd1', 'f', 'dolianeeeeee@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'agent', '2021-09-14 08:52:02', 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `booked`
-- (See below for the actual view)
--
CREATE TABLE `booked` (
`re_id` bigint(100)
,`h_id` bigint(100)
,`t_id` bigint(100)
,`start_date` date
,`end_date` date
,`end_date_2` date
,`re_price` decimal(11,2)
,`re_status` int(11)
,`re_reg_date` timestamp
,`re_reg_exp_date` timestamp
,`o_id` bigint(100)
,`tx_id` varchar(255)
,`tx_ref` varchar(255)
,`p_price` decimal(11,2)
,`p_status` varchar(255)
,`p_date` timestamp
);

-- --------------------------------------------------------

--
-- Table structure for table `houses`
--

CREATE TABLE `houses` (
  `h_id` bigint(100) NOT NULL,
  `l_id` bigint(100) NOT NULL,
  `c_id` bigint(200) NOT NULL,
  `h_description` text NOT NULL,
  `h_photos` text NOT NULL,
  `h_location` bigint(100) NOT NULL,
  `h_price` float(11,2) NOT NULL,
  `h_status` int(11) NOT NULL DEFAULT 1,
  `h_reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `h_reg_by` bigint(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `houses`
--

INSERT INTO `houses` (`h_id`, `l_id`, `c_id`, `h_description`, `h_photos`, `h_location`, `h_price`, `h_status`, `h_reg_date`, `h_reg_by`) VALUES
(1, 1, 1, 'a house for family', 'House_upload_61115f4cbd628_t_1628528460.jpg', 250, 200.00, 1, '2021-08-09 16:58:26', 1),
(2, 1, 1, 'Ahouse for students and professors', 'House_upload_61115eff13332_t_1628528383.jpg', 134, 200000.00, 1, '2021-08-09 16:59:43', 1),
(3, 1, 1, 'a house for college students', 'House_upload_61115f1f157dd_t_1628528415.jpg', 200, 250000.00, 1, '2021-08-09 17:00:15', 1),
(4, 1, 1, 'For test students', 'House_upload_613e706a308ba_t_1631481962.jpg.,*HDEV_prod*.,House_upload_613e706a3110d_t_1631481962.jpg.,*HDEV_prod*.,House_upload_613e706a3201b_t_1631481962.jpg', 599, 250000.00, 1, '2021-08-09 17:01:00', 1),
(5, 1, 1, 'a house for college students and directors', 'House_upload_61115f946f770_t_1628528532.jpg', 134, 600.00, 1, '2021-08-09 17:02:12', 1),
(6, 3, 1, 'for valued people', 'House_upload_61115fc4166ae_t_1628528580.png', 90, 40000.00, 1, '2021-08-09 17:03:00', 1),
(7, 1, 1, 'for lectures', 'House_upload_61115feed4274_t_1628528622.jpg', 11, 78000.00, 0, '2021-08-09 17:03:42', 1),
(8, 1, 1, 'for constructors', 'House_upload_6111601821ca2_t_1628528664.jpg', 14, 45000.00, 1, '2021-08-09 17:04:24', 1),
(9, 1, 1, 'new roger', 'House_upload_6111b7b4b52b7_t_1628551092.jpg', 700, 250800.00, 1, '2021-08-09 23:18:12', 1),
(10, 1, 1, 'INZU NZIZA', 'House_upload_611be998edbc0_t_1629219224.jpg.,*HDEV_prod*.,House_upload_611be99907e11_t_1629219225.jpg.,*HDEV_prod*.,House_upload_611be9992ce58_t_1629219225.jpg.,*HDEV_prod*.,House_upload_611be9992e9f7_t_1629219225.jpg', 50, 200.00, 1, '2021-08-17 16:53:45', 1),
(12, 1, 1, 'hhfhgfhgfhgfhgf', 'House_upload_613cfa0630bf0_t_1631386118.jpg', 250, 1000.00, 1, '2021-09-11 18:48:38', 1),
(13, 1, 1, '6jytuytytiut', 'House_upload_6140734dc9440_t_1631613773.jpg', 588, 2000.00, 1, '2021-09-14 10:02:53', 7),
(14, 7, 1, 'good house for familly', 'House_upload_61407684d8da8_t_1631614596.PNG', 901, 1200.00, 1, '2021-09-14 10:16:36', 7),
(15, 7, 1, 'myhfhgfghfhgfghfghfghf', 'House_upload_614078a77e509_t_1631615143.jpg', 860, 2000.00, 1, '2021-09-14 10:25:43', 7),
(16, 7, 1, 'jyhgjhgghjhgjhghj', 'House_upload_6140793e73a0b_t_1631615294.jpg.,*HDEV_prod*.,House_upload_6140793e79776_t_1631615294.PNG.,*HDEV_prod*.,House_upload_6140793e7af79_t_1631615294.PNG.,*HDEV_prod*.,House_upload_6140793e7c475_t_1631615294.jpg.,*HDEV_prod*.,House_upload_6140793e7cd7f_t_1631615294.jpg.,*HDEV_prod*.,House_upload_6140793e7d7a3_t_1631615294.jpg.,*HDEV_prod*.,House_upload_6140793e7f833_t_1631615294.png.,*HDEV_prod*.,House_upload_6140793e80269_t_1631615294.jpg', 565, 100.00, 1, '2021-09-14 10:28:14', 7);

-- --------------------------------------------------------

--
-- Table structure for table `house_category`
--

CREATE TABLE `house_category` (
  `c_id` bigint(100) NOT NULL,
  `c_name` text NOT NULL,
  `c_reg` timestamp NOT NULL DEFAULT current_timestamp(),
  `c_status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `house_category`
--

INSERT INTO `house_category` (`c_id`, `c_name`, `c_reg`, `c_status`) VALUES
(1, 'residential', '2021-09-02 20:13:28', 1);

-- --------------------------------------------------------

--
-- Table structure for table `land_lord`
--

CREATE TABLE `land_lord` (
  `l_id` bigint(100) NOT NULL,
  `l_name` text NOT NULL,
  `l_nid` text NOT NULL,
  `l_sex` varchar(1) NOT NULL,
  `l_tel` text NOT NULL,
  `l_username` text NOT NULL,
  `l_email` text NOT NULL,
  `l_password` text NOT NULL,
  `l_role` text NOT NULL,
  `l_reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `l_status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `land_lord`
--

INSERT INTO `land_lord` (`l_id`, `l_name`, `l_nid`, `l_sex`, `l_tel`, `l_username`, `l_email`, `l_password`, `l_role`, `l_reg_date`, `l_status`) VALUES
(1, 'iyizire berwa rosines', '', 'f', '0788788291', 'iyizire1', 'iyizire1@gmail.com', 'a5ef04bed67700389a7459bb1f256033', 'land_lord', '2021-08-03 09:38:25', 0),
(2, 'IZERE HIRWA Roger', '', 'm', '0788788291', 'izere1', 'izereroger@gmail.com', 'a5ef04bed67700389a7459bb1f256033', 'land_lord', '2021-08-03 15:58:35', 1),
(3, 'NGENZI Jean Luc', '', 'm', '0788788291', 'ngenzi2', 'ngenzi@gmail.com', 'a5ef04bed67700389a7459bb1f256033', 'land_lord', '2021-08-03 15:59:29', 1),
(5, 'MUKANTAGENGWA Ines', '', 'f', '0788788291', 'ines', 'ines@gmail.com', 'a5ef04bed67700389a7459bb1f256033', 'land_lord', '2021-08-03 17:27:55', 1),
(6, 'Niyomugaba kevin Joe', '', 'm', '0788788291', 'kevin', 'kevin@gmail.com', 'a5ef04bed67700389a7459bb1f256033', 'land_lord', '2021-09-14 00:06:29', 1),
(7, 'SUGIRA Pascal', '', 'm', '0788788291', 'sugira@1', 'sugira@gmail.com', '202cb962ac59075b964b07152d234b70', 'land_lord', '2021-09-14 09:32:15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `land_lord_payments`
--

CREATE TABLE `land_lord_payments` (
  `lp_id` bigint(100) NOT NULL,
  `lp_amount` text NOT NULL,
  `a_id` bigint(100) NOT NULL,
  `l_id` bigint(100) NOT NULL,
  `lp_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `lp_status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `land_lord_payments`
--

INSERT INTO `land_lord_payments` (`lp_id`, `lp_amount`, `a_id`, `l_id`, `lp_date`, `lp_status`) VALUES
(1, '1000', 1, 1, '2021-09-09 10:56:27', 1);

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `loc_id` bigint(100) NOT NULL,
  `loc_province` text NOT NULL,
  `loc_district` text NOT NULL,
  `loc_sector` text NOT NULL,
  `loc_cell` text NOT NULL,
  `loc_village` text NOT NULL,
  `loc_status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locations`
--

INSERT INTO `locations` (`loc_id`, `loc_province`, `loc_district`, `loc_sector`, `loc_cell`, `loc_village`, `loc_status`) VALUES
(1, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabahizi', 'Gihanga', 1),
(2, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabahizi', 'Iterambere', 1),
(3, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabahizi', 'Izuba', 1),
(4, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabahizi', 'Nyaburanga', 1),
(5, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabahizi', 'Nyenyeri', 1),
(6, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabahizi', 'Ubukorikori', 1),
(7, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabahizi', 'Ubumwe', 1),
(8, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabahizi', 'Ubwiyunge', 1),
(9, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabahizi', 'Umucyo', 1),
(10, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabahizi', 'Umurabyo', 1),
(11, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabahizi', 'Umuseke', 1),
(12, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabahizi', 'Vugizo', 1),
(13, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabeza', 'Akinyambo', 1),
(14, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabeza', 'Amayaga', 1),
(15, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabeza', 'Gitwa', 1),
(16, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabeza', 'Ituze', 1),
(17, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Akabeza', 'Mpazi', 1),
(18, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Gacyamo', 'Amahoro', 1),
(19, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Gacyamo', 'Impuhwe', 1),
(20, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Gacyamo', 'Intsinzi', 1),
(21, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Gacyamo', 'Kivumu', 1),
(22, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Gacyamo', 'Ubumwe', 1),
(23, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Gacyamo', 'Urukundo', 1),
(24, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Gacyamo', 'Ururembo', 1),
(25, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kigarama', 'Ingenzi', 1),
(26, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kigarama', 'Sangwa', 1),
(27, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kigarama', 'Umubano', 1),
(28, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kigarama', 'Umucyo', 1),
(29, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kigarama', 'Umuhoza', 1),
(30, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kigarama', 'Umurava', 1),
(31, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kinyange', 'Akabugenewe', 1),
(32, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kinyange', 'Ihuriro', 1),
(33, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kinyange', 'Isangano', 1),
(34, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kinyange', 'Isano', 1),
(35, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kinyange', 'Karitasi', 1),
(36, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kinyange', 'Ubumanzi', 1),
(37, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kinyange', 'Uburezi', 1),
(38, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kinyange', 'Ubwiza', 1),
(39, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kinyange', 'Umucyo', 1),
(40, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kinyange', 'Umwembe', 1),
(41, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kinyange', 'Urugano', 1),
(42, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kora', 'Isangano', 1),
(43, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kora', 'Kanunga', 1),
(44, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kora', 'Kinyambo', 1),
(45, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kora', 'Kivumu', 1),
(46, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kora', 'Kora', 1),
(47, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kora', 'Mpazi', 1),
(48, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kora', 'Rugano', 1),
(49, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kora', 'Rugari', 1),
(50, 'Umujyi wa Kigali', 'Nyarugenge', 'Gitega', 'Kora', 'Ubumwe', 1),
(51, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Nyamweru', 'Bwimo', 1),
(52, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Nyamweru', 'Gatare', 1),
(53, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Nyamweru', 'Mubuga', 1),
(54, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Nyamweru', 'Nyakirambi', 1),
(55, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Nyamweru', 'Nyamweru', 1),
(56, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Nyamweru', 'Ruhengeri', 1),
(57, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Nzove', 'Bibungo', 1),
(58, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Nzove', 'Bwiza', 1),
(59, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Nzove', 'Gateko', 1),
(60, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Nzove', 'Kagasa', 1),
(61, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Nzove', 'Nyabihu', 1),
(62, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Nzove', 'Rutagara I', 1),
(63, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Nzove', 'Rutagara Ii', 1),
(64, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Nzove', 'Ruyenzi', 1),
(65, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Taba', 'Kagaramira', 1),
(66, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Taba', 'Ngendo', 1),
(67, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Taba', 'Nyarurama', 1),
(68, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Taba', 'Nyarusange', 1),
(69, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Taba', 'Rwakivumu', 1),
(70, 'Umujyi wa Kigali', 'Nyarugenge', 'Kanyinya', 'Taba', 'Taba', 1),
(71, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Kigali', 'Akirwanda', 1),
(72, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Kigali', 'Gisenga', 1),
(73, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Kigali', 'Kadobogo', 1),
(74, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Kigali', 'Kagarama', 1),
(75, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Kigali', 'Kibisogi', 1),
(76, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Kigali', 'Muganza', 1),
(77, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Kigali', 'Murama', 1),
(78, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Kigali', 'Rubuye', 1),
(79, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Kigali', 'Ruhango', 1),
(80, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Kigali', 'Ryasharangabo', 1),
(81, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Mwendo', 'Agakomeye', 1),
(82, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Mwendo', 'Akagugu', 1),
(83, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Mwendo', 'Amahoro', 1),
(84, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Mwendo', 'Amajyambere', 1),
(85, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Mwendo', 'Birambo', 1),
(86, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Mwendo', 'Isangano', 1),
(87, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Mwendo', 'Kanyabami', 1),
(88, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Mwendo', 'Karambo', 1),
(89, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Mwendo', 'Mwendo', 1),
(90, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Mwendo', 'Ruhuha', 1),
(91, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Mwendo', 'Ubuzima', 1),
(92, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Mwendo', 'Umutekano', 1),
(93, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Nyabugogo', 'Gakoni', 1),
(94, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Nyabugogo', 'Gatare', 1),
(95, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Nyabugogo', 'Giticyinyoni', 1),
(96, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Nyabugogo', 'Kadobogo', 1),
(97, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Nyabugogo', 'Kamenge', 1),
(98, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Nyabugogo', 'Karama', 1),
(99, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Nyabugogo', 'Kiruhura', 1),
(100, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Nyabugogo', 'Nyabikoni', 1),
(101, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Nyabugogo', 'Nyabugogo', 1),
(102, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Nyabugogo', 'Ruhondo', 1),
(103, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Ruriba', 'Misibya', 1),
(104, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Ruriba', 'Nyabitare', 1),
(105, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Ruriba', 'Ruhango', 1),
(106, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Ruriba', 'Ruharabuge', 1),
(107, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Ruriba', 'Ruriba', 1),
(108, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Ruriba', 'Ruzigimbogo', 1),
(109, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Ruriba', 'Ryamakomari', 1),
(110, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Ruriba', 'Tubungo', 1),
(111, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Rwesero', 'Akanyamirambo', 1),
(112, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Rwesero', 'Akinama', 1),
(113, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Rwesero', 'Makaga', 1),
(114, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Rwesero', 'Musimba', 1),
(115, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Rwesero', 'Ruhogo', 1),
(116, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Rwesero', 'Rwesero', 1),
(117, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Rwesero', 'Rweza', 1),
(118, 'Umujyi wa Kigali', 'Nyarugenge', 'Kigali', 'Rwesero', 'Vuganyana', 1),
(119, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kamuhoza', 'Buhoro', 1),
(120, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kamuhoza', 'Busasamana', 1),
(121, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kamuhoza', 'Isimbi', 1),
(122, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kamuhoza', 'Ituze', 1),
(123, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kamuhoza', 'Karama', 1),
(124, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kamuhoza', 'Karwarugabo', 1),
(125, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kamuhoza', 'Kigabiro', 1),
(126, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kamuhoza', 'Mataba', 1),
(127, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kamuhoza', 'Munini', 1),
(128, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kamuhoza', 'Ntaraga', 1),
(129, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kamuhoza', 'Nunga', 1),
(130, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kamuhoza', 'Rurama', 1),
(131, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kamuhoza', 'Rutunga', 1),
(132, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kamuhoza', 'Tetero', 1),
(133, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Katabaro', 'Akamahoro', 1),
(134, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Katabaro', 'Akishinge', 1),
(135, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Katabaro', 'Akishuri', 1),
(136, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Katabaro', 'Amahumbezi', 1),
(137, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Katabaro', 'Inganzo', 1),
(138, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Katabaro', 'Kigarama', 1),
(139, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Katabaro', 'Mpazi', 1),
(140, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Katabaro', 'Mugina', 1),
(141, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Katabaro', 'Ubumwe', 1),
(142, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Katabaro', 'Ubusabane', 1),
(143, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Katabaro', 'Umubano', 1),
(144, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Katabaro', 'Umurinzi', 1),
(145, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Katabaro', 'Uruyange', 1),
(146, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Akabeza', 1),
(147, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Amahoro', 1),
(148, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Birama', 1),
(149, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Buhoro', 1),
(150, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Bwiza', 1),
(151, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Byimana', 1),
(152, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Gakaraza', 1),
(153, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Gaseke', 1),
(154, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Ihuriro', 1),
(155, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Inkurunziza', 1),
(156, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Karambi', 1),
(157, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Kigina', 1),
(158, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Kimisagara', 1),
(159, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Kove', 1),
(160, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Muganza', 1),
(161, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Nyabugogo', 1),
(162, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Nyagakoki', 1),
(163, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Nyakabingo', 1),
(164, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Nyamabuye', 1),
(165, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Sangwa', 1),
(166, 'Umujyi wa Kigali', 'Nyarugenge', 'Kimisagara', 'Kimisagara', 'Sano', 1),
(167, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Kankuba', 'Kamatamu', 1),
(168, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Kankuba', 'Kankuba', 1),
(169, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Kankuba', 'Karukina', 1),
(170, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Kankuba', 'Musave', 1),
(171, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Kankuba', 'Nyarumanga', 1),
(172, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Kankuba', 'Rugendabari', 1),
(173, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Kavumu', 'Ayabatanga', 1),
(174, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Kavumu', 'Kankurimba', 1),
(175, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Kavumu', 'Kavumu', 1),
(176, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Kavumu', 'Mubura', 1),
(177, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Kavumu', 'Murondo', 1),
(178, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Kavumu', 'Nyakabingo', 1),
(179, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Kavumu', 'Nyarubuye', 1),
(180, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Mataba', 'Burema', 1),
(181, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Mataba', 'Gahombo', 1),
(182, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Mataba', 'Kabeza', 1),
(183, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Mataba', 'Karambi', 1),
(184, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Mataba', 'Kwisanga', 1),
(185, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Mataba', 'Mageragere', 1),
(186, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Mataba', 'Mataba', 1),
(187, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Mataba', 'Rushubi', 1),
(188, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Ntungamo', 'Akana ka Mageragere', 1),
(189, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Ntungamo', 'Gatovu', 1),
(190, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Ntungamo', 'Nyabitare', 1),
(191, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Ntungamo', 'Nyarubande', 1),
(192, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Ntungamo', 'Rubungo', 1),
(193, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Ntungamo', 'Rwindonyi', 1),
(194, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Nyarufunzo', 'Akabungo', 1),
(195, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Nyarufunzo', 'Akamashinge', 1),
(196, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Nyarufunzo', 'Maya', 1),
(197, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Nyarufunzo', 'Nyarufunzo', 1),
(198, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Nyarufunzo', 'Nyarurama', 1),
(199, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Nyarufunzo', 'Rubete', 1),
(200, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Nyarurenzi', 'Amahoro', 1),
(201, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Nyarurenzi', 'Ayabaramba', 1),
(202, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Nyarurenzi', 'Gikuyu', 1),
(203, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Nyarurenzi', 'Iterambere', 1),
(204, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Nyarurenzi', 'Nyabirondo', 1),
(205, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Nyarurenzi', 'Nyarurenzi', 1),
(206, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Runzenze', 'Gisunzu', 1),
(207, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Runzenze', 'Mpanga', 1),
(208, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Runzenze', 'Nkomero', 1),
(209, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Runzenze', 'Runzenze', 1),
(210, 'Umujyi wa Kigali', 'Nyarugenge', 'Mageragere', 'Runzenze', 'Uwurugenge', 1),
(211, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Amahoro', 'Amahoro', 1),
(212, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Amahoro', 'Amizero', 1),
(213, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Amahoro', 'Inyarurembo', 1),
(214, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Amahoro', 'Kabirizi', 1),
(215, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Amahoro', 'Ubuzima', 1),
(216, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Amahoro', 'Uruhimbi', 1),
(217, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Kabasengerezi', 'Icyeza', 1),
(218, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Kabasengerezi', 'Ikana', 1),
(219, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Kabasengerezi', 'Intwari', 1),
(220, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Kabasengerezi', 'Kabasengerezi', 1),
(221, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Kabeza', 'Hirwa', 1),
(222, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Kabeza', 'Ikaze', 1),
(223, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Kabeza', 'Imanzi', 1),
(224, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Kabeza', 'Ingenzi', 1),
(225, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Kabeza', 'Ituze', 1),
(226, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Kabeza', 'Sangwa', 1),
(227, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Kabeza', 'Umwezi', 1),
(228, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Nyabugogo', 'Abeza', 1),
(229, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Nyabugogo', 'Icyerekezo', 1),
(230, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Nyabugogo', 'Indatwa', 1),
(231, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Nyabugogo', 'Rwezangoro', 1),
(232, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Nyabugogo', 'Ubucuruzi', 1),
(233, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Nyabugogo', 'Umutekano', 1),
(234, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Rugenge', 'Imihigo', 1),
(235, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Rugenge', 'Impala', 1),
(236, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Rugenge', 'Rugenge', 1),
(237, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Rugenge', 'Ubumanzi', 1),
(238, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Tetero', 'Indamutsa', 1),
(239, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Tetero', 'Ingoro', 1),
(240, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Tetero', 'Inkingi', 1),
(241, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Tetero', 'Intiganda', 1),
(242, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Tetero', 'Iwacu', 1),
(243, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Tetero', 'Tetero', 1),
(244, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Ubumwe', 'Bwahirimba', 1),
(245, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Ubumwe', 'Duterimbere', 1),
(246, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Ubumwe', 'Isangano', 1),
(247, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Ubumwe', 'Nyanza', 1),
(248, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Ubumwe', 'Urugwiro', 1),
(249, 'Umujyi wa Kigali', 'Nyarugenge', 'Muhima', 'Ubumwe', 'Urwego', 1),
(250, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Munanira I', 'Kabusunzu', 1),
(251, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Munanira I', 'Munanira', 1),
(252, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Munanira I', 'Ntaraga', 1),
(253, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Munanira I', 'Nyagasozi', 1),
(254, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Munanira I', 'Rurembo', 1),
(255, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Munanira Ii', 'Gasiza', 1),
(256, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Munanira Ii', 'Kamwiza', 1),
(257, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Munanira Ii', 'Kanyange', 1),
(258, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Munanira Ii', 'Karudandi', 1),
(259, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Munanira Ii', 'Kigabiro', 1),
(260, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Munanira Ii', 'Kokobe', 1),
(261, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Munanira Ii', 'Mucyuranyana', 1),
(262, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Munanira Ii', 'Nkundumurimbo', 1),
(263, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Nyakabanda I', 'Akinkware', 1),
(264, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Nyakabanda I', 'Gapfupfu', 1),
(265, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Nyakabanda I', 'Gasiza', 1),
(266, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Nyakabanda I', 'Kariyeri', 1),
(267, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Nyakabanda I', 'Kokobe', 1),
(268, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Nyakabanda I', 'Munini', 1),
(269, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Nyakabanda I', 'Nyakabanda', 1),
(270, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Nyakabanda I', 'Rwagitanga', 1),
(271, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Nyakabanda Ii', 'Ibuhoro', 1),
(272, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Nyakabanda Ii', 'Kabeza', 1),
(273, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Nyakabanda Ii', 'Kanyiranganji', 1),
(274, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Nyakabanda Ii', 'Karujongi', 1),
(275, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Nyakabanda Ii', 'Kigarama', 1),
(276, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyakabanda', 'Nyakabanda Ii', 'Kirwa', 1),
(277, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Cyivugiza', 'Amizero', 1),
(278, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Cyivugiza', 'Gabiro', 1),
(279, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Cyivugiza', 'Imanzi', 1),
(280, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Cyivugiza', 'Ingenzi', 1),
(281, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Cyivugiza', 'Intwari', 1),
(282, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Cyivugiza', 'Karisimbi', 1),
(283, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Cyivugiza', 'Mahoro', 1),
(284, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Cyivugiza', 'Mpano', 1),
(285, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Cyivugiza', 'Muhabura', 1),
(286, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Cyivugiza', 'Muhoza', 1),
(287, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Cyivugiza', 'Munini', 1),
(288, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Cyivugiza', 'Rugero', 1),
(289, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Cyivugiza', 'Shema', 1),
(290, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Gasharu', 'Kagunga', 1),
(291, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Gasharu', 'Karukoro', 1),
(292, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Gasharu', 'Rwintare', 1),
(293, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Mumena', 'Akanyana', 1),
(294, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Mumena', 'Akanyirazaninka', 1),
(295, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Mumena', 'Akarekare', 1),
(296, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Mumena', 'Akatabaro', 1),
(297, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Mumena', 'Irembo', 1),
(298, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Mumena', 'Itaba', 1),
(299, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Mumena', 'Kiberinka', 1),
(300, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Mumena', 'Mumena', 1),
(301, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Mumena', 'Rwampara', 1),
(302, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Rugarama', 'Gatare', 1),
(303, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Rugarama', 'Kiberinka', 1),
(304, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Rugarama', 'Munanira', 1),
(305, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Rugarama', 'Riba', 1),
(306, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Rugarama', 'Rubona', 1),
(307, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Rugarama', 'Rugarama', 1),
(308, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Rugarama', 'Runyinya', 1),
(309, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Rugarama', 'Rusisiro', 1),
(310, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyamirambo', 'Rugarama', 'Tetero', 1),
(311, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Agatare', 'Agatare', 1),
(312, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Agatare', 'Amajyambere', 1),
(313, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Agatare', 'Inyambo', 1),
(314, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Agatare', 'Meraneza', 1),
(315, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Agatare', 'Uburezi', 1),
(316, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Agatare', 'Umucyo', 1),
(317, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Agatare', 'Umurava', 1),
(318, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Biryogo', 'Biryogo', 1),
(319, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Biryogo', 'Gabiro', 1),
(320, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Biryogo', 'Isoko', 1),
(321, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Biryogo', 'Nyiranuma', 1),
(322, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Biryogo', 'Umurimo', 1),
(323, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Kiyovu', 'Amizero', 1),
(324, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Kiyovu', 'Cercle Sportif', 1),
(325, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Kiyovu', 'Ganza', 1),
(326, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Kiyovu', 'Imena', 1),
(327, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Kiyovu', 'Indangamirwa', 1),
(328, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Kiyovu', 'Ingenzi', 1),
(329, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Kiyovu', 'Inyarurembo', 1),
(330, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Kiyovu', 'Ishema', 1),
(331, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Kiyovu', 'Isibo', 1),
(332, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Kiyovu', 'Muhabura', 1),
(333, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Kiyovu', 'Rugunga', 1),
(334, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Kiyovu', 'Sugira', 1),
(335, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Rwampara', 'Amahoro', 1),
(336, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Rwampara', 'Gacaca', 1),
(337, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Rwampara', 'Intwari', 1),
(338, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Rwampara', 'Rwampara', 1),
(339, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Rwampara', 'Umucyo', 1),
(340, 'Umujyi wa Kigali', 'Nyarugenge', 'Nyarugenge', 'Rwampara', 'Umuganda', 1),
(341, 'Umujyi wa Kigali', 'Nyarugenge', 'Rwezamenyo', 'Kabuguru I', 'Muhoza', 1),
(342, 'Umujyi wa Kigali', 'Nyarugenge', 'Rwezamenyo', 'Kabuguru I', 'Muhuza', 1),
(343, 'Umujyi wa Kigali', 'Nyarugenge', 'Rwezamenyo', 'Kabuguru I', 'Mumararungu', 1),
(344, 'Umujyi wa Kigali', 'Nyarugenge', 'Rwezamenyo', 'Kabuguru I', 'Murambi', 1),
(345, 'Umujyi wa Kigali', 'Nyarugenge', 'Rwezamenyo', 'Kabuguru Ii', 'Buhoro', 1),
(346, 'Umujyi wa Kigali', 'Nyarugenge', 'Rwezamenyo', 'Kabuguru Ii', 'Gasabo', 1),
(347, 'Umujyi wa Kigali', 'Nyarugenge', 'Rwezamenyo', 'Kabuguru Ii', 'Mutara', 1),
(348, 'Umujyi wa Kigali', 'Nyarugenge', 'Rwezamenyo', 'Kabuguru Ii', 'Ubusabane', 1),
(349, 'Umujyi wa Kigali', 'Nyarugenge', 'Rwezamenyo', 'Rwezamenyo I', 'Abatarushwa', 1),
(350, 'Umujyi wa Kigali', 'Nyarugenge', 'Rwezamenyo', 'Rwezamenyo I', 'Indatwa', 1),
(351, 'Umujyi wa Kigali', 'Nyarugenge', 'Rwezamenyo', 'Rwezamenyo I', 'Inkerakubanza', 1),
(352, 'Umujyi wa Kigali', 'Nyarugenge', 'Rwezamenyo', 'Rwezamenyo I', 'Intwari', 1),
(353, 'Umujyi wa Kigali', 'Nyarugenge', 'Rwezamenyo', 'Rwezamenyo Ii', 'Amahoro', 1),
(354, 'Umujyi wa Kigali', 'Nyarugenge', 'Rwezamenyo', 'Rwezamenyo Ii', 'Umucyo', 1),
(355, 'Umujyi wa Kigali', 'Nyarugenge', 'Rwezamenyo', 'Rwezamenyo Ii', 'Urumuri', 1),
(356, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Kinyaga', 'Akakaza', 1),
(357, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Kinyaga', 'Kigarama', 1),
(358, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Kinyaga', 'Kingabo', 1),
(359, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Kinyaga', 'Muhozi', 1),
(360, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Kinyaga', 'Rubungo', 1),
(361, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Kinyaga', 'Ryakigogo', 1),
(362, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Kinyaga', 'Zindiro', 1),
(363, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Musave', 'Kagarama', 1),
(364, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Musave', 'Kayumba', 1),
(365, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Musave', 'Ramba', 1),
(366, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Musave', 'Rebero', 1),
(367, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Musave', 'Rugando', 1),
(368, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Mvuzo', 'Kigabiro', 1),
(369, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Mvuzo', 'Kiyoro', 1),
(370, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Mvuzo', 'Murarambo', 1),
(371, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Mvuzo', 'Nkona', 1),
(372, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Mvuzo', 'Nyakabingo', 1),
(373, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Mvuzo', 'Rukoma', 1),
(374, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Ngara', 'Birembo', 1),
(375, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Ngara', 'Gisasa', 1),
(376, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Ngara', 'Munini', 1),
(377, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Ngara', 'Ruhinga', 1),
(378, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Ngara', 'Uwaruraza', 1),
(379, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nkuzuzu', 'Akabenejuru', 1),
(380, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nkuzuzu', 'Akasedogo', 1),
(381, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nkuzuzu', 'Akimpama', 1),
(382, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nkuzuzu', 'Burima', 1),
(383, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nkuzuzu', 'Kityazo', 1),
(384, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyabikenke', 'Bushya', 1),
(385, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyabikenke', 'Gikumba', 1),
(386, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyabikenke', 'Kamutamu', 1),
(387, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyabikenke', 'Karama', 1),
(388, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyabikenke', 'Kayenzi', 1),
(389, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyabikenke', 'Kigara', 1),
(390, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyabikenke', 'Kiriza', 1),
(391, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyabikenke', 'Masizi', 1),
(392, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyabikenke', 'Mbogo', 1),
(393, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyabikenke', 'Nyampamo', 1),
(394, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyagasozi', 'Akanyiramugarura', 1),
(395, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyagasozi', 'Akigabiro', 1),
(396, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyagasozi', 'Gishaka', 1),
(397, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyagasozi', 'Kabuye', 1),
(398, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyagasozi', 'Mpabwa', 1),
(399, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyagasozi', 'Nyagasambu', 1),
(400, 'Umujyi wa Kigali', 'Gasabo', 'Bumbogo', 'Nyagasozi', 'Urutarishonga', 1),
(401, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Karuruma', 'Akamamana', 1),
(402, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Karuruma', 'Akimihigo', 1),
(403, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Karuruma', 'Bigega', 1),
(404, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Karuruma', 'Busasamana', 1),
(405, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Karuruma', 'Kingasire', 1),
(406, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Karuruma', 'Kumuyange', 1),
(407, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Karuruma', 'Muremera', 1),
(408, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Karuruma', 'Nyagasozi', 1),
(409, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Karuruma', 'Rugoro', 1),
(410, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Karuruma', 'Rwesero', 1),
(411, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Karuruma', 'Tetero', 1),
(412, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamabuye', 'Agakomeye', 1),
(413, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamabuye', 'Gashubi', 1),
(414, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamabuye', 'Gisiza', 1),
(415, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamabuye', 'Hanika', 1),
(416, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamabuye', 'Juru', 1),
(417, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamabuye', 'Kibaya', 1),
(418, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamabuye', 'Mpakabavu', 1),
(419, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamabuye', 'Musango', 1),
(420, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamabuye', 'Ndengo', 1),
(421, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamabuye', 'Nyakabande', 1),
(422, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamabuye', 'Nyakanunga', 1),
(423, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamabuye', 'Rubonobono', 1),
(424, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamabuye', 'Runyonza', 1),
(425, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamabuye', 'Rusoro', 1),
(426, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamabuye', 'Ruvumero', 1),
(427, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamabuye', 'Uwagatovu', 1),
(428, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamugari', 'Agataramo', 1),
(429, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamugari', 'Akamwunguzi', 1),
(430, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamugari', 'Akarubimbura', 1),
(431, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamugari', 'Akisoko', 1),
(432, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamugari', 'Amarembo', 1),
(433, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamugari', 'Amizero', 1),
(434, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamugari', 'Bwiza', 1),
(435, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamugari', 'Ihuriro', 1),
(436, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamugari', 'Isangano', 1),
(437, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamugari', 'Kanyonyomba', 1),
(438, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamugari', 'Nyakariba', 1),
(439, 'Umujyi wa Kigali', 'Gasabo', 'Gatsata', 'Nyamugari', 'Rwakarihejuru', 1),
(440, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Gasagara', 'Bwimiyange', 1),
(441, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Gasagara', 'Bwingeyo', 1),
(442, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Gasagara', 'Gasagara', 1),
(443, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Gasagara', 'Rugwiza', 1),
(444, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Gicaca', 'Ntaganzwa', 1),
(445, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Gicaca', 'Nyagasozi', 1),
(446, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Gicaca', 'Nyagisozi', 1),
(447, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Gicaca', 'Ruganda', 1),
(448, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Kibara', 'Gahinga', 1),
(449, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Kibara', 'Gasharu', 1),
(450, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Kibara', 'Kibobo', 1),
(451, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Kibara', 'Nombe', 1),
(452, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Munini', 'Munini', 1),
(453, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Munini', 'Mutokerezwa', 1),
(454, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Munini', 'Rudakabukirwa', 1),
(455, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Munini', 'Runyinya', 1),
(456, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Murambi', 'Kimisebeya', 1),
(457, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Murambi', 'Kivugiza', 1),
(458, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Murambi', 'Rugarama', 1),
(459, 'Umujyi wa Kigali', 'Gasabo', 'Gikomero', 'Murambi', 'Twina', 1),
(460, 'Umujyi wa Kigali', 'Gasabo', 'Gisozi', 'Musezero', 'Amajyambere', 1),
(461, 'Umujyi wa Kigali', 'Gasabo', 'Gisozi', 'Musezero', 'Amarembo', 1),
(462, 'Umujyi wa Kigali', 'Gasabo', 'Gisozi', 'Musezero', 'Byimana', 1),
(463, 'Umujyi wa Kigali', 'Gasabo', 'Gisozi', 'Musezero', 'Gasave', 1),
(464, 'Umujyi wa Kigali', 'Gasabo', 'Gisozi', 'Musezero', 'Gasharu', 1),
(465, 'Umujyi wa Kigali', 'Gasabo', 'Gisozi', 'Musezero', 'Kagara', 1),
(466, 'Umujyi wa Kigali', 'Gasabo', 'Gisozi', 'Musezero', 'Nyakariba', 1),
(467, 'Umujyi wa Kigali', 'Gasabo', 'Gisozi', 'Musezero', 'Rwinyana', 1),
(468, 'Umujyi wa Kigali', 'Gasabo', 'Gisozi', 'Ruhango', 'Kanyinya', 1),
(469, 'Umujyi wa Kigali', 'Gasabo', 'Gisozi', 'Ruhango', 'Kumukenke', 1),
(470, 'Umujyi wa Kigali', 'Gasabo', 'Gisozi', 'Ruhango', 'Murambi', 1),
(471, 'Umujyi wa Kigali', 'Gasabo', 'Gisozi', 'Ruhango', 'Ntora', 1),
(472, 'Umujyi wa Kigali', 'Gasabo', 'Gisozi', 'Ruhango', 'Rukeri', 1),
(473, 'Umujyi wa Kigali', 'Gasabo', 'Gisozi', 'Ruhango', 'Umurava', 1),
(474, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Akamatamu', 'Akamatamu', 1),
(475, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Akamatamu', 'Cyeyere', 1),
(476, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Akamatamu', 'Murehe', 1),
(477, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Akamatamu', 'Nyacyonga', 1),
(478, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Akamatamu', 'Nyagasozi', 1),
(479, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Akamatamu', 'Nyarukurazo', 1),
(480, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Bweramvura', 'Agakenke', 1),
(481, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Bweramvura', 'Agatare', 1),
(482, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Bweramvura', 'Akinyana', 1),
(483, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Bweramvura', 'Gikingo', 1),
(484, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Bweramvura', 'Gitega', 1),
(485, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Bweramvura', 'Gitenga', 1),
(486, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Bweramvura', 'Nyakabingo', 1),
(487, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Bweramvura', 'Nyarurama', 1),
(488, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Bweramvura', 'Rugogwe', 1),
(489, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Bweramvura', 'Taba', 1),
(490, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Kabuye', 'Amakawa', 1),
(491, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Kabuye', 'Amasangano', 1),
(492, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Kabuye', 'Buliza', 1),
(493, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Kabuye', 'Ihuriro', 1),
(494, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Kabuye', 'Kabeza', 1),
(495, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Kabuye', 'Karuruma', 1),
(496, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Kabuye', 'Murama', 1),
(497, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Kabuye', 'Nyagasozi', 1),
(498, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Kabuye', 'Rebero', 1),
(499, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Kabuye', 'Rugarama', 1),
(500, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Kabuye', 'Tetero', 1),
(501, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Kidashya', 'Agasekabuye', 1),
(502, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Kidashya', 'Agatare', 1),
(503, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Kidashya', 'Amasangano', 1),
(504, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Kidashya', 'Mubuga', 1),
(505, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Kidashya', 'Nyamweru', 1),
(506, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Ngiryi', 'Agahama', 1),
(507, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Ngiryi', 'Agasharu', 1),
(508, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Ngiryi', 'Akabuga', 1),
(509, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Ngiryi', 'Jurwe', 1),
(510, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Ngiryi', 'Kiberinka', 1),
(511, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Ngiryi', 'Nyakirehe', 1),
(512, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Ngiryi', 'Nyarubuye', 1),
(513, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Ngiryi', 'Rubona', 1),
(514, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Ngiryi', 'Rwanyanza', 1),
(515, 'Umujyi wa Kigali', 'Gasabo', 'Jabana', 'Ngiryi', 'Uwanyange', 1),
(516, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Agateko', 'Bugarama', 1),
(517, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Agateko', 'Bukamba', 1),
(518, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Agateko', 'Byimana', 1),
(519, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Agateko', 'Kabizoza', 1),
(520, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Agateko', 'Kinunga', 1),
(521, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Agateko', 'Runyinya', 1),
(522, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Agateko', 'Rwankuba', 1),
(523, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Buhiza', 'Akabande', 1),
(524, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Buhiza', 'Gatare', 1),
(525, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Buhiza', 'Nyamugali', 1),
(526, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Buhiza', 'Nyarubuye', 1),
(527, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Muko', 'Gahinga', 1),
(528, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Muko', 'Gatare', 1),
(529, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Muko', 'Umunyinya', 1),
(530, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nkusi', 'Agatwa', 1),
(531, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nkusi', 'Kabagina', 1),
(532, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nkusi', 'Kajevuba', 1),
(533, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nkusi', 'Kigarama', 1),
(534, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nkusi', 'Nyagasayo', 1),
(535, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nyabuliba', 'Byimana', 1),
(536, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nyabuliba', 'Kirehe', 1),
(537, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nyabuliba', 'Mataba', 1),
(538, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nyabuliba', 'Nyarurembo', 1),
(539, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nyabuliba', 'Rubona', 1),
(540, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nyakabungo', 'Bwocya', 1),
(541, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nyakabungo', 'Gitaba', 1),
(542, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nyakabungo', 'Karenge', 1),
(543, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nyakabungo', 'Rugina', 1),
(544, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nyakabungo', 'Ruhihi', 1),
(545, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nyamitanga', 'Agasharu', 1),
(546, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nyamitanga', 'Agatare', 1),
(547, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nyamitanga', 'Kabuga', 1),
(548, 'Umujyi wa Kigali', 'Gasabo', 'Jali', 'Nyamitanga', 'Urunyinya', 1),
(549, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamatamu', 'Amajyambere', 1),
(550, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamatamu', 'Bukinanyana', 1),
(551, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamatamu', 'Cyimana', 1),
(552, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamatamu', 'Gataba', 1),
(553, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamatamu', 'Itetero', 1),
(554, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamatamu', 'Kabare', 1),
(555, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamatamu', 'Kamuhire', 1),
(556, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamatamu', 'Karukamba', 1),
(557, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamatamu', 'Nyagacyamo', 1),
(558, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamatamu', 'Rwinzovu', 1),
(559, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamatamu', 'Urugwiro', 1),
(560, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamatamu', 'Uruhongore', 1),
(561, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamutwa', 'Agasaro', 1),
(562, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamutwa', 'Gasharu', 1),
(563, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamutwa', 'Inkingi', 1),
(564, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamutwa', 'Kanserege', 1),
(565, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamutwa', 'Kigugu', 1),
(566, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamutwa', 'Ruganwa', 1),
(567, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamutwa', 'Umuco', 1),
(568, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamutwa', 'Umutekano', 1),
(569, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamutwa', 'Urugero', 1),
(570, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kamutwa', 'Urwibutso', 1),
(571, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kibaza', 'Amahoro', 1),
(572, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kibaza', 'Bwiza', 1),
(573, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kibaza', 'Ihuriro', 1),
(574, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kibaza', 'Ineza', 1),
(575, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kibaza', 'Inyange', 1),
(576, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kibaza', 'Iriba', 1),
(577, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kibaza', 'Kabagari', 1),
(578, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kibaza', 'Ubumwe', 1),
(579, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kibaza', 'Umutako', 1),
(580, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kibaza', 'Urukundo', 1),
(581, 'Umujyi wa Kigali', 'Gasabo', 'Kacyiru', 'Kibaza', 'Virunga', 1),
(582, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kamukina', 'Inyamibwa', 1),
(583, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kamukina', 'Isangano', 1),
(584, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kamukina', 'Isano', 1),
(585, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kamukina', 'Ituze', 1),
(586, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kamukina', 'Izuba', 1),
(587, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kamukina', 'Juru', 1),
(588, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kamukina', 'Nyenyeri', 1),
(589, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kamukina', 'Umurava', 1),
(590, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kamukina', 'Urumuri', 1),
(591, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kimihurura', 'Amahoro', 1),
(592, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kimihurura', 'Amajyambere', 1),
(593, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kimihurura', 'Imihigo', 1),
(594, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kimihurura', 'Intambwe', 1),
(595, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kimihurura', 'Mutara', 1),
(596, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kimihurura', 'Rugarama', 1),
(597, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kimihurura', 'Ubumwe', 1),
(598, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kimihurura', 'Umutekano', 1),
(599, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Kimihurura', 'Urwego', 1),
(600, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Rugando', 'Gasange', 1),
(601, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Rugando', 'Gasasa', 1),
(602, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Rugando', 'Marembo', 1),
(603, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Rugando', 'Rebero', 1),
(604, 'Umujyi wa Kigali', 'Gasabo', 'Kimihurura', 'Rugando', 'Taba', 1),
(605, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Bibare', 'Abatuje', 1),
(606, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Bibare', 'Amariza', 1),
(607, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Bibare', 'Imanzi', 1),
(608, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Bibare', 'Imena', 1),
(609, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Bibare', 'Imitari', 1),
(610, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Bibare', 'Inganji', 1),
(611, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Bibare', 'Ingenzi', 1),
(612, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Bibare', 'Ingeri', 1),
(613, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Bibare', 'Inshuti', 1),
(614, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Bibare', 'Intashyo', 1),
(615, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Bibare', 'Intwari', 1),
(616, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Bibare', 'Inyamibwa', 1),
(617, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Bibare', 'Inyange', 1),
(618, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Bibare', 'Ubwiza', 1),
(619, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Bibare', 'Umwezi', 1),
(620, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Kibagabaga', 'Akintwari', 1),
(621, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Kibagabaga', 'Buranga', 1),
(622, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Kibagabaga', 'Gasharu', 1),
(623, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Kibagabaga', 'Ibuhoro', 1),
(624, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Kibagabaga', 'Kageyo', 1),
(625, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Kibagabaga', 'Kamahinda', 1),
(626, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Kibagabaga', 'Karisimbi', 1),
(627, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Kibagabaga', 'Karongi', 1),
(628, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Kibagabaga', 'Nyirabwana', 1),
(629, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Kibagabaga', 'Ramiro', 1),
(630, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Kibagabaga', 'Rindiro', 1),
(631, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Kibagabaga', 'Rugero', 1),
(632, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Kibagabaga', 'Rukurazo', 1),
(633, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Kibagabaga', 'Rumuri', 1),
(634, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Nyagatovu', 'Bukinanyana', 1),
(635, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Nyagatovu', 'Ibuhoro', 1),
(636, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Nyagatovu', 'Ijabiro', 1),
(637, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Nyagatovu', 'Isangano', 1),
(638, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Nyagatovu', 'Itetero', 1),
(639, 'Umujyi wa Kigali', 'Gasabo', 'Kimironko', 'Nyagatovu', 'Urugwiro', 1),
(640, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Gacuriro', 'Agatare', 1),
(641, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Gacuriro', 'Akanyamugabo', 1),
(642, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Gacuriro', 'Akarambo', 1),
(643, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Gacuriro', 'Akaruvusha', 1),
(644, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Gacuriro', 'Bishikiri', 1),
(645, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Gacuriro', 'Cyeru', 1),
(646, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Gacuriro', 'Gacuriro 2020', 1),
(647, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Gacuriro', 'Kabuhunde Ii', 1),
(648, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Gacuriro', 'Kirira', 1),
(649, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Gacuriro', 'Urubanda', 1),
(650, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Gacuriro', 'Urugarama', 1),
(651, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Gasharu', 'Agatare', 1),
(652, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Gasharu', 'Gasharu', 1),
(653, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Gasharu', 'Kami', 1),
(654, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Gasharu', 'Rwankuba', 1),
(655, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Kagugu', 'Dusenyi', 1),
(656, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Kagugu', 'Gicikiza', 1),
(657, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Kagugu', 'Giheka', 1),
(658, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Kagugu', 'Kabuhunde I', 1),
(659, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Kagugu', 'Kadobogo', 1),
(660, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Kagugu', 'Kagarama', 1),
(661, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Kagugu', 'Muhororo', 1),
(662, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Kagugu', 'Nyakabungo', 1),
(663, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Kagugu', 'Rukingu', 1),
(664, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Murama', 'Binunga', 1);
INSERT INTO `locations` (`loc_id`, `loc_province`, `loc_district`, `loc_sector`, `loc_cell`, `loc_village`, `loc_status`) VALUES
(665, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Murama', 'Ngaruyinka', 1),
(666, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Murama', 'Rusenyi', 1),
(667, 'Umujyi wa Kigali', 'Gasabo', 'Kinyinya', 'Murama', 'Taba', 1),
(668, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Bwiza', 'Akarwasa', 1),
(669, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Bwiza', 'Akasemuromba', 1),
(670, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Bwiza', 'Bucyemba', 1),
(671, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Bwiza', 'Gasharu', 1),
(672, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Bwiza', 'Kagarama', 1),
(673, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Bwiza', 'Ruhangare', 1),
(674, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Cyaruzinge', 'Ayabakora', 1),
(675, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Cyaruzinge', 'Cyaruzinge', 1),
(676, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Cyaruzinge', 'Gashure', 1),
(677, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Cyaruzinge', 'Gatare', 1),
(678, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Cyaruzinge', 'Gisura', 1),
(679, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Cyaruzinge', 'Karubibi', 1),
(680, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Cyaruzinge', 'Murindi', 1),
(681, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Kibenga', 'Bahoze', 1),
(682, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Kibenga', 'Berwa', 1),
(683, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Kibenga', 'Buhoro', 1),
(684, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Kibenga', 'Burunga', 1),
(685, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Kibenga', 'Gitaraga', 1),
(686, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Kibenga', 'Kira', 1),
(687, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Kibenga', 'Nezerwa', 1),
(688, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Kibenga', 'Rugazi', 1),
(689, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Kibenga', 'Runyonza', 1),
(690, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Kibenga', 'Tumurere', 1),
(691, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Kibenga', 'Ururembo', 1),
(692, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Masoro', 'Byimana', 1),
(693, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Masoro', 'Kabeza', 1),
(694, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Masoro', 'Masoro', 1),
(695, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Masoro', 'Matwari', 1),
(696, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Masoro', 'Mubuga', 1),
(697, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Masoro', 'Munini', 1),
(698, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Mukuyu', 'Akamusare', 1),
(699, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Mukuyu', 'Akimana', 1),
(700, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Mukuyu', 'Gasharu', 1),
(701, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Mukuyu', 'Jurwe', 1),
(702, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Mukuyu', 'Karambo', 1),
(703, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Mukuyu', 'Kigabiro', 1),
(704, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Mukuyu', 'Ruseno', 1),
(705, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Rudashya', 'Kacyinyaga', 1),
(706, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Rudashya', 'Kamahoro', 1),
(707, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Rudashya', 'Munini', 1),
(708, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Rudashya', 'Nyakagezi', 1),
(709, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Rudashya', 'Ruhangare', 1),
(710, 'Umujyi wa Kigali', 'Gasabo', 'Ndera', 'Rudashya', 'Ruhogo', 1),
(711, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Butare', 'Kanani', 1),
(712, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Butare', 'Kidahe', 1),
(713, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Butare', 'Kigabiro', 1),
(714, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Butare', 'Nyamurambi', 1),
(715, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Butare', 'Nyarubuye', 1),
(716, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Butare', 'Nyura', 1),
(717, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gasanze', 'Gatagara', 1),
(718, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gasanze', 'Kagarama', 1),
(719, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gasanze', 'Nyabitare', 1),
(720, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gasanze', 'Nyakabungo', 1),
(721, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gasanze', 'Nyarubande', 1),
(722, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gasanze', 'Uruhetse', 1),
(723, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gasura', 'Agacyamo', 1),
(724, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gasura', 'Gashinya', 1),
(725, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gasura', 'Gikombe', 1),
(726, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gasura', 'Kazi', 1),
(727, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gasura', 'Kigufi', 1),
(728, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gasura', 'Nyirakibehe', 1),
(729, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gasura', 'Uruhahiro', 1),
(730, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gatunga', 'Agasharu', 1),
(731, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gatunga', 'Amataba', 1),
(732, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gatunga', 'Burungero', 1),
(733, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gatunga', 'Karama', 1),
(734, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gatunga', 'Nyange', 1),
(735, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gatunga', 'Rebero', 1),
(736, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Gatunga', 'Uruyange', 1),
(737, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Muremure', 'Gatobotobo', 1),
(738, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Muremure', 'Kibungo', 1),
(739, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Muremure', 'Musezero', 1),
(740, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Muremure', 'Nyaburoro', 1),
(741, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Muremure', 'Taba', 1),
(742, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Sha', 'Bikumba', 1),
(743, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Sha', 'Gakizi', 1),
(744, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Sha', 'Gatare', 1),
(745, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Sha', 'Kamuyange', 1),
(746, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Sha', 'Kigarama', 1),
(747, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Sha', 'Ngara', 1),
(748, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Shango', 'Akazi', 1),
(749, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Shango', 'Kaduha', 1),
(750, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Shango', 'Kamuhoza', 1),
(751, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Shango', 'Mirambi', 1),
(752, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Shango', 'Munini', 1),
(753, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Shango', 'Ndanyoye', 1),
(754, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Shango', 'Nyamigina', 1),
(755, 'Umujyi wa Kigali', 'Gasabo', 'Nduba', 'Shango', 'Rugarama', 1),
(756, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Nyabisindu', 'Amarembo I', 1),
(757, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Nyabisindu', 'Amarembo Il', 1),
(758, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Nyabisindu', 'Gihogere', 1),
(759, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Nyabisindu', 'Kagara', 1),
(760, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Nyabisindu', 'Kinunga', 1),
(761, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Nyabisindu', 'Nyabisindu', 1),
(762, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Nyabisindu', 'Rugarama', 1),
(763, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Nyarutarama', 'Gishushu', 1),
(764, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Nyarutarama', 'Juru', 1),
(765, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Nyarutarama', 'Kamahwa', 1),
(766, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Nyarutarama', 'Kangondo I', 1),
(767, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Nyarutarama', 'Kangondo Ii', 1),
(768, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Nyarutarama', 'Kibiraro I', 1),
(769, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Nyarutarama', 'Kibiraro Ii', 1),
(770, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Rukiri I', 'Agashyitsi', 1),
(771, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Rukiri I', 'Amajyambere', 1),
(772, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Rukiri I', 'Izuba', 1),
(773, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Rukiri I', 'Kisimenti', 1),
(774, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Rukiri I', 'Ubumwe', 1),
(775, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Rukiri I', 'Ukwezi', 1),
(776, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Rukiri I', 'Urumuri', 1),
(777, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Rukiri Ii', 'Amahoro', 1),
(778, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Rukiri Ii', 'Rebero', 1),
(779, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Rukiri Ii', 'Ruturusu I', 1),
(780, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Rukiri Ii', 'Ruturusu Ii', 1),
(781, 'Umujyi wa Kigali', 'Gasabo', 'Remera', 'Rukiri Ii', 'Ubumwe', 1),
(782, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Bisenga', 'Bisenga', 1),
(783, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Bisenga', 'Gakenyeri', 1),
(784, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Bisenga', 'Gasiza', 1),
(785, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Bisenga', 'Kidogo', 1),
(786, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Gasagara', 'Agatare', 1),
(787, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Gasagara', 'Gasagara', 1),
(788, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Gasagara', 'Kamasasa', 1),
(789, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Gasagara', 'Rugagi', 1),
(790, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Gasagara', 'Ryabazana', 1),
(791, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kabuga I', 'Abatangampundu', 1),
(792, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kabuga I', 'Amahoro', 1),
(793, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kabuga I', 'Isangano', 1),
(794, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kabuga I', 'Kabeza', 1),
(795, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kabuga I', 'Kalisimbi', 1),
(796, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kabuga I', 'Masango', 1),
(797, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kabuga Ii', 'Bwiza', 1),
(798, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kabuga Ii', 'Cyanamo', 1),
(799, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kabuga Ii', 'Gatare', 1),
(800, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kabuga Ii', 'Kamashashi', 1),
(801, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kabuga Ii', 'Mataba', 1),
(802, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kabuga Ii', 'Nyagakombe', 1),
(803, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kabuga Ii', 'Ruhangare', 1),
(804, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kinyana', 'Busenyi', 1),
(805, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kinyana', 'Kigabiro', 1),
(806, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kinyana', 'Kinyana', 1),
(807, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Kinyana', 'Nyagisozi', 1),
(808, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Mbandazi', 'Cyeru', 1),
(809, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Mbandazi', 'Karambo', 1),
(810, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Mbandazi', 'Kataruha', 1),
(811, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Mbandazi', 'Mugeyo', 1),
(812, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Mbandazi', 'Rugarama', 1),
(813, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Mbandazi', 'Samuduha', 1),
(814, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Nyagahinga', 'Gisharara', 1),
(815, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Nyagahinga', 'Kabutare', 1),
(816, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Nyagahinga', 'Kanyinya', 1),
(817, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Nyagahinga', 'Kigarama', 1),
(818, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Nyagahinga', 'Nyarucundura', 1),
(819, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Nyagahinga', 'Runyonza', 1),
(820, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Nyagahinga', 'Urumuri', 1),
(821, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Ruhanga', 'Kinyaga', 1),
(822, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Ruhanga', 'Mirama', 1),
(823, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Ruhanga', 'Nyagacyamo', 1),
(824, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Ruhanga', 'Rugende', 1),
(825, 'Umujyi wa Kigali', 'Gasabo', 'Rusororo', 'Ruhanga', 'Ruhanga', 1),
(826, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Gasabo', 'Gasharu', 1),
(827, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Gasabo', 'Mulindi', 1),
(828, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Gasabo', 'Vugavuge', 1),
(829, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Indatemwa', 'Kabarera', 1),
(830, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Indatemwa', 'Kamusengo', 1),
(831, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Indatemwa', 'Karekare', 1),
(832, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Indatemwa', 'Karuranga', 1),
(833, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Indatemwa', 'Nyakabande', 1),
(834, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Kabaliza', 'Kabaliza', 1),
(835, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Kabaliza', 'Nyamise', 1),
(836, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Kabaliza', 'Rwanyanza', 1),
(837, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Kacyatwa', 'Cyili', 1),
(838, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Kacyatwa', 'Kacyatwa', 1),
(839, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Kacyatwa', 'Kandamira', 1),
(840, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Kacyatwa', 'Kantabana', 1),
(841, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Kacyatwa', 'Munini', 1),
(842, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Kibenga', 'Abanyangeyo', 1),
(843, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Kibenga', 'Kibenga', 1),
(844, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Kibenga', 'Nyamvumvu', 1),
(845, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Kigabiro', 'Kamusare', 1),
(846, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Kigabiro', 'Karwiru', 1),
(847, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Kigabiro', 'Kigabiro', 1),
(848, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Kigabiro', 'Rukerereza', 1),
(849, 'Umujyi wa Kigali', 'Gasabo', 'Rutunga', 'Kigabiro', 'Rwintare', 1),
(850, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Gahanga', 'Gahanga', 1),
(851, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Gahanga', 'Gatare', 1),
(852, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Gahanga', 'Gatovu', 1),
(853, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Gahanga', 'Rinini', 1),
(854, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Gahanga', 'Rwinanka', 1),
(855, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Gahanga', 'Ubumwe', 1),
(856, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Kagasa', 'Kabeza', 1),
(857, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Kagasa', 'Kabidandi', 1),
(858, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Kagasa', 'Kiyanja', 1),
(859, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Kagasa', 'Nyacyonga', 1),
(860, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Kagasa', 'Nyagafunzo', 1),
(861, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Kagasa', 'Nyakuguma', 1),
(862, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Kagasa', 'Rugando Ii', 1),
(863, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Karembure', 'Amahoro', 1),
(864, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Karembure', 'Bigo', 1),
(865, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Karembure', 'Kabeza', 1),
(866, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Karembure', 'Kamuyinga', 1),
(867, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Karembure', 'Karembure', 1),
(868, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Karembure', 'Kimena', 1),
(869, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Karembure', 'Mubuga', 1),
(870, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Karembure', 'Rwamaya', 1),
(871, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Murinja', 'Kampuro', 1),
(872, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Murinja', 'Kigasa', 1),
(873, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Murinja', 'Mashyiga', 1),
(874, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Murinja', 'Nyabigugu', 1),
(875, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Murinja', 'Nyamuharaza', 1),
(876, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Murinja', 'Rukore', 1),
(877, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Murinja', 'Runyoni', 1),
(878, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Murinja', 'Sabununga', 1),
(879, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Nunga', 'Kigarama', 1),
(880, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Nunga', 'Kinyana', 1),
(881, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Nunga', 'Mugendo', 1),
(882, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Nunga', 'Nunga I', 1),
(883, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Nunga', 'Nunga Ii', 1),
(884, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Nunga', 'Rugasa', 1),
(885, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Rwabutenge', 'Gahosha', 1),
(886, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Rwabutenge', 'Gashubi', 1),
(887, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Rwabutenge', 'Kaboshya', 1),
(888, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Rwabutenge', 'Karambo', 1),
(889, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Rwabutenge', 'Rebero', 1),
(890, 'Umujyi wa Kigali', 'Kicukiro', 'Gahanga', 'Rwabutenge', 'Rugando I', 1),
(891, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Gatenga', 'Amahoro', 1),
(892, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Gatenga', 'Gakoki', 1),
(893, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Gatenga', 'Gatenga', 1),
(894, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Gatenga', 'Ihuriro', 1),
(895, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Gatenga', 'Isangano', 1),
(896, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Gatenga', 'Rugari', 1),
(897, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Karambo', 'Gwiza', 1),
(898, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Karambo', 'Ihuriro', 1),
(899, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Karambo', 'Jyambere', 1),
(900, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Karambo', 'Kamabuye', 1),
(901, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Karambo', 'Mahoro', 1),
(902, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Karambo', 'Ramiro', 1),
(903, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Karambo', 'Rebero', 1),
(904, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Karambo', 'Rugwiro', 1),
(905, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Karambo', 'Ruhuka', 1),
(906, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Karambo', 'Sangwa', 1),
(907, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyanza', 'Bwiza', 1),
(908, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyanza', 'Cyeza', 1),
(909, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyanza', 'Gasabo', 1),
(910, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyanza', 'Ihuriro', 1),
(911, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyanza', 'Isonga', 1),
(912, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyanza', 'Juru', 1),
(913, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyanza', 'Marembo', 1),
(914, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyanza', 'Murambi', 1),
(915, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyanza', 'Nyanza', 1),
(916, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyanza', 'Rebero', 1),
(917, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyanza', 'Rusororo', 1),
(918, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyanza', 'Sabaganga', 1),
(919, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyanza', 'Taba', 1),
(920, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyarurama', 'Bigo', 1),
(921, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyarurama', 'Bisambu', 1),
(922, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyarurama', 'Kabeza', 1),
(923, 'Umujyi wa Kigali', 'Kicukiro', 'Gatenga', 'Nyarurama', 'Nyabikenke', 1),
(924, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kagunga', 'Gatare', 1),
(925, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kagunga', 'Kabuye I', 1),
(926, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kagunga', 'Kabuye Ii', 1),
(927, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kagunga', 'Kagunga I', 1),
(928, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kagunga', 'Kagunga Ii', 1),
(929, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kagunga', 'Rebero', 1),
(930, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kanserege', 'Kanserege I', 1),
(931, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kanserege', 'Kanserege Ii', 1),
(932, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kanserege', 'Kanserege Iii', 1),
(933, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kanserege', 'Marembo I', 1),
(934, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kanserege', 'Marembo Ii', 1),
(935, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kanserege', 'Marembo Iii', 1),
(936, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kinunga', 'Kigugu I', 1),
(937, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kinunga', 'Kigugu Ii', 1),
(938, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kinunga', 'Kigugu Iii', 1),
(939, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kinunga', 'Kinunga', 1),
(940, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kinunga', 'Ruganwa I', 1),
(941, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kinunga', 'Ruganwa Ii', 1),
(942, 'Umujyi wa Kigali', 'Kicukiro', 'Gikondo', 'Kinunga', 'Ruganwa Iii', 1),
(943, 'Umujyi wa Kigali', 'Kicukiro', 'Kagarama', 'Kanserege', 'Bwiza', 1),
(944, 'Umujyi wa Kigali', 'Kicukiro', 'Kagarama', 'Kanserege', 'Byimana', 1),
(945, 'Umujyi wa Kigali', 'Kicukiro', 'Kagarama', 'Kanserege', 'Ituze', 1),
(946, 'Umujyi wa Kigali', 'Kicukiro', 'Kagarama', 'Kanserege', 'Kanserege', 1),
(947, 'Umujyi wa Kigali', 'Kicukiro', 'Kagarama', 'Kanserege', 'Kinunga', 1),
(948, 'Umujyi wa Kigali', 'Kicukiro', 'Kagarama', 'Muyange', 'Kamuna', 1),
(949, 'Umujyi wa Kigali', 'Kicukiro', 'Kagarama', 'Muyange', 'Mugeyo', 1),
(950, 'Umujyi wa Kigali', 'Kicukiro', 'Kagarama', 'Muyange', 'Muyange', 1),
(951, 'Umujyi wa Kigali', 'Kicukiro', 'Kagarama', 'Muyange', 'Rugunga', 1),
(952, 'Umujyi wa Kigali', 'Kicukiro', 'Kagarama', 'Rukatsa', 'Inshuti', 1),
(953, 'Umujyi wa Kigali', 'Kicukiro', 'Kagarama', 'Rukatsa', 'Mpingayanyanza', 1),
(954, 'Umujyi wa Kigali', 'Kicukiro', 'Kagarama', 'Rukatsa', 'Nyacyonga', 1),
(955, 'Umujyi wa Kigali', 'Kicukiro', 'Kagarama', 'Rukatsa', 'Nyanza', 1),
(956, 'Umujyi wa Kigali', 'Kicukiro', 'Kagarama', 'Rukatsa', 'Rukatsa', 1),
(957, 'Umujyi wa Kigali', 'Kicukiro', 'Kagarama', 'Rukatsa', 'Taba', 1),
(958, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Busanza', 'Amahoro', 1),
(959, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Busanza', 'Antene', 1),
(960, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Busanza', 'Bamporeze I', 1),
(961, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Busanza', 'Bamporeze Ii', 1),
(962, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Busanza', 'Gashyushya', 1),
(963, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Busanza', 'Gishikiri', 1),
(964, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Busanza', 'Hope', 1),
(965, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Busanza', 'Kariyeri', 1),
(966, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Busanza', 'Nyarugugu', 1),
(967, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Busanza', 'Radari', 1),
(968, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Busanza', 'Rukore', 1),
(969, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Kabeza', 'Akagera', 1),
(970, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Kabeza', 'Bwiza', 1),
(971, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Kabeza', 'Gasabo', 1),
(972, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Kabeza', 'Giporoso I', 1),
(973, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Kabeza', 'Giporoso Ii', 1),
(974, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Kabeza', 'Juru', 1),
(975, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Kabeza', 'Kabeza', 1),
(976, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Kabeza', 'Karisimbi', 1),
(977, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Kabeza', 'Muhabura', 1),
(978, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Kabeza', 'Mulindi', 1),
(979, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Kabeza', 'Nyarurembo', 1),
(980, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Kabeza', 'Nyenyeri', 1),
(981, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Kabeza', 'Rebero', 1),
(982, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Karama', 'Bitare', 1),
(983, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Karama', 'Byimana', 1),
(984, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Karama', 'Cyurusagara', 1),
(985, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Karama', 'Gakorokombe', 1),
(986, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Karama', 'Gikundiro', 1),
(987, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Karama', 'Gitarama', 1),
(988, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Karama', 'Karama', 1),
(989, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Karama', 'Nyabyunyu', 1),
(990, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Karama', 'Nyarutovu', 1),
(991, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Karama', 'Urukundo', 1),
(992, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Rubirizi', 'Beninka', 1),
(993, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Rubirizi', 'Bukunzi', 1),
(994, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Rubirizi', 'Cyeru', 1),
(995, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Rubirizi', 'Intwari', 1),
(996, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Rubirizi', 'Itunda', 1),
(997, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Rubirizi', 'Kavumu', 1),
(998, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Rubirizi', 'Susuruka', 1),
(999, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Rubirizi', 'Ubumwe', 1),
(1000, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Rubirizi', 'Umunara', 1),
(1001, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Rubirizi', 'Uwabarezi', 1),
(1002, 'Umujyi wa Kigali', 'Kicukiro', 'Kanombe', 'Rubirizi', 'Zirakamwa', 1),
(1003, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Gasharu', 'Amajyambere', 1),
(1004, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Gasharu', 'Gasharu', 1),
(1005, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Gasharu', 'Sakirwa', 1),
(1006, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Gasharu', 'Umunyinya', 1),
(1007, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Kagina', 'Gashiha', 1),
(1008, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Kagina', 'Iriba', 1),
(1009, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Kagina', 'Multimedia', 1),
(1010, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Kagina', 'Umunyinya', 1),
(1011, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Kagina', 'Umuremure', 1),
(1012, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Kagina', 'Urugero', 1),
(1013, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Kicukiro', 'Gasave', 1),
(1014, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Kicukiro', 'Isoko', 1),
(1015, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Kicukiro', 'Karisimbi', 1),
(1016, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Kicukiro', 'Kicukiro', 1),
(1017, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Kicukiro', 'Triangle', 1),
(1018, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Kicukiro', 'Ubumwe', 1),
(1019, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Ngoma', 'Ahitegeye', 1),
(1020, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Ngoma', 'Intaho', 1),
(1021, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Ngoma', 'Iriba', 1),
(1022, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Ngoma', 'Isangano', 1),
(1023, 'Umujyi wa Kigali', 'Kicukiro', 'Kicukiro', 'Ngoma', 'Urugero', 1),
(1024, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Bwerankori', 'Gakokobe', 1),
(1025, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Bwerankori', 'Gatare', 1),
(1026, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Bwerankori', 'Imena', 1),
(1027, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Bwerankori', 'Ituze', 1),
(1028, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Bwerankori', 'Kabutare', 1),
(1029, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Bwerankori', 'Kimisange', 1),
(1030, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Bwerankori', 'Nyenyeri', 1),
(1031, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Bwerankori', 'Ubumenyi', 1),
(1032, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Karugira', 'Ibuga', 1),
(1033, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Karugira', 'Ihuriro', 1),
(1034, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Karugira', 'Murambi', 1),
(1035, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Karugira', 'Rutoki', 1),
(1036, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Karugira', 'Taba', 1),
(1037, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Karugira', 'Terimbere', 1),
(1038, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Karugira', 'Ubutare', 1),
(1039, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Karugira', 'Umurimo', 1),
(1040, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Kigarama', 'Akimana', 1),
(1041, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Kigarama', 'Amahoro', 1),
(1042, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Kigarama', 'Byimana', 1),
(1043, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Kigarama', 'Indatwa', 1),
(1044, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Kigarama', 'Ingenzi', 1),
(1045, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Kigarama', 'Kabeza', 1),
(1046, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Kigarama', 'Karurayi', 1),
(1047, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Kigarama', 'Mataba', 1),
(1048, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Kigarama', 'Umucyo', 1),
(1049, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Nyarurama', 'Kamabuye', 1),
(1050, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Nyarurama', 'Karuyenzi', 1),
(1051, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Nyarurama', 'Kivu', 1),
(1052, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Nyarurama', 'Rebero', 1),
(1053, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Nyarurama', 'Twishorezo', 1),
(1054, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Nyarurama', 'Zuba', 1),
(1055, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Rwampara', 'Amajyambere', 1),
(1056, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Rwampara', 'Bwiza', 1),
(1057, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Rwampara', 'Nyarurembo', 1),
(1058, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Rwampara', 'Ubumwe', 1),
(1059, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Rwampara', 'Umutekano', 1),
(1060, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Rwampara', 'Urumuri', 1),
(1061, 'Umujyi wa Kigali', 'Kicukiro', 'Kigarama', 'Rwampara', 'Uwateke', 1),
(1062, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Ayabaraya', 'Akababyeyi', 1),
(1063, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Ayabaraya', 'Ayabaraya', 1),
(1064, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Ayabaraya', 'Nyamico', 1),
(1065, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Ayabaraya', 'Nyamyijima', 1),
(1066, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Ayabaraya', 'Nyirakavomo', 1),
(1067, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Ayabaraya', 'Rususa', 1),
(1068, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Cyimo', 'Biryogo', 1),
(1069, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Cyimo', 'Bwiza', 1),
(1070, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Cyimo', 'Cyimo', 1),
(1071, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Cyimo', 'Kabeza', 1),
(1072, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Cyimo', 'Kiyovu', 1),
(1073, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Cyimo', 'Masaka', 1),
(1074, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Cyimo', 'Murambi', 1),
(1075, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Cyimo', 'Nyakagunga', 1),
(1076, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Cyimo', 'Urugwiro', 1),
(1077, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gako', 'Bamporeze', 1),
(1078, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gako', 'Butangampundu', 1),
(1079, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gako', 'Butare', 1),
(1080, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gako', 'Cyugamo', 1),
(1081, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gako', 'Gicaca', 1),
(1082, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gako', 'Gihuke', 1),
(1083, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gako', 'Kabeza', 1),
(1084, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gako', 'Kibande', 1),
(1085, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gako', 'Rebero', 1),
(1086, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gako', 'Rugende', 1),
(1087, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gako', 'Ruyaga', 1),
(1088, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gitaraga', 'Gitaraga', 1),
(1089, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gitaraga', 'Kabeza', 1),
(1090, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gitaraga', 'Kajevuba', 1),
(1091, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gitaraga', 'Nyakarambi', 1),
(1092, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gitaraga', 'Nyange', 1),
(1093, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gitaraga', 'Ruhanga', 1),
(1094, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Gitaraga', 'Rwintare', 1),
(1095, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Mbabe', 'Kabeza', 1),
(1096, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Mbabe', 'Kamashashi', 1),
(1097, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Mbabe', 'Mbabe', 1),
(1098, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Mbabe', 'Murambi', 1),
(1099, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Mbabe', 'Ngarama', 1),
(1100, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Mbabe', 'Sangano', 1),
(1101, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Rusheshe', 'Cyankongi', 1),
(1102, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Rusheshe', 'Cyeru', 1),
(1103, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Rusheshe', 'Gatare', 1),
(1104, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Rusheshe', 'Kagese', 1),
(1105, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Rusheshe', 'Kanyetabi', 1),
(1106, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Rusheshe', 'Mubano', 1),
(1107, 'Umujyi wa Kigali', 'Kicukiro', 'Masaka', 'Rusheshe', 'Ruhosha', 1),
(1108, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Gatare', 'Byimana', 1),
(1109, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Gatare', 'Gatare', 1),
(1110, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Gatare', 'Imena', 1),
(1111, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Gatare', 'Kamahoro', 1),
(1112, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Gatare', 'Kigarama', 1),
(1113, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Gatare', 'Rugunga', 1),
(1114, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Gatare', 'Rurembo', 1),
(1115, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Gatare', 'Taba', 1),
(1116, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Niboye', 'Buhoro', 1),
(1117, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Niboye', 'Gaseke', 1),
(1118, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Niboye', 'Gateke', 1),
(1119, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Niboye', 'Gorora', 1),
(1120, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Niboye', 'Kigabiro', 1),
(1121, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Niboye', 'Kinunga', 1),
(1122, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Niboye', 'Kiruhura', 1),
(1123, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Niboye', 'Munini', 1),
(1124, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Niboye', 'Murehe', 1),
(1125, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Niboye', 'Mwijabo', 1),
(1126, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Niboye', 'Mwijuto', 1),
(1127, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Niboye', 'Nyarubande', 1),
(1128, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Niboye', 'Rwezamenyo', 1),
(1129, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Niboye', 'Sovu', 1),
(1130, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Niboye', 'Taba', 1),
(1131, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Amahoro', 1),
(1132, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Amarebe', 1),
(1133, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Amarembo', 1),
(1134, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Bigabiro', 1),
(1135, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Bukinanyana', 1),
(1136, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Bumanzi', 1),
(1137, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Bwiza', 1),
(1138, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Gatsibo', 1),
(1139, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Gikundiro', 1),
(1140, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Indakemwa', 1),
(1141, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Indamutsa', 1),
(1142, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Indatwa', 1),
(1143, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Inyarurembo', 1),
(1144, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Isangano', 1),
(1145, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Karama', 1),
(1146, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Kinyana', 1),
(1147, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Rugwiro', 1),
(1148, 'Umujyi wa Kigali', 'Kicukiro', 'Niboye', 'Nyakabanda', 'Umurava', 1),
(1149, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Kamashashi', 'Akindege', 1),
(1150, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Kamashashi', 'Indatwa', 1),
(1151, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Kamashashi', 'Intwari', 1),
(1152, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Kamashashi', 'Kabagendwa', 1),
(1153, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Kamashashi', 'Kibaya', 1),
(1154, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Kamashashi', 'Mukoni', 1),
(1155, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Kamashashi', 'Mulindi', 1),
(1156, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Kamashashi', 'Umucyo', 1),
(1157, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Kamashashi', 'Uruhongore', 1),
(1158, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Nonko', 'Gasaraba', 1),
(1159, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Nonko', 'Gihanga', 1),
(1160, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Nonko', 'Gitara', 1),
(1161, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Nonko', 'Kavumu', 1),
(1162, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Nonko', 'Mahoro', 1),
(1163, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Nonko', 'Nyarutovu', 1),
(1164, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Nonko', 'Rugali', 1),
(1165, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Nonko', 'Runyonza', 1),
(1166, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Rwimbogo', 'Gabiro', 1),
(1167, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Rwimbogo', 'Kabaya', 1),
(1168, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Rwimbogo', 'Kanogo', 1),
(1169, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Rwimbogo', 'Marembo', 1),
(1170, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Rwimbogo', 'Mushumbamwiza', 1),
(1171, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Rwimbogo', 'Nyandungu', 1),
(1172, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Rwimbogo', 'Ruragendwa', 1),
(1173, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Rwimbogo', 'Rwinyana', 1),
(1174, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Rwimbogo', 'Rwinyange', 1),
(1175, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Rwimbogo', 'Rwiza', 1),
(1176, 'Umujyi wa Kigali', 'Kicukiro', 'Nyarugunga', 'Rwimbogo', 'Urwibutso', 1);

-- --------------------------------------------------------

--
-- Table structure for table `payment_operations`
--

CREATE TABLE `payment_operations` (
  `o_id` bigint(100) NOT NULL,
  `tx_id` varchar(255) DEFAULT NULL,
  `tx_ref` varchar(255) DEFAULT NULL,
  `p_price` decimal(11,2) NOT NULL,
  `p_status` varchar(255) NOT NULL DEFAULT 'p',
  `p_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `re_id` bigint(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_operations`
--

INSERT INTO `payment_operations` (`o_id`, `tx_id`, `tx_ref`, `p_price`, `p_status`, `p_date`, `re_id`) VALUES
(1, '11452', 'hra-pay-b541247451939822250e80768fb951d7', '40000.00', 'successful', '2021-08-17 09:18:47', 1),
(2, NULL, 'hra-pay-fa7d9db2075e309a00c5323050714259', '40000.00', 'pending', '2021-08-17 09:21:37', 2),
(3, NULL, 'hra-pay-a23cbf3eb734b1f8fc30b1b3055a12fb', '40000.00', 'p', '2021-08-17 16:36:55', 3),
(4, NULL, 'hra-pay-0c2414d7dfe09d669284e581a18e3c5a', '200.00', 'p', '2021-08-17 16:55:53', 4),
(5, NULL, 'hra-pay-acacadafd264e07c5eea56d8a250a0d7', '200.00', 'p', '2021-08-17 17:00:50', 5),
(6, NULL, 'hra-pay-1a7d72339c4f2e15ef474deaf0a7807d', '200.00', 'p', '2021-08-18 16:29:58', 6),
(7, NULL, 'hra-pay-1fc5e74d43ee3b8a2f64e5fb488140e0', '78000.00', 'pending', '2021-08-19 11:41:06', 7),
(9, '2424556', 'hra-pay-af981ff460168033dfb2a4c53df69395', '200.00', 'successful', '2021-08-20 15:40:22', 9),
(10, NULL, 'hra-pay-2b9118bd58ed0d8945215429bc90853f', '45000.00', 'pending', '2021-08-20 15:55:51', 10),
(11, NULL, 'hra-pay-385e663359180b5e67ae5508c1d4b5f6', '250000.00', 'pending', '2021-08-20 16:02:32', 11),
(13, NULL, 'hra-pay-f1c0aa68740188aa645b7f440e80e880', '800.00', 'pending', '2021-09-11 20:26:49', 13),
(14, NULL, 'hra-pay-4acae5da374f61b7a5ceeeba185ad88a', '2000.00', 'pending', '2022-04-15 10:41:02', 14),
(15, NULL, 'hra-pay-74d0a389eb39034f0aa02b09461ece27', '250000.00', 'pending', '2022-04-15 15:18:45', 15),
(16, NULL, 'hra-pay-df65ea28be4deccaa6ad41458c986668', '2400.00', 'pending', '2022-04-15 15:21:11', 16),
(17, NULL, 'hra-pay-2ba0eca40abf7e8a57af86ba6287b0cc', '2000.00', 'pending', '2022-04-27 20:10:24', 17),
(18, NULL, 'hra-pay-9947933443f46b587f44230674fd4ee5', '1200.00', 'pending', '2022-04-27 20:33:38', 18),
(19, NULL, 'hra-pay-bdde8384cbbaca11f0bb4d52546c9805', '2000.00', 'pending', '2022-04-27 20:35:20', 19),
(21, NULL, 'hra-pay-b3a8ebfd1caa09637a49c6dc7208b589', '100.00', 'pending', '2022-04-27 20:52:06', 21),
(23, '3345016', 'hra-pay-0377ccc94a94c77ab59ea77d70d85268', '2000.00', 'successful', '2022-05-07 20:48:28', 23),
(24, NULL, 'hra-pay-00def64ad30a6c959830d1e1e8784e14', '1200.00', 'pending', '2022-05-07 20:50:41', 24),
(25, '3345047', 'hra-pay-be248530c0970fef4e47c93d38df8517', '100.00', 'successful', '2022-05-07 21:28:11', 25);

-- --------------------------------------------------------

--
-- Table structure for table `rent_operations`
--

CREATE TABLE `rent_operations` (
  `re_id` bigint(100) NOT NULL,
  `h_id` bigint(100) NOT NULL,
  `t_id` bigint(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `re_price` decimal(11,2) NOT NULL,
  `re_status` int(11) NOT NULL DEFAULT 1,
  `re_reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `re_reg_exp_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rent_operations`
--

INSERT INTO `rent_operations` (`re_id`, `h_id`, `t_id`, `start_date`, `end_date`, `re_price`, `re_status`, `re_reg_date`, `re_reg_exp_date`) VALUES
(1, 6, 1, '2021-08-17', '2021-09-17', '40000.00', 1, '2021-08-17 09:18:47', '2021-08-18 09:18:47'),
(2, 6, 1, '2021-08-17', '2021-09-17', '40000.00', 1, '2021-08-17 09:21:37', '2021-08-18 09:21:37'),
(3, 6, 1, '2021-08-17', '2021-09-17', '40000.00', 1, '2021-08-17 16:36:55', NULL),
(4, 10, 1, '2021-08-17', '2021-09-17', '200.00', 1, '2021-08-17 16:55:53', '2021-08-18 16:55:53'),
(5, 10, 1, '2021-08-17', '2021-09-17', '200.00', 1, '2021-08-17 17:00:50', '2021-08-18 17:00:50'),
(6, 10, 1, '2021-08-18', '2021-09-18', '200.00', 1, '2021-08-18 16:29:53', '2021-08-19 16:29:53'),
(7, 7, 1, '2021-08-19', '2021-09-19', '78000.00', 1, '2021-08-19 11:41:05', '2021-08-20 11:41:05'),
(8, 10, 1, '2021-08-20', '2021-09-20', '200.00', 1, '2021-08-20 15:22:59', '2021-08-21 15:22:59'),
(9, 10, 1, '2021-08-20', '2021-09-20', '200.00', 1, '2021-08-20 15:40:22', '2021-08-21 15:40:22'),
(10, 8, 1, '2021-08-20', '2021-09-20', '45000.00', 1, '2021-08-20 15:55:51', '2021-08-21 15:55:51'),
(11, 4, 1, '2021-08-20', '2021-09-20', '250000.00', 1, '2021-08-20 16:02:29', '2021-08-21 16:02:29'),
(13, 1, 1, '2021-09-12', '2022-01-12', '800.00', 1, '2021-09-11 20:26:49', '2021-09-12 20:26:49'),
(14, 15, 6, '2022-04-16', '2022-05-16', '2000.00', 1, '2022-04-15 10:41:02', '2022-04-16 10:41:02'),
(15, 16, 7, '2022-04-16', '2022-05-16', '250000.00', 1, '2022-04-15 15:18:45', '2022-04-16 15:18:45'),
(16, 14, 8, '2022-04-16', '2022-06-16', '2400.00', 1, '2022-04-15 15:21:11', '2022-04-16 15:21:11'),
(17, 15, 9, '2022-04-28', '2022-05-28', '2000.00', 1, '2022-04-27 20:10:24', '2022-04-28 20:10:24'),
(18, 14, 9, '2022-04-27', '2022-05-27', '1200.00', 1, '2022-04-27 20:33:38', '2022-04-28 20:33:38'),
(19, 15, 9, '2022-04-27', '2022-05-27', '2000.00', 1, '2022-04-27 20:35:20', '2022-04-28 20:35:20'),
(21, 16, 9, '2022-04-28', '2022-05-28', '100.00', 1, '2022-04-27 20:52:06', '2022-04-28 20:52:06'),
(23, 15, 10, '2022-05-08', '2022-06-08', '2000.00', 1, '2022-05-07 20:48:28', '2022-05-08 20:48:28'),
(24, 14, 10, '2022-05-07', '2022-06-07', '1200.00', 1, '2022-05-07 20:50:41', '2022-05-08 20:50:41'),
(25, 16, 10, '2022-05-08', '2022-06-08', '100.00', 1, '2022-05-07 21:28:11', '2022-05-08 21:28:11');

-- --------------------------------------------------------

--
-- Table structure for table `tenants`
--

CREATE TABLE `tenants` (
  `t_id` bigint(100) NOT NULL,
  `t_name` text NOT NULL,
  `t_nid` text NOT NULL,
  `t_sex` text NOT NULL,
  `t_username` text NOT NULL,
  `t_email` text NOT NULL,
  `t_tel` text NOT NULL,
  `t_password` text NOT NULL,
  `t_status` int(11) NOT NULL DEFAULT 1,
  `t_reg_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tenants`
--

INSERT INTO `tenants` (`t_id`, `t_name`, `t_nid`, `t_sex`, `t_username`, `t_email`, `t_tel`, `t_password`, `t_status`, `t_reg_date`) VALUES
(1, 'hirwa_roger', '11223344', 'm', 'tenant', 'izereroger1@gmail.com', '07885569911', 'a5ef04bed67700389a7459bb1f256033', 1, '2021-08-06 17:16:00'),
(2, 'MUKANTAGENGWA Ines', '1122009876', 'f', 'ineza1', '', '', 'a5ef04bed67700389a7459bb1f256033', 1, '2021-08-06 19:04:46'),
(3, 'NDUNGUTSE FIDELE', '12508856324', 'm', 'fidele', '', '', '123', 1, '2021-08-17 06:54:40'),
(4, 'MUMPOREZE Doliane', '2500085', 'f', 'doliane', 'mumporeze@gmail.com', '07885569911', '202cb962ac59075b964b07152d234b70', 1, '2021-08-17 07:22:25'),
(5, 'HIRWA', '12508856324', 'm', 'roger', 'izereroger1@gmail.com', '+250788788291', '202cb962ac59075b964b07152d234b70', 1, '2021-08-27 11:58:42'),
(6, 'UMURERWA Clarisse', '1122009876111111', 'f', 'umurerwa1', 'umurerwaclarisse7@gmail.com', '0787552482', '202cb962ac59075b964b07152d234b70', 1, '2022-04-15 10:40:40'),
(7, 'ishimwe gilbert', '1111111111111111', 'm', 'ishimwe', 'ishimwe@gmail.com', '0780019558', '0950fa4851826b43791125b873ff1baf', 1, '2022-04-15 15:18:44'),
(8, 'ISHIMWE Gilbert', '2222222222222222', 'm', 'gilbert1', 'gilbert@gmail.com', '0780019558', 'f7743b4652be0a6d1befcc6bd70e4759', 1, '2022-04-15 15:21:10'),
(9, 'GILBERT', '1250885632487890', 'm', 'gilbert123', 'gilbertishimwe2020@gmail.com', '0780019558', '37a0eae12012f32afcdd187eddbdc47d', 1, '2022-04-27 20:10:23'),
(10, 'IZERE HIRWA Roger', '1234567890123456', 'm', 'ineza1', 'izereroger1@gmail.com', '0788788291', '1cf9a452d230bd350d083f02ec7203c1', 1, '2022-05-07 20:37:12');

-- --------------------------------------------------------

--
-- Structure for view `auth_engine`
--
DROP TABLE IF EXISTS `auth_engine`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `auth_engine`  AS  select `auth_storage`.`a_id` AS `a_id`,`auth_storage`.`a_username` AS `a_username`,`auth_storage`.`a_email` AS `a_email`,`auth_storage`.`a_password` AS `a_password`,`auth_storage`.`a_role` AS `a_role`,`auth_storage`.`a_status` AS `a_status` from `auth_storage` union all select `land_lord`.`l_id` AS `a_id`,`land_lord`.`l_username` AS `a_username`,`land_lord`.`l_email` AS `a_email`,`land_lord`.`l_password` AS `a_password`,'land_lord' AS `a_role`,`land_lord`.`l_status` AS `a_status` from `land_lord` union all select `tenants`.`t_id` AS `a_id`,`tenants`.`t_username` AS `a_username`,`tenants`.`t_username` AS `a_email`,`tenants`.`t_password` AS `a_password`,'tenant' AS `a_role`,`tenants`.`t_status` AS `a_status` from `tenants` ;

-- --------------------------------------------------------

--
-- Structure for view `booked`
--
DROP TABLE IF EXISTS `booked`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `booked`  AS  select `a`.`re_id` AS `re_id`,`a`.`h_id` AS `h_id`,`a`.`t_id` AS `t_id`,`a`.`start_date` AS `start_date`,`a`.`end_date` AS `end_date`,`a`.`end_date` + interval 15 day AS `end_date_2`,`a`.`re_price` AS `re_price`,`a`.`re_status` AS `re_status`,`a`.`re_reg_date` AS `re_reg_date`,`a`.`re_reg_exp_date` AS `re_reg_exp_date`,`b`.`o_id` AS `o_id`,`b`.`tx_id` AS `tx_id`,`b`.`tx_ref` AS `tx_ref`,`b`.`p_price` AS `p_price`,`b`.`p_status` AS `p_status`,`b`.`p_date` AS `p_date` from (`rent_operations` `a` join `payment_operations` `b`) where `a`.`start_date` <= current_timestamp() and `a`.`end_date` + interval 15 day >= current_timestamp() and `a`.`re_id` = `b`.`re_id` and `b`.`p_status` = 'successful' union select `a`.`re_id` AS `re_id`,`a`.`h_id` AS `h_id`,`a`.`t_id` AS `t_id`,`a`.`start_date` AS `start_date`,`a`.`end_date` AS `end_date`,`a`.`end_date` + interval 15 day AS `end_date_2`,`a`.`re_price` AS `re_price`,`a`.`re_status` AS `re_status`,`a`.`re_reg_date` AS `re_reg_date`,`a`.`re_reg_exp_date` AS `re_reg_exp_date`,`b`.`o_id` AS `o_id`,`b`.`tx_id` AS `tx_id`,`b`.`tx_ref` AS `tx_ref`,`b`.`p_price` AS `p_price`,`b`.`p_status` AS `p_status`,`b`.`p_date` AS `p_date` from (`payment_operations` `b` left join `rent_operations` `a` on(`a`.`re_id` = `b`.`re_id`)) where `a`.`start_date` <= current_timestamp() and `a`.`end_date` + interval 15 day >= current_timestamp() and time_to_sec(timediff(`a`.`re_reg_exp_date`,current_timestamp())) > 0 and `b`.`p_status` = 'pending' ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_storage`
--
ALTER TABLE `auth_storage`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `houses`
--
ALTER TABLE `houses`
  ADD PRIMARY KEY (`h_id`),
  ADD KEY `l_id` (`l_id`),
  ADD KEY `c_id` (`c_id`),
  ADD KEY `houses_ibfk_3` (`h_location`);

--
-- Indexes for table `house_category`
--
ALTER TABLE `house_category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `land_lord`
--
ALTER TABLE `land_lord`
  ADD PRIMARY KEY (`l_id`);

--
-- Indexes for table `land_lord_payments`
--
ALTER TABLE `land_lord_payments`
  ADD PRIMARY KEY (`lp_id`),
  ADD KEY `a_id` (`a_id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`loc_id`);

--
-- Indexes for table `payment_operations`
--
ALTER TABLE `payment_operations`
  ADD PRIMARY KEY (`o_id`),
  ADD UNIQUE KEY `tx_id` (`tx_id`),
  ADD UNIQUE KEY `tx_ref` (`tx_ref`),
  ADD KEY `payment_operations_ibfk_1` (`re_id`);

--
-- Indexes for table `rent_operations`
--
ALTER TABLE `rent_operations`
  ADD PRIMARY KEY (`re_id`),
  ADD KEY `t_id` (`t_id`),
  ADD KEY `h_id` (`h_id`);

--
-- Indexes for table `tenants`
--
ALTER TABLE `tenants`
  ADD PRIMARY KEY (`t_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_storage`
--
ALTER TABLE `auth_storage`
  MODIFY `a_id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `houses`
--
ALTER TABLE `houses`
  MODIFY `h_id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `house_category`
--
ALTER TABLE `house_category`
  MODIFY `c_id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `land_lord`
--
ALTER TABLE `land_lord`
  MODIFY `l_id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `land_lord_payments`
--
ALTER TABLE `land_lord_payments`
  MODIFY `lp_id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `loc_id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14842;

--
-- AUTO_INCREMENT for table `payment_operations`
--
ALTER TABLE `payment_operations`
  MODIFY `o_id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `rent_operations`
--
ALTER TABLE `rent_operations`
  MODIFY `re_id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tenants`
--
ALTER TABLE `tenants`
  MODIFY `t_id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `houses`
--
ALTER TABLE `houses`
  ADD CONSTRAINT `houses_ibfk_1` FOREIGN KEY (`l_id`) REFERENCES `land_lord` (`l_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `houses_ibfk_2` FOREIGN KEY (`c_id`) REFERENCES `house_category` (`c_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `houses_ibfk_3` FOREIGN KEY (`h_location`) REFERENCES `locations` (`loc_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `land_lord_payments`
--
ALTER TABLE `land_lord_payments`
  ADD CONSTRAINT `land_lord_payments_ibfk_1` FOREIGN KEY (`a_id`) REFERENCES `auth_storage` (`a_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `payment_operations`
--
ALTER TABLE `payment_operations`
  ADD CONSTRAINT `payment_operations_ibfk_1` FOREIGN KEY (`re_id`) REFERENCES `rent_operations` (`re_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rent_operations`
--
ALTER TABLE `rent_operations`
  ADD CONSTRAINT `rent_operations_ibfk_1` FOREIGN KEY (`t_id`) REFERENCES `tenants` (`t_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rent_operations_ibfk_2` FOREIGN KEY (`h_id`) REFERENCES `houses` (`h_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
