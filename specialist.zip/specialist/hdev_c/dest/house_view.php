<?php 
  $house_ref = hdev_session::get("house_id");
  $products_by_id = hdev_data::houses($house_ref,["data"]);
  $pic = $products_by_id['h_photos'];
  $price =  $products_by_id['h_price'];
  $description = $products_by_id['h_description'];
  $location = hdev_data::locations("all",$products_by_id['h_location']);
  $land_lord = hdev_data::land_lord($products_by_id['l_id'],["data"]);
  $appl = false;
  if ($products_by_id['h_status'] == 2 && hdev_data::service('land_lord_approve')) {
    $csrf = new CSRF_Protect();
    $tkn = $csrf->getToken();
    $build = "ref:house_approve;id:".$products_by_id['h_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
    $approve = hdev_data::encd("mod_close:#hs_app_close;app:".$tkn.";".$build);
    $build2 = "ref:house_reject;id:".$products_by_id['h_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
    $reject = hdev_data::encd("mod_close:#hs_rej_close;app:".$tkn.";".$build2);
    $appl = "waiting for approval scroll down to Approve/Reject";
  }
 ?>
<div id="app_data">
       <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline">
              <div class="card-header">
                <div class="user-block">
                  <span class="username"> House For Rent preview </span>
                </div>
                <!-- /.user-block -->
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Mark as read">
                    <i class="far fa-circle"></i></button>
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
                  </button>
                </div>
                <!-- /.card-tools -->
              </div>
              <div class="card-body">
              <div class="row">
                <div class="col-sm-6">
                  <table class="table">
                  <?php if ($appl): ?>
                    <tr>
                      <td class="bg-secondary border-bottom" colspan="2"><?php echo $appl ?></td>
                    </tr>
                  <?php endif ?>
                    <tr>
                      <th class="bg-secondary" style="text-align: right;">House Reg.no. :</th>
                      <th class="bg-info"><b><?php echo $products_by_id['h_id']; ?></b></th>
                    </tr>
                  </table>
                  <div style="height: 30% !important;">
                    <div class="sp-loading"><img src="<?php echo hdev_url::menu('dist/img/sp-loading.gif');?>" alt=""><br>LOADING IMAGES</div>
                    <div class="sp-wrap">

                      <?php foreach (hdev_data::product_images($pic) as $key): ?>
                      <a href="<?php echo $key ?>"><img src="<?php echo $key ?>" alt=""></a><?php endforeach ?>
                    </div>
                  </div>
                  <hr>
                  <br>
                </div>
                <div class="col-sm-6">
                  <table class="table border-bottom">
                    <tr>
                      <th class="bg-secondary border-bottom">House For Rent Details</th>
                      <th class="bg-secondary border-left border-bottom">House Reg.no : <?php echo $products_by_id['h_id'] ?></th>
                    </tr>
                    <tr>
                      <th colspan="2" class="bg-secondary">Landlord Info</th>
                    </tr>
                    <tr>
                      <td>Names</td>
                      <td>: <?php echo $land_lord["l_name"]; ?></td>
                    </tr>
                    <tr>
                      <td>Email</td>
                      <td>: <?php echo $land_lord["l_email"]; ?></td>
                    </tr>
                    <tr>
                      <td>Tell</td>
                      <td>: <?php echo $land_lord["l_tel"]; ?></td>
                    </tr>
                    <tr>
                      <th colspan="2" class="bg-secondary">House Location</th>
                    </tr>
                    <tr>
                      <td>Province</td>
                      <td>: <?php echo $location['loc_province']; ?></td>
                    </tr>
                    <tr>
                      <td>District</td>
                      <td>: <?php echo $location['loc_district']; ?></td>
                    </tr>
                    <tr>
                      <td>Sector</td>
                      <td>: <?php echo $location['loc_sector']; ?></td>
                    </tr>
                    <tr>
                      <td>Cell</td>
                      <td>: <?php echo $location['loc_cell']; ?></td>
                    </tr>
                    <tr>
                      <td>Village</td>
                      <td>: <?php echo $location['loc_village']; ?></td>
                    </tr>
                    <tr>
                      <th colspan="2" class="bg-secondary">Pricing</th>
                    </tr>
                    <tr>
                      <td>House Price/Month(30 days)</td>
                      <td>: <?php echo $price; ?>&nbsp;frw</td>
                    </tr>
                  </table>
                  <div align="center">
                    <?php $up = hdev_log::fid(); if (!hdev_log::admin() && $up !='agent' && hdev_data::service("houses_rent")) { ?>
                          <button class="btn btn-primary btn-block"  data-toggle="modal" data-target=".modal-reg">
                            <i class="fa fa-cart-plus"></i>
                            Book Now
                          </button>
                      <?php 
                      }
                      ?> 
                        <?php
                          if (hdev_log::admin()) {
                        ?>
                        <a href="<?php echo hdev_url::menu('prod_edit/'.hdev_data::encd($house_ref)); ?>" class="memb_up btn btn-outline-success btn-block">
                          <span class="fas fa-edit"></span>
                          <?php echo hdev_lang::on("form","edit"); ?>
                        </a>
                        <?php
                          }
                        if ($products_by_id['h_status'] == 2 && hdev_data::service('land_lord_approve')) {    
                         ?>    
                        <div class="btn-group btn-block">
                          <?php if (hdev_data::service('house_approve')) { ?>
                          <button rel="external" class="btn btn-success ld_approve" data-toggle="modal" data-target=".modal-approve"><i class="fas fa-check-circle"></i> Approve </button>
                           <?php } ?>
                          <?php if (hdev_data::service('house_reject')) { ?>
                          <button rel="external" class="btn btn-danger" data-toggle="modal" data-target=".modal-reject"><i class="fas fa-times"></i> Reject </button>
                           <?php } ?>
                        </div>
                         <?php }?>              
                  </div>
                  <br>
                </div>
              </div>
              <div class="row border-top">
                <div class="col-sm-9" align="left">
                  <u><h5>More Info :</h5></u>
                </div>              
              </div>
              <div class="row border-bottom">
                <div class="col-sm-12">
                  <?php echo $description ?>
                </div>
              </div>
              <div class="row p-2">
                <div class="col-sm-12">
                  <div align="center">
                    <i style="font-weight: bold;">
                      For more info about this house call The Landlord, Tel: <?php echo $land_lord['l_tel'] ?>
                    </i>
                  </div>
                </div>
              </div>
              </div>
            </div>
          </div>
        </div>
</div>
<?php if (hdev_data::service('house_approve')): ?> 
<div class="modal fade modal-approve" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To approve The Following House Registration Application?</th>
                </tr>
                <tr>
                  <td>House Id</td>
                  <td> :<?php echo $products_by_id['h_id']; ?></td>
                </tr>
                <tr>
                  <td>Landlord Name : </td>
                  <td id="land_lord_name"><?php echo $land_lord['l_name'] ?></td>
                </tr>
                <tr>
                  <td>Landlord Username : </td>
                  <td id="land_lord_username"><?php echo $land_lord['l_username'] ?></td>
                </tr>
                <tr>
                  <td>Landlord Email : </td>
                  <td id="land_lord_email"><?php echo $land_lord['l_email'] ?></td>
                </tr>
                <tr>
                  <td>Landlord Tel : </td>
                  <td id="land_lord_email"><?php echo $land_lord['l_tel'] ?></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#prof_edit_close">
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="hs_app_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-success" id="house_approve" hash="<?php echo $tkn; ?>" data="<?php echo $approve; ?>"><i class="fas fa-check-circle"></i> Approve This House Registration Application</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('house_reject')): ?> 
<div class="modal fade modal-reject" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Reject The Following House Registration Application?</th>
                </tr>
                <tr>
                  <td>House Id</td>
                  <td> :<?php echo $products_by_id['h_id']; ?></td>
                </tr>
                <tr>
                  <td>Landlord Name : </td>
                  <td id="land_lord_name"><?php echo $land_lord['l_name'] ?></td>
                </tr>
                <tr>
                  <td>Landlord Username : </td>
                  <td id="land_lord_username"><?php echo $land_lord['l_username'] ?></td>
                </tr>
                <tr>
                  <td>Landlord Email : </td>
                  <td id="land_lord_email"><?php echo $land_lord['l_email'] ?></td>
                </tr>
                <tr>
                  <td>Landlord Tel : </td>
                  <td id="land_lord_email"><?php echo $land_lord['l_tel'] ?></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="hs_rej_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="house_reject" hash="<?php echo $tkn; ?>" data="<?php echo $reject; ?>"><i class="fas fa-times-circle"></i> Reject This House Registration Application</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('houses_rent')): ?>
<div class="modal fade modal-reg">
  <?php if (!hdev_log::loged()): ?>
  <div class="modal-dialog modal-lg">
  <?php else: ?>
  <div class="modal-dialog">  
  <?php endif ?>
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Book New House For Rent</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <form method="post" id="houses_rent" action="<?php echo hdev_url::menu("up") ?>">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="houses_rent" id="hs_ref">
              <input type="hidden" name="ref_hs" value="<?php echo hdev_data::encd($products_by_id['h_id']); ?>">
         <div class="card">
          <div class="card-body row">
            <?php if (!hdev_log::loged()): ?>
            <div class="col-sm-6">
            <div class="form-group">
              <label for="t_name">
                Your name :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user"></span>
                  </div>
                </div>
                <input type="text" name="t_name" id="t_name" class="form-control" placeholder="Your name" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="t_nid">
                Your National id :
              </label>
              <div class="input-group mb-0">
                
                <div class="input-group-prepend">
                  <div class="input-group-text" id="input_icon_id">
                    <span class="fas fa-user-alt"></span>
                  </div>
                </div>
                <input type="number" oninput="id_validator($(this).val(),'#input_icon_id','#message_box_id','#rent_houses')" name="t_nid" id="t_nid" class="form-control" placeholder="Your National id" required="true">
              </div>
              <div class="input-group mb-3" id="message_box_id">

              </div>              
            </div>
            <div class="form-group">
              <label for="sex">
                Sex :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-friends"></span>
                  </div>
                </div>
                <select class="form-control" name="sex" id="sex">
                  <option value="">Select Sex</option>
                  <option value="m">Male</option>
                  <option value="f">Female</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label for="t_username">
                Your Username :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-tag"></span>
                  </div>
                </div>
                <input type="text" name="t_username" id="t_username" class="form-control" placeholder="Your Username" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="t_email">
                Tenant Email :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fa">@</span>
                  </div>
                </div>
                <input type="email" name="t_email" id="t_email" class="form-control" placeholder="Your Email" required="true">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fa fa-envelope"></span>
                  </div>
                </div>
              </div>
            </div>
            </div>  
            <div class="col-sm-6">

            <div class="form-group">
              <label for="t_tel">
                Your Telephone :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-phone"></span>
                  </div>
                </div>
                <input type="text" name="t_tel" id="t_tel" class="form-control" placeholder="Your Telephone" required="true">
              </div>
            </div>
            <?php else: ?>
            <div class="col-sm-12">
            <?php endif ?>
            <div class="form-group">
              <label for="start_date">
                Starting date(Arriving date) :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-calendar"></span>
                  </div>
                </div>
                <input type="date" name="start_date" id="start_date" class="form-control" placeholder="Arriving Date" required="true">
              </div>
            </div> 
            <div class="form-group">
              <label for="h_price">
                House Price/month(30 days) :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-coins"></span>
                  </div>
                </div>
                <input type="text" id="h_price" class="form-control" placeholder="House Price" disabled="true" value="<?php echo $products_by_id['h_price']; ?> frw">
              </div>
            </div>
            <div class="form-group">
              <label for="n_months">
                Number of months to pay or book :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-list-ol"></span>
                  </div>
                </div>
                <input type="number" name="n_months" id="n_months" class="form-control" placeholder="Number of months" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="t_pay">
                Total Amount To pay :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text" id="t_pay_ld" ico='<span class="fas fa-user-alt"></span>'>
                    <span class="fas fa-coins"></span>
                  </div>
                </div>
                <input type="text" id="t_pay" class="form-control" placeholder="Total amount to pay" readonly="true">
              </div>
            </div>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            </div>
          </div>
            </form>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="rent_houses"><i class="fas fa-check-circle"></i> Book and Pay This house</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>