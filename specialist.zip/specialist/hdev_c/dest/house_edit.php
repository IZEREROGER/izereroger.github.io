<?php 
  $house_ref = hdev_session::get("house_id");
  $products_by_id = hdev_data::houses($house_ref,["data"]);
  $pic = $products_by_id['h_photos'];
  $price =  $products_by_id['h_price'];
  $description = $products_by_id['h_description'];
  $location = hdev_data::locations("all",$products_by_id['h_location']);
  $land_lord = hdev_data::land_lord($products_by_id['l_id'],["data"]);
  $appl = false;
    $csrf = new CSRF_Protect();
    $tkn = $csrf->getToken();
    $build = "ref:house_approve;id:".$products_by_id['h_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
    $approve = hdev_data::encd("mod_close:#hs_app_close;app:".$tkn.";".$build);
    $build2 = "ref:house_reject;id:".$products_by_id['h_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
    $reject = hdev_data::encd("mod_close:#hs_rej_close;app:".$tkn.";".$build2);
 ?>
<div id="app_data">
       <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline">
              <div class="card-header">
                <div class="user-block">
                  <span class="username"> House For Rent preview </span>
                </div>
                <!-- /.user-block -->
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Mark as read">
                    <i class="far fa-circle"></i></button>
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
                  </button>
                </div>
                <!-- /.card-tools -->
              </div>
              <div class="card-body">
              <div class="row">
                <div class="col-sm-6">
                  <table class="table">
                    <tr>
                      <th class="bg-secondary" style="text-align: right;">House Reg.no. :</th>
                      <th class="bg-info"><b><?php echo $products_by_id['h_id']; ?></b></th>
                    </tr>
                  </table>
                  <div style="height: 30% !important;">
                    <div class="sp-loading"><img src="<?php echo hdev_url::menu('dist/img/sp-loading.gif');?>" alt=""><br>LOADING IMAGES</div>
                    <div class="sp-wrap">

                      <?php foreach (hdev_data::product_images($pic) as $key): ?>
                      <a href="<?php echo $key ?>"><img src="<?php echo $key ?>" alt=""></a><?php endforeach ?>
                    </div>
                  </div>
                  <hr>
                  <br>
                </div>
                <div class="col-sm-6">
                  <table class="table border-bottom">
                    <tr>
                      <th class="bg-secondary border-bottom">House For Rent Details</th>
                      <th class="bg-secondary border-left border-bottom">House Reg.no : <?php echo $products_by_id['h_id'] ?></th>
                    </tr>
                    <tr>
                      <th colspan="2" class="bg-secondary">Landlord Info</th>
                    </tr>
                    <tr>
                      <td>Names</td>
                      <td>: <?php echo $land_lord["l_name"]; ?></td>
                    </tr>
                    <tr>
                      <td>Email</td>
                      <td>: <?php echo $land_lord["l_email"]; ?></td>
                    </tr>
                    <tr>
                      <td>Tell</td>
                      <td>: <?php echo $land_lord["l_tel"]; ?></td>
                    </tr>
                    <tr>
                      <th colspan="2" class="bg-secondary">House Location</th>
                    </tr>
                    <tr>
                      <td>Province</td>
                      <td>: <?php echo $location['loc_province']; ?></td>
                    </tr>
                    <tr>
                      <td>District</td>
                      <td>: <?php echo $location['loc_district']; ?></td>
                    </tr>
                    <tr>
                      <td>Sector</td>
                      <td>: <?php echo $location['loc_sector']; ?></td>
                    </tr>
                    <tr>
                      <td>Cell</td>
                      <td>: <?php echo $location['loc_cell']; ?></td>
                    </tr>
                    <tr>
                      <td>Village</td>
                      <td>: <?php echo $location['loc_village']; ?></td>
                    </tr>
                    <tr>
                      <th colspan="2" class="bg-secondary">Pricing</th>
                    </tr>
                    <tr>
                      <td>House Price/Month(30 days)</td>
                      <td>: <?php echo $price; ?>&nbsp;frw</td>
                    </tr>
                  </table>
                  <div align="center">
                        <?php
                          if (hdev_data::service('house_edit')) {
                        ?>
                        <button class="btn btn-primary btn-block ftb" data-toggle="modal" data-target=".modal-reg" onclick="hs_edit(<?php echo "'".$products_by_id['c_id']."','".$location['loc_province']."','".$location['loc_district']."','".$location['loc_sector']."','".$location['loc_cell']."','".$location['loc_id']."'"; ?>);land_lord('<?php echo $products_by_id['l_id'] ?>','hs_reg');"><i class="fas fa-edit"></i>
                           Edit House Info
                         </button>&nbsp;
                        <?php
                          }
                         ?>
                      
                  </div>
                  <br>
                </div>
              </div>
              <div class="row border-top">
                <div class="col-sm-9" align="left">
                  <u><h5>More Info :</h5></u>
                </div>              
              </div>
              <div class="row border-bottom">
                <div class="col-sm-12">
                  <?php echo $description ?>
                </div>
              </div>
              <div class="row p-2">
                <div class="col-sm-12">
                  <div align="center">
                    <i style="font-weight: bold;">
                      For more info about this house call The Landlord, Tel: <?php echo $land_lord['l_tel'] ?>
                    </i>
                  </div>
                </div>
              </div>
              </div>
            </div>
          </div>
        </div>
</div>
<?php if (hdev_data::service('house_edit')): ?>
<div class="modal fade modal-reg">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit House Info</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>" id="reg_close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <form method="post" class="house_edit" id="houses_edit" action="<?php echo hdev_url::menu("up"); ?>" enctype="multipart/form-data">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="house_edit">
              <input type="hidden" name="h_id" value="<?php echo $products_by_id['h_id'] ?>">
              <input type="hidden" name="mod_close" value="#reg_close">
                <div class="bs-stepper" step_val="ok">
                  <div class="bs-stepper-header" role="tablist">
                    <!-- your steps here -->
                    <div class="step" data-target="#land-lord">
                      <button type="button" class="step-trigger" role="tab" aria-controls="logins-part" id="land-lord-trigger">
                        <span class="bs-stepper-circle">1</span>
                        <span class="bs-stepper-label">House information</span>
                      </button>
                    </div>
                    <div class="line"></div>
                    <div class="step" data-target="#photo-part">
                      <button type="button" class="step-trigger" role="tab" aria-controls="photo-part" id="photo-part-trigger">
                        <span class="bs-stepper-circle">2</span>
                        <span class="bs-stepper-label">House Photos</span>
                      </button>
                    </div>
                    <div class="step" data-target="#description-part">
                      <button type="button" class="step-trigger" role="tab" aria-controls="description-part" id="description-part-trigger">
                        <span class="bs-stepper-circle">2</span>
                        <span class="bs-stepper-label">House Description</span>
                      </button>
                    </div>
                    <div class="line"></div>
                    <div class="step" data-target="#information-part">
                      <button type="button" class="step-trigger" role="tab" aria-controls="information-part" id="information-part-trigger">
                        <span class="bs-stepper-circle">3</span>
                        <span class="bs-stepper-label">House Location</span>
                      </button>
                    </div>
                  </div>
                  <div class="bs-stepper-content">
                    <!-- your steps content here -->
                    <div id="land-lord" class="content" role="tabpanel" aria-labelledby="land-lord-trigger">
                      <div class="row">
                        <div class="col-sm-6 border-right">
                          <div class="form-group">
                            <label for="l_id">
                              House Category :
                            </label>
                            <div class="input-group mb-3">
                              <div class="input-group-prepend">
                                <div class="input-group-text">
                                  <span class="fa fa-th-list"></span>
                                </div>
                              </div>
                              <select type="text" name="c_id" id="c_id" class="form-control">
                                <option value="">Select Category</option>
                                <?php foreach (hdev_data::house_category() as $cat) {
                                ?>
                                <option value="<?php echo $cat['c_id']; ?>"><?php echo $cat['c_name']; ?></option>
                                <?php
                                } ?>
                              </select>
                            </div>
                          </div> 
                          <?php 
                            if (hdev_log::fid() != "land_lord") {
                          ?>
                          <div class="form-group">
                            <label for="l_id">
                              LandLord Reg No.:
                            </label>
                            <div class="input-group mb-3">
                              
                              <div class="input-group-prepend">
                                <div class="input-group-text">
                                  <span class="fa fa-user-secret"></span>
                                </div>
                              </div>
                              <input type="text" name="l_id" id="l_id" class="form-control" placeholder="LandLord Reg No." required="true" value="<?php echo $products_by_id['l_id'] ?>" oninput="land_lord($(this).val(),'hs_reg');" readonly='true'>
                            </div>
                          </div>  
                          <?php }else{ ?>
                            <input type="hidden" name="l_id" id="l_id" class="form-control" placeholder="LandLord Reg No." required="true" value="<?php echo hdev_log::uid() ?>">
                          <?php } ?>
                          <div class="form-group">
                            <label for="h_price">
                              House Price / month :
                            </label>
                            <div class="input-group mb-3">
                              <div class="input-group-prepend">
                                <div class="input-group-text">
                                  <span class="fas fa-coins"></span>
                                </div>
                              </div>
                              <input type="text" name="h_price" id="h_price" class="form-control" placeholder="House Price" required="true" value="<?php echo $products_by_id['h_price'] ?>">
                            </div>
                          </div>                         
                        </div>
                        <?php 
                          if (hdev_log::fid() != "land_lord") {
                        ?>
                        <div class="col-sm-6 border-left">
                          <table class="table border-bottom" id="hs_reg">
                            <tr>
                              <th class="bg-secondary" colspan="2"><span id="hash" hash="<?php echo $tkn; ?>"></span>Landlord Info</th>
                            </tr>
                            <tr>
                              <td>Names</td>
                              <td> : <span id="name" class="ldd"></span></td>
                            </tr>
                            <tr>
                              <td>Usename</td>
                              <td> : <span id="username" class="ldd"></span></td>
                            </tr>
                            <tr>
                              <td>Email</td>
                              <td> : <span id="email" class="ldd"></span></td>
                            </tr>
                            <tr>
                              <td>Tell</td>
                              <td> : <span id="tel" class="ldd"></span></td>
                            </tr>
                          </table>
                        </div>
                        <?php
                          }
                         ?>
                        
                      </div>
                      <div class="row">
                        <div class="col-sm-12">
                          <button type="button" class="btn btn-primary" onclick="mr_step('next');">Next</button>
                        </div>
                      </div>
                    </div>
                    <div id="photo-part" class="content" role="tabpanel" aria-labelledby="photo-part-trigger">
                      <div class="form-group">
                        <label for="h_photo_in">
                          House Photos :
                        </label>
                        <div class="input-group mb-3">
                          
                          <input type="file" name="h_photo[]" id="h_photo_in" class="form-control"multiple="true">
                        </div>
                      </div>
                      <button type="button" class="btn btn-primary" onclick="mr_step('previous');">Previous</button>
                      <button type="button" class="btn btn-primary" onclick="mr_step('next',2);">Next</button>
                    </div>
                    <div id="description-part" class="content" role="tabpanel" aria-labelledby="description-part-trigger">
                      <h3>House Description</h3>
                       <textarea name="h_description" class="form-control"><?php echo $description; ?></textarea>
                      <button type="button" class="btn btn-primary" onclick="mr_step('next',1);">Previous</button>
                      <button type="button" class="btn btn-primary" onclick="mr_step('next',3);">Next</button>
                    </div>
                    <div id="information-part" class="content" role="tabpanel" aria-labelledby="information-part-trigger">
                      <div class="row">
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label for="province">
                              Province :
                            </label>
                            <div class="input-group mb-3">
                              <div class="input-group-prepend">
                                <div class="input-group-text" province-ico="fas fa-map-marker-alt">
                                  <span class="fas fa-map-marker-alt"></span>
                                </div>
                              </div>
                              <select id="province" class="form-control" required="true" onchange="mr_locator('district',$(this).val())">
                                <?php echo hdev_data::locations("province"); ?>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label for="h_location">
                              District :
                            </label>
                            <div class="input-group mb-3">
                              <div class="input-group-prepend">
                                <div class="input-group-text" district-ico="fas fa-map-marker-alt">
                                  <span class="fas fa-map-marker-alt" ></span>
                                </div>
                              </div>
                              <select id="district" class="form-control" required="true" onchange="mr_locator('sector',$('#province').val(),$(this).val())">
                                <?php echo hdev_data::locations("district",$location['loc_province']); ?>
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label for="h_location">
                              Sector :
                            </label>
                            <div class="input-group mb-3">
                              <div class="input-group-prepend">
                                <div class="input-group-text" sector-ico="fas fa-map-marker-alt">
                                  <span class="fas fa-map-marker-alt" ></span>
                                </div>
                              </div>
                              <select id="sector" class="form-control" required="true" onchange="mr_locator('cell',$('#province').val(),$('#district').val(),$(this).val())">
                                <?php echo hdev_data::locations("sector",$location['loc_province'],$location['loc_district']); ?>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                              <label for="h_location">
                                Cell :
                              </label>
                              <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                  <div class="input-group-text" cell-ico="fas fa-map-marker-alt">
                                    <span class="fas fa-map-marker-alt" ></span>
                                  </div>
                                </div>
                                <select id="cell" class="form-control" required="true" onchange="mr_locator('village',$('#province').val(),$('#district').val(),$('#sector').val(),$(this).val())">
                                <?php echo hdev_data::locations("cell",$location['loc_province'],$location['loc_district'],$location['loc_sector']); ?>
                                </select>
                              </div>
                            </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label for="h_location">
                              Village :
                            </label>
                            <div class="input-group mb-3">
                              <div class="input-group-prepend">
                                <div class="input-group-text" village-ico="fas fa-map-marker-alt">
                                  <span class="fas fa-map-marker-alt" ></span>
                                </div>
                              </div>
                              <select id="village" name="h_location" class="form-control" required="true">
                                <?php echo hdev_data::locations("village",$location['loc_province'],$location['loc_district'],$location['loc_sector'],$location['loc_cell']); ?>
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <button type="button" class="btn btn-primary" onclick="mr_step('next',2);">Previous</button>
                      <button type="submit" class="btn btn-primary" id="edit_houses"><i class="fas fa-save"></i> Register House</button>
                    </div>
                  </div>
                </div>
            </form>
           <div class="card">
              <div class="card-body register-card-body table-responsive p-3">
                <div class="progress">
                  <div class="progress-bar bg-primary progress-bar-striped" role="progressbar" id="progress-bar">
                  </div>
                </div>
                <div class="wait" align="center"></div>
              </div>
              <!-- /.form-box -->
            </div><!-- /.card -->
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>
<script type="text/javascript">
  //$(".wait").html('...kufyjhgftyrytrytrtyrrtyrhgfvnbgncbcbvcvbcvb');
</script>