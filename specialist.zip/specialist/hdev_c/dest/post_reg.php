<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">Current registered posts</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">
                  <?php if (hdev_data::service('post_reg')): ?>
                  <button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fas fa-plus-circle"></i> Register new post</button>&nbsp;
                  <?php endif ?>
                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="table table-bordered table-hover table-striped text-nowrap" id="rasms_all_tables">
                  <thead class="border-top">
                    <tr>
                      <th>Reg no.</th>
                      <th>Post by</th> 
                      <th>Title</th>
                      <th>Short description</th> 
                      <th>Reg date</th>
                      <?php 
                      if (hdev_data::service('post_edit') || hdev_data::service('post_delete')): ?>
                      <th>Action</th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>

                    <?php foreach (hdev_data::post() AS $post) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:post_delete;id:".$post['p_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#ld_del_close;app:".$tkn.";".$build2);
                    ?>

                    <tr>
                      <td>
                        <?php echo $post["p_id"]; ?>
                      </td>
                      <td>
                        <?php echo hdev_data::provider($post["s_id"],['data'])['s_name']; ?>
                      </td>
                      <td>
                        <?php echo $post["p_title"]; ?>
                      </td>
                      <td>
                        <?php echo $post['p_short_desc']; ?>
                      </td>
                      <td>
                        <?php echo $post["p_reg_date"]; ?>
                      </td>
                      <?php if (hdev_data::service('post_delete') || hdev_data::service('post_edit')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('post_edit')): ?>
                            <a href="<?php echo hdev_url::menu('edit/'.$post['p_id'].'/post') ?>">
                          <button type="button" class="ld_edit btn btn-success">
                            <span class="fas fa-edit"></span>
                            Edit
                          </button></a>
                          <?php endif ?>
                          <?php if (hdev_data::service('post_delete')): ?>
                          <?php 
                            if (hdev_data::get_attend($post["p_status"],'valid')) {
                          ?>
                          <button type="button" hash="<?php echo $tkn; ?>" data="<?php echo $reject; ?>" rel="external" p_title="<?php echo $post['p_title']; ?>" p_short_desc="<?php echo $post['p_short_desc']; ?>" class="btn btn-danger pst_delete" data-toggle="modal" data-target=".modal-delete"><i class="fas fa-trash"></i> Delete </button>
                          <?php
                            }else{
                              ?>
                          <a href="<?php echo hdev_url::menu($recover); ?>" rel="external" class="btn btn-secondary"><i class="fas fa-recycle"></i> Recover </a>
                          <?php
                            }
                           ?>
                           <?php endif ?>
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('post_reg')): ?>
<div class="modal fade modal-reg">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" align="center">Register New post</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" enctype="multipart/form-data"  id="post_reg" action="<?php echo hdev_url::menu('up'); ?>">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="post_reg">
              <div class="form-group">
              <label for="p_category">
                Post Category
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-cubes"></span>
                  </div>
                </div>
                <input type="text" name="p_category" id="p_category" class="form-control" placeholder="Post Category" required="true">
              </div>
            </div>
              <div class="form-group">
              <label for="p_pic">
                Post Picture
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-file-image"></span>
                  </div>
                </div>
                <input type="file" name="p_pic" id="reg_post_pic" class="form-control" placeholder="Post Picture" required="true">
              </div>
            </div>
              <div class="form-group">
              <label for="p_title">
                Post Title
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-tasks"></span>
                  </div>
                </div>
                <input type="text" name="p_title" id="p_title" class="form-control" placeholder="Post title" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="short_desc">
                Short description :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-tasks"></span>
                  </div>
                </div>
                <textarea type="text" id="short_desc" name="short_desc" class="form-control" placeholder="description to be  visible on post card" required="true"></textarea>
              </div>
            </div>
            <div class="form-group">
              <label for="Content">
                Main Content :
              </label>
              <div class="input-group mb-3">
              </div>
            </div>
            <textarea class="editor1" id="editor1" name="main_content"></textarea>
            <div class="form-group">
              <label for="p_atachment">
                Attachment :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-file-image"></span>
                  </div>
                </div>

                <input type="file" name="p_atachment" id="p_atachment" class="form-control" placeholder="Attachment" required="true">
              </div>
            </div>
              <div class="progress">
                  <div class="progress-bar bg-primary progress-bar-striped" role="progressbar" id="progress-bar">
                  </div>
                </div>
                <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="reg_post" onclick="CKupdate();$('#post_reg').submit();"><i class="fas fa-save"></i> Register post</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>
<?php if (hdev_data::service('post_delete')): ?> 
<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Delete The Following post?</th>
                </tr>
                <tr>
                  <td>Post Title : </td>
                  <td id="p_title"></td>
                </tr>
                <tr>
                  <td>Post Short description : </td>
                  <td id="p_short_desc"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="ld_del_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="post_delete" data="" hash=""><i class="fas fa-times-circle"></i> Delete This post</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>