<?php 
  $main_post = hdev_data::post(hdev_session::get('p_id'),['data']);
  $current_provider = $main_post['s_id'];
  //var_dump($main_id);
 ?>
<div id="app_data" class="mb-3">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">
                <div class="user-block border-right" style="margin-right: 10px;">
                  <span class="username"><a href="#"><?php echo "Posted By : ".hdev_data::provider($main_post['s_id'],['data'])['s_name']; ?></a></span>
                  <span class="description">Posted publicly - <?php echo hdev_data::time_ago($main_post['p_reg_date']); ?> - <?php echo $main_post['p_reg_date'] ?></span>
                  <span class="description">
                    <button type="button" class="btn btn-secondary btn-xs" data-toggle="modal" data-target=".modal-edit">
                        <span class="fas fa-user-alt"></span>
                     View Provider's Profile
                  </button>
                  </span>
                </div>
                <div style="margin-left: 2%;">
                  <h4 class="border-left"><?php echo $main_post['p_title']; ?></h4>
                </div>
                <!-- /.user-block -->
              </div>
              <div class="card-body table-responsive p-2">
                <p style="text-align: center;"><?php echo "Category : ".$main_post['c_id']; ?></p>
                <hr>
                <div>
                  <?php echo $main_post['p_content']; ?>
                </div>
                  <hr>
                <div>
                  <?php 
                    if (!is_null($main_post['p_attachment']) && !empty($main_post['p_attachment'])) {
                  ?>
                  <b>Attachment : <i><a ext_link="ok" href="<?php echo hdev_url::menu('dist/img/doc/'.$main_post['p_attachment']); ?>">[<?php echo $main_post['p_title']; ?>]</a></i></b>
                  <?php
                    }
                   ?>
                </div>
              </div>
              <div class="card-footer justify-content-between align-items-center" style="text-align: center;">
                <?php echo "Posted By : ".hdev_data::provider($main_post['s_id'],['data'])['s_name']; ?> - Posted publicly - <?php echo hdev_data::time_ago($main_post['p_reg_date']); ?> - <?php echo $main_post['p_reg_date'] ?>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<div class="modal fade modal-edit"> 
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Provider's Profile</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <input type="hidden" name="ref" value="user_edit">
            <div class="form-group">
              <label for="name">
                Names :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-alt"></span>
                  </div>
                </div>
                <i class="form-control"><?php echo hdev_data::provider($current_provider,['data'])["s_name"]; ?></i>
              </div>
            </div>
            <div class="form-group">
              <label for="Qualification">
                Qualification :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-secret"></span>
                  </div>
                </div>
                <i class="form-control"><?php echo hdev_data::provider($current_provider,['data'])["s_qualification"]; ?></i>
              </div>
            </div>  
            <div class="form-group">
              <label for="email">
                Email :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <span class="input-group-text">@</span>
                </div>
                <i class="form-control"><?php echo hdev_data::provider($current_provider,['data'])["s_email"]; ?></i>
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-envelope"></span>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <label for="tel">
                Telephone:
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-phone"></span>
                  </div>
                </div>
                <i class="form-control"><?php echo hdev_data::provider($current_provider,['data'])["s_tel"]; ?></i>
              </div>
            </div>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-danger btn-block" data-dismiss="modal" id="reg_close"><?php echo hdev_lang::on("form","close"); ?></button>
      </div>
      </form>
    </div>

    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>