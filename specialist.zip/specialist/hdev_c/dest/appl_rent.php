<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">Current registered Rent applications</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">
                  <?php if (hdev_data::service('houses_reg')): ?>
                  <button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fas fa-plus-circle"></i> Register new House</button>&nbsp;
                  <?php endif ?>
                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="table table-bordered table-hover table-striped text-nowrap" id="rasms_all_tables">
                  <thead class="border-top">
                    <tr>
                      <th>Reg no.</th>
                      <th>House</th> 
                      <th>Price</th> 
                      <th>Start Date</th> 
                      <th>End Date</th>
                      <th>Payment Status</th>
                      <th>Reg date</th>
                      <?php if (hdev_data::service('houses') || hdev_data::service('houses')): ?>
                      <th>Action</th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php /*var_dump(hdev_data::my_rent());*/ foreach (hdev_data::my_rent() AS $my_rent) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build = "ref:my_rent;id:".$my_rent['re_id'].";src:".$my_rent["re_status"].";from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $delete = "app/delete/".$tkn."/".hdev_data::encd($build);
                      $build2 = "ref:my_rent;id:".$my_rent['re_id'].";src:".$my_rent["re_status"].";from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $recover = "app/delete/".$tkn."/".hdev_data::encd($build2);
                    ?>

                    <tr>
                      <td>
                        <?php echo $my_rent["re_id"]; ?>
                      </td>
                      <td>
                        <?php 
                          $house = hdev_data::houses($my_rent['h_id'],['data']);
                          $pic =hdev_data::product_images($house['h_photos'])[0];
                          $pict = '<img src="'.$pic.'" class="img-size-50 img-square mr-3">';
                          echo $pict;
                        ?>
                      </td>
                      <td>
                        <?php echo $my_rent["re_price"]; ?>
                      </td>
                      <td>
                        <?php echo hdev_data::date($my_rent["start_date"],2); ?>
                      </td>
                      <td>
                        <?php echo hdev_data::date($my_rent["end_date"],2); ?>
                      </td>
                      <td>
                        <?php echo $my_rent["re_status"]; ?>    
                      </td>
                      <td>
                        <?php echo hdev_data::date($my_rent["re_reg_date"],"date_time"); ?>
                      </td>
                      <?php if (hdev_data::service('stud_delete') || hdev_data::service('stud_edit')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('stud_edit')): ?>
                          <button type="button" class="stud_edit btn btn-success" data-toggle="modal" data-target="#modal-edit">
                            <span class="fas fa-edit"></span>
                            Edit
                          </button>
                          <?php endif ?>
                          <?php if (hdev_data::service('stud_delete')): ?>
                          <?php 
                            if (hdev_data::get_attend($my_rent["l_status"],'valid')) {
                          ?>
                          <a href="<?php echo hdev_url::menu($delete); ?>" rel="external" class="btn btn-danger"><i class="fas fa-trash"></i> Delete </a>
                          <?php
                            }else{
                              ?>
                          <a href="<?php echo hdev_url::menu($recover); ?>" rel="external" class="btn btn-secondary"><i class="fas fa-recycle"></i> Recover </a>
                          <?php
                            }
                           ?>
                           <?php endif ?>
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>