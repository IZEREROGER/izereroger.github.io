<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">Current Providers Applications</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">

                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="table table-bordered table-hover table-striped text-nowrap" id="rasms_all_tables">
                  <thead class="border-top">
                    <tr>
                      <th>Reg no.</th>
                      <th>Names</th> 
                      <th>Gender</th>
                      <th>Qualification</th> 
                      <th>Tel</th> 
                      <th>Email</th>
                      <th>Reg date</th>
                      <?php if (hdev_data::service('provider_approve')): ?>
                      <th>Action</th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php  foreach (hdev_data::provider("",["approve"]) AS $provider) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build = "ref:provider_approve;id:".$provider['s_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $approve = hdev_data::encd("mod_close:#ld_app_close;app:".$tkn.";".$build);
                      $build2 = "ref:provider_reject;id:".$provider['s_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#ld_rej_close;app:".$tkn.";".$build2);
                    ?>

                    <tr>
                      <td>
                        <?php echo $provider["s_id"]; ?>
                      </td>
                      <td>
                        <?php echo $provider["s_name"]; ?>
                      </td>
                      <td>
                        <?php echo hdev_data::get_sex($provider["s_sex"]); ?>
                      </td>
                      <td>
                        <?php echo $provider["s_qualification"]; ?>
                      </td>
                      <td>
                        <?php echo $provider["s_tel"]; ?>
                      </td>
                      <td>
                        <?php echo $provider["s_email"]; ?>    
                      </td>
                      <td>
                        <?php echo $provider["s_reg_date"]; ?>
                      </td>
                      <?php if (hdev_data::service('provider_approve')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('provider_approve')) { ?>
                          <button hash="<?php echo $tkn; ?>" data="<?php echo $approve; ?>" rel="external" class="btn btn-success ld_approve" email="<?php echo $provider["s_email"]; ?>" name="<?php echo $provider["s_name"]; ?>" username="<?php echo $provider["s_qualification"]; ?>" data-toggle="modal" data-target=".modal-approve"><i class="fas fa-check-circle"></i> Approve </button>
                           <?php } ?>
                          <?php if (hdev_data::service('provider_reject')) { ?>
                          <button hash="<?php echo $tkn; ?>" data="<?php echo $reject; ?>" rel="external" class="btn btn-danger ld_reject" email="<?php echo $provider["s_email"]; ?>" name="<?php echo $provider["s_name"]; ?>" username="<?php echo $provider["s_qualification"]; ?>" data-toggle="modal" data-target=".modal-reject"><i class="fas fa-times"></i> Reject </button>
                           <?php } ?>
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('provider_approve')): ?> 
<div class="modal fade modal-approve" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To approve The Following Provider Application?</th>
                </tr>
                <tr>
                  <td>Name : </td>
                  <td id="provider_name"></td>
                </tr>
                <tr>
                  <td>Qualification : </td>
                  <td id="provider_username"></td>
                </tr>
                <tr>
                  <td>Email : </td>
                  <td id="provider_email"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#prof_edit_close">
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="ld_app_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-success" id="provider_approve" data="" hash=""><i class="fas fa-check-circle"></i> Approve This Provider Application</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('provider_reject')): ?> 
<div class="modal fade modal-reject" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Reject The Following Provider Application?</th>
                </tr>
                <tr>
                  <td>Name : </td>
                  <td id="provider_name"></td>
                </tr>
                <tr>
                  <td>Username : </td>
                  <td id="provider_username"></td>
                </tr>
                <tr>
                  <td>Email : </td>
                  <td id="provider_email"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="ld_rej_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="provider_reject" data="" hash=""><i class="fas fa-times-circle"></i> Reject This Provider Application</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>