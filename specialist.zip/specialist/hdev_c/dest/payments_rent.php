<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">Current Rent payments</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">
                  <?php if (hdev_data::service('houses_reg')): ?>
                    
                  <?php endif ?>
                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="table table-bordered table-hover table-striped text-nowrap" id="rasms_all_tables">
                  <thead class="border-top">
                    <tr>
                      <th>Reg no.</th>
                      <th>House</th>
                      <th>Tx_id</th> 
                      <th>Tx_ref</th> 
                      <th>Total Amount</th> 
                      <th>Payment Status</th>
                      <th>Payment Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach (hdev_data::my_payments() AS $my_pay) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build = "ref:my_rent;id:".$my_pay['re_id'].";src:".$my_pay["re_status"].";from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $delete = "app/delete/".$tkn."/".hdev_data::encd($build);
                      $build2 = "ref:my_rent;id:".$my_pay['re_id'].";src:".$my_pay["re_status"].";from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $recover = "app/delete/".$tkn."/".hdev_data::encd($build2);
                    ?>

                    <tr>
                      <td>
                        <?php echo $my_pay["o_id"]; ?>
                      </td>
                      <td>
                        <?php 
                          $house = hdev_data::houses($my_pay['h_id'],['data']);
                          $pic =hdev_data::product_images($house['h_photos'])[0];
                          $pict = '<img src="'.$pic.'" class="img-size-50 img-square mr-3">';
                          echo $pict;
                        ?>
                      </td>
                      <td>
                        <?php echo $my_pay["tx_id"]; ?>
                      </td>
                      <td>
                        <?php echo $my_pay["tx_ref"]; ?>
                      </td>
                      <td>
                        <?php echo $my_pay["p_price"]; ?> frw
                      </td>
                      <td>
                        <?php echo $my_pay["p_status"]; ?>    
                      </td>
                      <td>
                        <?php echo hdev_data::date($my_pay["p_date"],"date_time"); ?>
                      </td>
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>