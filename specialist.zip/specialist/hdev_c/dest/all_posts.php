<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">All Posts</h5>
              </div>
              <div class="card-body table-responsive p-2">
                <hr>
                <div class="card-group mb-30">
                  <?php 
                    if ($_GET) {
                      if (isset($_GET['q']) && !empty($_GET['q'])) {
                        $serch = $_GET['q'];
                        $var = hdev_data::post('',['search']);
                      }else{
                        $serch = "";
                        $var = hdev_data::post();
                      }
                    }else{
                      $serch = "";
                      $var = hdev_data::post();
                    } 
                    $counter = 0;
                    $counter_group = 1;
                    $maxer = (is_array($var)) ? count($var) : 0 ;
                    $maxer_rec = ($maxer%3);
                    $countt = 1;
                    foreach ($var as $post) {
                      $countt++;
                      $counter++;
                   ?>
                    <div class="border-secondary border-top border-right border-left border-bottom card">
                      
                          <div class="ribbon-wrapper">
                            <div class="ribbon bg-gradient-secondary" style="font-size: 10px;">
                              <?php echo $post['c_id']; ?>
                            </div>
                          </div> 
                            <img class="card-img-top" src="<?php echo hdev_url::menu('dist/img/doc/'.$post['p_pic']); ?>" alt="image" style="height: 300px !important;">
                          <div class="card-body">
                            <i style="text-align: center;" class="card-text">
                              <h5 class="" style="text-align: center;">
                                <?php echo $post['p_title'] ?>
                              </h5>
                            </i>
                            <p class="card-text btn btn-block btn-outline-secondary btn-flat" align="center">
                              <?php echo $post['p_short_desc']; ?>
                            </p>
                            <p class="card-text btn btn-block btn-outline-secondary btn-flat" align="center">
                              <?php echo hdev_data::time_ago($post['p_reg_date']); ?>
                            </p>
                              <div align="btn-group btn-block"> 
                                
                            <div class="card-footer" align="center">
                              <a href="<?php echo hdev_url::menu('view/'.$post['p_id'].'/post') ?>">
                              <button class="btn btn-secondary" type="button"><i class="fa fa-cubes"></i> View full post</button></a>
                            </div>                  
                              </div> 
                          </div> 
                        </div>
                <?php
                    if (($counter%3) == 0) {
                      echo '</div><div class="card-group mb-30">';
                      $counter_group++;
                    }
                  }
                 ?>
                <?php 
                  if ($counter == $maxer) {
                    //echo $maxer_rec;
                    if ($maxer_rec == 1) {
                      echo '<div class="card card-box"></div>';
                      echo '<div class="card card-box"></div>';
                    }elseif ($maxer_rec == 2) {
                      echo '<div class="card card-box"></div>';
                    }
                  }
                 ?>
                </div>
                <hr>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
