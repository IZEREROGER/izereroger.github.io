<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">Current registered tenant</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">
                  <?php if (hdev_data::service('tenant_reg')): ?>
                  <button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fas fa-plus-circle"></i> Register new Tenant</button>&nbsp;
                  <?php endif ?>
                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="table table-bordered table-hover table-striped text-nowrap" id="rasms_all_tables">
                  <thead class="border-top">
                    <tr>
                      <th>Reg no.</th>
                      <th>Name</th> 
                      <th>N. ID</th>
                      <th>Gender</th> 
                      <th>Username</th> 
                      <th>Telephone</th> 
                      <th>Email</th>
                      <th>Reg date</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach (hdev_data::tenant() AS $tenant) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build = "ref:tenant;id:".$tenant['t_id'].";src:".$tenant["t_status"].";from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $delete = "app/delete/".$tkn."/".hdev_data::encd($build);
                      $build2 = "ref:tenant;id:".$tenant['t_id'].";src:".$tenant["t_status"].";from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $recover = "app/delete/".$tkn."/".hdev_data::encd($build2);
                    ?>

                    <tr>
                      <td>
                        <?php echo $tenant["t_id"]; ?>
                      </td>
                      <td>
                        <?php echo $tenant["t_name"]; ?>
                      </td>
                      <td>
                        <?php echo $tenant["t_nid"]; ?>
                      </td>
                      <td>
                        <?php echo $tenant["t_sex"]; ?>
                      </td>
                      <td>
                        <?php echo $tenant["t_username"]; ?>
                      </td>
                      <td>
                        <?php echo $tenant["t_tel"]; ?>
                      </td>
                      <td>
                        <?php echo $tenant["t_email"]; ?>
                      </td>
                      <td>
                        <?php echo $tenant["t_reg_date"]; ?>
                      </td>
                      
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('tenant_reg')): ?>
<div class="modal fade modal-reg">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Register tenant</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" id="tenant_reg">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="tenant_reg"> 
            <div class="form-group">
              <label for="t_name">
                Tenant name :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-alt"></span>
                  </div>
                </div>
                <input type="text" name="t_name" id="t_name" class="form-control" placeholder="Tenant name" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="t_nid">
                Tenant National id :
              </label>
              <div class="input-group mb-0">
                
                <div class="input-group-prepend">
                  <div class="input-group-text" id="input_icon_id">
                    <span class="fas fa-user-tag"></span>
                  </div>
                </div>
                <input type="number" oninput="id_validator($(this).val(),'#input_icon_id','#message_box_id','#reg_tenant')" name="t_nid" id="t_nid" class="form-control" placeholder="Tenant National id" required="true">
              </div>
              <div class="input-group mb-3" id="message_box_id">

              </div>              
            </div>
            <div class="form-group">
              <label for="sex">
                Sex :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-friends"></span>
                  </div>
                </div>
                <select class="form-control" name="sex" id="sex">
                  <option value="">Select Sex</option>
                  <option value="m">Male</option>
                  <option value="f">Female</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label for="t_username">
                Tenant Username :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-tag"></span>
                  </div>
                </div>
                <input type="text" name="t_username" id="t_username" class="form-control" placeholder="Tenant Username" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="t_tel">
                Tenant Telephone :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-phone"></span>
                  </div>
                </div>
                <input type="text" name="t_tel" id="t_tel" class="form-control" placeholder="Tenant Telephone" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="t_email">
                Tenant Email :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fa">@</span>
                  </div>
                </div>
                <input type="email" name="t_email" id="t_email" class="form-control" placeholder="Tenant Email" required="true">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fa">@</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <label for="t_password">
                Tenant password :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-tag"></span>
                  </div>
                </div>
                <input type="text" id="t_password" name="t_password" class="form-control" placeholder="Tenant password" required="true">
              </div>
            </div>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="reg_tenant"><i class="fas fa-save"></i> Register Tenant</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>