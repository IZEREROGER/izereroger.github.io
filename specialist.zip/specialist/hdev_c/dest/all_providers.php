<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">All Providers</h5>
              </div>
              <div class="card-body table-responsive p-2">
                <hr>
                <div class="card-group mb-30">
                  <?php 
                    $var = hdev_data::provider();
                    $counter = 0;
                    $counter_group = 1;
                    $maxer = (is_array($var)) ? count($var) : 0 ;
                    $maxer_rec = ($maxer%3);
                    $countt = 1;
                    foreach ($var as $provider) {
                      $countt++;
                      $counter++;
                   ?>
                    <div class="border-secondary border-top border-right border-left border-bottom card">
                      
                          <div class="ribbon-wrapper">
                            <div class="ribbon bg-gradient-secondary" style="font-size: 10px;">
                              <?php echo "Provider"; ?>
                            </div>
                          </div> 
                          <div class="card-body">
                            <i style="text-align: center;" class="card-text">
                              <h5 class="" style="text-align: center;">
                                <?php echo $provider['s_name'] ?>
                              </h5>
                            </i>
                            <p class="card-text btn btn-block btn-outline-secondary btn-flat" align="center">
                              <?php echo $provider['s_email']; ?>
                            </p>
                              <div align="btn-group btn-block"> 
                                
                            <div class="card-footer" align="center">
                              <a href="<?php echo hdev_url::menu('provider/'.$provider['s_id'].'/post') ?>">
                              <button class="btn btn-secondary" type="button"><i class="fa fa-cubes"></i> View Provider's Posts</button></a>
                            </div>                  
                              </div> 
                          </div> 
                        </div>
                <?php
                    if (($counter%3) == 0) {
                      echo '</div><div class="card-group mb-30">';
                      $counter_group++;
                    }
                  }
                 ?>
                <?php 
                  if ($counter == $maxer) {
                    //echo $maxer_rec;
                    if ($maxer_rec == 1) {
                      echo '<div class="card card-box"></div>';
                      echo '<div class="card card-box"></div>';
                    }elseif ($maxer_rec == 2) {
                      echo '<div class="card card-box"></div>';
                    }
                  }
                 ?>
                </div>
                <hr>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
