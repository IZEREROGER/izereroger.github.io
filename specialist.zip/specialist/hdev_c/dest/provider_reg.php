<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">Current registered Provider</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">
                  <?php if (hdev_data::service('provider_reg')): ?>
                  <button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fas fa-plus-circle"></i> Register new Provider</button>&nbsp;
                  <?php endif ?>
                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="table table-bordered table-hover table-striped text-nowrap" id="rasms_all_tables">
                  <thead class="border-top">
                    <tr>
                      <th>Reg no.</th>
                      <th>Names</th> 
                      <th>Gender</th>
                      <th>Qualification</th> 
                      <th>Tel</th> 
                      <th>Email</th>
                      <th>Reg date</th>
                      <?php 
                      if (hdev_data::service('provider_edit') || hdev_data::service('provider_delete')): ?>
                      <th>Action</th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach (hdev_data::provider() AS $provider) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:provider_delete;id:".$provider['s_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#ld_del_close;app:".$tkn.";".$build2);
                    ?>

                    <tr>
                      <td>
                        <?php echo $provider["s_id"]; ?>
                      </td>
                      <td>
                        <?php echo $provider["s_name"]; ?>
                      </td>
                      <td>
                        <?php echo hdev_data::get_sex($provider["s_sex"]); ?>
                      </td>
                      <td>
                        <?php echo $provider["s_qualification"]; ?>
                      </td>
                      <td>
                        <?php echo $provider["s_tel"]; ?>
                      </td>
                      <td>
                        <?php echo $provider["s_email"]; ?>    
                      </td>
                      <td>
                        <?php echo $provider["s_reg_date"]; ?>
                      </td>
                      <?php if (hdev_data::service('provider_delete') || hdev_data::service('provider_edit')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('provider_edit')): ?>
                          <button type="button" class="ld_edit btn btn-success" data-toggle="modal" data-target=".modal-edit" l_l_name="<?php echo $provider["s_name"]; ?>" l_id="<?php echo $provider["s_id"]; ?>" l_l_name="<?php echo $provider["s_name"]; ?>" sex="<?php echo $provider["s_sex"]; ?>" l_l_username="<?php echo $provider["s_qualification"]; ?>" tel="<?php echo $provider["s_tel"]; ?>" email="<?php echo $provider["s_email"]; ?>">
                            <span class="fas fa-edit"></span>
                            Edit
                          </button>
                          <?php endif ?>
                          <?php if (hdev_data::service('provider_delete')): ?>
                          <?php 
                            if (hdev_data::get_attend($provider["s_status"],'valid')) {
                          ?>
                          <button type="button" hash="<?php echo $tkn; ?>" data="<?php echo $reject; ?>" rel="external" class="btn btn-danger ld_delete" email="<?php echo $provider["s_email"]; ?>" name="<?php echo $provider["s_name"]; ?>" username="<?php echo $provider["s_qualification"]; ?>" data-toggle="modal" data-target=".modal-delete"><i class="fas fa-trash"></i> Delete </button>
                          <?php
                            }else{
                              ?>
                          <a href="<?php echo hdev_url::menu($recover); ?>" rel="external" class="btn btn-secondary"><i class="fas fa-recycle"></i> Recover </a>
                          <?php
                            }
                           ?>
                           <?php endif ?>
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('provider_reg')): ?>
<div class="modal fade modal-reg">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Register New Provider</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" id="provider_reg">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="provider_reg">
              <div class="form-group">
              <label for="s_s_name">
                Provider name :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-alt"></span>
                  </div>
                </div>
                <input type="text" name="s_s_name" id="s_s_name" class="form-control" placeholder="Provider Name" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="sex">
                Sex :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-friends"></span>
                  </div>
                </div>
                <select class="form-control" name="sex" id="sex">
                  <option value="">Select Sex</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label for="s_s_qualification">
                Qualification :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-tag"></span>
                  </div>
                </div>
                <input type="text" id="s_s_qualification" name="s_s_qualification" class="form-control" placeholder="Qualification" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="email">
                Email :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span>@</span>
                  </div>
                </div>
                <input type="text" id="email" name="email" class="form-control" placeholder="Email" required="true">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fa fa-envelope"></span>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <label for="tel">
                Telephone :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-phone"></span>
                  </div>
                </div>
                <input type="text" id="tel" name="tel" class="form-control" placeholder="Telephone" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="pwd">
                Provider Password :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-lock"></span>
                  </div>
                </div>
                <input type="password" id="pwd" name="pwd" class="form-control" placeholder="Password" required="true">
              </div>
            </div>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="reg_provider"><i class="fas fa-save"></i> Register Provider</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>
<?php if (hdev_data::service('provider_edit')): ?>
<div class="modal fade modal-edit">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Provider info</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" id="provider_edit">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="s_id" id="e_s_sd">
              <input type="hidden" name="ref" value="provider_edit">
              <div class="form-group">
              <label for="e_s_s_name">
                Provider name :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-alt"></span>
                  </div>
                </div>
                <input type="text" name="s_s_name" id="e_s_s_name" class="form-control" placeholder="Provider Name" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="sex">
                Sex :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-friends"></span>
                  </div>
                </div>
                <select class="form-control" name="sex" id="e_sex">
                  <option value="">Select Sex</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label for="s_s_qualification">
                Qualification :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-tag"></span>
                  </div>
                </div>
                <input type="text" id="e_s_s_qualification" name="s_s_qualification" class="form-control" placeholder="Qualification" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="email">
                Email :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span>@</span>
                  </div>
                </div>
                <input type="text" id="e_email" name="email" class="form-control" placeholder="Email" required="true">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fa fa-envelope"></span>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <label for="tel">
                Telephone :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-phone"></span>
                  </div>
                </div>
                <input type="text" id="e_tel" name="tel" class="form-control" placeholder="Telephone" required="true">
              </div>
            </div>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#edit_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="edit_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="edit_provider"><i class="fas fa-save"></i> Edit Provider info</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>
<?php if (hdev_data::service('provider_delete')): ?> 
<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Delete The Following Provider Account?</th>
                </tr>
                <tr>
                  <td>Name : </td>
                  <td id="provider_name"></td>
                </tr>
                <tr>
                  <td>Qualification : </td>
                  <td id="provider_username"></td>
                </tr>
                <tr>
                  <td>Email : </td>
                  <td id="provider_email"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="ld_del_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="provider_delete" data="" hash=""><i class="fas fa-times-circle"></i> Delete This Provider Acount</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>