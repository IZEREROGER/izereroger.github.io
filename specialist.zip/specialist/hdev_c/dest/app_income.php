<?php 
$csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
  switch (hdev_log::fid()) {
    case 'admin':
      $url = hdev_url::menu('app/report/'.$tkn.'/admin-income');
      break;
    case 'agent':
      $url = hdev_url::menu('app/report/'.$tkn.'/admin-income');
      break;    
    default:
      // code...
      break;
  }
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">Current Application Income</h5>
              </div>
              <div class="card-body table-responsive p-2">
                <div class="row">
                  <div class="col-sm-12" align="center">
                    <a href="<?php echo $url ?>" ext_link="ok" target="_blank" class="btn btn-success"><span class="fa fa-print"></span> Print This Report</a><br>
                  </div>
                </div>
                <br>
                <div class="row">
                  <div class="col-sm-12" align="center">
                    <?php 
                      if ($_GET) {
                        if (isset($_GET['to']) && isset($_GET['from'])) {
                          $to = $_GET['to'];
                          $from = $_GET['from'];
                          if (!empty($to) && !empty($from)) {
                            $_SESSION['to'] = $to;
                            $_SESSION['from'] = $from;
                          }
                        }elseif (isset($_GET['all_rep'])) {
                          $_SESSION['to'] = "";
                          $_SESSION['from'] = "";
                        }
                      }
                      $from = (isset($_SESSION['from'])) ? $_SESSION['from'] : "" ;
                      $to = (isset($_SESSION['to'])) ? $_SESSION['to'] : "" ;
                      if (!empty($to) && !empty($from)) {
                        echo "viewing Transaction history from : ";
                        echo date_format(date_create($from),"d/m/Y"); 
                        echo " - to : "; 
                        echo date_format(date_create($to),"d/m/Y");
                        echo "<hr>"; 
                      }
                    ?> 
                  </div>
                </div>
                <form action="#">
                  <div class="row">
                    <div class="col-sm-4">
                      <div class="form-group">
                        <div class="input-group mb-1">
                          <div class="input-group-prepend">
                            <div class="input-group-text">
                              <span class="">From : </span>
                            </div>
                          </div>
                          <input type="date" name="from" id="t_username" class="form-control" placeholder="Agent Username" required="true">
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-4">
                      <div class="form-group">
                        <label for="to">
                        <div class="input-group mb-0">
                          <div class="input-group-prepend">
                            <div class="input-group-text">
                              <span>To : </span>
                            </div>
                          </div>
                          <input type="date" name="to" id="to" class="form-control">
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-4" align="right">
                      <button type="submit" class="btn btn-success">Generate report</button>
                      <a href="?all_rep=1" ext_link="ok" class="btn btn-primary">View all days report</a> 
                    </div>
                  </div>
                </form>
                <hr>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="table table-bordered table-hover table-striped text-nowrap" id="rasms_all_tables2">
                  <thead class="border-top">
                    <tr>
                      <th>Reg no.</th>
                      <th>House</th>
                      <th>Tx_id</th> 
                      <th>Total Amount</th> 
                      <th>Income Fee (10%)</th> 
                      <th>Payment Status</th>
                      <th>Payment Date</th>
                      <?php if (hdev_data::service('houses') || hdev_data::service('houses')): ?>
                      <th>Action</th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach (hdev_data::app_income() AS $income) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build = "ref:my_rent;id:".$income['re_id'].";src:".$income["re_status"].";from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $delete = "app/delete/".$tkn."/".hdev_data::encd($build);
                      $build2 = "ref:my_rent;id:".$income['re_id'].";src:".$income["re_status"].";from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $recover = "app/delete/".$tkn."/".hdev_data::encd($build2);
                    ?>

                    <tr>
                      <td>
                        <?php echo $income["o_id"]; ?>
                      </td>
                      <td>
                        <?php 
                          $house = hdev_data::houses($income['h_id'],['data']);
                          $pic =hdev_data::product_images($house['h_photos'])[0];
                          $pict = '<img src="'.$pic.'" class="img-size-50 img-square mr-3">';
                          echo $pict;
                        ?>
                      </td>
                      <td>
                        <?php echo $income["tx_id"]; ?>
                      </td>
                      <td>
                        <?php echo $income["p_price"]; ?> frw
                      </td>
                      <td>
                        <?php echo $income["inc"]; ?> frw
                      </td>
                      <td>
                        <?php echo $income["p_status"]; ?>    
                      </td>
                      <td>
                        <?php echo hdev_data::date($income["p_date"],"date_time"); ?>
                      </td>
                      <?php if (hdev_data::service('stud_delete') || hdev_data::service('stud_edit')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('stud_edit')): ?>
                          <button type="button" class="stud_edit btn btn-success" data-toggle="modal" data-target="#modal-edit">
                            <span class="fas fa-edit"></span>
                            Edit
                          </button>
                          <?php endif ?>
                          <?php if (hdev_data::service('stud_delete')): ?>
                          <?php 
                            if (hdev_data::get_attend($income["l_status"],'valid')) {
                          ?>
                          <a href="<?php echo hdev_url::menu($delete); ?>" rel="external" class="btn btn-danger"><i class="fas fa-trash"></i> Delete </a>
                          <?php
                            }else{
                              ?>
                          <a href="<?php echo hdev_url::menu($recover); ?>" rel="external" class="btn btn-secondary"><i class="fas fa-recycle"></i> Recover </a>
                          <?php
                            }
                           ?>
                           <?php endif ?>
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
              <div class="card-footer">
                <div align="center" class="text-success">
                  <h3>Total system income : <?php echo hdev_data::app_income("",['1','sum','']); ?> Frw</h3>
                </div>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>