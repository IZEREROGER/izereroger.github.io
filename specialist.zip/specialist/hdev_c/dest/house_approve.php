<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">Current Houses Registration Appications</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">

                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="table table-bordered table-hover table-striped text-nowrap" id="rasms_all_tables">
                  <thead class="border-top">
                    <tr>
                      <th>Reg no.</th>
                      <th>Photo</th>  
                      <th>Price</th>
                      <th>Landlord Name</th>
                      <th>Landlord Tell</th> 
                      <th>Reg date</th>
                      <?php if (hdev_data::service('house_approve')): ?>
                      <th>Action</th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach (hdev_data::houses("",["approve"]) AS $houses) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build = "ref:houses;id:".$houses['h_id'].";src:".$houses["h_status"].";from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $delete = "app/delete/".$tkn."/".hdev_data::encd($build);
                      $build2 = "ref:houses;id:".$houses['h_id'].";src:".$houses["h_status"].";from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $recover = "app/delete/".$tkn."/".hdev_data::encd($build2);
                      $land_lord = hdev_data::land_lord($houses['l_id'],['data']);
                    ?>

                    <tr>
                      <td>
                        <?php echo $houses["h_id"]; ?>
                      </td>
                      <td>
                        <?php 
                          $pic = hdev_data::product_images($houses["h_photos"])[0];
                          $pict = '<img src="'.$pic.'" class="img-size-50 img-square mr-3">';
                          echo $pict;
                        ?>
                      </td>
                      <td>
                        <?php echo $houses["h_price"]; ?> Frw
                      </td>
                      <td>
                        <?php echo $land_lord["l_name"]; ?>
                      </td>
                      <td>
                        <?php echo $land_lord["l_tel"]; ?>
                      </td>
                      <td>
                        <?php echo $houses["h_reg_date"]; ?>
                      </td>
                      <?php if (hdev_data::service('house_approve')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('house_approve')) { ?>
                          <a href="<?php echo hdev_url::menu('r/house_view/'.hdev_data::encd($houses['h_id'])); ?>" class="btn btn-success" >
                            <span class="fas fa-eye"></span>
                            Approve/Reject
                          </a>
                          <?php } ?>
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>