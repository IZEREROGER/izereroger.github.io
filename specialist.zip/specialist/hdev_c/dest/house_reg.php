<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">Current registered Houses</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">
                  <?php if (hdev_data::service('houses_reg')): ?>
                  <button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fas fa-plus-circle"></i> Register new House</button>&nbsp;
                  <?php endif ?>
                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="table table-bordered table-hover table-striped text-nowrap" id="rasms_all_tables">
                  <thead class="border-top">
                    <tr>
                      <th>Reg no.</th>
                      <th>Photo</th>  
                      <th>Price</th>
                      <th>Landlord Name</th>
                      <th>Landlord Tell</th> 
                      <th>Reg date</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach (hdev_data::houses() AS $houses) { 
                      $land_lord = hdev_data::land_lord($houses['l_id'],['data']);
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:house_delete;id:".$houses['h_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $delete = hdev_data::encd("mod_close:#hs_rej_close;app:".$tkn.";".$build2);
                    ?>

                    <tr>
                      <td>
                        <?php echo $houses["h_id"]; ?>
                      </td>
                      <td>
                        <?php 
                          $pic = hdev_data::product_images($houses["h_photos"])[0];
                          $pict = '<img src="'.$pic.'" class="img-size-50 img-square mr-3">';
                          echo $pict;
                        ?>
                      </td>
                      <td>
                        <?php echo $houses["h_price"]; ?> Frw
                      </td>
                      <td>
                        <?php echo $land_lord["l_name"]; ?>
                      </td>
                      <td>
                        <?php echo $land_lord["l_tel"]; ?>
                      </td>
                      <td>
                        <?php echo $houses["h_reg_date"]; ?>
                      </td>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <a href="<?php echo hdev_url::menu('r/house_view/'.hdev_data::encd($houses['h_id'])); ?>" class="house_edit btn btn-info" data-toggle="modal" data-target="#modal-edit">
                            <span class="fas fa-eye"></span>
                            View
                          </a>
                          <?php if (hdev_data::service('house_edit')): ?>
                            <a class="house_edit btn btn-success" href="<?php echo hdev_url::menu('prod_edit/'.hdev_data::encd(trim($houses['h_id']))) ?>">
                                <span class="fas fa-edit"></span>
                                Edit
                            </a>
                          <?php endif ?>
                          <?php if (hdev_data::service('house_delete')) { ?>
                          <button hash="<?php echo $tkn; ?>" data="<?php echo $delete; ?>" rel="external" class="btn btn-danger hs_delete" hs_id="<?php echo $houses['h_id'] ?>" email="<?php echo $land_lord["l_email"]; ?>" name="<?php echo $land_lord["l_name"]; ?>" username="<?php echo $land_lord["l_username"]; ?>" data-toggle="modal" data-target=".modal-reject"><i class="fas fa-trash"></i> Delete </button>
                           <?php } ?>
                        </div>
                      </td>
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('house_delete')): ?> 
<div class="modal fade modal-reject" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Delete This House?</th>
                </tr>
                <tr>
                  <td>House Id</td>
                  <td id="hs_id"> :</td>
                </tr>
                <tr>
                  <td>Landlord Name : </td>
                  <td id="land_lord_name"></td>
                </tr>
                <tr>
                  <td>Landlord Username : </td>
                  <td id="land_lord_username"></td>
                </tr>
                <tr>
                  <td>Landlord Email : </td>
                  <td id="land_lord_email"></td>
                </tr>
                <tr>
                  <td>Landlord Tel : </td>
                  <td id="land_lord_email"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="hs_rej_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="house_delete" hash="<?php echo $tkn; ?>" data="<?php echo $reject; ?>"><i class="fas fa-trash"></i> Delete This House</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('houses_reg')): ?>
<div class="modal fade modal-reg">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Register New House</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>" id="reg_close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <form method="post" id="houses_reg" action="<?php echo hdev_url::menu("up"); ?>" enctype="multipart/form-data">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="houses_reg">
              <input type="hidden" name="mod_close" value="#reg_close">
                <div class="bs-stepper" step_val="ok">
                  <div class="bs-stepper-header" role="tablist">
                    <!-- your steps here -->
                    <div class="step" data-target="#land-lord">
                      <button type="button" class="step-trigger" role="tab" aria-controls="logins-part" id="land-lord-trigger">
                        <span class="bs-stepper-circle">1</span>
                        <span class="bs-stepper-label">House information</span>
                      </button>
                    </div>
                    <div class="line"></div>
                    <div class="step" data-target="#photo-part">
                      <button type="button" class="step-trigger" role="tab" aria-controls="photo-part" id="photo-part-trigger">
                        <span class="bs-stepper-circle">2</span>
                        <span class="bs-stepper-label">House Photos</span>
                      </button>
                    </div>
                    <div class="step" data-target="#description-part">
                      <button type="button" class="step-trigger" role="tab" aria-controls="description-part" id="description-part-trigger">
                        <span class="bs-stepper-circle">2</span>
                        <span class="bs-stepper-label">House Description</span>
                      </button>
                    </div>
                    <div class="line"></div>
                    <div class="step" data-target="#information-part">
                      <button type="button" class="step-trigger" role="tab" aria-controls="information-part" id="information-part-trigger">
                        <span class="bs-stepper-circle">3</span>
                        <span class="bs-stepper-label">House Location</span>
                      </button>
                    </div>
                  </div>
                  <div class="bs-stepper-content">
                    <!-- your steps content here -->
                    <div id="land-lord" class="content" role="tabpanel" aria-labelledby="land-lord-trigger">
                      <div class="row">
                        <div class="col-sm-6 border-right">
                          <div class="form-group">
                            <label for="l_id">
                              House Category :
                            </label>
                            <div class="input-group mb-3">
                              <div class="input-group-prepend">
                                <div class="input-group-text">
                                  <span class="fas fa-th-list"></span>
                                </div>
                              </div>
                              <select type="text" name="c_id" id="c_id" class="form-control">
                                <option value="">Select Category</option>
                                <?php foreach (hdev_data::house_category() as $cat) {
                                ?>
                                <option value="<?php echo $cat['c_id']; ?>"><?php echo $cat['c_name']; ?></option>
                                <?php
                                } ?>
                              </select>
                            </div>
                          </div> 
                          <?php 
                            if (hdev_log::fid() != "land_lord") {
                          ?>
                          <div class="form-group">
                            <label for="l_id">
                              LandLord Reg No.:
                            </label>
                            <div class="input-group mb-3">
                              <div class="input-group-prepend">
                                <div class="input-group-text">
                                  <span class="fas fa-user-secret"></span>
                                </div>
                              </div>
                              <input type="text" name="l_id" id="l_id" class="form-control" placeholder="LandLord Reg No." required="true" oninput="land_lord($(this).val(),'hs_reg');">
                            </div>
                          </div>  
                          <?php }else{ ?>
                            <input type="hidden" name="l_id" id="l_id" class="form-control" placeholder="LandLord Reg No." required="true" value="<?php echo hdev_log::uid() ?>">
                          <?php } ?>
                          <div class="form-group">
                            <label for="h_price">
                              House Price / month :
                            </label>
                            <div class="input-group mb-3">
                              <div class="input-group-prepend">
                                <div class="input-group-text">
                                  <span class="fas fa-coins"></span>
                                </div>
                              </div>
                              <input type="text" name="h_price" id="h_price" class="form-control" placeholder="House Price" required="true">
                            </div>
                          </div>                         
                        </div>
                        <?php 
                          if (hdev_log::fid() != "land_lord") {
                        ?>
                        <div class="col-sm-6 border-left">
                          <table class="table border-bottom" id="hs_reg">
                            <tr>
                              <th class="bg-secondary" colspan="2"><span id="hash" hash="<?php echo $tkn; ?>"></span>Landlord Info</th>
                            </tr>
                            <tr>
                              <td>Names</td>
                              <td> : <span id="name" class="ldd"></span></td>
                            </tr>
                            <tr>
                              <td>Usename</td>
                              <td> : <span id="username" class="ldd"></span></td>
                            </tr>
                            <tr>
                              <td>Email</td>
                              <td> : <span id="email" class="ldd"></span></td>
                            </tr>
                            <tr>
                              <td>Tell</td>
                              <td> : <span id="tel" class="ldd"></span></td>
                            </tr>
                          </table>
                        </div>
                        <?php
                          }
                         ?>
                        
                      </div>
                      <div class="row">
                        <div class="col-sm-12">
                          <button type="button" class="btn btn-primary" onclick="mr_step('next');">Next</button>
                        </div>
                      </div>
                    </div>
                    <div id="photo-part" class="content" role="tabpanel" aria-labelledby="photo-part-trigger">
                      <div class="form-group">
                        <label for="h_photo_in">
                          House Photos :
                        </label>
                        <div class="input-group mb-3">
                          
                          <input type="file" name="h_photo[]" id="h_photo_in" class="form-control"multiple="true">
                        </div>
                      </div>
                      <button type="button" class="btn btn-primary" onclick="mr_step('previous');">Previous</button>
                      <button type="button" class="btn btn-primary" onclick="mr_step('next',2);">Next</button>
                    </div>
                    <div id="description-part" class="content" role="tabpanel" aria-labelledby="description-part-trigger">
                      <h3>House Description</h3>
                       <textarea name="h_description" class="form-control"></textarea>
                      <button type="button" class="btn btn-primary" onclick="mr_step('next',1);">Previous</button>
                      <button type="button" class="btn btn-primary" onclick="mr_step('next',3);">Next</button>
                    </div>
                    <div id="information-part" class="content" role="tabpanel" aria-labelledby="information-part-trigger">
                      <div class="row">
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label for="province">
                              Province :
                            </label>
                            <div class="input-group mb-3">
                              <div class="input-group-prepend">
                                <div class="input-group-text" province-ico="fas fa-map-marker-alt">
                                  <span class="fas fa-map-marker-alt"></span>
                                </div>
                              </div>
                              <select id="province" class="form-control" required="true" onchange="mr_locator('district',$(this).val())">
                                <?php echo hdev_data::locations("province"); ?>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label for="h_location">
                              District :
                            </label>
                            <div class="input-group mb-3">
                              <div class="input-group-prepend">
                                <div class="input-group-text" district-ico="fas fa-map-marker-alt">
                                  <span class="fas fa-map-marker-alt" ></span>
                                </div>
                              </div>
                              <select id="district" class="form-control" required="true" onchange="mr_locator('sector',$('#province').val(),$(this).val())">
                                <option value="">Select</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-sm-6">
                          <div class="form-group">
                            <label for="h_location">
                              Sector :
                            </label>
                            <div class="input-group mb-3">
                              <div class="input-group-prepend">
                                <div class="input-group-text" sector-ico="fas fa-map-marker-alt">
                                  <span class="fas fa-map-marker-alt" ></span>
                                </div>
                              </div>
                              <select id="sector" class="form-control" required="true" onchange="mr_locator('cell',$('#province').val(),$('#district').val(),$(this).val())">
                                <option value="">Select</option>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                              <label for="h_location">
                                Cell :
                              </label>
                              <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                  <div class="input-group-text" cell-ico="fas fa-map-marker-alt">
                                    <span class="fas fa-map-marker-alt" ></span>
                                  </div>
                                </div>
                                <select id="cell" class="form-control" required="true" onchange="mr_locator('village',$('#province').val(),$('#district').val(),$('#sector').val(),$(this).val())">
                                  <option value="">Select</option>
                                </select>
                              </div>
                            </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-sm-12">
                          <div class="form-group">
                            <label for="h_location">
                              Village :
                            </label>
                            <div class="input-group mb-3">
                              <div class="input-group-prepend">
                                <div class="input-group-text" village-ico="fas fa-map-marker-alt">
                                  <span class="fas fa-map-marker-alt" ></span>
                                </div>
                              </div>
                              <select id="village" name="h_location" class="form-control" required="true">
                                <option value="">Select</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <button type="button" class="btn btn-primary" onclick="mr_step('next',2);">Previous</button>
                      <button type="submit" class="btn btn-primary" id="reg_houses"><i class="fas fa-save"></i> Register House</button>
                    </div>
                  </div>
                </div>
            </form>
           <div class="card">
              <div class="card-body register-card-body table-responsive p-3">
                <div class="progress">
                  <div class="progress-bar bg-primary progress-bar-striped" role="progressbar" id="progress-bar">
                  </div>
                </div>
                <div class="wait" align="center"></div>
              </div>
              <!-- /.form-box -->
            </div><!-- /.card -->
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>