<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">Current registered Agents</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">
                  <?php if (hdev_data::service('agent_reg')): ?>
                  <button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fas fa-plus-circle"></i> Register new Agent</button>&nbsp;
                  <?php endif ?>
                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="table table-bordered table-hover table-striped text-nowrap" id="rasms_all_tables">
                  <thead class="border-top">
                    <tr>
                      <th>Reg no.</th>
                      <th>Name</th> 
                      <th>N. ID</th>
                      <th>Gender</th> 
                      <th>Username</th> 
                      <th>Telephone</th> 
                      <th>Email</th>
                      <th>Reg date</th>
                      <?php if (hdev_data::service('agent_edit') || hdev_data::service('agent_delete')): ?>
                      <th>Action</th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach (hdev_data::get_agent() AS $agent) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:agent_delete;id:".$agent['a_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#ag_del_close;app:".$tkn.";".$build2);

                    ?>

                    <tr>
                      <td>
                        <?php echo $agent["a_id"]; ?>
                      </td>
                      <td>
                        <?php echo $agent["a_name"]; ?>
                      </td>
                      <td>
                        <?php echo $agent["a_nid"]; ?>
                      </td>
                      <td>
                        <?php echo $agent["a_sex"]; ?>
                      </td>
                      <td>
                        <?php echo $agent["a_username"]; ?>
                      </td>
                      <td>
                        <?php echo $agent["a_tel"]; ?>
                      </td>
                      <td>
                        <?php echo $agent["a_email"]; ?>
                      </td>
                      <td>
                        <?php echo $agent["a_reg_date"]; ?>
                      </td>
                      <?php if (hdev_data::service('agent_delete') || hdev_data::service('agent_edit')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('agent_edit')): ?>
                          <button type="button" class="ag_edit btn btn-success" data-toggle="modal" data-target=".modal-edit" a_id="<?php echo $agent["a_id"]; ?>" e_t_name="<?php echo $agent["a_name"]; ?>" e_t_nid="<?php echo $agent["a_nid"]; ?>" e_sex="<?php echo $agent["a_sex"]; ?>" e_t_username="<?php echo $agent["a_username"]; ?>" e_t_tel="<?php echo $agent["a_tel"]; ?>" e_t_email="<?php echo $agent["a_email"]; ?>">
                            <span class="fas fa-edit"></span>
                            Edit
                          </button>
                          <?php endif ?>
                          <?php if (hdev_data::service('agent_delete')): ?>
                          <button type="button" hash="<?php echo $tkn; ?>" data="<?php echo $reject; ?>" rel="external" class="btn btn-danger ag_delete" email="<?php echo $agent["a_email"]; ?>" name="<?php echo $agent["a_name"]; ?>" username="<?php echo $agent["a_username"]; ?>" data-toggle="modal" data-target=".modal-delete"><i class="fas fa-trash"></i> Delete </button>
                          <?php endif ?>
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('agent_reg')): ?>
<div class="modal fade modal-reg">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Register Agent</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" id="agent_reg">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="agent_reg"> 
            <div class="form-group">
              <label for="t_name">
                Agent name :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-alt"></span>
                  </div>
                </div>
                <input type="text" name="t_name" id="t_name" class="form-control" placeholder="Agent name" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="t_nid">
                Agent National id :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-tag"></span>
                  </div>
                </div>
                <input type="text" name="t_nid" id="t_nid" class="form-control" placeholder="Agent National id" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="sex">
                Sex :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-friends"></span>
                  </div>
                </div>
                <select class="form-control" name="sex" id="sex">
                  <option value="">Select Sex</option>
                  <option value="m">Male</option>
                  <option value="f">Female</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label for="t_username">
                Agent Username :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-alt"></span>
                  </div>
                </div>
                <input type="text" name="t_username" id="t_username" class="form-control" placeholder="Agent Username" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="t_tel">
                Agent Telephone :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-phone"></span>
                  </div>
                </div>
                <input type="text" name="t_tel" id="t_tel" class="form-control" placeholder="Agent Telephone" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="t_email">
                Agent Email :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fa">@</span>
                  </div>
                </div>
                <input type="email" name="t_email" id="t_email" class="form-control" placeholder="Agent Email" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="t_password">
                Agent password :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-lock"></span>
                  </div>
                </div>
                <input type="password" id="t_password" name="t_password" class="form-control" placeholder="Agent password" required="true">
              </div>
            </div>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="reg_agent"><i class="fas fa-save"></i> Register agent</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>
<?php if (hdev_data::service('agent_edit')): ?>
<div class="modal fade modal-edit">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Agent Info</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" id="agent_edit">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="a_id" id="a_id" value="agent_edit"> 
              <input type="hidden" name="ref" value="agent_edit"> 
            <div class="form-group">
              <label for="t_name">
                Agent name :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-alt"></span>
                  </div>
                </div>
                <input type="text" name="t_name" id="e_t_name" class="form-control" placeholder="Agent name" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="t_nid">
                Agent National id :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-tag"></span>
                  </div>
                </div>
                <input type="text" name="t_nid" id="e_t_nid" class="form-control" placeholder="Agent National id" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="sex">
                Sex :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-friends"></span>
                  </div>
                </div>
                <select class="form-control" name="sex" id="e_sex">
                  <option value="">Select Sex</option>
                  <option value="m">Male</option>
                  <option value="f">Female</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label for="t_username">
                Agent Username :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-user-alt"></span>
                  </div>
                </div>
                <input type="text" name="t_username" id="e_t_username" class="form-control" placeholder="Agent Username" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="t_tel">
                Agent Telephone :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-phone"></span>
                  </div>
                </div>
                <input type="text" name="t_tel" id="e_t_tel" class="form-control" placeholder="Agent Telephone" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="t_email">
                Agent Email :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fa">@</span>
                  </div>
                </div>
                <input type="email" name="t_email" id="e_t_email" class="form-control" placeholder="Agent Email" required="true">
              </div>
            </div>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#edit_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="edit_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="edit_agent"><i class="fas fa-save"></i> Edit agent info</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>
<?php if (hdev_data::service('agent_delete')): ?> 
<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Delete The Following Agent Account?</th>
                </tr>
                <tr>
                  <td>Name : </td>
                  <td id="agent_name"></td>
                </tr>
                <tr>
                  <td>Username : </td>
                  <td id="agent_username"></td>
                </tr>
                <tr>
                  <td>Email : </td>
                  <td id="agent_email"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="ag_del_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="agent_delete" data="" hash=""><i class="fas fa-times-circle"></i> Delete This Agent Acount</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>