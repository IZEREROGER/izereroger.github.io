<?php 
  $main_post = hdev_data::post(hdev_session::get('p_id'),['data']);
  //var_dump($main_id);
 ?>
<div id="app_data" class="mb-3">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">Modify post : "<?php echo $main_post['p_title']; ?>"</h5>
              </div>
              <div class="card-body table-responsive p-2">
                <form method="post" enctype="multipart/form-data"  id="post_reg" action="<?php echo hdev_url::menu('up'); ?>">
                  <?php 
                    $csrf = new CSRF_Protect();
                    $csrf->echoInputField();
                  ?>
                  <input type="hidden" name="p_id" value="<?php echo $main_post['p_id'] ?>">
                  <input type="hidden" name="ref" value="post_edit">
                  <input type="hidden" id="edit_loader" value="enabled">
                  <div class="form-group">
                  <label for="p_category">
                    Post Category
                  </label>
                  <div class="input-group mb-3">
                    
                    <div class="input-group-prepend">
                      <div class="input-group-text">
                        <span class="fas fa-cubes"></span>
                      </div> 
                    </div>
                    <input type="text" name="p_category" id="p_category" class="form-control" placeholder="Post Category" required="true" value="<?php echo $main_post['c_id']; ?>">
                  </div>
                </div>
                  <div class="form-group">
                  <label for="p_pic">
                    Post Picture
                  </label>
                  <div class="input-group mb-3">
                    
                    <div class="input-group-prepend">
                      <div class="input-group-text">
                        <span class="fas fa-file-image"></span>
                      </div>
                    </div>
                    <input type="file" name="p_pic" id="reg_post_pic" class="form-control" placeholder="Post Picture" required="true">
                  </div>
                </div>
                  <div class="form-group">
                  <label for="p_title">
                    Post Title
                  </label>
                  <div class="input-group mb-3">
                    
                    <div class="input-group-prepend">
                      <div class="input-group-text">
                        <span class="fas fa-tasks"></span>
                      </div>
                    </div>
                    <input type="text" name="p_title" id="p_title" class="form-control" placeholder="Post title" required="true" value="<?php echo $main_post['p_title']; ?>">
                  </div>
                </div>
                <div class="form-group">
                  <label for="short_desc">
                    Short description :
                  </label>
                  <div class="input-group mb-3">
                    
                    <div class="input-group-prepend">
                      <div class="input-group-text">
                        <span class="fas fa-tasks"></span>
                      </div>
                    </div>
                    <textarea type="text" id="short_desc" name="short_desc" class="form-control" placeholder="description to be  visible on post card" required="true"><?php echo $main_post['p_short_desc']; ?></textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label for="Content">
                    Main Content :
                  </label>
                  <div class="input-group mb-3">
                  </div>
                </div>
                <textarea class="editor1" id="editor1" name="main_content"><?php echo $main_post['p_content']; ?></textarea>
                <div class="form-group">
                  <label for="p_atachment">
                    Attachment :
                  </label>
                  <div class="input-group mb-3">
                    
                    <div class="input-group-prepend">
                      <div class="input-group-text">
                        <span class="fas fa-file-image"></span>
                      </div>
                    </div>

                    <input type="file" name="p_atachment" id="p_atachment" class="form-control" placeholder="Attachment" required="true">
                  </div>
                </div>
                  <div class="progress">
                      <div class="progress-bar bg-primary progress-bar-striped" role="progressbar" id="progress-bar">
                      </div>
                    </div>
                    <div class="wait" align="center"></div>
                <input type="hidden" name="mod_close" value="#reg_close">
                </form>
              </div>
              <div class="card-footer justify-content-between align-items-center">
                <!--<button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close">
                  <span class="fa fa-times"></span> 
                  <?php echo hdev_lang::on("form","close"); ?>
                </button>-->
                <button type="button" class="btn btn-primary btn-block" id="reg_post" onclick="CKupdate();$('#post_reg').submit();">
                  <i class="fas fa-save"></i> Save updated Post
                </button>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>