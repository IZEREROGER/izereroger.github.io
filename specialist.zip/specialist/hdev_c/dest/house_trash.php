<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">Current Deleted Houses</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">
                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="table
                   table-bordered table-hover table-striped text-nowrap" id="rasms_all_tables">
                  <thead class="border-top">
                    <tr>
                      <th>Reg no.</th>
                      <th>Photo</th>  
                      <th>Price</th>
                      <th>Landlord Name</th>
                      <th>Landlord Tell</th> 
                      <th>Reg date</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach (hdev_data::houses("",['delete']) AS $houses) { 
                      $land_lord = hdev_data::land_lord($houses['l_id'],['data']);
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:house_recover;id:".$houses['h_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $delete = hdev_data::encd("mod_close:#hs_rej_close;app:".$tkn.";".$build2);
                    ?>

                    <tr>
                      <td>
                        <?php echo $houses["h_id"]; ?>
                      </td>
                      <td>
                        <?php 
                          $pic = hdev_data::product_images($houses["h_photos"])[0];
                          $pict = '<img src="'.$pic.'" class="img-size-50 img-square mr-3">';
                          echo $pict;
                        ?>
                      </td>
                      <td>
                        <?php echo $houses["h_price"]; ?> Frw
                      </td>
                      <td>
                        <?php echo $land_lord["l_name"]; ?>
                      </td>
                      <td>
                        <?php echo $land_lord["l_tel"]; ?>
                      </td>
                      <td>
                        <?php echo $houses["h_reg_date"]; ?>
                      </td>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('house_recover')) { ?>
                          <button hash="<?php echo $tkn; ?>" data="<?php echo $delete; ?>" rel="external" class="btn btn-secondary hs_delete" hs_id="<?php echo $houses['h_id'] ?>" email="<?php echo $land_lord["l_email"]; ?>" name="<?php echo $land_lord["l_name"]; ?>" username="<?php echo $land_lord["l_username"]; ?>" data-toggle="modal" data-target=".modal-reject"><i class="fas fa-recycle"></i> Recover </button>
                           <?php } ?>
                        </div>
                      </td>
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('house_recover')): ?> 
<div class="modal fade modal-reject" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Recover This House?</th>
                </tr>
                <tr>
                  <td>House Id</td>
                  <td id="hs_id"> :</td>
                </tr>
                <tr>
                  <td>Landlord Name : </td>
                  <td id="land_lord_name"></td>
                </tr>
                <tr>
                  <td>Landlord Username : </td>
                  <td id="land_lord_username"></td>
                </tr>
                <tr>
                  <td>Landlord Email : </td>
                  <td id="land_lord_email"></td>
                </tr>
                <tr>
                  <td>Landlord Tel : </td>
                  <td id="land_lord_email"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="hs_rej_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-success" id="house_delete" hash="<?php echo $tkn; ?>" data="<?php echo $recover; ?>"><i class="fas fa-recycle"></i> Recover This House</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>