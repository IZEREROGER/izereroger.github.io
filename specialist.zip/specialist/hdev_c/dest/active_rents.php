<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">Current Active Rents</h5>
              </div>
              <div class="card-body p-2 table-responsive">
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="table table-bordered table-hover table-striped text-nowrap" id="rasms_all_tables">
                  <thead class="border-top">
                    <tr>
                      <th>Reg no.</th>
                      <th>House</th>
                      <th>Start Date</th> 
                      <th>End Date</th> 
                      <th>Total Amount</th> 
                      <th>Tx_id</th>
                      <th>Payment Date</th>
                      <?php if (hdev_log::fid()=="tenant" && hdev_data::service("houses_rent")): ?>
                      <th>Action</th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php /*var_dump(hdev_data::my_books());*/ foreach (hdev_data::my_books() AS $my_pay) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build = "ref:my_rent;id:".$my_pay['re_id'].";src:".$my_pay["re_status"].";from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $delete = "app/delete/".$tkn."/".hdev_data::encd($build);
                      $build2 = "ref:my_rent;id:".$my_pay['re_id'].";src:".$my_pay["re_status"].";from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $recover = "app/delete/".$tkn."/".hdev_data::encd($build2);
                    ?>

                    <tr>
                      <td>
                        <?php echo $my_pay["o_id"]; ?>
                      </td>
                      <td>
                        <?php 
                          $house = hdev_data::houses($my_pay['h_id'],['data']);
                          $pic =hdev_data::product_images($house['h_photos'])[0];
                          $pict = '<img src="'.$pic.'" class="img-size-50 img-square mr-3">';
                          echo $pict;
                        ?>
                      </td>
                      <td>
                        <?php echo hdev_data::date($my_pay["start_date"],2); ?>
                      </td>
                      <td>
                        <?php echo hdev_data::date($my_pay["end_date"],2); ?>
                      </td>
                      <td>
                        <?php echo $my_pay["p_price"]; ?> frw
                      </td>
                      <td>
                        <?php echo $my_pay["tx_id"]; ?>   
                      </td>
                      <td>
                        <?php echo hdev_data::date($my_pay["p_date"],"date_time"); ?>
                      </td>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php $up = hdev_log::fid(); if ($up=="tenant" && hdev_data::service("houses_rent")) { ?>
                            <button class="btn btn-primary btn-block" onclick="$('#o_id').val('<?php echo hdev_data::encd($my_pay['o_id']); ?>');$('#start_date').val('<?php echo hdev_data::encd($my_pay['end_date']); ?>');$('#ref_hs').val('<?php echo hdev_data::encd($my_pay['h_id']); ?>');$('#h_price').val('<?php echo $house['h_price'] ?>');" data-toggle="modal" data-target=".modal-reg">
                              <i class="fa fa-cart-plus"></i>
                              Pay Next month(s)
                            </button>
                          <?php 
                          }
                          ?> 
                        </div>
                      </td>
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>




<?php if (hdev_data::service('houses_rent')): ?>
<div class="modal fade modal-reg">
  <div class="modal-dialog">  
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Pay onother Month</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <form method="post" id="houses_rent" action="<?php echo hdev_url::menu("up") ?>">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="houses_rent" id="hs_ref">
              <input type="hidden" name="ref_hs" id="ref_hs" value="">
              <input type="hidden" name="start_date" id="start_date" class="form-control" value="i">
              <input type="hidden" name="o_id" id="o_id" class="form-control" value="i">
         <div class="card">
          <div class="card-body row">
            <div class="col-sm-12">
            <div class="form-group">
              <label for="h_price">
                House Price/month(30 days) :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-coins"></span>
                  </div>
                </div>
                <input type="text" id="h_price" class="form-control" placeholder="House Price" disabled="true" value="">
              </div>
            </div>
            <div class="form-group">
              <label for="n_months">
                Number of months to pay or book :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fas fa-columns"></span>
                  </div>
                </div>
                <input type="number" name="n_months" id="n_months" class="form-control" placeholder="Number of months" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="t_pay">
                Total Amount To pay :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text" id="t_pay_ld" ico='<span class="fas fa-user-alt"></span>'>
                    <span class="fas fa-coins"></span>
                  </div>
                </div>
                <input type="text" id="t_pay" class="form-control" placeholder="Total amount to pay" readonly="true">
              </div>
            </div>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            </div>
          </div>
            </form>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="rent_houses"><i class="fas fa-save"></i> Pay This house</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>