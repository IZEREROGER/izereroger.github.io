<?php 
//exit($data);
	if (isset($data) && !empty($data)) {}else{exit('validation failed');}
	$store = explode(';', $data);
	$HDEV =array();
	if (is_array($store) && count($store)>0) {
		foreach ($store as $stt) {
			$store2 = explode(':', $stt);
			if (is_array($store2) && count($store2) == 2) {
				$HDEV[$store2[0]]=$store2[1];
			}
		}
		
	}else{exit('validation failed');}
	
	if (is_array($HDEV) && count($HDEV) > 0 && isset($HDEV['ref'])) {
	}else{
		exit("validation Failed!");
	}
	$rasms_stc = new hdev_auth_service('',trim($HDEV['ref']));
	if ($rasms_stc->access()) {
		/// access granted 
	}else{
	  $disp = $rasms_stc->error('alert');
	  $HDEV['ref'] = "";

	  $from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');
	  hdev_note::message($disp);
	  hdev_note::redirect($from);
	  exit();
	}
	$csrf = new CSRF_Protect();
  	$csrf->verifyRequest($HDEV['app']);
	switch ($HDEV['ref']) {
		case 'agent_delete':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("main_auths");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `a_status` = :status WHERE `a_id` = :id;",[[":id",$id],[":status",'0']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success('Agent Account With <u>Reg No: '.$id.'</u> Deleted Well',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success('Agent Account With <u>Reg No: '.$id.'</u> Deleted Well');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;	
		case 'agent_recover':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("main_auths");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `a_status` = :status WHERE `a_id` = :id;",[[":id",$id],[":status",'1']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success('Agent Account With <u>Reg No: '.$id.'</u> Recovered Well',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success('Agent Account With <u>Reg No: '.$id.'</u> Recovered Well');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;	
			
		case 'provider_delete':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("specialist");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `s_status` = :status WHERE `s_id` = :id;",[[":id",$id],[":status",'0']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success('Provider Account With <u>Reg No: '.$id.'</u> Deleted Well',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success('Provider Account With <u>Reg No: '.$id.'</u> Deleted Well');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;	
		case 'provider_recover':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("specialist");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `s_status` = :status WHERE `s_id` = :id;",[[":id",$id],[":status",'1']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success('Provider Account With <u>Reg No: '.$id.'</u> Recovered Well',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success('Provider Account With <u>Reg No: '.$id.'</u> Recovered Well');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;				
		case 'provider_approve':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("specialist");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `s_status` = :status WHERE `s_id` = :id;",[[":id",$id],[":status",'1']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					$provider = hdev_data::provider($id,['data'])['s_tel'];
      					hdev_note::live_sms($provider,"Your request to be registerd at : ".constant('APP_NAME').' Was approved, now you can login at '.hdev_url::menu('login').' using Your username and password you created before!');
      					hdev_note::success('Provider Application With <u>Reg No: '.$id.'</u> Approved Well',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success('Provider Application With <u>Reg No: '.$id.'</u> Approved Well');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;
		case 'provider_reject':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("specialist");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `s_status` = :status WHERE `s_id` = :id;",[[":id",$id],[":status",'3']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					$provider = hdev_data::provider($id,['data'])['s_tel'];
      					hdev_note::live_sms($provider,"Your request to be registerd at : ".constant('APP_NAME').' Was rejected!');
      					hdev_note::success('Provider Application With <u>Reg No: '.$id.'</u> Rejected Well',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success('Provider Application With <u>Reg No: '.$id.'</u> Rejected Well');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;	


		case 'post_delete':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("post");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `p_status` = :status WHERE `p_id` = :id;",[[":id",$id],[":status",'0']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					$ppp = hdev_data::post($id,['data'])['s_id'];
      					$provider = hdev_data::provider($ppp,['data'])['s_tel'];
      					hdev_note::live_sms($provider,"Your post  at : ".constant('APP_NAME').' Was deleted !');
      					hdev_note::success('Post With <u>Reg No: '.$id.'</u> Deleted Well',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success('Provider Account With <u>Reg No: '.$id.'</u> Deleted Well');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;	
		case 'post_recover':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("post");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `p_status` = :status WHERE `p_id` = :id;",[[":id",$id],[":status",'1']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success('Post With <u>Reg No: '.$id.'</u> Recovered Well',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success('Provider Account With <u>Reg No: '.$id.'</u> Recovered Well');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;				
		case 'post_approve':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("post");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `p_status` = :status WHERE `p_id` = :id;",[[":id",$id],[":status",'1']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					hdev_note::success('Post Application With <u>Reg No: '.$id.'</u> Approved Well',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success('Post Application With <u>Reg No: '.$id.'</u> Approved Well');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;
		case 'post_reject':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("post");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `p_status` = :status WHERE `p_id` = :id;",[[":id",$id],[":status",'3']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				if (isset($HDEV['mod_close']) && !empty($HDEV['mod_close'])) {
      					$ppp = hdev_data::post($id,['data'])['s_id'];
      					$provider = hdev_data::provider($ppp,['data'])['s_tel'];
      					hdev_note::live_sms($provider,"Your post registration/modification request at : ".constant('APP_NAME').' Was rejected !');
      					hdev_note::success('Post Application With <u>Reg No: '.$id.'</u> Rejected Well',$HDEV['mod_close']);
      					//hdev_note::redirect($from);
      				}else{
      					hdev_note::success('Post Application With <u>Reg No: '.$id.'</u> Rejected Well');
      					//hdev_note::redirect($from);
      				}
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;
		default:
			hdev_note::message('we cannot handle what you requested try again later');
			hdev_note::redirect(hdev_url::menu(''));
		break;
	}

 ?>