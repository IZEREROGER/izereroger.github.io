<?php  
	if ($_GET) {
		if (isset($_GET['ref'])) {
			switch ($_GET['ref'] && isset($_GET['hash']) ) {
				case 'slide':
					if (isset($_GET['id']) && isset($_GET['hash']) && md5($_GET['id']) == $_GET['hash']) {
						$data = new hdev_db;
						$table = $data->table("slider");
						$id = $_GET['id'];
						if (!hdev_data::service('slide')) {
							exit('Access denied to you!');
						}
						$sql = $data->insert("DELETE FROM $table WHERE p_id=:p_id",[[':p_id',$id]]);
						if ($sql == "ok") {
							hdev_note::message($_GET['ref'].' deleted');
							hdev_note::redirect(hdev_url::menu('modify/slide'));
						}else {
							hdev_note::message('something went wrong');
							hdev_note::redirect(hdev_url::menu('modify/slide'));
						}
					}else{

							hdev_note::message('try again later');
							hdev_note::redirect(hdev_url::menu('modify/slide'));
					}
				break;
				
				default:
					echo "error occured please try again";
					hdev_note::message('error occured please try again later');
					hdev_note::redirect(hdev_url::menu('modify/slide'));
					break;
			}
			exit();
		}
	}
	if ($_POST) {
		if (!empty($_POST['ref'])) { 
			$rasms_stc = new hdev_auth_service('',trim($_POST['ref']));
			if ($rasms_stc->access()) {
				/// access granted 
			}else{
			  $rasms_stc->error('danger');
			}

  		switch ($_POST['ref']) {
  			case 'login':
  				
				if (!empty($_POST['usn']) && !empty($_POST['psw'])) {
					hdev_v::login($_POST["usn"],$_POST['psw']);
				}else{
					hdev_note::message(hdev_lang::on("validation","log_fair"));
	        		//hdev_note::redirect(hdev_url::get_url_host()."/h/login");
				}
 
			break;

			case 'send_reset_code':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['tell'])) {
					$tel = $_POST['tell'];
					if (hdev_data::phone_valid($tel)) {
      					exit(hdev_data::phone_valid($tel));
      				}
					$user = hdev_data::get_admin($tel,['tel']);
					$send_code = 0;
					if (is_array($user) && count($user) > 0) {
						$code = rand();
						$mask1 = time();
						$sent = md5($code.$mask1);
						$sent_og = strtoupper(substr($sent, 0, 6));
						//$sent_og = 12345;

						$code2 = $csrf->getToken();
						$mask2 = $sent_og.'-'.$code2.'-'.$tel;
						$mask = md5($mask2);
						$stmg = "Your Reset Code Is: ".$sent_og;
						hdev_note::live_sms($tel,$stmg);
						$send_code = 1;

					}else{
						$user = hdev_data::provider($tel,['tel']);
						$send_code = 0;
						if (is_array($user) && count($user) > 0) {
							$code = rand();
							$mask1 = time();
							$sent = md5($code.$mask1);
							$sent_og = strtoupper(substr($sent, 0, 6));
							//$sent_og = 1234;

							$code2 = $csrf->getToken();
							$mask2 = $sent_og.'-'.$code2.'-'.$tel;
							$mask = md5($mask2);
							$stmg = "Your Reset Code Is: ".$sent_og;
							hdev_note::live_sms($tel,$stmg);
							$send_code = 1;

						}

					}

					if ($send_code == 1) {
						$return['act'] = "success";
						$return['message'] = "Code Sent to: ".$tel;
						$return['mask'] = $mask;
						$return['tel'] = $tel;
					}else{
						$return['act'] = "error";
						$return['message'] = "Something went Wrong Try again later";
					}
      				echo json_encode($return);
				}else{
					$return['act'] = "error";
					$return['message'] = "Telephone number can't be empty";
					echo json_encode($return);
				}
			break;	
			case 'enter_code':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['mask']) && !empty($_POST['tel']) && !empty($_POST['code'])) {
					$mask = $_POST['mask'];
					$code = $_POST['code'];
					$tel = $_POST['tel'];

					$sent_og = strtoupper(trim($code));
					$code2 = $csrf->getToken();
					$mask2 = $sent_og.'-'.$code2.'-'.$tel;
					$mask_code = md5($mask2);


					if ($mask_code == $mask) {
						$user = hdev_data::get_admin($tel,['tel']);
						$profiles = "";
						foreach ($user as $users) {
							$profiles .= '<option value="'.$users['a_id']."-".'admin'.'">'.$users['a_email'].'</option>';
						}
						$user = array();
						$user = hdev_data::provider($tel,['tel']);
						foreach ($user as $users) {
							$profiles .= '<option value="'.$users['s_id']."-".'provider'.'">'.$users['s_email'].'</option>';
						}

						if ($profiles != "") {
							$return['act'] = "success";
							$return['message'] = "Entered Code Validated !";
							$return['profiles'] = $profiles;
							$return['mask2'] = $mask.'-'.$code;
							$return['tel'] = $tel;
						}else{
							$return['act'] = "error";
							$return['message'] = "Something went Wrong Try again later";
						}
					}else{
						$return['act'] = "error";
						$return['message'] = "Code Entered is invalid or expired.";
					}
      				echo json_encode($return);
				}else{
					$return['act'] = "error";
					$return['message'] = "All Fields are required";
					echo json_encode($return);
				}
			break;	
			case 'reset_password':
					//var_dump($_POST);
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['mask']) && !empty($_POST['tel']) && !empty($_POST['user']) && !empty($_POST['pass_1']) && !empty($_POST['pass_2'])) {
					$mask = $_POST['mask'];
					$tel = $_POST['tel'];
					$user_mix = $_POST['user'];
					$pass_1 = $_POST['pass_1'];
					$pass_2 = $_POST['pass_2'];

					$user_array = explode('-',$user_mix);
					if (isset($user_array[0]) && isset($user_array[1])) {
						$user = $user_array[0];
						$role = $user_array[1];
					}else{
						$return['act'] = "error";
						$return['message'] = "something went wrong try again later";
						echo json_encode($return);
						exit();
					}

					$mask_part = explode('-', $mask);
					if (isset($mask_part[0]) && isset($mask_part[1])) {
						$code = $mask_part[1];
						$mask = $mask_part[0];
					}else{
						$code = 0;
						$mask = 1;
					}

					$sent_og = strtoupper(trim($code));
					$code2 = $csrf->getToken();
					$mask2 = $sent_og.'-'.$code2.'-'.$tel;
					$mask_code = md5($mask2);


					if ($mask_code == $mask) {
						if ($pass_1 == $pass_2) {
							$rt = new hdev_db();
							$password = hdev_data::password_enc($pass_1);
							switch ($role) {
								case 'admin':
									$tab = $rt->table('main_auths');
		      						$ck = $rt->insert("UPDATE $tab SET `a_password` = :pwd WHERE `a_id` = :id",[[':pwd',$password],[':id',$user]]);
								break;
								case 'provider':
									$tab = $rt->table('specialist');
		      						$ck = $rt->insert("UPDATE $tab SET `s_password` = :pwd WHERE `s_id` = :id",[[':pwd',$password],[':id',$user]]);
								break;					
								default:
									exit("access denied you can't change your password");
									break;
							}
							
						}else{
							$ck = "no";
							$pw = 1;
						}
      					if ($ck == "ok") {
							$return['act'] = "success";
							//$return['user'] = $user;
							$return['message'] = "Password For: [".$tel."] changed succesfull, You can now log in with the new password.";
							//$csrf->up_tk();
						}else{
							$return['act'] = "error";
							$return['message'] = (isset($pw)) ? "two passwords doesn't match" : 'Something went Wrong Try again later' ;;
						}
					}else{
						$return['act'] = "error";
						$return['message'] = "Code Entered is invalid or expired.";
					}
      				echo json_encode($return);
				}else{
					//var_dump($_POST);
					$return['act'] = "error";
					$return['message'] = "All Fields are required";
					echo json_encode($return);
				}
			break;
			case 'slide':
				if (isset($_POST['p_title']) && !empty($_POST['p_title']) && isset($_POST['p_desc']) && !empty($_POST['p_desc']) && $_FILES && is_array($_FILES)) {
					$p_title = $_POST['p_title'];
					$p_desc = $_POST['p_desc'];
					$p_type = $_POST['ref'];
					$rt = new hdev_db();
      				$tab = $rt->table("slider"); 

					$up_files_array = $_FILES['p_pic'];
      				$countfiles = 1;
					$files_array = array();
						if (file_exists($up_files_array["tmp_name"])) {
							$file_type = $up_files_array["type"]; //returns the mimetype
							$allowed = array("image/jpeg", "image/gif", "image/png");
							if(!in_array($file_type, $allowed)) {
							}else{
								$ckup="";
								// Check file size
								if ($up_files_array["size"] > 50000000) {
								    $ckup = 1;
								}

								$fileData = pathinfo(basename($up_files_array["name"]));
								$fileName = "slide"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
								$regd = getcwd().DIRECTORY_SEPARATOR.'dist'.DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR.'upload'.DIRECTORY_SEPARATOR;
								$target_path = $regd.$fileName;
								while(file_exists($target_path))
								{
								    $fileName = "slide"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
								    $regd = getcwd().DIRECTORY_SEPARATOR.'dist'.DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR.'upload'.DIRECTORY_SEPARATOR;
									$target_path = $regd.$fileName;
								}
		 						if ($ckup == "") {
									if (move_uploaded_file($up_files_array["tmp_name"], $target_path))
									{
										array_push($files_array, $fileName);
									}
								}
							}
						}
					$reft = "";
					$reft = $files_array[0];

					if (strlen($reft) > 0) {
							$p_pic = $reft;

		      				$ck = $rt->insert("INSERT INTO `$tab` (`p_id`, `p_title`, `p_pic`, `p_desc`, `p_type`, `p_date`) VALUES (NULL, :p_title, :p_pic, :p_desc, :p_type, current_timestamp())",[[':p_title',$p_title],[':p_pic',$p_pic],[':p_desc',$p_desc],[':p_type',$p_type]]);
		      				if ($ck == "ok") {
		      					hdev_note::message("New ".$p_type." registered");
		      					hdev_note::redirect(hdev_url::menu('modify/slide'));
		      					//echo "new service registered";
		      				}else{
		      					echo "error occured try again";
		      				}
	      				}else{
	      					echo "something went wrong try again later";
	      				}
					}else{
						echo "fill all fields";
					}
  			break;
			case 'agent_reg':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['t_name']) && !empty($_POST['t_nid']) && !empty($_POST['sex']) && !empty($_POST['t_username']) && !empty($_POST['t_password']) && !empty($_POST['t_email']) && !empty($_POST['t_tel'])) {

					$t_name = $_POST['t_name'];
					$t_nid = $_POST['t_nid'];
					$sex = $_POST['sex'];
					$t_username = $_POST['t_username'];
					$t_password = hdev_data::password_enc($_POST['t_password']);
					$t_email = $_POST['t_email'];
					$t_tel = $_POST['t_tel'];
      				 
					$rt = new hdev_db();
      				$tab = $rt->table("main_auths"); 
      				$user = hdev_log::uid();

      				$ck = $rt->insert("INSERT INTO `$tab` (`a_id`, `a_nid`, `a_name`, `a_tel`, `a_username`, `a_sex`, `a_email`, `a_password`, `a_role`, `a_reg_date`, `a_status`) VALUES (NULL, :t_nid, :t_name, :t_tel, :t_username, :t_sex, :t_email, :t_password, 'agent', current_timestamp(), '1')",[[':t_name',$t_name],[':t_nid',$t_nid],[':t_sex',$sex],[':t_username',$t_username],[':t_tel',$t_tel],[':t_email',$t_email],[':t_password',$t_password]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("Agent Registered",$_POST['mod_close']);
      					}else{
      						hdev_note::success("Agent Registered");
      					}
      				}else{
      					echo "something went wrong try again later";
      				}
				}else{
					echo "all fields are required";
				}
			break;
			case 'agent_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['a_id']) && !empty($_POST['t_name']) && !empty($_POST['t_nid']) && !empty($_POST['sex']) && !empty($_POST['t_username']) && !empty($_POST['t_email']) && !empty($_POST['t_tel'])) {
					$a_id = $_POST['a_id'];
					$t_name = $_POST['t_name'];
					$t_nid = $_POST['t_nid'];
					$sex = $_POST['sex'];
					$t_username = $_POST['t_username'];
					$t_email = $_POST['t_email'];
					$t_tel = $_POST['t_tel'];
      				 
					$rt = new hdev_db();
      				$tab = $rt->table("main_auths"); 
      				$user = hdev_log::uid();

      				$ck = $rt->insert("UPDATE `$tab` SET `a_nid` = :t_nid, `a_name` = :t_name, `a_tel` = :t_tel, `a_username` = :t_username, `a_sex` = :t_sex, `a_email` = :t_email WHERE `a_id` = :a_id",[[':a_id',$a_id],[':t_name',$t_name],[':t_nid',$t_nid],[':t_sex',$sex],[':t_username',$t_username],[':t_tel',$t_tel],[':t_email',$t_email]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("Agent Info Updated",$_POST['mod_close']);
      					}else{
      						hdev_note::success("Agent Info Updated");
      					}
      				}else{
      					echo "something went wrong try again later";
      				}
				}else{
					echo "all fields are required";
				}
			break;
			case 'provider_reg':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['s_s_name']) && !empty($_POST['sex']) && !empty($_POST['s_s_qualification']) && !empty($_POST['email']) && !empty($_POST['tel']) && !empty($_POST['pwd'])) {
					$status = (hdev_log::fid() == "guest") ? "2" : "1" ;
					$s_s_name = $_POST['s_s_name'];
					$sex = $_POST['sex'];
					$s_s_qualification = $_POST['s_s_qualification'];
					$email = $_POST['email'];
					$pwd = hdev_data::password_enc($_POST['pwd']);
      				$tel = "";
      				if (isset($_POST['tel']) && !empty($_POST['tel'])) {
      					$tel = $_POST['tel'];
      					if (hdev_data::phone_valid($tel)) {
      						exit(hdev_data::phone_valid($tel));
      					}
      				}
					$rt = new hdev_db();
      				$tab = $rt->table("specialist"); 
      				$user = hdev_log::uid();

      				$ck = $rt->insert("INSERT INTO `$tab` (`s_id`,`s_name`, `s_sex`,`s_tel`, `s_qualification`, `s_email`, `s_password`, `s_reg_date`, `s_status`) VALUES (NULL, :s_s_name, :sex, :tel, :s_s_qualification, :email, :pwd, current_timestamp(), :status)",[[':s_s_name',$s_s_name],[':sex',$sex],[':s_s_qualification',$s_s_qualification],[':email',$email],[':pwd',$pwd],[':tel',$tel],[':status',$status]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						if ($status == "2") {
      							hdev_note::live_sms($tel,'Your Provider application was received and Waiting for admin approval, you will be able to login when your account is approved!');
      							hdev_note::success("Provider Registered and Waiting for admin approval, you will be able to login when your account is approved",$_POST['mod_close']);
      						}else{
      							hdev_note::success("Provider Registered",$_POST['mod_close']);
      						}
      					}else{
      						if ($status == "2") {
      							hdev_note::success("Provider Registered and Waiting for admin approval, you will be able to login when your account is approved");
      						}else{
      							hdev_note::success("Provider Registered");
      						}
      					}
      				}else{
      					echo "something went wrong try again later";
      				}
				}else{
					echo "all fields are required";
				}
			break;		
			case 'provider_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['s_id']) && !empty($_POST['s_s_name']) && !empty($_POST['sex']) && !empty($_POST['s_s_qualification']) && !empty($_POST['email']) && !empty($_POST['tel'])) {
					$s_s_name = $_POST['s_s_name'];
					$l_id = $_POST['s_id'];
					$sex = $_POST['sex'];
					$s_s_qualification = $_POST['s_s_qualification'];
					$email = $_POST['email'];
      				$tel = "";
      				if (isset($_POST['tel']) && !empty($_POST['tel'])) {
      					$tel = $_POST['tel'];
      					if (hdev_data::phone_valid($tel)) {
      						exit(hdev_data::phone_valid($tel));
      					}
      				}
					$rt = new hdev_db();
      				$tab = $rt->table("specialist"); 
      				$user = hdev_log::uid();
      				//var_dump($_POST);exit;
      				$ck = $rt->insert("UPDATE `$tab` SET `s_name` = :s_s_name, `s_sex` = :sex, `s_tel` = :tel, `s_qualification` = :s_s_qualification, `s_email` = :email WHERE `s_id` = :l_id",[[':s_s_name',$s_s_name],[':sex',$sex],[':s_s_qualification',$s_s_qualification],[':email',$email],[':l_id',$l_id],[':tel',$tel]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("Provider Info Updated",$_POST['mod_close']);
      					}else{
      						hdev_note::success("Provider Info Updated");
      					}
      				}else{
      					echo "something went wrong try again later";
      				}
				}else{
					echo "all fields are required";
				}
			break;
			case 'post_reg':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['p_title']) && isset($_POST['short_desc']) && !empty($_POST['p_category']) && !empty($_POST['main_content']) && $_FILES && is_array($_FILES)) {
					//print_r($_FILES);
					//print_r($_POST);
					$s_id = 1;
					$p_title = $_POST['p_title'];
					$p_short_desc = $_POST['short_desc'];
					$main_content = $_POST['main_content'];
					$p_category = $_POST['p_category'];

					$rt = new hdev_db();
      				$tab = $rt->table("post"); 
					$up_files_array = $_FILES['p_pic'];
      				$countfiles = 1;
					$files_array = array();
						if (file_exists($up_files_array["tmp_name"])) {
							$file_type = $up_files_array["type"]; //returns the mimetype
							$allowed = array("image/jpeg", "image/gif", "image/png");
							if(!in_array($file_type, $allowed)) {
							}else{
								$ckup="";
								// Check file size
								if ($up_files_array["size"] > 50000000) {
								    $ckup = 1;
								}

								$fileData = pathinfo(basename($up_files_array["name"]));
								$fileName = "post"."_img_pic_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
								$regpath = __DIR__;

								$regd = getcwd().DIRECTORY_SEPARATOR.'dist'.DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR.'doc'.DIRECTORY_SEPARATOR;

								$target_path = $regd.$fileName;
								while(file_exists($target_path))
								{
								    $fileName = "post"."_img_pic_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
									$target_path = $regd.$fileName;
								}
		 						if ($ckup == "") {
									if (move_uploaded_file($up_files_array["tmp_name"], $target_path))
									{
										array_push($files_array, $fileName);
									}
								}
							}
						}else{
							exit("please choose the file to upload");
						}				
					$reft = "";
					$p_pic = "";
					if (isset($files_array[0])) {
						$reft = $files_array[0];
						$p_pic = $reft; //////REQUIRED PICTURE
					}


					$up_files_array = array();	
					$up_files_array = $_FILES['p_atachment'];
      				$countfiles = 1;
					$files_array = array();
						if (file_exists($up_files_array["tmp_name"])) {
							$file_type = $up_files_array["type"]; //returns the mimetype
							$allowed = array("image/jpeg", "image/gif", "image/png");
							if($countfiles != 1) {
							}else{
								$ckup="";
								// Check file size
								if ($up_files_array["size"] > 50000000) {
								    $ckup = 1;
								}

								$fileData = pathinfo(basename($up_files_array["name"]));
								$fileName = "post"."_doc_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
								$regd = getcwd().DIRECTORY_SEPARATOR.'dist'.DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR.'doc'.DIRECTORY_SEPARATOR;
								$target_path = $regd.$fileName;
								while(file_exists($target_path))
								{
								    $fileName = "post"."_doc_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
									$regpath = __DIR__;
									$target_path = $regd.$fileName;
								}
		 						if ($ckup == "") {
									if (move_uploaded_file($up_files_array["tmp_name"], $target_path))
									{
										array_push($files_array, $fileName);
									}
								}
							}
						}else{
							exit("please choose the file to upload");
						}						
					$reft = "";
					$p_atachment = "";
					if (isset($files_array[0])) {
						$reft = $files_array[0];
						$p_atachment = $reft; //////REQUIRED PICTURE
					}


					if (strlen($reft) > 0) {

		      				$ck = $rt->insert("INSERT INTO `$tab` (`p_id`, `s_id`, `c_id`, `p_pic`, `p_title`, `p_short_desc`, `p_content`, `p_attachment`, `p_status`, `p_reg_date`) VALUES (NULL, :s_id, :c_id, :p_pic, :p_title, :p_short_desc, :p_content, :p_atachment, '2', current_timestamp())",[[':c_id',$p_category],[':p_title',$p_title],[':p_pic',$p_pic],[':p_short_desc',$p_short_desc],[':s_id',$s_id],[':p_content',$main_content],[':p_atachment',$p_atachment]]);
		      				if ($ck == "ok") {
		      					$csrf->up_tk();
		      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
		      						hdev_note::success("Post Registered successfull",$_POST['mod_close']);
		      					}else{
		      						hdev_note::success("Post Registered successfull");
		      					}
		      				}else{
		      					echo "error occured try again";
		      				}
	      				}else{
	      					echo "something went wrong try again later";
	      				}
					}else{
						echo "fill all fields";
					}
			break;
			case 'post_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['p_id']) && !empty($_POST['p_title']) && isset($_POST['short_desc']) && !empty($_POST['p_category']) && !empty($_POST['main_content'])) {
					$s_id = 1;
					$p_id = $_POST['p_id'];
					$p_title = $_POST['p_title'];
					$p_short_desc = $_POST['short_desc'];
					$main_content = $_POST['main_content'];
					$p_category = $_POST['p_category'];

					$rt = new hdev_db();
      				$tab = $rt->table("post"); 
      				if (isset($_FILES['p_pic'])) {
						$up_files_array = $_FILES['p_pic'];
      				}
      				$countfiles = 1;
					$files_array = array();
						if (isset($up_files_array['tmp_name']) && file_exists($up_files_array["tmp_name"])) {
							$file_type = $up_files_array["type"]; //returns the mimetype
							$allowed = array("image/jpeg", "image/gif", "image/png");
							if(!in_array($file_type, $allowed)) {
							}else{
								$ckup="";
								// Check file size
								if ($up_files_array["size"] > 50000000) {
								    $ckup = 1;
								}

								$fileData = pathinfo(basename($up_files_array["name"]));
								$fileName = "post"."_img_pic_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
								$regpath = __DIR__;

								$regd = getcwd().DIRECTORY_SEPARATOR.'dist'.DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR.'doc'.DIRECTORY_SEPARATOR;

								$target_path = $regd.$fileName;
								while(file_exists($target_path))
								{
								    $fileName = "post"."_img_pic_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
									$target_path = $regd.$fileName;
								}
		 						if ($ckup == "") {
									if (move_uploaded_file($up_files_array["tmp_name"], $target_path))
									{
										array_push($files_array, $fileName);
									}
								}
							}			
							$reft = "";
							$p_pic = "";
							if (isset($files_array[0])) {
								$reft = $files_array[0];
								$p_pic = $reft; //////REQUIRED PICTURE
								$p_pic_content = ",p_pic='".$p_pic."'";
							}
						}else{
							$p_pic_content = "";
						}	


					$up_files_array = array();	
      				if (isset($_FILES['p_pic'])) {
						$up_files_array = $_FILES['p_atachment'];
      				}
      				$countfiles = 1;
					$files_array = array();
						if (isset($up_files_array['tmp_name']) && file_exists($up_files_array["tmp_name"])) {
							$file_type = $up_files_array["type"]; //returns the mimetype
							$allowed = array("image/jpeg", "image/gif", "image/png");
							if($countfiles != 1) {
							}else{
								$ckup="";
								// Check file size
								if ($up_files_array["size"] > 50000000) {
								    $ckup = 1;
								}

								$fileData = pathinfo(basename($up_files_array["name"]));
								$fileName = "post"."_doc_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
								$regd = getcwd().DIRECTORY_SEPARATOR.'dist'.DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR.'doc'.DIRECTORY_SEPARATOR;
								$target_path = $regd.$fileName;
								while(file_exists($target_path))
								{
								    $fileName = "post"."_doc_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
									$regpath = __DIR__;
									$target_path = $regd.$fileName;
								}
		 						if ($ckup == "") {
									if (move_uploaded_file($up_files_array["tmp_name"], $target_path))
									{
										array_push($files_array, $fileName);
									}
								}
							}						
							$reft = "";
							$p_atachment = "";
							if (isset($files_array[0])) {
								$reft = $files_array[0];
								$p_atachment = $reft; //////REQUIRED PICTURE
								$p_atachment_content = "p_atachment='".$p_atachment."'";
							}
						}else{
							$p_atachment_content = "";
						}

						$reft="890";
					if (strlen($reft) > 0) {

		      				$ck = $rt->insert("UPDATE `post` SET `p_status`=2, `c_id` = :c_id $p_pic_content, `p_title` = :p_title, `p_short_desc` = :p_short_desc, `p_content` = :p_content $p_atachment_content WHERE `post`.`p_id` = :p_id",[[':c_id',$p_category],[':p_title',$p_title],[':p_id',$p_id],[':p_short_desc',$p_short_desc],[':p_content',$main_content]]);
		      				if ($ck == "ok") {
		      					$csrf->up_tk();
		      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
		      						hdev_note::success("Post Updated successfull",$_POST['mod_close']);
		      					}else{
		      						hdev_note::success("Post Updated successfull");
		      					}
		      				}else{
		      					echo "error occured try again";
		      				}
	      				}else{
	      					echo "something went wrong try again later";
	      				}
					}else{
						echo "fill all fields";
					}
			break;
			case 'user_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (isset($_POST['name']) && isset($_POST['sex']) && isset($_POST['email']) && isset($_POST['tel'])) {
					$name = $_POST['name'];
					$sex = $_POST['sex'];
					$email = $_POST['email'];
					$tel = $_POST['tel'];
      				if (hdev_data::phone_valid($tel)) {
      					exit(hdev_data::phone_valid($tel));
      				}
					$id = hdev_log::uid();
					$rt = new hdev_db();
		      		$tab = $rt->auth_tbl();

					switch (hdev_log::fid()) {
						case 'admin':
		      				$ck = $rt->insert("UPDATE $tab SET `a_name` = :name, `a_tell` = :tel, `a_sex` = :sex, `a_email` = :email WHERE `a_id` = :id",[[":id",$id],[':name',$name],[':sex',$sex],[":email",$email],[":tel",$tel]]);
						break;
						case 'provider':
							if (isset($_POST['s_qualification']) && !empty($_POST['s_qualification'])) {
								$s_s_qualification = $_POST['s_qualification'];
							}else{
								exit("all fields are required");
							}
		      				$ck = $rt->insert("UPDATE $tab SET `s_name` = :name, `s_tel` = :tel, `s_qualification` = :s_qualification, `s_sex` = :sex, `s_email` = :email WHERE `s_id` = :id",[[":id",$id],[':name',$name],[':sex',$sex],[":email",$email],[":s_qualification",$s_s_qualification],[":tel",$tel]]);
						break;					
						default:
							exit("access denied you can't edit your user info");
							break;
					}

      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("User info Updated",$_POST['mod_close']);
      					}else{
      						hdev_note::success("User info Updated");
      					}
      				}else{
      					echo "something went wrong try again later";
      				}
				}else{
					echo "all fields are required";
				}
			break;			
			case 'self_change_user_pwd':
				$csrf = new CSRF_Protect(); 
    			$csrf->verifyRequest();
				if (!empty($_POST['old_password']) && !empty($_POST['new_password']) && !empty($_POST['confirm_password'])) {
					$id = hdev_log::uid();
					$new_password = $_POST['new_password'];
					$confirm_password = $_POST['confirm_password'];
					$old_password = $_POST['old_password'];

					if ($new_password != $confirm_password) {
						exit("New and Confirm Passwords do not match!");
					}

					$password = hdev_data::password_enc($new_password);
					$old_password_hash = hdev_data::password_enc($old_password);
					$id = hdev_log::uid();
					$rt = new hdev_db();
		      		$tab = $rt->auth_tbl();

					switch (hdev_log::fid()) {
						case 'admin':
							$old_password_db = hdev_data::get_admin(hdev_log::uid(),['data'])["a_password"];
							$user = hdev_data::get_admin(hdev_log::uid(),['data'])["a_name"];
							if ($old_password_hash != $old_password_db) {
								exit("Provided current password is incorrect.");
							}
      						$ck = $rt->insert("UPDATE $tab SET `a_password` = :pwd WHERE `a_id` = :id",[[':pwd',$password],[':id',$id]]);
						break;
						case 'provider':
							$old_password_db = hdev_data::provider(hdev_log::uid(),['data'])["s_password"];
							$user = hdev_data::provider(hdev_log::uid(),['data'])["s_name"];
							if ($old_password_hash != $old_password_db) {
								exit("Provided current password is incorrect.");
							}
      						$ck = $rt->insert("UPDATE $tab SET `s_password` = :pwd WHERE `s_id` = :id",[[':pwd',$password],[':id',$id]]);
						break;					
						default:
							exit("access denied you can't change your password");
							break;
					}
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("Password for User: \" <u>".$user."</u> \" changed",$_POST['mod_close']);
      					}else{
      						hdev_note::success("Password for User: \" <u>".$user."</u> \" changed");
      					}
      				}else{
      					echo "something went wrong try again later";
      				}

				}else{
					echo "all fields are required";
				}
			break;
			default:
				echo "404! Sorry we can't see what you are looking for please refesh this page and try again.";
			break;
		}
		}
		//var_dump($_POST);
	}

 ?>