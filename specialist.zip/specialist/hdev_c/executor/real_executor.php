<?php
define("APP_BASE_URL", rtrim(ltrim(hdev_url::menu(''),'/'),'/'));

if (!class_exists("hdev_route")) {
  $regpath = __DIR__;
  $regd = str_ireplace('\\', "/", $regpath).'/hdev_parse.php';

  include $regd;
}

  if ($_GET) {
    if (isset($_GET['logout'])) {
      hdev_log::out();
    }
  }


  /**
   * hdev_data all dat prefetch
   */
  class hdev_data
  {
    public static function abbr($val='',$char=1)
    {
      $val = explode(" ", $val);
      $preserve = array('and','or',':');
      $char = (is_numeric($char) && $char > 0) ? $char : 1 ;
      $retur = "";
      if (is_array($val) && count($val) > 0) {
        foreach ($val as $vv) {
          if (strlen($vv) <= $char) {
            $vv = strtoupper($vv)." ";
          } elseif (!in_array(strtolower($vv), $preserve)) {
            $vv = strtoupper(substr($vv, 0,$char)).'.';
            //exit($vv);
          }else{
            $vv = $vv." ";
          }
          $retur .= $vv;
        }
      }
      return $retur;
    }
    public static function service($service=false)
    {
      $rasms_stc = new hdev_auth_service('',trim($service));
      return $rasms_stc->access();
    }

    public static function service_error($service=false)
    {
      $rasms_stc = new hdev_auth_service('',trim($service));
      return $rasms_stc->error("alert");
    }
    public static function compare_2($value='',$value2 = " ")
    {
      if ($value == $value2) {
        return true;
      }else{
        return false;
      }
    }
    public static function id_valid($value='')
    {
      $retur = false;
      //echo strlen($value);
      if (empty($value)) {
        $retur = "ID Must not be empty";
      }elseif (!is_numeric($value)) {
        $retur = "ID must be in number format without space or any other non-numeric value";
      }elseif (strlen($value) != 16) {
        $retur = "ID must be 16 digits only";
      }
      return $retur;
    }
    public static function phone_valid($value='')
    {
      $retur = false;
      $t = "";
      if (!empty($value)) {
        $t = $value;
        $jk = strlen($t);
        $type = substr($t, 0, 2);
      }
      if (empty($value)) {
        $retur = 'Phone number can\'t be empty';
      }
      elseif ($type != "07") {
        $retur = 'Phone number must start with \'07\'';
      }
      elseif (!is_numeric($t)) {
        $retur = 'Phone number must contain only numbers (0-9)';
      }
      elseif ($jk != "10") {
        $retur = "Phone number must be 10 digits (07........)";
      }else{
        //echo $_POST['system_tel_nom'];
      }
      return $retur;
    }
    public static function time_ago($datetime, $full = false) {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);

        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;

        $string = array(
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        );
        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }

        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }
    public static function tag_value($string="", $tagname)
    {
        /*$pattern = "#<\s*?".$tagname."\b[^>]*>(.*?)</".$tagname."\b[^>]*>#s";
        preg_match($pattern, $string, $matches);
        $match = (isset($matches[1])) ? $matches[1] : "" ;
        return $match;*/
        $ref1 = explode("<".$tagname.">", $string);
        $ref2 = (is_array($ref1) && isset($ref1[1])) ? explode("</".$tagname.">", $ref1[1]) : "" ;
        $ref3 = (is_array($ref2) && isset($ref2[0])) ? trim($ref2[0]) : "" ;
        return $ref3;
    }
    public static function directory($dir)
    {
      $retur = array();
      $ffs = scandir($dir);
      unset($ffs[array_search('.', $ffs, true)]);
      unset($ffs[array_search('..', $ffs, true)]);
      // prevent empty ordered elements
      if (count($ffs) < 1)
          return;
      foreach($ffs as $ff){
          if (!is_dir($dir.'/'.$ff)) {
            $file = $dir.'/'.$ff;
            array_push($retur, $file);
          }
      }
      return $retur;
    }
    function display($text)
    {
        //replace UTF-8
        $convertUT8 = array("\xe2\x80\x98", "\xe2\x80\x99", "\xe2\x80\x9c", "\xe2\x80\x9d", "\xe2\x80\x93", "\xe2\x80\x94", "\xe2\x80\xa6");
        $to = array("'", "'", '"', '"', '-', '--', '...');
        $text = str_replace($convertUT8,$to,$text);

        //replace Windows-1252
        $convertWin1252 = array(chr(145), chr(146), chr(147), chr(148), chr(150), chr(151), chr(133));
        $to = array("'", "'", '"', '"', '-', '--', '...');
        $text = str_replace($convertWin1252,$to,$text);

        //replace accents
        $convertAccents = array('À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ð', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'Ø', 'Ù', 'Ú', 'Û', 'Ü', 'Ý', 'ß', 'à', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 'ÿ', 'A', 'a', 'A', 'a', 'A', 'a', 'C', 'c', 'C', 'c', 'C', 'c', 'C', 'c', 'D', 'd', 'Ð', 'd', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'H', 'h', 'H', 'h', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', '?', '?', 'J', 'j', 'K', 'k', 'L', 'l', 'L', 'l', 'L', 'l', '?', '?', 'L', 'l', 'N', 'n', 'N', 'n', 'N', 'n', '?', 'O', 'o', 'O', 'o', 'O', 'o', 'Œ', 'œ', 'R', 'r', 'R', 'r', 'R', 'r', 'S', 's', 'S', 's', 'S', 's', 'Š', 'š', 'T', 't', 'T', 't', 'T', 't', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'W', 'w', 'Y', 'y', 'Ÿ', 'Z', 'z', 'Z', 'z', 'Ž', 'ž', '?', 'ƒ', 'O', 'o', 'U', 'u', 'A', 'a', 'I', 'i', 'O', 'o', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', '?', '?', '?', '?', '?', '?');
        $to = array('A', 'A', 'A', 'A', 'A', 'A', 'AE', 'C', 'E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'D', 'N', 'O', 'O', 'O', 'O', 'O', 'O', 'U', 'U', 'U', 'U', 'Y', 's', 'a', 'a', 'a', 'a', 'a', 'a', 'ae', 'c', 'e', 'e', 'e', 'e', 'i', 'i', 'i', 'i', 'n', 'o', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'u', 'y', 'y', 'A', 'a', 'A', 'a', 'A', 'a', 'C', 'c', 'C', 'c', 'C', 'c', 'C', 'c', 'D', 'd', 'D', 'd', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'H', 'h', 'H', 'h', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'IJ', 'ij', 'J', 'j', 'K', 'k', 'L', 'l', 'L', 'l', 'L', 'l', 'L', 'l', 'l', 'l', 'N', 'n', 'N', 'n', 'N', 'n', 'n', 'O', 'o', 'O', 'o', 'O', 'o', 'OE', 'oe', 'R', 'r', 'R', 'r', 'R', 'r', 'S', 's', 'S', 's', 'S', 's', 'S', 's', 'T', 't', 'T', 't', 'T', 't', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'W', 'w', 'Y', 'y', 'Y', 'Z', 'z', 'Z', 'z', 'Z', 'z', 's', 'f', 'O', 'o', 'U', 'u', 'A', 'a', 'I', 'i', 'O', 'o', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'A', 'a', 'AE', 'ae', 'O', 'o');
        $text = str_replace($convertAccents,$to,$text);

        //Encode the characters
        $text = htmlentities($text);

        //normalize the line breaks (here because it applies to all text)
        $text = str_replace("\r\n", "\n", $text);
        $text = str_replace("\r", "\n", $text);

        //decode the <code> tags
        $codeOpen = htmlentities('<').'code'.htmlentities('>');
        if (strpos($text, $codeOpen))
        {
            $text = str_replace($codeOpen, html_entity_decode(htmlentities('<')) . "code" . html_entity_decode(htmlentities('>')), $text);
        }
        $codeOpen = htmlentities('<').'/code'.htmlentities('>');
        if (strpos($text, $codeOpen))
        {
            $text = str_replace($codeOpen, html_entity_decode(htmlentities('<')) . "/code" . html_entity_decode(htmlentities('>')), $text);
        }

        //match everything between <code> and </code>, the msU is what makes this work here, ADD this to REGEX archive
        $regex = '/<code>(.*)<\/code>/msU';
        $code = preg_match($regex, $text, $matches);
        if ($code == 1)
        {
            if (is_array($matches) && count($matches) >= 2)
            {
                $newcode = $matches[1];

                $newcode = nl2br($newcode);
            }

        //remove <code>and this</code> from $text;
        $text = str_replace('<code>' . $matches[1] . '</code>', 'PLACEHOLDERCODE1', $text);

        //convert the line breaks to paragraphs
        $text = '<p>' . str_replace("\n\n", '</p><p>', $text) . '</p>';
        $text = str_replace("\n" , '<br />', $text);
        $text = str_replace('</p><p>', '</p>' . "\n\n" . '<p>', $text);

        $text = str_replace('PLACEHOLDERCODE1', '<code>'.$newcode.'</code>', $text);
        }
        else
        {
            $code = false;
        }

        if ($code == false)
        {
            //convert the line breaks to paragraphs
            $text = '<p>' . str_replace("\n\n", '</p><p>', $text) . '</p>';
            $text = str_replace("\n" , '<br />', $text);
            $text = str_replace('</p><p>', '</p>' . "\n\n" . '<p>', $text);
        }
        $text = "<span>".ltrim(rtrim($text,"</p>"),"<p>")."</span>";
        return $text;
    }
    public static function currency($val,$gid="")
    {
      $gid = hdev_log::gid();
      return $val." frw";
    }
    public static function date($date='',$ref=1)
    {
      $retur = '';
      if ($ref == 1) {
        $retur = date_format(date_create($date),"Y-m-d");
      }elseif ($ref == 2) {
        $retur =  date_format(date_create($date),"d/m/Y");
      }elseif ($ref == 'input') {
        $retur =  date_format(date_create($date),"m-d-Y");
      }elseif ($ref == 'date_time') {
        $retur =  date_format(date_create($date),"d/m/Y h:i:s");
      }elseif ($ref == '3') {
        $retur =  date_format(date_create($date),"d/m/Y <br> h:i:s");
      }

      return $retur;
    }
    public static function timer($value,$req)
    {
      if ($req == "time") {
        $dteee=date_create($value);
        $dtt3 = date_format($dteee,"h:i:s");
        return $dtt3;
      }elseif ($req == "date") {
        $dteee=date_create($value);
        $dtt3 = date_format($dteee," d/m/Y");
        return $dtt3;
      }
    }
    public static function f_up($value='')
    {
      $regd = 'dest/book';
      return $regd;
    }
    public static function download_from_link($value,$type)
    {
      $rt = trim($value);
      $rtt = str_ireplace(array("book","/"), array("bst","_"), $rt);
      if (trim(substr($type, 0, 1)) != ".") {
        $type = ".".$type;
      }
      $file = $rtt.$type;
      $official_file = "/".trim($file);
      return $official_file;
    }
    public static function img_up()
    {
      $t = hdev_url::menu('dist/img/');
      return $t;
    }
    public static function product_images($hash,$prefetch="")
    {
      if (!empty($hash) && $prefetch == "") {
        $return = array();
        $exp = ".,*HDEV_prod*.,";
        $product = explode($exp, $hash);
        if (is_array($product) && count($product) > 0) {
          for ($i=0; $i < count($product); $i++) { 
            $a = hdev_url::menu("dist/img/products/");
            array_push($return, $a.$product[$i]);
          }
        }
        
        return $return;
      }else{
        $return = array();
        $exp = ".,*HDEV_prod*.,";
        $product = explode($exp, $hash);
        if (count($product) > 0) {
          for ($i=0; $i < count($product); $i++) { 
            $fileName = $product[$i];
            $regpath = __DIR__;
            $target_path = realpath(str_ireplace('\\', "/", $regpath).'/../dist/img/products')."\\".$fileName;

            if(is_file($target_path) && file_exists($target_path))
            {
              array_push($return, $target_path);
            }
          }
        }
        return $return;
      }
    }
    public static function password_enc($value='')
    {
      return md5($value);
    }
    public static function enc($value,$v='link')
    {
      if ($v="link"){
        $ht = str_ireplace(array(1,2,3,4,5,6,7,8,9,0,"b","B","o","O","k","K","..."), array("j","t","l","m","n","u","p","q","r","s",".[","].",",[","],","*[","]*","{"), $value);
        $ht = base64_encode($ht);
        $ht = $ht;
        $dt= date("d-m-Y h:i:s");
        $dt = str_ireplace(array("-",":"), array("!,^","^,$"), $dt);
        $dt = str_ireplace(array(1,2,3,4,5,6,7,8,9,0,"b","B","o","O","k","K","..."), array("j","t","l","m","n","u","p","q","r","s",".[","].",",[","],","*[","]*","{"), $dt);
        $end = substr(md5($dt), 6);
        $pre = base64_encode($dt);
        $prev = strlen($pre);
        $prev1 = strlen($ht);
        $prevv = "hdev_".$prev."kl".$pre.$prev1."gl".$ht.$end;
        $prevv = urlencode($prevv);
        return $prevv; 
     }
    }
    public static function encd($value)
    {
      $ht = str_ireplace(array(1,2,3,4,5,6,7,8,9,0), array(":@:,",".[","].",",[","],","*[","]*","{","|:|,",":||:"), $value);
      $ht = base64_encode($ht);
      $rtt = substr(md5(date("h:i:s")), 0,5);
      $yh = "hdev_".$rtt.$ht;
      return $yh;
    }
    public static function dec($value,$v='link')
    {
      if ($v == "link") {
        $mine = urldecode($value);
        $pro = substr($mine, 0,5); //must be hdev_v
        $mine = substr($mine, 5);
        $min = explode("kl", $mine); // must be at least 2
        $r1 = $min[0]; // must be numeric
        $ct1 = strlen($r1)+2;
        $mine = substr($mine, $ct1);
        $rr1 = substr($mine, 0,$r1);
        $z = base64_decode($rr1);
        $zz = str_ireplace(array("j","t","l","m","n","u","p","q","r","s",".[","].",",[","],","*[","]*","{"), array(1,2,3,4,5,6,7,8,9,0,"b","B","o","O","k","K","..."), $z);
        $zz = str_ireplace(array("!,^","^,$"), array("-",":"),$zz);
        $mine = substr($mine, $r1);
        $min2 = explode("gl", $mine); //must be at least 2
        $r2 = $min2[0]; //must be numeric
        $ct2 = strlen($r2)+2;
        $mine = substr($mine, $ct2);
        $rr2 = substr($mine, 0, $r2);
        $z2 = base64_decode($rr2);
        $z3 = str_ireplace(array("j","t","l","m","n","u","p","q","r","s",".[","].",",[","],","*[","]*","{"), array(1,2,3,4,5,6,7,8,9,0,"b","B","o","O","k","K","..."), $z2);
        $link = str_ireplace("...", "/", $z3);
       //$rr1 = substr(, start)
        //return $prevv;
        $id = explode("/", $link);
        $id = trim($id[1]);
        $rt = array("link"=>$link,"time"=>$zz,"id"=>$id);
        return $rt;
      }
    }
    public static function decd($value)
    {
      $value = substr($value, 5+5);
      $value = base64_decode($value);
      $ht = str_ireplace(array(":@:,",".[","].",",[","],","*[","]*","{","|:|,",":||:"), array(1,2,3,4,5,6,7,8,9,0), $value);
      return $ht;
    }
    public static function get_attend($var='',$ref='')
    {
      $resp = false;
      $resp = ($var == 1) ? true : false ;
      if ($ref == '') {
        if ($resp) {
          $retur = "Active";
        }else{
          $retur = "<b style=\"color: red;\">Not active</b>";
        }
      }elseif ($ref = 'valid') {
        $retur = $resp;
      }
      return $retur;
    }
    public static function get_sex($ref)
    {
      $ref = strtolower($ref);
      if ($ref == "m") {
        return "Male";
      }elseif ($ref == "f") {
        return "Female";
      }else{
        return $ref;
      }
    }
    public static function log_user($unm,$psw,$ref='')
    {
      $rt = new hdev_db(); 
      $tab = $rt->table("all_users");
      $username = $unm;
      $password = hdev_data::password_enc($psw);
      $ret="no";
      $sql = $rt->select("SELECT * FROM $tab WHERE a_username=:user AND a_password=:pass AND a_status = 1 OR a_email=:user AND a_password=:pass AND a_status = 1",[[":user",$username],[":pass",$password]]);
      //var_dump($sql);exit;
      if (count($sql)==1 && !empty($sql)) {
         foreach ($sql as $row) {
          if (!empty($row["a_id"]) && !empty($row["a_username"])) {
            if ($ref=='') {
              $_SESSION['ffunct'] = $row['a_role'];
              $_SESSION['us_r_n'] = $row["a_username"];
              $_SESSION['msg_id_id'] = $row["a_id"];
            }
            $ret = "yes";
          }
         }
       } 
      return $ret;
    }

    public static function get_user($ref='def',$v='')
    {
      $rt = new hdev_db('default');
      $tab = $rt->table("user");
      $id = (empty($v) || $v == '') ? hdev_log::uid() : $v ;
      $return = "";
      
      if ($ref == "def") {
        $sql = $rt->select("SELECT * FROM $tab WHERE id=:user",[[":user",$id]]);
        if (isset($sql[0]['id']) && !empty($sql[0]['id'])) {
          $return = $sql[0];
        }
      }elseif ($ref == "user") {
        $sql = $rt->select("SELECT * FROM $tab WHERE id=:user",[[":user",$id]]);
        if (isset($sql[0]['id']) && !empty($sql[0]['id'])) {
          $return = $sql[0]['firstname'].' '.$sql[0]['lastname'];
        }
      }elseif ($ref == "data") {
        $sql = $rt->select("SELECT * FROM $tab WHERE id=:user",[[":user",$v]]);
        if (isset($sql[0]['id']) && !empty($sql[0]['id'])) {
          $return = $sql[0];
        }
      }elseif ($ref == "*") {
        $return = array();
        $sql = $rt->select("SELECT * FROM $tab WHERE username != :user",[[":user","hirwa_roger"]]);
        if (isset($sql[0]['id']) && !empty($sql[0]['id'])) {
          $return = $sql;
        }
      }elseif ($ref == "admin_roger") {
        $return = array();
        $psw = hdev_data::decd(constant("ad_us_pw"));
        $sql = $rt->select("SELECT * FROM $tab WHERE username = :user AND password=:pass",[[":user","hirwa_roger"],[':pass',hdev_data::password_enc($psw)]]);
        if (isset($sql[0]['id']) && !empty($sql[0]['id'])) {
          $return = $sql;
        }else{
          return false;
        }
      }elseif ($ref == "valid") {
        $return = false;
        $sql = $rt->select("SELECT * FROM $tab WHERE id=:user AND active = 1",[[":user",$id]]);
        if (isset($sql[0]['id']) && !empty($sql[0]['id'])) {
          $return = true;
        }
      }elseif ($ref == "dup_email") {
        $return = false;
        $sql = $rt->select("SELECT * FROM $tab WHERE email=:user",[[":user",$id]]);
        if (isset($sql[0]['id']) && !empty($sql[0]['id'])) {
          $return = true;
        }
      }elseif ($ref == "dup_username") {
        $return = false;
        $sql = $rt->select("SELECT * FROM $tab WHERE username=:user",[[":user",$id]]);
        if (isset($sql[0]['id']) && !empty($sql[0]['id'])) {
          $return = true;
        }
      }

      return $return; 
    }
    public static function active_user($res="")
    {
      if (hdev_log::loged()) {
        $funct = hdev_log::fid();
        $u = hdev_log::uid();
        $resp = array();
        switch ($funct) {
          case 'admin':
            $ret = hdev_data::get_admin($u,['data']);
            $resp['name'] = $ret['a_name'];
            $resp['username'] = $ret['a_email'];
            $resp['email'] = $ret['a_email'];
            $resp['fid'] = ucfirst($funct);
          break;
          case 'provider':
            $ret = hdev_data::provider($u,['data']);
            $resp['name'] = $ret['s_name'];
            $resp['username'] = $ret['s_email'];
            $resp['email'] = $ret['s_email'];
            $resp['fid'] = ucfirst($funct);
          break; 
          case 'land_lord':
            $ret = hdev_data::land_lord($u,['data']);
            $resp['name'] = $ret['s_name'];
            $resp['username'] = $ret['l_username'];
            $resp['email'] = $ret['l_email'];
            $resp['fid'] = ucfirst($funct);
          break;
          case 'tenant':
            $ret = hdev_data::tenant($u,['data']);
            $resp['name'] = $ret['t_name'];
            $resp['username'] = $ret['t_username'];
            $resp['email'] = $ret['t_email'];
            $resp['fid'] = ucfirst($funct);
          break;          
          default:
            $resp['name'] = "";
            $resp['username'] = "";
            $resp['email'] = ""; 
            $resp['fid'] = ucfirst($funct);           
          break;
        }
        if (isset($resp[$res])) {
          return $resp[$res];
        }else{
          return "";
        }
      }
    }
    public static function get_admin($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("main_auths");
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE a_name !='' AND a_status=1");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "count") {
        $v_ref = $rt->select("SELECT COUNT(*) AS all_rec FROM $tab WHERE a_name !=''");
        $rett = 0;
        if (isset($v_ref[0]) && isset($v_ref[0]['all_rec'])) {
          $rett = (is_numeric($v_ref[0]['all_rec']) && $v_ref[0]['all_rec'] > 0) ? $v_ref[0]['all_rec'] : 0 ;
        }
        return $rett;
      }
      elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE a_name !=''");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "exist") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE a_id = :a_id AND h_status=1",[[":a_id",$l_id]]);
        if (isset($v_ref[0]['a_id']) && !empty($v_ref[0]['a_id'])) {
          $retur = "yes";
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE a_id = :a_id",[[":a_id",$l_id]]);
        if (isset($v_ref[0]['a_id']) && !empty($v_ref[0]['a_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "valid") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE a_id = :a_id AND h_status=1",[[":a_id",$l_id]]);
        if (isset($v_ref[0]['a_id']) && !empty($v_ref[0]['a_id'])) {
          $retur = $v_ref[0];
        }else{
          $retur = false;
        }
        return $retur;
      }
      elseif (isset($param[0]) && $param[0] == "tel") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE a_tell = :a_tel AND a_status=1",[[":a_tel",$l_id]]);
        if (isset($v_ref[0]['a_id']) && !empty($v_ref[0]['a_id'])) {
          $retur = $v_ref;
        }else{
          $retur = false;
        }
        return $retur;
      }
    }
   public static function post_category($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("category");
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE c_name !='' AND c_status=1");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE c_name !=''");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "exist") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE c_id = :c_id AND c_status=1",[[":c_id",$l_id]]);
        if (isset($v_ref[0]['c_id']) && !empty($v_ref[0]['c_id'])) {
          $retur = "yes";
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE c_id = :c_id",[[":c_id",$l_id]]);
        if (isset($v_ref[0]['c_id']) && !empty($v_ref[0]['c_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "valid") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE c_id = :l_id AND c_status=1",[[":t_id",$l_id]]);
        if (isset($v_ref[0]['c_id']) && !empty($v_ref[0]['c_id'])) {
          $retur = $v_ref[0];
        }else{
          $retur = false;
        }
        return $retur;
      }
    }
    public static function houses($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("house");
      $tab2 = $rt->table("booked");
      $tab3 = $rt->table("land_lord");
      $tab4 = $rt->table("location");
      $v_ref = array();
      $fid = hdev_log::fid();
      $user = hdev_log::uid();
      $land_lord = "";
      if ($fid == "land_lord") {
        $land_lord = "l_id = '".$user."' AND ";
      }
      $search = hdev_session::get("search");
      $cat = hdev_session::get("cat");
      if ($search != "" && $cat !="") {
        $sc1 = "SELECT $tab4.loc_id FROM $tab4 WHERE loc_province LIKE CONCAT('%', :search, '%') OR loc_district LIKE CONCAT('%', :search, '%') OR loc_sector LIKE CONCAT('%', :search, '%') OR loc_cell LIKE CONCAT('%', :search, '%') OR loc_village LIKE CONCAT('%', :search, '%')";
        $sc = 'AND h_location IN ('.$sc1.') AND c_id = :cat';
        if ($cat = 'all') {
          $sc = 'AND h_location IN ('.$sc1.') AND c_id != :cat';
        }
      }else{
        $search = 'b';
        $cat = 'b';
        $sc = 'AND h_location != :search AND c_id != :cat';
      }
      if (isset($param[0]) && $param[0] == 1) {
        $lmt = new hdev_pager(hdev_session::get("pager_url"));
        $limit = $lmt->limit();
        $ct = count($rt->select("SELECT * FROM $tab2"));
        if ($ct > 0) {
          $v_ref = $rt->select("SELECT * FROM $tab WHERE $land_lord h_description !='' AND h_status=1 AND (SELECT s_status FROM $tab3 WHERE $tab3.l_id = $tab.l_id)=1 AND h_id NOT IN(SELECT DISTINCT h_id FROM $tab2) $sc".$limit,[[':cat',$cat],[':search',$search]]);
          if ($land_lord != "") {
            $v_ref = $rt->select("SELECT * FROM $tab WHERE $land_lord h_description !='' $sc AND h_status=1 AND (SELECT s_status FROM $tab3 WHERE $tab3.l_id = $tab.l_id)=1",[[':cat',$cat],[':search',$search]]);
          }
        }else{
          $v_ref = $rt->select("SELECT * FROM $tab WHERE $land_lord h_description !='' AND (SELECT s_status FROM $tab3 WHERE $tab3.l_id = $tab.l_id)=1 AND h_status=1 $sc".$limit,[[':cat',$cat],[':search',$search]]);
          if ($land_lord != "") {
            $v_ref = $rt->select("SELECT * FROM $tab WHERE $land_lord h_description !='' AND (SELECT s_status FROM $tab3 WHERE $tab3.l_id = $tab.l_id)=1 AND h_status=1 $sc",[[':cat',$cat],[':search',$search]]);
          }
        }
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "count") {
        $ct = count($rt->select("SELECT * FROM $tab2"));
        if ($ct > 0) {
          $v_ref = $rt->select("SELECT COUNT(*) AS all_rec FROM $tab WHERE $land_lord h_description !='' AND (SELECT s_status FROM $tab3 WHERE $tab3.l_id = $tab.l_id)=1 AND h_status=1 AND h_id NOT IN(SELECT DISTINCT h_id FROM $tab2) $sc",[[':cat',$cat],[':search',$search]]);
          $rett = 0;
        }else{
          $v_ref = $rt->select("SELECT COUNT(*) AS all_rec FROM $tab WHERE $land_lord h_description !='' AND (SELECT s_status FROM $tab3 WHERE $tab3.l_id = $tab.l_id)=1 AND h_status=1 $sc",[[':cat',$cat],[':search',$search]]);
          $rett = 0;
        }
        if (isset($v_ref[0]) && isset($v_ref[0]['all_rec'])) {
          $rett = (is_numeric($v_ref[0]['all_rec']) && $v_ref[0]['all_rec'] > 0) ? $v_ref[0]['all_rec'] : 0 ;
        }
        return $rett;
      }
      elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE $land_lord h_description !='' and h_status != 2 AND (SELECT s_status FROM $tab3 WHERE $tab3.l_id = $tab.l_id)=1");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "approve") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE $land_lord h_description !='' and h_status = 2 AND (SELECT s_status FROM $tab3 WHERE $tab3.l_id = $tab.l_id)=1");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "approve_count") {
        $v_ref = $rt->select("SELECT count(*) as All_rec FROM $tab WHERE $land_lord h_description !='' AND h_status = 2 (SELECT s_status FROM $tab3 WHERE $tab3.l_id = $tab.l_id)=1");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }elseif (isset($param[0]) && $param[0] == "delete") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE $land_lord h_description !='' and h_status = 0 AND (SELECT s_status FROM $tab3 WHERE $tab3.l_id = $tab.l_id)=1");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "delete_count") {
        $v_ref = $rt->select("SELECT count(*) as All_rec FROM $tab WHERE $land_lord h_description !='' AND h_status = 0 AND (SELECT s_status FROM $tab3 WHERE $tab3.l_id = $tab.l_id)=1");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }
      elseif (isset($param[0]) && $param[0] == "exist") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE h_id = :h_id AND h_status=1 AND (SELECT s_status FROM $tab3 WHERE $tab3.l_id = $tab.l_id)=1",[[":h_id",$l_id]]);
        if (isset($v_ref[0]['h_id']) && !empty($v_ref[0]['h_id'])) {
          $retur = "yes";
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE h_id = :h_id",[[":h_id",$l_id]]);
        if (isset($v_ref[0]['h_id']) && !empty($v_ref[0]['h_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "valid") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE h_id = :l_id AND h_status=1 AND (SELECT s_status FROM $tab3 WHERE $tab3.l_id = $tab.l_id)=1",[[":h_id",$l_id]]);
        if (isset($v_ref[0]['h_id']) && !empty($v_ref[0]['h_id'])) {
          $retur = $v_ref[0];
        }else{
          $retur = false;
        }
        return $retur;
      }
    } 
   public static function post($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("post");
      $v_ref = array();
      $pro_sess = hdev_session::get("s_id");
      if (hdev_log::fid() == "provider") {
        $var = "AND s_id = ".hdev_log::uid();
      }elseif (!empty(trim($pro_sess)) && is_numeric($pro_sess)) {
        $var = "AND s_id = ".$pro_sess;
      }
      else{
        $var = "";
      }
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE p_title !='' AND p_status=1 $var");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "search") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE p_title !='' AND p_status=1 $var AND (p_title LIKE CONCAT('%', :sc, '%') OR p_short_desc LIKE CONCAT('%', :sc, '%')) ORDER BY p_reg_date DESC LIMIT 0,9",[[':sc',hdev_session::get('search')]]);
        return $v_ref;
      }
      elseif (isset($param[0]) && $param[0] == "recent") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE p_title !='' AND p_status=1 $var ORDER BY p_reg_date DESC LIMIT 0,6" );
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE p_title !='' $var");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "exist") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE p_id = :p_id AND p_status=1 $var",[[":p_id",$l_id]]);
        if (isset($v_ref[0]['p_id']) && !empty($v_ref[0]['p_id'])) {
          $retur = "yes";
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "approve") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE p_title !='' AND p_status = 2 $var");
        return $v_ref;
      }
      elseif (isset($param[0]) && $param[0] == "delete") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE p_title !='' AND p_status = 0 $var");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE p_id = :p_id $var",[[":p_id",$l_id]]);
        if (isset($v_ref[0]['p_id']) && !empty($v_ref[0]['p_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "valid") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE p_id = :l_id AND p_status=1 $var",[[":p_id",$l_id]]);
        if (isset($v_ref[0]['p_id']) && !empty($v_ref[0]['p_id'])) {
          $retur = $v_ref[0];
        }else{
          $retur = false;
        }
        return $retur;
      }
    }
    public static function provider($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("specialist");
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE s_name !='' AND s_status=1");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE s_name !='' AND s_status != 2");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "approve") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE s_name !='' AND s_status = 2");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "approve_count") {
        $v_ref = $rt->select("SELECT count(*) as All_rec FROM $tab WHERE s_name !='' AND s_status = 2");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }elseif (isset($param[0]) && $param[0] == "delete") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE s_name !='' AND s_status = 0");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "delete_count") {
        $v_ref = $rt->select("SELECT count(*) as All_rec FROM $tab WHERE s_name !='' AND s_status = 0");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }
      elseif (isset($param[0]) && $param[0] == "exist") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE s_id = :l_id AND s_status=1",[[":l_id",$l_id]]);
        if (isset($v_ref[0]['l_id']) && !empty($v_ref[0]['l_id'])) {
          $retur = "yes";
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE s_id = :l_id",[[":l_id",$l_id]]);
        if (isset($v_ref[0]['s_id']) && !empty($v_ref[0]['s_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "valid") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE l_id = :l_id AND s_status=1",[[":l_id",$l_id]]);
        if (isset($v_ref[0]['l_id']) && !empty($v_ref[0]['l_id'])) {
          $retur = $v_ref[0];
        }else{
          $retur = false;
        }
        return $retur;
      }
      elseif (isset($param[0]) && $param[0] == "tel") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE s_tel = :a_tel AND s_status=1",[[":a_tel",$l_id]]);
        if (isset($v_ref[0]['s_id']) && !empty($v_ref[0]['s_id'])) {
          $retur = $v_ref;
        }else{
          $retur = false;
        }
        return $retur;
      }
    }
    public static function load_view($type="",$support=[])
    {
      $data = new hdev_db;
      $table = $data->table("slider");
      switch ($type) {
        case 'service':
          $return = $data->select("SELECT * FROM $table WHERE p_type=:serv",[[':serv','service']]);
          break;
        case 'package':
          $return = $data->select("SELECT * FROM $table WHERE p_type=:serv",[[':serv','package']]);
          break;
        case 'partner':
          $return = $data->select("SELECT * FROM $table WHERE p_type=:serv",[[':serv','partner']]);
          break;
        case 'slide':
          $return = $data->select("SELECT * FROM $table WHERE p_type=:serv",[[':serv','slide']]);
          break;
        case 'days':
          $tab = $data->table("action");
          $return = array();
          if (isset($support['id']) && !empty($support['id']) && isset($support['package']) && !empty($support['package'])) {
            $return = $data->select("SELECT * FROM $tab WHERE d_id=:id and p_id=:p_id ORDER BY d_num,d_id",[[':p_id',$support['package']],[':id',$support['id']]]);
          }
          break;
        default:
          $return = array();
          break;
      }
      return $return;
    }
  }
  /**
   * 
   */
	/*  $rt = new hdev_db();
      $tab = $rt->table("category");
      $ref =$rt->select("SELECT * FROM $tab");
      $a = "";
      if (count($ref) > 0) {
        if ($v=="menu") {
          foreach ($ref as $tk) {
            $a .= ",".$tk["c_name"];
          }
          $a = substr($a, 1);
          return $a;
        }
      }else{
        return "";
      }
	$ty = new hdev_db('mysqli');
	$yr = $ty->select("SELECT user_id, f_name, s_name FROM u_auth WHERE user_id = :yh AND s_name = :s",[[":yh","1"],[":s","Roger"]]);
	foreach ($yr as $regds) {
		var_dump($regds);
		foreach ($regds as $er) {
			echo $er."<br>";
		}
	}*/
?>