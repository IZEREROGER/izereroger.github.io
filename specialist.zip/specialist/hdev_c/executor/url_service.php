<?php 
	$rasms_urls = array ( 

	'/login_i' => array (
		'name' => 'access to view [/login_i]',
		'error' => 'You can not access this page',
		),
	'/up' => array (
		'name' => 'access to view [/up]',
		'error' => 'You can not access this page',
		),
	'/app/report/(.*)/(.*)' => array (
		'name' => 'access to view [/app/report/(.*)/(.*)]',
		'error' => 'You can not access this page',
		),
	'/app/setting/(.*)/(.*)' => array (
		'name' => 'access to view [/app/setting/(.*)/(.*)]',
		'error' => 'You can not access this page',
		),
	'/login' => array (
		'name' => 'access to view [/login]',
		'error' => 'You can not access this page',
		),
	'/register' => array (
		'name' => 'access to view [/register]',
		'error' => 'You can not access this page',
		),
	'/' => array (
		'name' => 'access to view [/]',
		'error' => 'You can not access this page',
		),
	'' => array (
		'name' => 'access to view []',
		'error' => 'You can not access this page',
		),
	'/r/about' => array (
		'name' => 'access to view [/r/about]',
		'error' => 'You can not access this page',
		),
	'/r/home' => array (
		'name' => 'access to view [/r/home]',
		'error' => 'You can not access this page',
		),
	'/r/home/a/b/c' => array (
		'name' => 'access to view [/r/home/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/r/home/page/(.*)/a/b/c' => array (
		'name' => 'access to view [/r/home/page/(.*)/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/r/home/page/(.*)' => array (
		'name' => 'access to view [/r/home/page/(.*)]',
		'error' => 'You can not access this page',
		),
	'/r/profile' => array (
		'name' => 'access to view [/r/profile]',
		'error' => 'You can not access this page',
		),
	'/r/profile/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/r/reg_provider' => array (
		'name' => 'access to view [/r/reg_provider]',
		'error' => 'You can not access this page',
		),
	'/r/reg_provider/a/b/c' => array (
		'name' => 'access to view [/r/reg_provider/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/approval/provider' => array (
		'name' => 'access to view [/approval/provider]',
		'error' => 'You can not access this page',
		),
	'/approval/provider/a/b/c' => array (
		'name' => 'access to view [/approval/provider/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/trash/provider' => array (
		'name' => 'access to view [/trash/provider]',
		'error' => 'You can not access this page',
		),
	'/trash/provider/a/b/c' => array (
		'name' => 'access to view [/trash/provider/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/r/reg_post' => array (
		'name' => 'access to view [/r/reg_provider]',
		'error' => 'You can not access this page',
		),
	'/r/reg_post/a/b/c' => array (
		'name' => 'access to view [/r/reg_provider/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/approval/post' => array (
		'name' => 'access to view [/approval/provider]',
		'error' => 'You can not access this page',
		),
	'/approval/post/a/b/c' => array (
		'name' => 'access to view [/approval/provider/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/trash/post' => array (
		'name' => 'access to view [/trash/provider]',
		'error' => 'You can not access this page',
		),
	'/trash/post/a/b/c' => array (
		'name' => 'access to view [/trash/provider/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/edit/(.*)/post' => array (
		'name' => 'access to view [/trash/provider]',
		'error' => 'You can not access this page',
		),
	'/edit/(.*)/post/a/b/c' => array (
		'name' => 'access to view [/trash/provider/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/modify/slide' => array (
		'name' => 'access to view [/trash/provider]',
		'error' => 'You can not access this page',
		),
	'/modify/slide/a/b/c' => array (
		'name' => 'access to view [/trash/provider/a/b/c]',
		'error' => 'You can not access this page',
		),		
	'/view/(.*)/post' => array (
		'name' => 'access to view [/trash/provider]',
		'error' => 'You can not access this page',
		),
	'/view/(.*)/post/a/b/c' => array (
		'name' => 'access to view [/trash/provider/a/b/c]',
		'error' => 'You can not access this page',
		),				
	'/s' => array (
		'name' => 'access to view [/s]',
		'error' => 'You can not access this page',
		),
	'/script-1' => array (
		'name' => 'access to view [/script-1]',
		'error' => 'You can not access this page',
		),
	'/auth/gen/(.*)' => array (
		'name' => 'access to view [/auth/gen/(.*)]',
		'error' => 'You can not access this page',
		),
	'/test' => array (
		'name' => 'access to view [/test]',
		'error' => 'You can not access this page',
		),
	'/forgot' => array (
		'name' => 'access to view [/test]',
		'error' => 'You can not access this page',
		),
	'/view/provider' => array (
		'name' => 'access to view [/test]',
		'error' => 'You can not access this page',
		),
	'/view/provider/a/b/c' => array (
		'name' => 'access to view [/test]',
		'error' => 'You can not access this page',
		),	
	'/provider/(.*)/post' => array (
		'name' => 'access to view [/test]',
		'error' => 'You can not access this page',
		),
	'/provider/(.*)/post/a/b/c' => array (
		'name' => 'access to view [/test]',
		'error' => 'You can not access this page',
		),		
	'/post/view' => array (
		'name' => 'access to view [/test]',
		'error' => 'You can not access this page',
		),
	'/post/view/a/b/c' => array (
		'name' => 'access to view [/test]',
		'error' => 'You can not access this page',
		),	
	'/search' => array (
		'name' => 'access to view [/test]',
		'error' => 'You can not access this page',
		),
	'/search/a/b/c' => array (
		'name' => 'access to view [/test]',
		'error' => 'You can not access this page',
		),			
	);
	//$all_services = array_keys($rasms_urls);
	//$tg = "";
	//foreach ($all_services as $key) {
	//	if ($key == "stud_delete") {
	//		$tg = 9;
	//	}
	//	if ($tg != 9) {
	//		echo "'".$key."' /*".$rasms_urls[$key]['name']."*/,\n";
	//	}
		
	//}
	$rasms_urls_users = array(
		'guest'=>array(
			'/register' /*Access to login*/,
			'/login' /*Access to login*/,
			'/login_i' /*Access To view Login Page*/,
			'/up' /*Access to submit data*/,
			'/login_i',
			'/edit/(.*)/post',
			'/edit/(.*)/post/a/b/c',
			'/forgot',
			'/search',
			'/search/a/b/c',
			'',
			'/',
			'/r/home' /*Access to view homepage*/,
			'/r/home/a/b/c' /*Access to view homepage*/,
			'/r/home/page/(.*)' /*Access to view homepage*/,
			'/r/home/page/(.*)/a/b/c' /*Access to view homepage*/,
			'/script-1' /*Access to test*/,
			'/view/(.*)/post',
			'/view/(.*)/post/a/b/c',
			'/view/provider',
			'/view/provider/a/b/c',
			'/provider/(.*)/post',
			'/provider/(.*)/post/a/b/c',
			'/post/view',
			'/post/view/a/b/c'
		),
		'admin'=> array( /// was admin


			'/login_i',
			'/up',
			'/app/report/(.*)/(.*)',
			'/app/setting/(.*)/(.*)',
			'/login',
			'/register',
			'/',
			'',
			'/search',
			'/search/a/b/c',
			'/r/about',
			'/r/home',
			'/r/home/a/b/c',
			'/r/home/page/(.*)/a/b/c',
			'/r/home/page/(.*)',
			'/modify/slide',
			'/modify/slide/a/b/c',
			'/r/profile',
			'/r/profile/a/b/c',
			'/r/reg_provider',
			'/r/reg_provider/a/b/c',
			'/edit/(.*)/post',
			'/edit/(.*)/post/a/b/c',
			'/approval/provider',
			'/approval/provider/a/b/c',
			'/trash/provider',
			'/trash/provider/a/b/c',
			'/r/reg_post',
			'/r/reg_post/a/b/c',
			'/approval/post',
			'/approval/post/a/b/c',
			'/trash/post',
			'/trash/post/a/b/c',			
			'/s',
			'/script-1',
			'/auth/gen/(.*)',
			'/test',
			'/view/provider',
			'/view/provider/a/b/c',
			'/view/provider',
			'/view/provider/a/b/c',
			'/provider/(.*)/post',
			'/provider/(.*)/post/a/b/c',
			'/post/view',
			'/post/view/a/b/c'

			
		),
		'provider'=> array( /// was admin

			'/login_i',
			'/up',
			'/app/setting/(.*)/(.*)',
			'/login',
			'/register',
			'/',
			'',
			'/search',
			'/search/a/b/c',
			'/r/about',
			'/r/home',
			'/r/home/a/b/c',
			'/r/home/page/(.*)/a/b/c',
			'/r/home/page/(.*)',
			'/r/profile',
			'/r/profile/a/b/c',
			'/r/reg_post',
			'/r/reg_post/a/b/c',
			'/approval/post',
			'/approval/post/a/b/c',
			'/edit/(.*)/post',
			'/edit/(.*)/post/a/b/c',
			'/view/(.*)/post',
			'/view/(.*)/post/a/b/c',
			'/trash/post',
			'/trash/post/a/b/c',
			'/s',
			'/script-1',
			'/auth/gen/(.*)',
			'/test',
			'/app/report/(.*)/(.*)',
			'/view/provider',
			'/view/provider/a/b/c',
			'/provider/(.*)/post',
			'/provider/(.*)/post/a/b/c',
			'/post/view',
			'/post/view/a/b/c'
			
		),
	);
	
 ?>