<?php  
	define('base_path', '/specialist/');
	define("APP_NAME", "Project consultancy");
	define('APP_MASK', 'Project consultancy');
	//define("APP_NAME", "My System");
	//define('APP_MASK', 'My System');
	define("district", "Kicukiro District");
	define('tel', '0787041561');

	define('APP_PREFIX', 'HRA-pay');
	define('SMS_SENDER', 'Ni OHRS');
	define('SMS_USERNAME', 'enock23');// username
	define('SMS_PASSWORD', 'enockENOCK@2021');// password
	define("APP_VERSION", "1.1");
	define('APP_PROGRAMMER', ['name'=>'Me','email'=>'me@gmail.com']);
	
	define('db',"hdev_specialist");
	define('db_preview',"hdev_specialist");
	define('dbpass_preview', '');
	define('dbusr_preview', 'root');	
	define('dbpass', '');
	define('dbusr', 'root');
	define('dbport', '3306');
	define('dbport_preview', '3306');
	define('db_remote', 'st_soft');
	define('dbusr_remote', 'roger');	
	define('dbpass_remote', 'qwe');
	define('dbport_remote', '3309');
	define('school_code', 'rasms_mtvet');
	//auth check 
	define("roger_draft", "hdev_c3538TVVTQU1WVSBUVkVUIFNDSE9PTA==");
	define('ad_us_pw', "hdev_79b11Li4uUk9HLi4=");
	//error_reporting(0);
 ?>