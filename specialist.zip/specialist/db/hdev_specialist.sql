-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jun 29, 2022 at 04:03 AM
-- Server version: 10.3.34-MariaDB-log-cll-lve
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ltgrqxgp_sales`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `a_id` int(11) NOT NULL,
  `a_name` text NOT NULL,
  `a_sex` text NOT NULL,
  `a_dob` date NOT NULL,
  `a_email` text NOT NULL,
  `a_tell` text NOT NULL,
  `a_password` text NOT NULL,
  `a_status` int(11) NOT NULL DEFAULT 1,
  `a_reg_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`a_id`, `a_name`, `a_sex`, `a_dob`, `a_email`, `a_tell`, `a_password`, `a_status`, `a_reg_date`) VALUES
(1, 'Niyomukiza Enock', 'Male', '2022-06-01', 'enock@gmail.com', '0785504550', '202cb962ac59075b964b07152d234b70', 1, '2022-06-11 13:24:58');

-- --------------------------------------------------------

--
-- Stand-in structure for view `auth_engine`
-- (See below for the actual view)
--
CREATE TABLE `auth_engine` (
`a_id` int(11)
,`a_username` mediumtext
,`a_email` mediumtext
,`a_password` mediumtext
,`a_role` varchar(8)
,`a_status` mediumtext
);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `p_id` int(11) NOT NULL,
  `s_id` int(11) NOT NULL,
  `c_id` text NOT NULL,
  `p_pic` text NOT NULL,
  `p_title` text NOT NULL,
  `p_short_desc` text NOT NULL,
  `p_content` longtext NOT NULL,
  `p_attachment` text DEFAULT NULL,
  `p_status` int(11) NOT NULL DEFAULT 1,
  `p_reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`p_id`, `s_id`, `c_id`, `p_pic`, `p_title`, `p_short_desc`, `p_content`, `p_attachment`, `p_status`, `p_reg_date`) VALUES
(1, 1, 'Marketing', 'post_img_pic_62acb89c9668f_t_1655486620.jpg', 'marketing', '', '<h1>Use the Menu</h1><p>We recommend reading this tutorial, in the sequence listed in the menu.</p><p>If you have a large screen, the menu will always be present on the left.</p><p>If you have a small screen, open the menu by clicking the top menu sign ☰.</p><hr><h2 style=\"margin-left:0px;\">Learn by Examples</h2><p>Examples are better than 1000 words. Examples are often easier to understand than text explanations.</p><p>This tutorial supplements all explanations with clarifying \"Try it Yourself\" examples.</p><p style=\"margin-left:-32px;\">If you try all the examples, you will learn a lot about JavaScript, in a very short time!</p><p style=\"margin-left:-32px;\"><a href=\"https://www.w3schools.com/js/js_examples.asp\">JavaScript Examples »</a></p><hr><h2 style=\"margin-left:0px;\">Why Study JavaScript?</h2><p>JavaScript is one of the <strong>3 languages</strong> all web developers <strong>must</strong> learn:</p><p>&nbsp;&nbsp; 1. <a href=\"https://www.w3schools.com/html/default.asp\"><strong>HTML</strong></a> to define the content of web pages</p><p>&nbsp;&nbsp; 2. <a href=\"https://www.w3schools.com/css/default.asp\"><strong>CSS</strong></a> to specify the layout of web pages</p><p>&nbsp;&nbsp; 3. <strong>JavaScript</strong> to program the behavior of web pages</p><p style=\"margin-left:-32px;\">This tutorial covers every version of JavaScript:</p><ul><li>The Original JavaScript ES1 ES2 ES3 (1997-1999)</li><li>The First Main Revision ES5 (2009)</li><li>The Second Revision ES6 (2015)</li><li>The Yearly Additions (2016, 2017, 2018)</li></ul><hr><p style=\"margin-left:-16px;\">&nbsp;</p><hr><h2 style=\"margin-left:0px;\">Learning Speed</h2><p>In this tutorial, the learning speed is your choice.</p><p>Everything is up to you.</p><p>If you are struggling, take a break, or re-read the material.</p><p><strong>Always</strong> make sure you understand <strong>all</strong> the \"Try-it-Yourself\" examples.</p><p>The only way to become a clever programmer is to: Practice. Practice. Practice. Co</p><p>&nbsp;</p>', 'post_doc_62acb89c96967_t_1655486620.docx', 1, '2022-06-18 09:22:41'),
(2, 1, 'NEW PODUCT', 'post_img_pic_62ad98daa42f5_t_1655544026.jpg', 'LESSON ONE', 'WE OFFE THIS', '<h1>WELCOME</h1><p>JavaScript is the world\'s most popular programming language.</p><p>JavaScript is the programming language of the Web.</p><p>JavaScript is easy to learn.</p><p>This tutorial will teach you JavaScript from basic to advanced.</p>', 'post_doc_62ad98daa45ef_t_1655544026.docx', 1, '2022-06-18 09:22:56');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `p_id` int(11) NOT NULL,
  `p_title` text NOT NULL,
  `p_pic` text NOT NULL,
  `p_desc` text NOT NULL,
  `p_type` text NOT NULL,
  `p_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`p_id`, `p_title`, `p_pic`, `p_desc`, `p_type`, `p_date`) VALUES
(4, 'New ones on Project Consultancy', 'slide_upload_62ade9dce3e75_t_1655564764.jpeg', 'welcome you may choose which one is good', 'slide', '2022-06-18 15:06:04'),
(5, 'Olivier', 'slide_upload_62adea639e11c_t_1655564899.jpg', 'New consultancy  also', 'slide', '2022-06-18 15:08:19');

-- --------------------------------------------------------

--
-- Table structure for table `specialist`
--

CREATE TABLE `specialist` (
  `s_id` int(11) NOT NULL,
  `s_name` text NOT NULL,
  `s_sex` text NOT NULL,
  `s_dob` date NOT NULL,
  `s_qualification` text NOT NULL,
  `s_email` text NOT NULL,
  `s_tel` text NOT NULL,
  `s_password` text NOT NULL,
  `s_status` text DEFAULT '1',
  `s_reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `specialist`
--

INSERT INTO `specialist` (`s_id`, `s_name`, `s_sex`, `s_dob`, `s_qualification`, `s_email`, `s_tel`, `s_password`, `s_status`, `s_reg_date`) VALUES
(1, 'IZERE HIRWA Roger', 'Male', '0000-00-00', 'A1 IN INFORMATION TECHNOLOGY', 'izere@gmail.com', '0788788291', '202cb962ac59075b964b07152d234b70', '1', '2022-06-17 15:40:27'),
(2, 'Jordan', 'Male', '0000-00-00', 'Bachelor\'s in physiology', 'jordan@gmail.com', '0785504550', '202cb962ac59075b964b07152d234b70', '1', '2022-06-17 16:17:51'),
(3, 'Niyonkuru', 'Male', '0000-00-00', 'Bachelor degree in business and information technology', 'niyonkuruolivier97@gmail.com', '0784254890', '202cb962ac59075b964b07152d234b70', '1', '2022-06-17 16:37:59');

-- --------------------------------------------------------

--
-- Structure for view `auth_engine`
--
DROP TABLE IF EXISTS `auth_engine`;

CREATE ALGORITHM=UNDEFINED DEFINER=`ltgrqxgp`@`localhost` SQL SECURITY DEFINER VIEW `auth_engine`  AS SELECT `admin`.`a_id` AS `a_id`, `admin`.`a_email` AS `a_username`, `admin`.`a_email` AS `a_email`, `admin`.`a_password` AS `a_password`, 'admin' AS `a_role`, `admin`.`a_status` AS `a_status` FROM `admin` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `specialist`
--
ALTER TABLE `specialist`
  ADD PRIMARY KEY (`s_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `specialist`
--
ALTER TABLE `specialist`
  MODIFY `s_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `post_ibfk_1` FOREIGN KEY (`s_id`) REFERENCES `specialist` (`s_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
