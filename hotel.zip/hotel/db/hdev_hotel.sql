-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 03, 2022 at 10:09 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.0.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hdev_hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `h_brand`
--

CREATE TABLE `h_brand` (
  `b_id` bigint(100) NOT NULL,
  `b_name` text NOT NULL,
  `b_desc` text NOT NULL,
  `b_status` int(11) NOT NULL DEFAULT 1,
  `b_reg_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `h_cart`
--

CREATE TABLE `h_cart` (
  `cart_id` bigint(20) NOT NULL,
  `cart_type` text NOT NULL,
  `cart_ref_id` varchar(255) NOT NULL,
  `cart_qty` int(11) NOT NULL,
  `cart_price` double NOT NULL,
  `cart_request` varchar(255) NOT NULL,
  `ext_info` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `h_category`
--

CREATE TABLE `h_category` (
  `c_id` bigint(100) NOT NULL,
  `c_name` text NOT NULL,
  `c_desc` text NOT NULL,
  `c_status` int(11) NOT NULL DEFAULT 1,
  `c_reg_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `h_order`
--

CREATE TABLE `h_order` (
  `o_id` bigint(100) NOT NULL,
  `client` text NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `o_hash` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `h_products`
--

CREATE TABLE `h_products` (
  `p_id` bigint(100) NOT NULL,
  `c_id` bigint(100) NOT NULL,
  `b_id` bigint(100) NOT NULL,
  `p_name` text NOT NULL,
  `p_unit` text NOT NULL,
  `p_desc` text NOT NULL,
  `p_pic` text NOT NULL,
  `p_price` double NOT NULL,
  `p_stock_status` int(11) NOT NULL DEFAULT 1,
  `p_status` int(11) NOT NULL DEFAULT 1,
  `p_reg_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `h_product_order`
--

CREATE TABLE `h_product_order` (
  `po_id` bigint(100) NOT NULL,
  `p_id` bigint(100) NOT NULL,
  `o_id` bigint(100) NOT NULL,
  `po_price` double NOT NULL,
  `po_qty` double NOT NULL,
  `po_status` int(11) NOT NULL DEFAULT 1,
  `po_reg_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `h_room`
--

CREATE TABLE `h_room` (
  `r_id` bigint(100) NOT NULL,
  `r_name` text NOT NULL,
  `r_desc` text NOT NULL,
  `r_price` double NOT NULL,
  `r_pic` text NOT NULL,
  `r_status` int(11) NOT NULL DEFAULT 1,
  `r_reg_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `h_room_order`
--

CREATE TABLE `h_room_order` (
  `ro_id` bigint(20) NOT NULL,
  `o_id` bigint(100) NOT NULL,
  `r_id` bigint(100) NOT NULL,
  `ro_days` int(11) NOT NULL,
  `ro_unit_price` double NOT NULL,
  `ro_reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `ro_status` int(11) NOT NULL DEFAULT 1,
  `ext_info` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `h_tools`
--

CREATE TABLE `h_tools` (
  `t_id` bigint(100) NOT NULL,
  `t_name` text NOT NULL,
  `t_desc` text NOT NULL,
  `t_qty` double NOT NULL,
  `t_health` int(11) NOT NULL DEFAULT 1,
  `t_status` int(11) NOT NULL DEFAULT 1,
  `t_update` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `h_users`
--

CREATE TABLE `h_users` (
  `u_id` bigint(100) NOT NULL,
  `names` text NOT NULL,
  `n_id` varchar(16) NOT NULL,
  `tel` text NOT NULL,
  `email` text NOT NULL,
  `role` text NOT NULL,
  `password` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `h_users`
--

INSERT INTO `h_users` (`u_id`, `names`, `n_id`, `tel`, `email`, `role`, `password`, `status`) VALUES
(1, 'Curie', '1122558', '0788788291', 'curie@gmail.com', 'admin', '202cb962ac59075b964b07152d234b70', 1),
(2, 'Uwase', '1234567890123456', '0785569911', 'uwase@gmail.com', 'manager', '81dc9bdb52d04dc20036dbd8313ed055', 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `stock_detail_transactions`
-- (See below for the actual view)
--
CREATE TABLE `stock_detail_transactions` (
`sin_id` bigint(100)
,`p_id` bigint(100)
,`price_unit` decimal(11,2)
,`sell_price_unit` decimal(11,0)
,`sin_qty` decimal(11,2)
,`sout_qty` decimal(33,2)
,`qty_balance` decimal(34,2)
,`supplier` text
,`product_mfg_date` date
,`product_exp_date` date
,`sin_reg_date` timestamp
,`sin_status` int(11)
,`sin_reg_by` bigint(100)
);

-- --------------------------------------------------------

--
-- Table structure for table `stock_in`
--

CREATE TABLE `stock_in` (
  `sin_id` bigint(100) NOT NULL,
  `p_id` bigint(100) NOT NULL,
  `price_unit` decimal(11,2) NOT NULL,
  `sell_price_unit` decimal(11,0) NOT NULL,
  `sin_qty` decimal(11,2) NOT NULL,
  `supplier` text NOT NULL,
  `product_mfg_date` date DEFAULT NULL,
  `product_exp_date` date DEFAULT NULL,
  `sin_reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `sin_status` int(11) NOT NULL DEFAULT 1,
  `sin_reg_by` bigint(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `stock_out`
--

CREATE TABLE `stock_out` (
  `sout_id` bigint(100) NOT NULL,
  `sin_id` bigint(100) NOT NULL,
  `sout_unit_price` decimal(11,2) NOT NULL,
  `sout_qty` decimal(11,2) NOT NULL,
  `customer` text NOT NULL,
  `sout_reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `sout_reg_by` bigint(100) NOT NULL,
  `sout_status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Stand-in structure for view `stock_status`
-- (See below for the actual view)
--
CREATE TABLE `stock_status` (
`sout_id` bigint(100)
,`p_id` bigint(100)
,`price_unit` decimal(11,2)
,`sell_price_unit` decimal(11,0)
,`sout_qty` decimal(11,2)
,`supplier` text
,`product_mfg_date` date
,`product_exp_date` date
,`sin_reg_date` timestamp
,`sout_reg_date` date
,`sout_status` int(11)
,`sin_reg_by` bigint(100)
);

-- --------------------------------------------------------

--
-- Structure for view `stock_detail_transactions`
--
DROP TABLE IF EXISTS `stock_detail_transactions`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `stock_detail_transactions`  AS SELECT `a`.`sin_id` AS `sin_id`, `a`.`p_id` AS `p_id`, `a`.`price_unit` AS `price_unit`, `a`.`sell_price_unit` AS `sell_price_unit`, `a`.`sin_qty` AS `sin_qty`, ifnull(sum(`b`.`sout_qty`),0) AS `sout_qty`, `a`.`sin_qty`- ifnull(sum(`b`.`sout_qty`),0) AS `qty_balance`, `a`.`supplier` AS `supplier`, `a`.`product_mfg_date` AS `product_mfg_date`, `a`.`product_exp_date` AS `product_exp_date`, `a`.`sin_reg_date` AS `sin_reg_date`, `a`.`sin_status` AS `sin_status`, `a`.`sin_reg_by` AS `sin_reg_by` FROM ((`stock_in` `a` left join `stock_out` `b` on(`a`.`sin_id` = `b`.`sin_id`)) join `h_products` `c` on(`a`.`p_id` = `c`.`p_id`)) WHERE `c`.`p_status` = 1 GROUP BY `a`.`sin_id` ORDER BY `a`.`sin_reg_date` ASC  ;

-- --------------------------------------------------------

--
-- Structure for view `stock_status`
--
DROP TABLE IF EXISTS `stock_status`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `stock_status`  AS SELECT `b`.`sout_id` AS `sout_id`, `a`.`p_id` AS `p_id`, `a`.`price_unit` AS `price_unit`, `a`.`sell_price_unit` AS `sell_price_unit`, `b`.`sout_qty` AS `sout_qty`, `a`.`supplier` AS `supplier`, `a`.`product_mfg_date` AS `product_mfg_date`, `a`.`product_exp_date` AS `product_exp_date`, `a`.`sin_reg_date` AS `sin_reg_date`, cast(`b`.`sout_reg_date` as date) AS `sout_reg_date`, `b`.`sout_status` AS `sout_status`, `a`.`sin_reg_by` AS `sin_reg_by` FROM ((`stock_in` `a` left join `stock_out` `b` on(`a`.`sin_id` = `b`.`sin_id`)) join `h_products` `c` on(`a`.`p_id` = `c`.`p_id`)) WHERE `c`.`p_status` = 1 AND `b`.`sout_status` = 1 ORDER BY `b`.`sout_reg_date` AS `DESCdesc` ASC  ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `h_brand`
--
ALTER TABLE `h_brand`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `h_cart`
--
ALTER TABLE `h_cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `h_category`
--
ALTER TABLE `h_category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `h_order`
--
ALTER TABLE `h_order`
  ADD PRIMARY KEY (`o_id`);

--
-- Indexes for table `h_products`
--
ALTER TABLE `h_products`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `c_id` (`c_id`),
  ADD KEY `b_id` (`b_id`);

--
-- Indexes for table `h_product_order`
--
ALTER TABLE `h_product_order`
  ADD PRIMARY KEY (`po_id`),
  ADD KEY `o_id` (`o_id`),
  ADD KEY `p_id` (`p_id`);

--
-- Indexes for table `h_room`
--
ALTER TABLE `h_room`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `h_room_order`
--
ALTER TABLE `h_room_order`
  ADD PRIMARY KEY (`ro_id`),
  ADD KEY `o_id` (`o_id`),
  ADD KEY `r_id` (`r_id`);

--
-- Indexes for table `h_tools`
--
ALTER TABLE `h_tools`
  ADD PRIMARY KEY (`t_id`);

--
-- Indexes for table `h_users`
--
ALTER TABLE `h_users`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `stock_in`
--
ALTER TABLE `stock_in`
  ADD PRIMARY KEY (`sin_id`),
  ADD KEY `p_id` (`p_id`);

--
-- Indexes for table `stock_out`
--
ALTER TABLE `stock_out`
  ADD PRIMARY KEY (`sout_id`),
  ADD KEY `sin_id` (`sin_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `h_brand`
--
ALTER TABLE `h_brand`
  MODIFY `b_id` bigint(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `h_cart`
--
ALTER TABLE `h_cart`
  MODIFY `cart_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `h_category`
--
ALTER TABLE `h_category`
  MODIFY `c_id` bigint(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `h_order`
--
ALTER TABLE `h_order`
  MODIFY `o_id` bigint(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `h_products`
--
ALTER TABLE `h_products`
  MODIFY `p_id` bigint(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `h_product_order`
--
ALTER TABLE `h_product_order`
  MODIFY `po_id` bigint(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `h_room`
--
ALTER TABLE `h_room`
  MODIFY `r_id` bigint(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `h_room_order`
--
ALTER TABLE `h_room_order`
  MODIFY `ro_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `h_tools`
--
ALTER TABLE `h_tools`
  MODIFY `t_id` bigint(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `h_users`
--
ALTER TABLE `h_users`
  MODIFY `u_id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `stock_in`
--
ALTER TABLE `stock_in`
  MODIFY `sin_id` bigint(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stock_out`
--
ALTER TABLE `stock_out`
  MODIFY `sout_id` bigint(100) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `h_products`
--
ALTER TABLE `h_products`
  ADD CONSTRAINT `h_products_ibfk_1` FOREIGN KEY (`c_id`) REFERENCES `h_category` (`c_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `h_products_ibfk_2` FOREIGN KEY (`b_id`) REFERENCES `h_brand` (`b_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `h_product_order`
--
ALTER TABLE `h_product_order`
  ADD CONSTRAINT `h_product_order_ibfk_1` FOREIGN KEY (`o_id`) REFERENCES `h_order` (`o_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `h_product_order_ibfk_2` FOREIGN KEY (`p_id`) REFERENCES `h_products` (`p_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `h_room_order`
--
ALTER TABLE `h_room_order`
  ADD CONSTRAINT `h_room_order_ibfk_1` FOREIGN KEY (`o_id`) REFERENCES `h_order` (`o_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `h_room_order_ibfk_2` FOREIGN KEY (`r_id`) REFERENCES `h_room` (`r_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `stock_in`
--
ALTER TABLE `stock_in`
  ADD CONSTRAINT `stock_in_ibfk_1` FOREIGN KEY (`p_id`) REFERENCES `h_products` (`p_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `stock_out`
--
ALTER TABLE `stock_out`
  ADD CONSTRAINT `stock_out_ibfk_1` FOREIGN KEY (`sin_id`) REFERENCES `stock_in` (`sin_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
