<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Hotel Deleted equipments</h5>
              </div>
              <div class="card-body table-responsive p-2">
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="data-table table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort"><?php echo hdev_lang::on("data","regno"); ?></th>
                      <th>Equipment name</th>
                      <th>Equipment Quantity</th> 
                      <th>Equipment description</th>
                      <th>Equipment Health</th>
                      <th>Last update</th>
                      <?php if (hdev_data::service('tools_delete') || hdev_data::service('tools_edit')): ?>
                      <th><?php echo hdev_lang::on("form","action"); ?></th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::tools('',['delete']);
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $tools) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:tools_recover;id:".$tools['t_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#eq_del_close;app:".$tkn.";".$build2);
                    ?>

                    <tr>
                      <td class="table-plus">
                        <?php echo $tools["t_id"]; ?>
                      </td>
                      <td>
                        <?php echo $tools["t_name"]; ?>
                      </td>
                      <td>
                        <?php echo $tools["t_qty"]; ?>
                      </td>
                      <td>
                        <?php echo $tools["t_desc"]; ?>
                      </td>
                      <td>
                        <?php echo hdev_data::tool_health($tools["t_health"]); ?>
                      </td>
                      <td>
                        <?php echo $tools["t_update"]; ?>
                      </td>
                      <?php if (hdev_data::service('tools_delete') || hdev_data::service('tools_edit')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('tools_delete')): ?>
                          <button type="button" hash="<?php echo $tkn; ?>" data="<?php echo $reject; ?>" rel="external" class="btn btn-secondary eq_delete" t_name="<?php echo $tools['t_name']; ?>" data-toggle="modal" data-target=".modal-delete"><i class="fa fa-recycle"></i> <?php echo hdev_lang::on("form","recover"); ?> </button>
                           <?php endif ?>
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('tools_delete')): ?> 
<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo hdev_lang::on("form","accept"); ?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you sure you want to Recover the following Equipment to current hotel equipment list ?</th>
                </tr>
                <tr>
                  <td>Equipment name : </td>
                  <td id="t_name"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="eq_del_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-success" id="tools_delete" data="" hash=""><i class="fa fa-recycle"></i> Recover equipment</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>