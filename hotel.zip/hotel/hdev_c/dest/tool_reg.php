<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Hotel equipments</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">
                  <?php if (hdev_data::service('tools_reg')): ?>
                  <button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fa fa-plus-circle"></i> Add equipment</button>&nbsp;
                  <?php endif ?>
                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="data-table table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort"><?php echo hdev_lang::on("data","regno"); ?></th>
                      <th>Equipment name</th>
                      <th>Equipment Quantity</th> 
                      <th>Equipment description</th>
                      <th>Equipment Health</th>
                      <th>Last update</th>
                      <?php if (hdev_data::service('tools_delete') || hdev_data::service('tools_edit')): ?>
                      <th><?php echo hdev_lang::on("form","action"); ?></th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::tools();
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $tools) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:tools_delete;id:".$tools['t_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#eq_del_close;app:".$tkn.";".$build2);
                    ?>

                    <tr>
                      <td class="table-plus">
                        <?php echo $tools["t_id"]; ?>
                      </td>
                      <td>
                        <?php echo $tools["t_name"]; ?>
                      </td>
                      <td>
                        <?php echo $tools["t_qty"]; ?>
                      </td>
                      <td>
                        <?php echo $tools["t_desc"]; ?>
                      </td>
                      <td>
                        <?php echo hdev_data::tool_health($tools["t_health"]); ?>
                      </td>
                      <td>
                        <?php echo $tools["t_update"]; ?>
                      </td>
                      <?php if (hdev_data::service('tools_delete') || hdev_data::service('tools_edit')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                           <?php if (hdev_data::service('tools_edit')): ?>
                          <button type="button" rel="external" class="btn btn-success eq_edit" t_id="<?php echo $tools['t_id']; ?>" t_name="<?php echo $tools['t_name']; ?>" t_qty="<?php echo $tools['t_qty']; ?>" t_desc="<?php echo $tools['t_desc']; ?>" t_health="<?php echo $tools['t_health']; ?>" data-toggle="modal" data-target=".modal-edit"><i class="fa fa-edit"></i> <?php echo hdev_lang::on("form","edit"); ?> </button>
                           <?php endif ?>
                          <?php if (hdev_data::service('tools_delete')): ?>
                          <button type="button" hash="<?php echo $tkn; ?>" data="<?php echo $reject; ?>" rel="external" class="btn btn-danger eq_delete" t_name="<?php echo $tools['t_name']; ?>" data-toggle="modal" data-target=".modal-delete"><i class="fa fa-trash"></i> <?php echo hdev_lang::on("form","delete"); ?> </button>
                           <?php endif ?>
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('tools_delete')): ?> 
<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo hdev_lang::on("form","accept"); ?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you sure you want to remove the following Equipment from current hotel equipment list ?</th>
                </tr>
                <tr>
                  <td>Equipment name : </td>
                  <td id="t_name"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="eq_del_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="tools_delete" data="" hash=""><i class="fa fa-trash"></i> Remove equipment</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('tools_edit')): ?>
<div class="modal fade modal-edit">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Modify equipment info</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" id="tools_edit">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="t_id" id="t_id">
              <input type="hidden" name="ref" value="tools_edit">          
            <div class="form-group">
              <label for="t_name">
                Equipment name :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="t_name" id="t_name" class="form-control" placeholder="Equipment name" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="t_qty">
                Equipment Quantity :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="t_qty" id="t_qty" class="form-control" placeholder="Equipment Quantity" required="true">
              </div>
            </div>         
            <div class="form-group">
              <label for="t_desc">
                Equipment Description :
              </label>
              <div class="input-group mb-3">
                <textarea type="text" name="t_desc" id="t_desc" class="form-control" placeholder="Equipment Description" required="true"></textarea>
              </div>
            </div>                
            <div class="form-group">
              <label for="t_health">
                Equipment Health :
              </label>
              <div class="input-group mb-3">
                <select type="text" name="t_health" id="t_health" class="form-control" required="true">
                  <option value="">-- Select Health status--</option>
                  <option value="1">Very Good</option>
                  <option value="2">Good</option>
                  <option value="3">Bad</option>
                  <option value="4">Subjected for replacement</option>
                </select>
              </div>
            </div>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#edit_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="edit_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="edit_tools" onclick="fm_submit('edit_tools','tools_edit');"><i class="fa fa-save"></i> Save equipment info</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>

<?php if (hdev_data::service('tools_reg')): ?>
<div class="modal fade modal-reg">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add new equipment</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" id="tools_reg">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="tools_reg">          
            <div class="form-group">
              <label for="t_name">
                Equipment name :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="t_name" id="t_name" class="form-control" placeholder="Equipment name" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="t_qty">
                Equipment Quantity :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="t_qty" id="t_qty" class="form-control" placeholder="Equipment Quantity" required="true">
              </div>
            </div>         
            <div class="form-group">
              <label for="t_desc">
                Equipment Description :
              </label>
              <div class="input-group mb-3">
                <textarea type="text" name="t_desc" id="t_desc" class="form-control" placeholder="Equipment Description" required="true"></textarea>
              </div>
            </div>                
            <div class="form-group">
              <label for="t_health">
                Equipment Health :
              </label>
              <div class="input-group mb-3">
                <select type="text" name="t_health" id="t_health" class="form-control" required="true">
                  <option value="">-- Select Health status--</option>
                  <option value="1">Very Good</option>
                  <option value="2">Good</option>
                  <option value="3">Bad</option>
                  <option value="4">Subjected for replacement</option>
                </select>
              </div>
            </div>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="reg_tools" onclick="fm_submit('reg_tools','tools_reg');"><i class="fa fa-save"></i> Save equipment info</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>