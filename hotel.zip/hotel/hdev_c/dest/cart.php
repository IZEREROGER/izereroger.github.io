<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Items in cart</h5>
              </div>
              <div class="card-body table-responsive p-2">
                <h4 class="bg-secondary text-white text-center">Products in cart</h4>
                <div class="btn-group">
                  <?php if (hdev_data::service('add_to_cart')): ?>
                  <a class="btn btn-primary" href="<?php echo hdev_url::menu('r/home'); ?>"><i class="fa fa-plus-circle"></i> Add more Products</a>&nbsp;
                  <?php endif ?>
                </div>
                  <table class="data-table table table-bordered table-hover text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort"><?php echo hdev_lang::on("data","regno"); ?></th>
                      <th>Product name</th> 
                      <th>Price/unit</th>
                      <th>Quantity</th>
                      <th>Price</th>
                      <?php if (hdev_data::service('cart_delete')): ?>
                      <th>Action</th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::cart('',['product']);
                      $sum1 = hdev_data::cart('',['product_sum']);
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $product) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:cart_delete;id:".$product['cart_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#cat_delete_close;app:".$tkn.";".$build2);
                    ?>

                    <tr>
                      <td class="table-plus">
                        <?php echo $product["cart_id"]; ?>
                      </td>
                      <td>
                        <?php echo hdev_data::products($product["cart_ref_id"],['data'])['p_name']; ?>
                      </td>
                      <td>
                        <?php echo number_format($product["cart_price"],2).constant('currency'); ?>
                      </td>
                      <td>
                        <input type="number" class="form-control form-control-primary edit_to_cart" o_id="def" price="<?php echo $product['cart_price']; ?>" o_type="<?php echo $product['cart_type']; ?>" ref_id="<?php echo $product['cart_ref_id']; ?>" cart_id="<?php echo $product['cart_id']; ?>" value='<?php echo $product["cart_qty"]; ?>'>
                      </td>
                      <td>
                        <?php echo number_format(($product["cart_qty"]*$product["cart_price"]),2).constant('currency'); ?>
                      </td>                      
                      <?php if (hdev_data::service('category_delete') || hdev_data::service('category_edit')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('category_delete')): ?>
                          <button type="button" hash="<?php echo $tkn; ?>" data="<?php echo $reject; ?>" rel="external" class="btn btn-danger cart_delete" data-toggle="modal" p_name="<?php echo hdev_data::products($product["cart_ref_id"],['data'])['p_name']; ?>" data-target=".modal-delete"><i class="fa fa-trash"></i> <?php echo hdev_lang::on("form","delete"); ?> </button>
                           <?php endif ?>
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
                <table class="table table-bordered bg-info">
                  <tbody>
                    <tr>
                      <th>Products Total price :</th>
                      <td><?php echo number_format($sum1["sm_price"],2).constant('currency'); ?></td>
                    </tr>
                  </tbody>
                </table>
                <h4 class="bg-secondary text-white text-center">Rooms in cart</h4>
                <div class="btn-group">
                  <?php if (hdev_data::service('add_to_cart')): ?>
                  <button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fa fa-plus-circle"></i> Add more Rooms</button>&nbsp;
                  <?php endif ?>
                </div>
                  <table class="data-table table table-bordered table-hover text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort"><?php echo hdev_lang::on("data","regno"); ?></th>
                      <th>Room Category</th>
                      <th>Room number</th> 
                      <th>Price/Day</th>
                      <th>Days</th>
                      <th>Total Price</th>
                      <?php if (hdev_data::service('cart_delete')): ?>
                      <th>Action</th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::cart('',['room']);
                      $sum2 = hdev_data::cart('',['room_sum']);
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $product) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:cart_delete;id:".$product['cart_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#cat_delete_close;app:".$tkn.";".$build2);
                    ?>

                    <tr>
                      <td class="table-plus">
                        <?php echo $product["cart_id"]; ?>
                      </td>
                      <td class="table-plus">
                        <?php echo hdev_data::rooms($product["cart_ref_id"],['data'])['r_name']; ?>
                      </td>
                      <td>
                        <?php echo $product["ext_info"]; ?>
                      </td>
                      <td>
                        <?php echo number_format($product["cart_price"],2).constant('currency'); ?>
                      </td> 
                      <td>
                        <input type="number" class="form-control edit_to_cart" o_id="def" price="<?php echo $product['cart_price']; ?>" o_type="<?php echo $product['cart_type']; ?>" ref_id="<?php echo $product['cart_ref_id']; ?>" cart_id="<?php echo $product['cart_id']; ?>" value='<?php echo $product["cart_qty"]; ?>'>
                      </td>
                      <td>
                        <?php echo number_format(($product["cart_qty"]*$product["cart_price"]),2).constant('currency'); ?>
                      </td>                      
                      <?php if (hdev_data::service('cart_delete')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('cart_delete')): ?>
                          <button type="button" hash="<?php echo $tkn; ?>" data="<?php echo $reject; ?>" rel="external" class="btn btn-danger cart_delete" data-toggle="modal" p_name="<?php echo $product["cart_ref_id"]; ?>" data-target=".modal-delete"><i class="fa fa-trash"></i> <?php echo hdev_lang::on("form","delete"); ?> </button>
                           <?php endif ?>
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
                <table class="table table-bordered bg-info">
                  <tbody>
                    <tr>
                      <th>Rooms Total price :</th>
                      <td><?php echo number_format($sum2["sm_price"],2).constant('currency'); ?></td>
                    </tr>
                    <tr class="bg-secondary text-white">
                      <th>Grand total</th>
                      <td><?php echo number_format($sum1["sm_price"]+$sum2["sm_price"],2).constant('currency'); ?></td>
                    </tr>
                  </tbody>
                </table>
                <div class="row">
                  <div class="col-sm-3"></div>
                  <div class="col-sm-6">
                    <button type="button" class="btn btn-success btn-block btn-xl" data-toggle="modal" data-target=".modal-approve"><span class="fa fa-print"></span> Make a receipt <i class="ik ik-check-circle"></i></button>
                  </div>
                  <div class="col-sm-3"></div>
                </div>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('add_to_cart')): ?> 
<div class="modal fade modal-approve" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo hdev_lang::on("form","accept"); ?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                  $tkn = $csrf->getToken();
                ?>
              <table class="table border-bottom">
                <tr>
                  <td>
                    <label for="receipt_client">Client Name :</label>
                    <input type="text" class="form-control" id="receipt_client" name="client_name" placeholder="Enter client name">
                  </td>
                </tr>
                <tr>
                  <td>Do you accept this ? </td>
                </tr>
                <tr>
                  <th>By clicking 'Accept & Generate receipt' this transanction will be permanently recorded and you will not be able to modify it later.</th>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="receipt_generate_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-success" id="receipt_generate" onclick="var rec_client=$('#receipt_client').val();generate_receipt('receipt_generate','<?php echo $tkn ?>',rec_client);"><i class="ik ik-check-circle"></i> Accept & Generate receipt </button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('cart_delete')): ?> 
<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo hdev_lang::on("form","accept"); ?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you sure that you want to remove this item from cart ?</th>
                </tr>
                <tr>
                  <td>Item name : </td>
                  <td id="p_name"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="cat_delete_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="cart_delete" data="" hash=""><i class="fa fa-trash"></i> Remove from cart</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('add_to_cart')): ?>
<div class="modal fade modal-reg">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add Room to cart</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" id="add_to_cart">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="add_to_cart"> 
              <input type="hidden" name="type" value="room">
            <div class="form-group">
              <label for="ref_id">Room Category : </label>
              <select name="ref_id" id="ref_id" class="form-control" required="true" onchange="room_change('set',$(this).val());">
                <option value="">--Select Room Category--</option>
                <?php 
                  $prod = hdev_data::rooms();
                  foreach ($prod as $rooms) {
                ?>
                  <option value="<?php echo $rooms['r_id'] ?>" price='<?php echo $rooms['r_price'] ?>'><?php echo $rooms['r_name'] ?></option>
                <?php
                  }
                 ?>
              </select>
            </div>                
            <div class="form-group">
              <label for="ext">
                Room Number :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="ext" id="ext" class="form-control" placeholder="Room Number" required="true">
              </div>
            </div>         
            <div class="form-group">
              <label for="c_desc">
                Room price / day:
              </label>
              <div class="input-group mb-0">
                <input type="text" name="price" id="price" class="form-control" placeholder="Price" readonly oninput="total_calculator('price','qty','tt_price');">
              </div>
            </div> 
            <div class="form-group">
              <label for="c_desc">
                Days :
              </label>
              <div class="input-group mb-0">
                <input type="text" name="qty" id="qty" class="form-control" placeholder="Days" required="true" oninput="total_calculator('price','qty','tt_price');">
              </div>
            </div>   
            <div class="form-group">
              <label for="tt_price">
                Total Price :
              </label>
              <div class="input-group mb-0">
                <input type="text" id="tt_price" class="form-control" placeholder="Total Price" readonly>
              </div>
            </div>                         
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="add_to_cart_btn" onclick="fm_submit('add_to_cart_btn','add_to_cart');"><i class="fa fa-save"></i> Add room to cart</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>

<script type="text/javascript">
  function room_change(type='set',vall='') {
    if (vall == '' || type=="reset") {
      $('#add_to_cart #price').val('');
    }else{
      var priced = $("#add_to_cart #ref_id option[value='"+vall+"']").attr('price');
      $('#add_to_cart #price').val(priced);
      total_calculator('price','qty','tt_price');
    }
  }
</script>