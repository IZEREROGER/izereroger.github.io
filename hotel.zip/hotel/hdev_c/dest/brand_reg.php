<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Current registered brands</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">
                  <?php if (hdev_data::service('brand_reg')): ?>
                  <button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fa fa-plus-circle"></i> Add new Brand</button>&nbsp;
                  <?php endif ?>
                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="data-table table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort"><?php echo hdev_lang::on("data","regno"); ?></th>
                      <th>Brand name</th> 
                      <th>Description</th>
                      <?php if (hdev_data::service('brand_delete') || hdev_data::service('brand_edit')): ?>
                      <th>Action</th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::brand();
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $brand) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:brand_delete;id:".$brand['b_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#cat_delete_close;app:".$tkn.";".$build2);
                    ?>

                    <tr>
                      <td class="table-plus">
                        <?php echo $brand["b_id"]; ?>
                      </td>
                      <td>
                        <?php echo $brand["b_name"]; ?>
                      </td>
                      <td>
                        <?php echo $brand["b_desc"]; ?>
                      </td>
                      <?php if (hdev_data::service('brand_delete') || hdev_data::service('brand_edit')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                           <?php if (hdev_data::service('brand_edit')): ?>
                          <button type="button" rel="external" class="btn btn-success cat_edit" c_id="<?php echo $brand['b_id']; ?>" c_name="<?php echo $brand['b_name']; ?>" c_desc="<?php echo $brand['b_desc']; ?>" data-toggle="modal" data-target=".modal-edit"><i class="fa fa-edit"></i> <?php echo hdev_lang::on("form","edit"); ?> </button>
                           <?php endif ?>
                          <?php if (hdev_data::service('brand_delete')): ?>
                          <button type="button" hash="<?php echo $tkn; ?>" data="<?php echo $reject; ?>" rel="external" class="btn btn-danger cat_delete" c_name="<?php echo $brand['b_name']; ?>" data-toggle="modal" data-target=".modal-delete"><i class="fa fa-trash"></i> <?php echo hdev_lang::on("form","delete"); ?> </button>
                           <?php endif ?>
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('brand_delete')): ?> 
<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo hdev_lang::on("form","accept"); ?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you sure that you want to delete this Brand ?</th>
                </tr>
                <tr>
                  <td>Brand name : </td>
                  <td id="c_name"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="cat_delete_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="category_delete" data="" hash=""><i class="fa fa-trash"></i> Delete brand</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('brand_edit')): ?>
<div class="modal fade modal-edit">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit brand info</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" id="category_edit">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="brand_edit"> 
              <input type="hidden" name="c_id" id="c_id" value="">
            <div class="form-group">
              <label for="c_name">
                Brand name :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="c_name" id="c_name" class="form-control" placeholder="Brand name" required="true">
              </div>
            </div>         
            <div class="form-group">
              <label for="c_desc">
                Brand Description:
              </label>
              <div class="input-group mb-0">
                <textarea name="c_desc" id="c_desc" class="form-control" placeholder="Brand Description" required="true"></textarea>
              </div>
            </div> 
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#edit_mod_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="edit_mod_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="edit_category" onclick="fm_submit('edit_category','category_edit');"><i class="fa fa-save"></i> Save brand info</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>
<?php if (hdev_data::service('category_reg')): ?>
<div class="modal fade modal-reg">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add new brand</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" id="category_reg">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="brand_reg"> 
            <div class="form-group">
              <label for="c_name">
                Brand name :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="c_name" id="c_name" class="form-control" placeholder="Brand name" required="true">
              </div>
            </div>         
            <div class="form-group">
              <label for="c_desc">
                Brand Description:
              </label>
              <div class="input-group mb-0">
                <textarea name="c_desc" id="c_desc" class="form-control" placeholder="Brand Description" required="true"></textarea>
              </div>
            </div> 
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="reg_category" onclick="fm_submit('reg_category','category_reg');"><i class="fa fa-save"></i> Save brand info</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>