<?php 
    $base = ltrim($_SESSION['act_url'][2],"/");
    $date = urldecode(hdev_session::get("date"));
    $chop = json_decode($date);
    $start = date('Y-m-d');
    $end = date('Y-m-d');
    //print_r($chop->from);exit();
    if (isset($chop->from) && isset($chop->to) && !empty($chop->from) && !empty($chop->to)) {
      if ($chop->to > $chop->from) {
        $start = date_format(date_create($chop->from),"Y-m-d");
        $end = date_format(date_create($chop->to),"Y-m-d");
      }
    }
    $linker = json_encode(array("from"=>$start,"to"=>$end));
    $link = hdev_url::menu($base)."/".urlencode($linker)."/date";
    $csrf = new CSRF_Protect();
    $hash = $csrf->getToken();
    $link2 = hdev_url::menu("app/report")."/".$hash."/".urlencode($linker);
    hdev_session::set('start',$start);
    hdev_session::set('end',$end);
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header" style="width: 100%;">
                <div class="row">
                  <div class="col-sm-9">
                    <h5>Rooms Sales Report | From : <?php echo $start ?>, To : <?php echo $end; ?></h5>
                  </div>
                  <div class="col-sm-3" style="align-items: right !important;">
                    <div class="btn-group">
                      <a from="<?php echo $start; ?>" to="<?php echo $end; ?>" id="report_mask"></a>
                      <button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fa fa-calendar"></i> <?php echo hdev_lang::on("form","filter_report_by_date"); ?></button>&nbsp;
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-body p-2" id="rep_txt">
                  <div class="row" align="right">
                    <div class="col-sm-12">
                      <button type="button" class="btn btn-success" id="rec_print" onclick="app_printer('rep_txt','rec_print')">
                        <i class="fa fa-print"></i> 
                        Print this Report
                      </button>
                    </div>
                  </div>
                  <div class="row hd_pt" style="display: none;">
                    <div class="col-sm-12" align="center">
                      <h3><?php echo APP_NAME." system"; ?></h3>
                      <hr>
                      <u><h4>Rooms Sales Report | From : <?php echo $start ?>, To : <?php echo $end; ?></h4></u>
                    </div>
                  </div>
                  <table class="table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort">Reg_no #</th>
                      <th>Room Category</th>
                      <th>Room Number</th>
                      <th>Days</th>
                      <th>Price/Day</th>
                      <th>Total Price</th>
                      <th>Client</th>
                      <th>Reg date</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::room_report();
                      $sum = hdev_data::room_report('',['sum']);
                     ?>
                    <?php foreach ($ck AS $stock) { 
                    ?>
                    <tr>
                      <td class="table-plus">
                        <?php echo $stock["ro_id"]; ?>
                      </td>
                      <td>
                        <?php echo hdev_data::rooms($stock["r_id"],['data'])['r_name']; ?>
                      </td>
                      <td>
                        <?php echo $stock['ext_info']; ?>
                      </td>
                      <td>
                        <?php echo $stock['ro_days']; ?>
                      </td> 
                      <td>
                        <?php echo number_format($stock['ro_unit_price'],2).constant('currency'); ?>
                      </td> 
                      <td>
                        <?php echo number_format(($stock['ro_days']*$stock["ro_unit_price"]),2).constant('currency'); ?>
                      </td>                    
                      <td>
                        <?php echo hdev_data::order($stock['o_id'],['data'])['client'] ?>
                      </td> 
                      <td>
                        <?php echo $stock['ro_reg_date']; ?>
                      </td>
                    </tr>
                  <?php } ?>
                  </tbody>
                  <tfoot>
                      <tr>
                        <th colspan="5">Total</th>
                        <th>
                          <?php echo number_format($sum["sm_price"],2).constant('currency'); ?>
                        </th> 
                        <th colspan="2">
                          
                        </th>
                      </tr>
                  </tfoot>
                </table>
                <table class="table table-bordered hd_pt" style="display: none;">
                  <tbody>
                    <tr>
                      <th colspan="2" style="text-align:center !important;">
                        This report is Generated by <b><i><?php echo APP_NAME ?></i> System</b><br> Under Control of <b><i><?php echo hdev_data::active_user('email'); ?></i></b>
                      </th>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<div class="modal fade modal-reg">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Filter Report By date</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" id="report_date">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
            <div class="form-group">
              <label for="from">
                From :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend border-top border-bottom border-left">
                  <div class="input-group-text">
                    <span class="fa fa-calendar"></span>
                  </div>
                </div>
                <input type="date" name="from" id="from" class="form-control" placeholder="From" required="true" oninput="build_rep_link($(this).val(),$('#to').val(),'#get_report')" value="<?php echo $start; ?>">
              </div>
            </div>
            <div class="form-group">
              <label for="to">
                To :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend border-top border-bottom border-left">
                  <div class="input-group-text">
                    <span class="fa fa-calendar"></span>
                  </div>
                </div>
                <input type="date" name="to" id="to" class="form-control" placeholder="To" required="true" oninput="build_rep_link($('#from').val(),$(this).val(),'#get_report')" value="<?php echo $end; ?>">
              </div>
            </div>   
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <a data-dismiss="modal" class="btn btn-primary" id="get_report" href="<?php echo $link; ?>" onclick="window.location.href=$(this).attr('href');">Get Filtered report</a>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>

<script type="text/javascript">
  function build_rep_link(from='',to='',target_btn='') {
    var returr = '{"from":"'+from+'","to":"'+to+'"}';
    var gen_ret = encodeURIComponent(returr);
    var gen_lnk = '<?php echo hdev_url::menu($base); ?>/'+gen_ret+'/date';
    $(target_btn).attr('href',gen_lnk);
  }
</script>