<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Items in cart</h5>
              </div>
              <div class="card-body table-responsive p-2" id="rec_txt">
                <div align="right" style="width: 100%;">
                  <button type="button" class="btn btn-success" id="rec_print" onclick="app_printer('rec_txt','rec_print')">
                    <i class="fa fa-print"></i> 
                    Print this receipt
                  </button>
                </div>
                <table class="table table-bordered">
                  <tr>
                    <th colspan="2" style="text-align: center !important;"><h4><?php echo APP_NAME ?> Client Receipt</h4></th>
                  </tr>
                  <tr class="bg-secondary">
                    <th>Order id :</th>
                    <td><?php echo hdev_session::get('order'); ?></td>
                  </tr>
                  <tr>
                    <th>Client : </th>
                    <td><?php echo hdev_data::order(hdev_session::get('order'),['data'])['client']; ?></td>
                  </tr>
                </table>
                <h4 class="bg-secondary text-white text-center">Products Bill</h4>
                  <table class="table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort"><?php echo hdev_lang::on("data","regno"); ?></th>
                      <th>Product name</th> 
                      <th>Quantity</th>
                      <th>Price/unit</th>
                      <th>Total Price</th> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::product_report(hdev_session::get('order'),['order']);
                      $sum = hdev_data::product_report(hdev_session::get('order'),['order_sum']);
                     ?>
                    <?php foreach ($ck AS $product) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                    ?>

                    <tr>
                      <td class="table-plus">
                        <?php echo $product["po_id"]; ?>
                      </td>
                      <td>
                        <?php echo hdev_data::products($product["p_id"],['data'])['p_name']; ?>
                      </td>
                      <td>
                        <?php echo $product["po_qty"]; ?>
                      </td>
                      <td>
                        <?php echo number_format($product["po_price"],2).constant('currency'); ?>
                      </td>
                      <td>
                        <?php echo number_format(($product["po_qty"]*$product["po_price"]),2).constant('currency'); ?>
                      </td> 
                    </tr>
                  <?php } ?>
                  </tbody>
                  <tfoot>
                    <tr>
                      <th colspan="4">Products Total Price</th>
                      <th><?php echo number_format($sum["sm_price"],2).constant('currency'); ?></th>
                    </tr>
                  </tfoot>
                </table>
                <h4 class="bg-secondary text-white text-center">Rooms Bill</h4>
                  <table class="table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort"><?php echo hdev_lang::on("data","regno"); ?></th>
                      <th>Room Category</th> 
                      <th>Room Number</th> 
                      <th>Days</th>
                      <th>Price/Day</th>
                      <th>Total Price</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::room_report(hdev_session::get('order'),['order']);
                      $sum1 = hdev_data::room_report(hdev_session::get('order'),['order_sum']);
                     ?>
                    <?php foreach ($ck AS $product) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                    ?>

                    <tr>
                      <td class="table-plus">
                        <?php echo $product["ro_id"]; ?>
                      </td>
                      <td>
                        <?php echo hdev_data::rooms($product["r_id"],['data'])['r_name']; ?>
                      </td>
                      <td>
                        <?php echo $product["ext_info"]; ?>
                      </td>
                      <td>
                        <?php echo $product["ro_days"]; ?>
                      </td>
                      <td>
                        <?php echo number_format($product["ro_unit_price"],2).constant('currency'); ?>
                      </td>
                      <td>
                        <?php echo number_format(($product["ro_days"]*$product["ro_unit_price"]),2).constant('currency'); ?>
                      </td>         
                    </tr>
                  <?php } ?>
                  </tbody>
                  <tfoot>
                    <tr>
                      <th colspan="5">Rooms Total Price</th>
                      <th><?php echo number_format($sum1["sm_price"],2).constant('currency'); ?></th>
                    </tr>
                  </tfoot>
                </table>
                <table class="table table-bordered">
                  <tbody>
                    <tr>
                      <th>Grand Total :</th>
                      <th><?php echo number_format(($sum["sm_price"]+$sum1['sm_price']),2).constant('currency'); ?></th>
                    </tr>
                    <tr>
                      <th>Payment status :</th>
                      <td>Payed</td>
                    </tr>
                    <tr>
                      <th colspan="2" style="text-align:center !important;">
                        This Receipt is Generated by <b><i><?php echo APP_NAME ?></i> System</b><br> Under Control of <b><i><?php echo hdev_data::active_user('email'); ?></i></b>
                      </th>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>