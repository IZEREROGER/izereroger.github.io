<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Active Rooms categories</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">
                  <?php if (hdev_data::service('rooms_reg')): ?>
                  <button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fa fa-plus-circle"></i> Add new room category</button>&nbsp;
                  <?php endif ?>
                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="data-table table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort"><?php echo hdev_lang::on("data","regno"); ?></th>
                      <th>image</th>
                      <th>Room category name</th>
                      <th>Price</th>
                      <th>Description</th>
                      <th>Reg date</th>
                      <?php if (hdev_data::service('rooms_delete') || hdev_data::service('rooms_edit')): ?>
                      <th><?php echo hdev_lang::on("form","action"); ?></th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::rooms();
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $rooms) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:rooms_delete;id:".$rooms['r_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#prod_del_close;app:".$tkn.";".$build2);
                    ?>

                    <tr>
                      <td class="table-plus">
                        <?php echo $rooms["r_id"]; ?>
                      </td>
                      <td>
                        <?php if (isset(hdev_data::product_images($rooms["r_pic"])[0]) && !empty(hdev_data::product_images($rooms["r_pic"])[0])) {
                        $key = hdev_data::product_images($rooms["r_pic"])[0];
                        ?>
                        <img style="width: 100px;" src="<?php echo $key ?>" alt="image">
                        <?php }else{ echo '-'; } ?>
                      </td>
                      <td>
                        <?php echo $rooms["r_name"]; ?>
                      </td>
                      <td>
                        <?php echo $rooms["r_price"]; ?>
                      </td>
                      <td>
                        <?php echo $rooms["r_desc"]; ?>
                      </td>
                      <td>
                        <?php echo $rooms["r_reg_date"]; ?>
                      </td>
                      <?php if (hdev_data::service('rooms_delete') || hdev_data::service('rooms_edit')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                           <?php if (hdev_data::service('rooms_edit')): ?>
                          <button type="button" rel="external" class="btn btn-success rm_edit" r_id="<?php echo $rooms['r_id']; ?>" r_name="<?php echo $rooms['r_name']; ?>" r_price="<?php echo $rooms['r_price']; ?>" r_desc="<?php echo $rooms['r_desc']; ?>" data-toggle="modal"  data-target=".modal-edit"><i class="fa fa-edit"></i> <?php echo hdev_lang::on("form","edit"); ?> </button>
                           <?php endif ?>
                          <?php if (hdev_data::service('rooms_delete')): ?>
                          <button type="button" hash="<?php echo $tkn; ?>" data="<?php echo $reject; ?>" rel="external" class="btn btn-danger rm_delete" r_name="<?php echo $rooms['r_name']; ?>" data-toggle="modal" data-target=".modal-delete"><i class="fa fa-trash"></i> <?php echo hdev_lang::on("form","delete"); ?> </button>
                           <?php endif ?>
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('rooms_delete')): ?> 
<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo hdev_lang::on("form","accept"); ?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you sure you want to delete the following room category ?</th>
                </tr>
                <tr>
                  <td><?php echo hdev_lang::on("data","name"); ?> : </td>
                  <td id="r_name"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="prod_del_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="rooms_delete" data="" hash=""><i class="fa fa-trash"></i> Delete room category</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('rooms_edit')): ?>
<div class="modal fade modal-edit">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Room info</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" action="<?php echo hdev_url::menu('up'); ?>" id="rooms_edit" enctype="multipart/form-data">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="rooms_edit"> 
              <input type="hidden" name="r_id" id="r_id" value="">          
            <div class="form-group">
              <label for="r_name">
                Room category name :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="r_name" id="r_name" class="form-control" placeholder="Room category name" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="r_price">
                Room price :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="r_price" id="r_price" class="form-control" placeholder="Room price" required="true">
              </div>
            </div>                    
            <div class="form-group">
              <label for="r_desc">
                Room category Description :
              </label>
              <div class="input-group mb-0">
                <textarea name="r_desc" id="r_desc" class="form-control" placeholder="Room category Description" required="true"></textarea>
              </div>
            </div>                        
            <div class="form-group">
              <label for="cata2">
                Choose Product pictures to upload :
              </label>
              <div class="input-group mb-3">
                <span id="fpc" style="display: none !important;">
                  <input type="file" name2="prod_pic[]" class="form-control" id="upic_a" multiple>
                </span>
                <span id="fpc2">
                  <input type="file" name="prod_pic[]" class="form-control" id="upic_a" multiple>
                </span>
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-file-image"></span>
                  </div>
                </div>
              </div>
            </div>
            <div class="wait" align="center"></div>
            <div class="row">
              <div class="col-sm-12">
                <div class="progress">
                    <div class="progress-bar bg-primary progress-bar-striped" role="progressbar" id="progress-bar">
                    </div>
                  </div>

              </div>
            </div>
            <input type="hidden" name="mod_close" value="#edit_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="edit_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="edit_rooms" onclick="$('#rooms_edit').submit();"><i class="fa fa-save"></i> <?php echo hdev_lang::on("form","save_product"); ?></button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>

<?php if (hdev_data::service('rooms_reg')): ?>
<div class="modal fade modal-reg">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add Room category</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" action="<?php echo hdev_url::menu('up'); ?>" id="rooms_reg" enctype="multipart/form-data">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="rooms_reg">        
            <div class="form-group">
              <label for="r_name">
                Room category name :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="r_name" id="r_name" class="form-control" placeholder="Room category name" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="r_price">
                Room price :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="r_price" id="r_price" class="form-control" placeholder="Room price" required="true">
              </div>
            </div>                    
            <div class="form-group">
              <label for="r_desc">
                Room category Description :
              </label>
              <div class="input-group mb-0">
                <textarea name="r_desc" id="r_desc" class="form-control" placeholder="Room category Description" required="true"></textarea>
              </div>
            </div>              
            <div class="form-group">
              <label for="cata2">
                Choose Rooms pictures to upload :
              </label>
              <div class="input-group mb-3">
                <input type="file" name="prod_pic[]" class="form-control" id="upic_a" multiple required>
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-file-image"></span>
                  </div>
                </div>
              </div>
            </div>
            <div class="wait" align="center"></div>
            <div class="row">
              <div class="col-sm-12">
                <div class="progress">
                    <div class="progress-bar bg-primary progress-bar-striped" role="progressbar" id="progress-bar">
                    </div>
                  </div>

              </div>
            </div>
            <input type="hidden" name="mod_close" value="#reg_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="reg_rooms" onclick="$('#rooms_reg').submit();"><i class="fa fa-save"></i> <?php echo hdev_lang::on("form","save_product"); ?></button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>