<?php if (hdev_log::fid() == "manager"): ?>
<div id="app_data">
      <div class="card-group">
        <div class="card p-3 mb-20">
          <a href="<?php echo hdev_url::menu('warn/exp'); ?>">
          <div class="card-box height-100-p widget-style3">
            <div class="d-flex flex-wrap">
              <div class="widget-data">
                <div class="weight-700 font-24 text-dark"><?php echo count(hdev_data::warning('',['warn_exp'])); ?></div>
                <div class="font-12 text-secondary weight-500">Stock in(s) going to expire</div>
              </div>
              <div class="widget-icon">
                <div class="icon" data-color="#00eccf"><i class="icon-copy dw dw-calendar-1"></i></div>
              </div>
            </div>
          </div>
          </a>
        </div>
        <div class="card p-3 mb-20">
          <a href="<?php echo hdev_url::menu('exp/products'); ?>">
          <div class="card-box height-100-p widget-style3">
            <div class="d-flex flex-wrap">
              <div class="widget-data">
                <div class="weight-700 font-24 text-dark"><?php echo count(hdev_data::warning('',['exp_products'])); ?></div>
                <div class="font-12 text-secondary weight-500">Stock in(s) Expired</div>
              </div>
              <div class="widget-icon">
                <div class="icon" data-color="#ff5b5b"><i class="icon-copy dw dw-broken"></i></div>
              </div>
            </div>
          </div>
          </a>
        </div>   
       <div class="card p-3 mb-20">
          <a href="<?php echo hdev_url::menu('warn/out'); ?>">
          <div class="card-box height-100-p widget-style3">
            <div class="d-flex flex-wrap">
              <div class="widget-data">
                <div class="weight-700 font-24 text-dark"><?php echo count(hdev_data::warning('',['warn_out'])); ?></div>
                <div class="font-12 text-secondary weight-500">Products going to be out of stock</div>
              </div>
              <div class="widget-icon">
                <div class="icon" data-color="#00eccf"><i class="icon-copy dw dw-shopping-basket-1"></i></div>
              </div>
            </div>
          </div>
          </a>
        </div>
        <div class="card p-3 mb-20">
          <a href="<?php echo hdev_url::menu('out/products'); ?>">
          <div class="card-box height-100-p widget-style3">
            <div class="d-flex flex-wrap">
              <div class="widget-data">
                <div class="weight-700 font-24 text-dark"><?php echo count(hdev_data::warning('',['out_products'])); ?></div>
                <div class="font-12 text-secondary weight-500">Products Out of stock</div>
              </div>
              <div class="widget-icon">
                <div class="icon" data-color="#ff5b5b"><i class="icon-copy dw dw-shopping-cart-1"></i></div>
              </div>
            </div>
          </div>
          </a>
        </div>
      </div>
</div>
<?php endif ?>


<?php if (!hdev_log::loged()): ?>
<h2>Welecome to <?php echo APP_NAME; ?></h2>
<div id="app_data" align="center">
  <div class="card" style="height: 100%;">
    <div class="card-header row">
        <div class="col-sm-8" align="left">
          <h5>What We have</h5>
        </div>
        <div class="col-sm-4">
          <form onsubmit="$('#product_search_btn').click(); return false;">
            <div class="input-group">
              <input type="search" id="product_search" class="form-control" placeholder="Search a product ......." required="true">
              <div class="input-group-prepend border-top border-bottom border-left">
                <button id="product_search_btn" class="btn btn-info" type="button" onclick="main_search($('#product_search').val());"><i class="fa fa-search"></i></button>
              </div>
            </div>
          </form>
        </div>
    </div>
    <div class="card-body p-2">
        <div align="center">
          <h4>Rooms on system</h4>
        </div>
        <hr>

          <div class="card-group owl-carousel owl-theme">
            <?php /////////////////this is prod owl/////////// ?>
            <?php 
              $counter = 0;
              $counter_group = 1;
              $ck = hdev_data::rooms();
              foreach ($ck as $product) {
            ?>
              <div class="card card-box">
                 <?php if (isset(hdev_data::product_images($product["r_pic"])[0]) && !empty(hdev_data::product_images($product["r_pic"])[0])) {
                 $key = hdev_data::product_images($product["r_pic"])[0];
                 ?>
                 <img class="card-img-top" src="<?php echo $key ?>" alt="image" style="height: 300px !important;">
                 <?php }else{ ?>
                    <i class="icon-copy fa fa-shopping-bag fa-5x card-img-top" aria-hidden="true"></i>
                 <?php } ?>
                <div class="card-body">
                  <h5 class="card-title bg-primary text-white"><?php echo $product['r_name']; ?></h5>
                  <p class="card-text bg-secondary text-white"><?php echo $product['r_price']; ?> Frw</p>
                  <p class="card-text"><small class="text-muted"> Available</small></p>
                </div>
              </div>
            <?php
              }
              unset($product);
             ?>
             <?php /////////////////this is prod owl/////////// ?>
        </div>
        <div align="center">
          <h4>Products on system</h4>
        </div>
        <hr>

          <div class="card-group owl-carousel owl-theme">
            <?php /////////////////this is prod owl/////////// ?>
            <?php 
              $counter = 0;
              $counter_group = 1;
              $ck = hdev_data::products();
              foreach ($ck as $product) {
            ?>
              <div class="card card-box">
                 <?php if (isset(hdev_data::product_images($product["p_pic"])[0]) && !empty(hdev_data::product_images($product["p_pic"])[0])) {
                 $key = hdev_data::product_images($product["p_pic"])[0];
                 ?>
                 <img class="card-img-top" src="<?php echo $key ?>" alt="image" style="height: 300px !important;">
                 <?php }else{ ?>
                    <i class="icon-copy fa fa-shopping-bag fa-5x card-img-top" aria-hidden="true"></i>
                 <?php } ?>
                <div class="card-body">
                  <h5 class="card-title bg-primary text-white"><?php echo $product['p_name']; ?></h5>
                  <p class="card-text bg-secondary text-white"><?php echo $product['p_price']; ?> Frw</p>
                  <p class="card-text"><small class="text-muted"> in stock</small></p>
                </div>
              </div>
            <?php
              }
              unset($product);
             ?>
             <?php /////////////////this is prod owl/////////// ?>
        </div>
    </div>
  </div>
  </div>
<?php endif ?>
<?php if (hdev_log::loged()): ?>
<div id="app_data" align="center">
  <div class="card" style="height: 100%;">
    <div class="card-header row">
        <div class="col-sm-8" align="left">
          <h5>What We have</h5>
        </div>
        <div class="col-sm-4">
          <form onsubmit="$('#product_search_btn').click(); return false;">
            <div class="input-group">
              <input type="search" id="product_search" class="form-control" placeholder="Search a product ......." required="true">
              <div class="input-group-prepend border-top border-bottom border-left">
                <button id="product_search_btn" class="btn btn-info" type="button" onclick="main_search($('#product_search').val());"><i class="fa fa-search"></i></button>
              </div>
            </div>
          </form>
        </div>
    </div>
    <div class="card-body p-2">
        <div align="center">
          <h4>Rooms on system</h4>
        </div>
        <hr>

          <div class="card-group owl-carousel owl-theme">
            <?php /////////////////this is prod owl/////////// ?>
            <?php 
              $counter = 0;
              $counter_group = 1;
              $ck = hdev_data::rooms();
              foreach ($ck as $product) {
            ?>
              <div class="card card-box">
                 <?php if (isset(hdev_data::product_images($product["r_pic"])[0]) && !empty(hdev_data::product_images($product["r_pic"])[0])) {
                 $key = hdev_data::product_images($product["r_pic"])[0];
                 ?>
                 <img class="card-img-top" src="<?php echo $key ?>" alt="image" style="height: 300px !important;">
                 <?php }else{ ?>
                    <i class="icon-copy fa fa-shopping-bag fa-5x card-img-top" aria-hidden="true"></i>
                 <?php } ?>
                <div class="card-body">
                  <h5 class="card-title bg-primary text-white"><?php echo $product['r_name']; ?></h5>
                  <p class="card-text bg-secondary text-white"><?php echo $product['r_price']; ?> Frw</p>
                  <p class="card-text"><small class="text-muted"> Available</small></p>
                </div>
              </div>
            <?php
              }
              unset($product);
             ?>
             <?php /////////////////this is prod owl/////////// ?>
        </div>
        <div align="center">
          <h4>Products on system</h4>
        </div>
        <hr>

          <div class="card-group owl-carousel owl-theme">
            <?php /////////////////this is prod owl/////////// ?>
            <?php 
              $counter = 0;
              $counter_group = 1;
              $ck = hdev_data::products();
              foreach ($ck as $product) {
            ?>
              <div class="card card-box">
                 <?php if (isset(hdev_data::product_images($product["p_pic"])[0]) && !empty(hdev_data::product_images($product["p_pic"])[0])) {
                 $key = hdev_data::product_images($product["p_pic"])[0];
                 ?>
                 <img class="card-img-top" src="<?php echo $key ?>" alt="image" style="height: 300px !important;">
                 <?php }else{ ?>
                    <i class="icon-copy fa fa-shopping-bag fa-5x card-img-top" aria-hidden="true"></i>
                 <?php } ?>
                <div class="card-body">
                  <h5 class="card-title bg-primary text-white"><?php echo $product['p_name']; ?></h5>
                  <p class="card-text bg-secondary text-white"><?php echo $product['p_price']; ?> Frw</p>
                  <p class="card-text"><small class="text-muted"> in stock</small></p>
                </div>
                <?php if (hdev_data::service('add_to_cart')): ?>
                  <div class="card-footer">
                    <button type="button" class="btn btn-secondary btn-block add_to_cart" id="prod_<?php echo $product['p_id']; ?>_btn" price="<?php echo $product['p_price']; ?>" o_type="product" ref_id="<?php echo $product['p_id']; ?>" qty="1">Add To cart <span class="fa fa-cart-plus"></span></button>
                  </div>
                <?php endif ?>
              </div>
            <?php
              }
              unset($product);
             ?>
             <?php /////////////////this is prod owl/////////// ?>
        </div>
    </div>
  </div>
  </div>
<?php endif ?>