  <!-- js -->
  <script src="<?php echo hdev_url::menu('vendors/scripts/core.js'); ?>"></script>
  <script src="<?php echo hdev_url::menu('vendors/scripts/script.min.js'); ?>"></script>
  <script src="<?php echo hdev_url::menu('vendors/scripts/process.js'); ?>"></script>
  <script src="<?php echo hdev_url::menu('vendors/scripts/layout-settings.js'); ?>"></script>
  <script src="<?php echo hdev_url::menu('src/plugins/jQuery-Knob-master/jquery.knob.min.js'); ?>"></script>
  <script src="<?php echo hdev_url::menu('src/plugins/highcharts-6.0.7/code/highcharts.js'); ?>"></script>
  <script src="<?php echo hdev_url::menu('src/plugins/highcharts-6.0.7/code/highcharts-more.js'); ?>"></script>
  <script src="<?php echo hdev_url::menu('src/plugins/jvectormap/jquery-jvectormap-2.0.3.min.js'); ?>"></script>
  <script src="<?php echo hdev_url::menu('src/plugins/jvectormap/jquery-jvectormap-world-mill-en.js'); ?>"></script>
  <script src="<?php echo hdev_url::menu('vendors/scripts/dashboard2.js'); ?>"></script>
<script type="text/javascript">

  //sm_nt();
  function update_datatable() {
     

  }
  function attach(cur='') {
    //alert(cur);
    if (cur == "") {
      cur = window.location.href;
    }
    $('#menu_loader').html('<div class="process-loader"></div>');
    var rest =  cur.split("?");
     xhttp = new XMLHttpRequest();
     xhttp.onreadystatechange = function() {
        if (this.readyState == 4) {
          if (this.status == 200) {
            $('body #app_body').html(this.responseText);
            $('#menu_loader').html('<!--loader-->');
            update_datatable();
          }
          if (this.status == 404) {
            //window.location.reload();
          }
        }
      }
      xhttp.open("GET", ""+rest[0]+"/a/b/c", true);
      xhttp.send();
  }

  $load_status= $('<span><img src="<?php echo hdev_url::img(hdev_url::menu('dist/img/loading2.gif'));?>"/></span><i>&nbsp;&nbsp;wait...!!!</i>');
  $saved = $('<span class="text-success"><?php echo hdev_lang::on("validation","saved"); ?></span>');
  $min_wait = $('<span class="text-success"><?php echo hdev_lang::on("validation","loading"); ?></span>');
 $(document).ready(function(){ 
  update_datatable();

    $(document).on('click','.pager_control',function(e) {
        var urr=$(this).attr("url");
        var pgg=$(this).attr("page");
        var lcc = urr+'/'+pgg;
        attach(lcc);
    });    
 
  });
</script><!--
<script src="<?php echo hdev_url::menu('script-1'); ?>"></script>-->
</body>
</html>

