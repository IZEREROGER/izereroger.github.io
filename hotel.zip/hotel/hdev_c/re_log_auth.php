        <div class="auth-wrapper">
            <div class="container-fluid h-100">
                <div class="row flex-row h-100 bg-white">
                    <div class="col-xl-8 col-lg-6 col-md-5 p-0 d-md-block d-lg-block d-sm-none d-none">
                        <div class="lavalite-bg" style="background-image: url('<?php echo hdev_url::menu('img/hot_login.jpg'); ?>')">
                            <div class="lavalite-overlay"></div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6 col-md-7 my-auto p-0">
                        <div class="authentication-form mx-auto">
                            <div class="logo-centered">
                                <a href="../index.html"><img src="<?php echo hdev_url::menu('icon/Logo.png') ?>" alt=""></a>
                            </div>
                            <h3>Sign In to <?php echo APP_NAME; ?> </h3>
                            <p>Happy to see you again!</p>
                            <form id="login_form" class="form-signin" onsubmit="login(); return false;">
                              <input type="hidden" name="ref" value="login">
                                <div class="form-group">
                                    <input type="text" name="usn" class="form-control" placeholder="Email" required="">
                                    <i class="ik ik-user"></i>
                                </div>
                                <div class="form-group">
                                    <input type="password" name="psw" class="form-control" placeholder="Password" required="">
                                    <i class="ik ik-lock"></i>
                                </div>
                                <div class="row">
                                    <div class="col text-right">
                                        <a href="<?php echo hdev_url::menu('forgot'); ?>">Forgot Password ?</a>
                                    </div>
                                </div>
                                <div class="sign-btn text-center" id="fsave">
                                    <button class="btn btn-theme" type="submit">Sign In</button>
                                </div>
                                <div class="col-sm-12 wait border-left border-right border-bottom border-top" align="center" style="display: none;">
                                  <i class="icon-copy fa fa-spinner fa-spin fa-3x" aria-hidden="true"></i>
                                  <br>
                                  <i><?php echo hdev_lang::on('validation','processing'); ?>!!!</i>
                                </div>
                            </form>
                            <div class="register">
                                <p>Don't have an account? <a href="#">Contact your administrator.</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>