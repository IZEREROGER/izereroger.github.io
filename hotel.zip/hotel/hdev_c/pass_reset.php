<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title><?php echo APP_NAME; ?> - Password Reset</title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <link rel="icon" href="<?php echo hdev_url::menu('icon/logo.png'); ?>" type="image/x-icon" />

        <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,600,700,800" rel="stylesheet">
        
        <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/bootstrap/dist/css/bootstrap.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/fontawesome-free/css/all.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/ionicons/dist/css/ionicons.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/icon-kit/dist/css/iconkit.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/perfect-scrollbar/css/perfect-scrollbar.css'); ?>">
        <link rel="stylesheet" href="<?php echo hdev_url::menu('dist/css/theme.min.css'); ?>">
        <script src="<?php echo hdev_url::menu('src/js/vendor/modernizr-2.8.3.min.js'); ?>"></script>
    </head>

    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <?php 
          $csrf = new CSRF_Protect();
        ?>

        <div class="auth-wrapper">
            <div class="container-fluid h-100">
                <div class="row flex-row h-100 bg-white">
                    <div class="col-xl-8 col-lg-6 col-md-5 p-0 d-md-block d-lg-block d-sm-none d-none">
                        <div class="lavalite-bg" style="background-image: url('<?php echo hdev_url::menu('img/hot_login.jpg'); ?>')">
                            <div class="lavalite-overlay"></div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6 col-md-7 my-auto p-0">
                        <div class="authentication-form mx-auto">
                            <div class="logo-centered">
                                <a href="<?php echo hdev_url::menu('r/home') ?>"><img src="<?php echo hdev_url::menu('icon/logo.png') ?>" alt=""></a>
                            </div>
                            <h3 class="text-center"><?php echo APP_NAME; ?> </h3>
                            <div class="" id="forgot_1" style="">
                                <div class="login-box bg-white box-shadow border-radius-10">
                                    <div class="login-title">
                                        <h2 class="text-center text-primary">Forgot Password</h2>
                                    </div>
                                    <h6 class="mb-20">Enter your Phone number To reset your Password</h6>
                                    <form id="reset_1" onsubmit="forgot_1(); return false;">
                                        <?php echo $csrf->echoInputField(); ?>
                                        <input type="hidden" name="ref" value="send_reset_code">
                                        <div class="input-group custom">
                                            <input type="text" name="tell" class="form-control form-control-lg" placeholder="Phone number">
                                            <div class="input-group-append custom">
                                                <span class="input-group-text"><i class="fa fa-phone" aria-hidden="true"></i></span>
                                            </div>
                                        </div>
                                        <div class="row">
                                          <div class="col-sm-12 wait1 border-left border-right border-bottom border-top" align="center" style="display: none;">
                                              <i class="icon-copy fa fa-spinner fa-spin fa-2x" aria-hidden="true"></i>
                                              <br>
                                              <i><?php echo hdev_lang::on('validation','processing'); ?>!!!</i>
                                          </div>
                                        </div>
                                        <div class="row align-items-center" id="fsave">
                                            <div class="col-12">
                                                <div class="input-group mb-0">
                                                    <!--
                                                        use code for form submit
                                                        <input class="btn btn-primary btn-lg btn-block" type="submit" value="Submit">
                                                    -->
                                                    <button class="btn btn-primary btn-lg btn-block" type="submit">Submit</button>
                                                    <br>
                                                    <div class="text-center" style="width: 100%;">
                                                        <h3 class="text-primary">OR</h3>
                                                        <a href="<?php echo hdev_url::menu('login') ?>" class="btn btn-secondary btn-block">Login</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="" id="forgot_2" style="display: none;">
                                <div class="login-box bg-white box-shadow border-radius-10">
                                    <div class="login-title">
                                        <h2 class="text-center text-primary">Enter a Code sent to you</h2>
                                    </div>
                                    <form id="reset_2" onsubmit="forgot_2(); return false;">
                                        <?php echo $csrf->echoInputField(); ?>
                                        <input type="hidden" name="ref" value="enter_code">
                                        <input type="hidden" name="mask" id="mask">
                                        <div class="input-group custom">
                                            <input type="text" id="tel_2" name="tel" class="form-control form-control-lg" placeholder="Phone number" readonly>
                                            <div class="input-group-append custom">
                                                <span class="input-group-text"><i class="fa fa-phone"></i></span>
                                            </div>
                                        </div>
                                        <div class="input-group custom">
                                            <input type="text" class="form-control form-control-lg" name="code" placeholder="Type Code sent to you Here">
                                            <div class="input-group-append custom">
                                                <span class="input-group-text"><i class="dw dw-padlock1"></i></span>
                                            </div>
                                        </div>
                                        <div class="row">
                                          <div class="col-sm-12 wait2 border-left border-right border-bottom border-top" align="center" style="display: none;">
                                              <i class="icon-copy fa fa-spinner fa-spin fa-2x" aria-hidden="true"></i>
                                              <br>
                                              <i><?php echo hdev_lang::on('validation','processing'); ?>!!!</i>
                                          </div>
                                        </div>
                                        <div class="row align-items-center" id="fsave2">
                                            <div class="col-12">
                                                <div class="input-group mb-0">
                                                    <!--
                                                        use code for form submit
                                                        <input class="btn btn-primary btn-lg btn-block" type="submit" value="Submit">
                                                    -->
                                                    <button class="btn btn-primary btn-lg btn-block" type="submit">Submit</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>                  
                            <div class="" id="forgot_3" style="display: none;">
                                <div class="login-box bg-white box-shadow border-radius-10">
                                    <div class="login-title">
                                        <h2 class="text-center text-primary">Reset Password</h2>
                                    </div>
                                    <h6 class="mb-20">Enter your new password, confirm and submit</h6>
                                    <form id="reset_3" onsubmit="forgot_3(); return false;">
                                        <?php echo $csrf->echoInputField(); ?>
                                        <input type="hidden" name="ref" value="reset_password">
                                        <input type="hidden" name="mask" id="mask2">
                                        <input type="hidden" name="tel" id="tel_3">
                                        <div class="input-group custom">
                                            <select class="form-control form-control-lg" name="user" id="profiles" required>
                                                <option value="">--Select Usename for your account--</option>
                                            </select>
                                        </div>
                                        <div class="input-group custom">
                                            <input type="text" class="form-control form-control-lg" name="pass_1" placeholder="New Password">
                                            <div class="input-group-append custom">
                                                <span class="input-group-text"><i class="dw dw-padlock1"></i></span>
                                            </div>
                                        </div>
                                        <div class="input-group custom">
                                            <input type="text" class="form-control form-control-lg" name="pass_2" placeholder="Confirm New Password">
                                            <div class="input-group-append custom">
                                                <span class="input-group-text"><i class="dw dw-padlock1"></i></span>
                                            </div>
                                        </div>
                                        <div class="row">
                                          <div class="col-sm-12 wait3 border-left border-right border-bottom border-top" align="center" style="display: none;">
                                              <i class="icon-copy fa fa-spinner fa-spin fa-2x" aria-hidden="true"></i>
                                              <br>
                                              <i><?php echo hdev_lang::on('validation','processing'); ?>!!!</i>
                                          </div>
                                        </div>
                                        <div class="row align-items-center" id="fsave3">
                                            <div class="col-12">
                                                <div class="input-group mb-0">
                                                    <!--
                                                        use code for form submit
                                                        <input class="btn btn-primary btn-lg btn-block" type="submit" value="Submit">
                                                    -->
                                                    <button class="btn btn-primary btn-lg btn-block" type="submit">Submit</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script>window.jQuery || document.write('<script src="<?php echo hdev_url::menu('src/js/vendor/jquery-3.3.1.min.js'); ?>"><\/script>')</script>
        <script src="<?php echo hdev_url::menu('plugins/popper.js/dist/umd/popper.min.js'); ?>"></script>
        <script src="<?php echo hdev_url::menu('plugins/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
        <script src="<?php echo hdev_url::menu('plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js'); ?>"></script>
        <script src="<?php echo hdev_url::menu('plugins/screenfull/dist/screenfull.js'); ?>"></script>
        <script src="<?php echo hdev_url::menu('dist/js/theme.js'); ?>"></script>
    <script type="text/javascript">
    function forgot_1() {
        var formData = jQuery('#reset_1').serialize();
        $.ajax({
          type: "POST",
          url: "<?php echo hdev_url::menu('login_i');?>",
          data: formData,
          beforeSend: function(){
            // Show image container
            $("#fsave").hide();
            $(".wait1").show();
           },
          success:function(data){
            //alert(data);
            var jsonData = JSON.parse(data);
            if (jsonData.act == 'success') {
                var a = '<span class="text-success">';
                var mg = a+jsonData.message+'</span>';      
                $('.wait1').html(mg);

                $('#reset_2 #tel_2').val(jsonData.tel);
                $('#reset_2 #mask').val(jsonData.mask);
                $('#forgot_1').hide();
                $('#forgot_2').show();
            }else{
                var mg = jsonData.message;      
                $('.wait1').html(mg);
            }
            //alert(data);
            //$('.wait1').html(j);
          },
          complete:function(data){
            // Hide image container
           setTimeout(function(){
              $("#fsave").show();
              $(".wait1").hide();
            }, 4000);
           }
        });
    }
    function forgot_2() {
        var formData = jQuery('#reset_2').serialize();
        $.ajax({
          type: "POST",
          url: "<?php echo hdev_url::menu('login_i');?>",
          data: formData,
          beforeSend: function(){
            // Show image container
            $("#fsave2").hide();
            $(".wait2").show();
           },
          success:function(data){
            //alert(data);
            var jsonData = JSON.parse(data);
            if (jsonData.act == 'success') {
                var a = '<span class="text-success">';
                var mg = a+jsonData.message+'</span>';      
                $('.wait2').html(mg);

                $('#reset_3 #tel_3').val(jsonData.tel);
                $('#reset_3 #profiles').html(jsonData.profiles);
                $('#reset_3 #mask2').val(jsonData.mask2);
                $('#forgot_2').hide();
                $('#forgot_3').show();
            }else{
                var mg = jsonData.message;      
                $('.wait2').html(mg);
            }
            //alert(data);
            //$('.wait1').html(j);
          },
          complete:function(data){
            // Hide image container
           setTimeout(function(){
              $("#fsave2").show();
              $(".wait2").hide();
            }, 4000);
           }
        });
    }    
    function forgot_3() {
        var formData = jQuery('#reset_3').serialize();
        $.ajax({
          type: "POST",
          url: "<?php echo hdev_url::menu('login_i');?>",
          data: formData,
          beforeSend: function(){
            // Show image container
            $("#fsave3").hide();
            $(".wait3").show();
           },
          success:function(data){
            //alert(data);
            var jsonData = JSON.parse(data);
            if (jsonData.act == 'success') {
                var a = '<span class="text-success">';
                var mg = a+jsonData.message+'</span>';  
                $('.wait3').html(mg);   
                alert(jsonData.message);
                window.location.href = '<?php echo hdev_url::menu('login') ?>';
            }else{
                var mg = jsonData.message;      
                $('.wait3').html(mg);
            }
            //alert(data);
            //$('.wait1').html(j);
          },
          complete:function(data){
            // Hide image container
           setTimeout(function(){
              $("#fsave3").show();
              $(".wait3").hide();
            }, 4000);
           }
        });
    }    
    </script>
    </body>
</html>
