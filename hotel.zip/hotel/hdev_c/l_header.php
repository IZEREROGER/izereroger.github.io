<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>Login | <?php echo APP_NAME ?></title>
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <link rel="icon" href="<?php echo hdev_url::menu('icon/Logo.png') ?>" type="image/png" />
        <link rel="manifest" href="<?php echo hdev_url::menu('manifest.json'); ?>">
        <script>
            //if browser support service worker
            if('serviceWorker' in navigator) {
              navigator.serviceWorker.register('<?php echo hdev_url::menu('sw_ct.js'); ?>');
            };
        </script>
        <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,600,700,800" rel="stylesheet">
        
        <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/bootstrap/dist/css/bootstrap.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/fontawesome-free/css/all.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/ionicons/dist/css/ionicons.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/icon-kit/dist/css/iconkit.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/perfect-scrollbar/css/perfect-scrollbar.css'); ?>">
        <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/jquery-toast-plugin/dist/jquery.toast.min.css'); ?>">
        <link rel="stylesheet" href="<?php echo hdev_url::menu('dist/css/theme.min.css'); ?>">
        <script src="<?php echo hdev_url::menu('src/js/vendor/modernizr-2.8.3.min.js'); ?>"></script>
    </head>

    <body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->