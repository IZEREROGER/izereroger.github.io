                </div> <!--app body end -->
                <footer class="footer">
                    <div class="w-100 clearfix">
                        <span class="text-center text-sm-left d-md-inline-block">Copyright © 2022 Software ltd. All Rights Reserved.</span>
                        <span class="float-none float-sm-right mt-1 mt-sm-0 text-center">Crafted with <i class="fa fa-heart text-danger"></i> by <a href="<?php echo hdev_url::menu(''); ?>" class="text-dark" target="_blank"><?php echo APP_PROGRAMMER['name']; ?></a></span>
                    </div>
                </footer>
          </div> <!--page wrap end -->
        </div>
       <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script>window.jQuery || document.write('<script src="<?php echo hdev_url::menu('src/js/vendor/jquery-3.3.1.min.js'); ?>"><\/script>')</script>
        <script src="<?php echo hdev_url::menu('plugins/popper.js/dist/umd/popper.min.js'); ?>"></script>
        <script src="<?php echo hdev_url::menu('plugins/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
          <!-- pace-progress -->
        <script src="<?php echo hdev_url::menu('plugins/pace-progress/pace.min.js'); ?>"></script>
        <script src="<?php echo hdev_url::menu('plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js'); ?>"></script>
        <script src="<?php echo hdev_url::menu('plugins/screenfull/dist/screenfull.js'); ?>"></script>
        <script src="<?php echo hdev_url::menu('plugins/datatables.net/js/jquery.dataTables.min.js'); ?>"></script>
        <script src="<?php echo hdev_url::menu('plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js'); ?>"></script>
        <script src="<?php echo hdev_url::menu('plugins/ajax/former.js');?>"></script>
        <script src="<?php echo hdev_url::menu('plugins/datatables-responsive/js/dataTables.responsive.min.js'); ?>"></script>
                <script src="<?php echo hdev_url::menu('dist/js/theme.min.js'); ?>"></script>
                <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script src="<?php echo hdev_url::menu('plugins/ajax/sl.js');?>"></script>
        <script>
            $(document).ready(function() {
              $('.owl-carousel').owlCarousel({
                loop: true,
                margin: 2,
                autoplay: true,
                autoplayTimeout: 2500,
                autoplayHoverPause: true,
                lazyLoad: true,
                lazyLoadEager: 1,
                responsiveClass: true,
                responsive: {
                  0: {
                    items: 1,
                    nav: true
                  },
                  600: {
                    items: 3,
                    nav: true
                  },
                  1000: {
                    items: 3,
                    nav: true,
                    loop: true,
                    margin: 2
                  }
                }
              })
            })
          </script>
  <script type="text/javascript">
    function main_search(val='') {
      var a = '<?php echo hdev_url::menu('home/'); ?>';
      var b = '/search';
      window.location.href = a+val+b;
    }
    var $load_min= '<span><i class="fa fa-spinner fa-spin"></i></span>';
    function total_calculator(pu='',qty='',final_id='',act_ref='*') {
      var pu = $('#'+pu).val();
      var qty = $('#'+qty).val();
      if (isNaN(pu)) {
        pu = 0;
      };
      if (isNaN(qty)) {
        qty = 0;
      };
      if (act_ref == '*') {
        $('#'+final_id).val(pu*qty);
      }
      if (act_ref == '-') {
        $('#'+final_id).val(pu-qty);
      }   
    }
    function app_printer(id_t,btnn) {
      $('#'+btnn).hide();
      $("#"+id_t+' .no_print').hide();
      $("#"+id_t+" .hd_pt").show();
      $("#"+id_t+" .bg-secondary").addClass("dt_b-gg");
      $("#"+id_t+" .dt_b-gg").removeClass("bg-secondary");
      $("#"+id_t+" .dt_b-gg").removeClass("text-white");
      var id_to_print = document.getElementById(id_t);
      var WinPrint = window.open('', '<?php echo APP_NAME." -- PRINTER" ?>', 'left=0,top=0,width='+screen.width+',height='+screen.height+',toolbar=0,scrollbars=0,status=0');
      WinPrint.document.write('<html><head><title><?php echo APP_NAME." -- PRINTER" ?></title>');
      WinPrint.document.write('<link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/bootstrap/dist/css/bootstrap.min.css'); ?>">');
      WinPrint.document.write('<style>*{color: #000000 !important;}</style></head><body onload="print();close();">');
      WinPrint.document.write(id_to_print.innerHTML);
      WinPrint.document.write('</body></html>');
      WinPrint.document.close();
      WinPrint.focus();
      $("#"+id_t+' .no_print').show();
      $("#"+id_t+" .hd_pt").hide();
      $("#"+id_t+" .dt_b-gg").addClass("text-white");
      $("#"+id_t+" .dt_b-gg").addClass("bg-secondary");
      $("#"+id_t+" .bg-secondary").removeClass("dt_b-gg");
      $('#'+btnn).show();
    }
    function stock_in(prod='',has_v='',target_data='',target_load='') {
      var old_data = $('#'+target_load).html();
      $('#'+target_data).html('<option value="">- Select Stock in -</option>');
      $.ajax({
        url   : "<?php echo hdev_url::menu('up'); ?>",
        method  : "POST",
        data  : {ref:'stock_in_bind',p_id:prod,hash_mask:has_v},
        beforeSend: function(){
          $('#'+target_load).html($load_min);
        },
        success:function(data){
          $('#'+target_data).html(data);
          $('#'+target_load).html(old_data);
        }, 
        error: function(){
          alert("refresh a page and try again");
        }
      });
    }
    function cart_items(badge='cart_items') {
      $.ajax({
        url   : "<?php echo hdev_url::menu('up'); ?>",
        method  : "POST",
        data  : {ref:'cart_items'},
        beforeSend: function(){
          $('#'+badge).html($load_min);
        },
        success:function(data){
          $('#'+badge).html(data);
        }, 
        error: function(){
          alert("refresh a page and try again");
          window.location.reload();
        }
      });      
    }    
    function count_cart(badge='cart_val') {
      $.ajax({
        url   : "<?php echo hdev_url::menu('up'); ?>",
        method  : "POST",
        data  : {ref:'count_cart'},
        beforeSend: function(){
          $('#'+badge).html($load_min);
        },
        success:function(data){
          $('#'+badge).html(data);
          cart_items();
        }, 
        error: function(){
          alert("refresh a page and try again");
          window.location.reload();
        }
      });      
    }
    function add_to_cart(has_v='',type_num='',ref_id_num='',qty_num='',price_num='',button='r') {
      $.ajax({
        url   : "<?php echo hdev_url::menu('up'); ?>",
        method  : "POST",
        data  : {ref:'add_to_cart',hash:has_v,type:type_num,ref_id:ref_id_num,qty:qty_num,price:price_num,ext:''},
        beforeSend: function(){
          $('#'+button).html('adding to cart. '+$load_min);
        },
        success:function(data){
          count_cart();
          $('#'+button).attr("disabled","true");
          $('#'+button).attr("onclick","");
          $('#'+button).html("added to cart");
        }, 
        error: function(){
          alert("refresh a page and try again");
          window.location.reload();
        }
      });
    }    
    function edit_to_cart(cart_id_num='',type_num='',ref_id_num='',qty_num='',price_num='',button='r') {
      $.ajax({
        url   : "<?php echo hdev_url::menu('up'); ?>",
        method  : "POST",
        data  : {ref:'edit_to_cart',cart_id:cart_id_num,type:type_num,ref_id:ref_id_num,qty:qty_num,price:price_num},
        beforeSend: function(){
          //alert(qty_num);
          //$('#'+button).html('adding to cart. '+$load_min);
        },
        success:function(data){
          //$().attr('disabled','true');

          //alert(data);
          attach();
          //count_cart();
        }, 
        error: function(){
          alert("something went wrong. Refresh a page and try again");
          window.location.reload();
        }
      });
    }       
    function generate_receipt(v_btn='r',v_hash='r',rec_client='') {
      $.ajax({
        url   : "<?php echo hdev_url::menu('up'); ?>",
        method  : "POST",
        data  : {ref:'generate_receipt',hash:v_hash,client_name:rec_client,mod_close:'#'+v_btn+'_close'},
        beforeSend: function(){
          $('.wait').html($load_status);
          $('#'+v_btn).hide();
         },
        success:function(html){
            a = '<span class="text-danger">'+html+'</span>';
            $('.wait').html(a);
            setTimeout(function(){
              $('.wait').html('');
              $('#'+v_btn).show();
            }, 4000);
        },
        error: function(){
          $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
          $('#'+v_btn).show();
        }
      });
    }        
    function update_datatable() {
    count_cart();
      $('.data-table').DataTable({
        scrollCollapse: true,
        autoWidth: false,
        responsive: true,
        columnDefs: [{
          targets: "datatable-nosort",
          orderable: false,
        }],
        "language": {
          "info": "_START_-_END_ of _TOTAL_ entries",
          searchPlaceholder: "Search",
          paginate: {
            next: '<i class="ion-chevron-right"></i>',
            previous: '<i class="ion-chevron-left"></i>'  
          }
        },
      });
    }
    function attach(cur='') {
      //alert(cur);
      if (cur == "") {
        cur = window.location.href;
      }
      $('#menu_loader').html('<div class="process-loader"></div>');
      var rest =  cur.split("?");
       xhttp = new XMLHttpRequest();
       xhttp.onreadystatechange = function() {
          if (this.readyState == 4) {
            if (this.status == 200) {
              $('body #app_body').html(this.responseText);
              $('#menu_loader').html('<!--loader-->');
              update_datatable();
            }
            if (this.status == 404) {
              //window.location.reload();
            }
          }
        }
        xhttp.open("GET", ""+rest[0]+"/a/b/c", true);
        xhttp.send();
    }
    var $load_status= '<span><i class="fa fa-spinner fa-spin"></i></span><i>&nbsp;&nbsp;wait...!!!</i>';
    function fm_submit(btn_ck,fm_ck,url_action='') {
      //alert('hello');
        var formData = jQuery('#'+fm_ck).serialize();
        $.ajax({ 
              type: "POST",
              url: "<?php echo hdev_url::menu('up');?>",
              data: formData,
              beforeSend: function(){
                $('.wait').html($load_status);
                $('#'+btn_ck).hide();
               },
              success:function(html){
                  //alert(html);
                  a = '<span class="text-danger">'+html+'</span>';
                  $('.wait').html(a);
                  setTimeout(function(){
                    $('.wait').html('');
                    $('#'+btn_ck).show();
                  }, 4000);
              },
              error: function(){
                $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
                $('#'+btn_ck).show();
              }
            });
    }
   $(document).ready(function(){ 
    update_datatable();

    <?php if (hdev_data::service('edit_to_cart')): ?> 
    $(document).on('change','.edit_to_cart',function(e) {
      var o_id=$(this).attr("id");
      var price=$(this).attr("price");
      var o_type=$(this).attr("o_type"); 
      var ref_id=$(this).attr("ref_id");
      var qty=$(this).val(); 
      var cart_id=$(this).attr("cart_id"); 
      var o_id=$(this).attr("id");
      edit_to_cart(cart_id,o_type,ref_id,qty,price,o_id);
    }); 
    <?php endif ?>   
    <?php if (hdev_data::service('add_to_cart')): ?> 
    $(document).on('click','.add_to_cart',function(e) {
      var price=$(this).attr("price");
      var o_type=$(this).attr("o_type"); 
      var ref_id=$(this).attr("ref_id");
      var qty=$(this).attr("qty"); 
      var o_id=$(this).attr("id"); 

      add_to_cart('hash',o_type,ref_id,qty,price,o_id);
    }); 
    <?php endif ?>   
    <?php if (hdev_data::service('category_edit')): ?> 
    $(document).on('click','.cat_edit',function(e) {
      var c_id=$(this).attr("c_id");
      var c_name=$(this).attr("c_name");
      var c_desc=$(this).attr("c_desc"); 

      $('.modal-edit #c_id').val(c_id);
      $('.modal-edit #c_name').val(c_name);
      $('.modal-edit #c_desc').html(c_desc);
    }); 
    <?php endif ?>   
    <?php if (hdev_data::service('cart_delete')): ?> 
    $(document).on('click','.cart_delete',function(e) {
      var p_name=$(this).attr("p_name");
      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");
      $('.modal-delete #p_name').html(p_name);
      $('.modal-delete #cart_delete').attr("data","");
      $('.modal-delete #cart_delete').attr("hash","");      
      $('.modal-delete #cart_delete').attr("data",dt);
      $('.modal-delete #cart_delete').attr("hash",hs);
      //alert(dt);
    }); 
    $(document).on('click','#cart_delete',function(e) {
      e.preventDefault();
      var dtt = $(this).attr("data");
      var hss = $(this).attr("hash");
      $.ajax({ 
            type: "POST",
            url: "<?php echo hdev_url::menu('app/setting');?>/"+hss+"/"+dtt,
            data: {req:'ajax'},
             beforeSend: function(){
              $('.wait').html($load_status);
              $('#cart_delete').hide();
             },
            success:function(html){
                a = '<span class="text-danger">'+html+'</span>';
                $('.wait').html(a);
                setTimeout(function(){
                  $('.wait').html('');
                  $('#cart_delete').show();
                }, 4000);
            },
            error: function(){
              $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
              $('#cart_delete').show();
            }
          });
        return false; 
    });
    <?php endif ?>  
    <?php if (hdev_data::service('category_delete') || hdev_data::service('category_reover')): ?> 
    $(document).on('click','.cat_delete',function(e) {
      var c_name=$(this).attr("c_name");
      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");
      $('.modal-delete #c_name').html(c_name);
      $('.modal-delete #category_delete').attr("data","");
      $('.modal-delete #category_delete').attr("hash","");      
      $('.modal-delete #category_delete').attr("data",dt);
      $('.modal-delete #category_delete').attr("hash",hs);
      //alert(dt);
    }); 
    $(document).on('click','#category_delete',function(e) {
      e.preventDefault();
      var dtt = $(this).attr("data");
      var hss = $(this).attr("hash");
      $.ajax({ 
            type: "POST",
            url: "<?php echo hdev_url::menu('app/setting');?>/"+hss+"/"+dtt,
            data: {req:'ajax'},
             beforeSend: function(){
              $('.wait').html($load_status);
              $('#category_delete').hide();
             },
            success:function(html){
                a = '<span class="text-danger">'+html+'</span>';
                $('.wait').html(a);
                setTimeout(function(){
                  $('.wait').html('');
                  $('#category_delete').show();
                }, 4000);
            },
            error: function(){
              $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
              $('#category_delete').show();
            }
          });
        return false; 
    });
    <?php endif ?> 
    $(document).on('submit','#rooms_reg',function(e) {
      if($('.modal-reg #upic_a').val()) {
        e.preventDefault();

        $(this).ajaxSubmit({  
          target:   '.modal-reg .wait',  
          beforeSubmit: function() {
            $(".modal-reg #progress-bar").width('0%');
            $('.modal-reg .wait').html($load_status);
            $('.modal-reg #reg_rooms').hide();
          },
          uploadProgress: function (event, position, total, percentComplete){ 
            $(".modal-reg #progress-bar").width(percentComplete + '%');
            $(".modal-reg #progress-bar").html('<div id="progress-status">' + percentComplete +' %</div>');

          },
          success:function (){
              $('#reg_rooms').show();

            setTimeout(function(){
              $('.modal-reg .wait').html('');
            }, 4000);
          },
          resetForm: false 
        }); 
        return false; 
      }else{
       setTimeout(function(){
              $('.modal-reg .wait').html('Select what to upload first');
            }, 4000);
      }
    });      
    <?php if (hdev_data::service('rooms_edit')): ?> 
    $(document).on('click','.rm_edit',function(e) {
      var r_id=$(this).attr("r_id");
      var r_name=$(this).attr("r_name");
      var r_price=$(this).attr("r_price");
      var r_desc=$(this).attr("r_desc");
          
      $('.modal-edit #r_id').val(r_id);
      $('.modal-edit #r_name').val(r_name);
      $('.modal-edit #r_price').val(r_price);
      $('.modal-edit #r_desc').val(r_desc);  
      var plchd = $('.modal-edit #fpc').html();
      $('.modal-edit #fpc2').html(plchd);
      var vl = $('.modal-edit #fpc2 #upic_a').attr('name2');
      $('.modal-edit #fpc2 #upic_a').attr('name',vl);      
      //alert(dt);
    }); 
    $(document).on('submit','#rooms_edit',function(e) {
      if($('.modal-edit #fpc2 #upic_a').val()) {
        e.preventDefault();

        $(this).ajaxSubmit({  
          target:   '.modal-edit .wait',  
          beforeSubmit: function() {
            $(".modal-edit #progress-bar").width('0%');
            $('.modal-edit .wait').html($load_status);
            $('#edit_rooms').hide();
          },
          uploadProgress: function (event, position, total, percentComplete){ 
            $(".modal-edit #progress-bar").width(percentComplete + '%');
            $(".modal-edit #progress-bar").html('<div id="progress-status">' + percentComplete +' %</div>');

          },
          success:function (){
              $('#edit_rooms').show();

            setTimeout(function(){
              $('.modal-edit .wait').html('');
            }, 4000);
          },
          resetForm: false 
        }); 
        return false; 
      }else{
        //alert('12');
       var formData = jQuery('#rooms_edit').serialize();
       e.preventDefault();
        $.ajax({ 
              type: "POST",
              url: "<?php echo hdev_url::menu('up');?>",
              data: formData,
              beforeSend: function(){
                $('.modal-edit #edit_rooms').hide();
                $('.modal-edit .wait').html($load_status);
               },
              success:function(html){
                if (html == 'ok'){
                  
                }else{
                  a = '<span class="text-danger">'+html+'</span>';
                  
                  setTimeout(function(){
                    $('.modal-edit .wait').html(a);
                  }, 1500);
                  setTimeout(function(){
                    $('.modal-edit #edit_rooms').show();
                    $('.modal-edit .wait').html('');
                  }, 4000);
                }
              }, 
              error: function(){
                $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
                setTimeout(function(){
                    $('.modal-edit #edit_rooms').show();
                    $('.modal-edit .wait').html('');
                  }, 3000);
              }
            });
      }
    });
    <?php endif ?>
        <?php if (hdev_data::service('rooms_delete') || hdev_data::service('rooms_reover')): ?> 
    $(document).on('click','.rm_delete',function(e) {
      var r_name=$(this).attr("r_name");
      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");
      $('.modal-delete #r_name').html(r_name);
      $('.modal-delete #rooms_delete').attr("data","");
      $('.modal-delete #rooms_delete').attr("hash","");      
      $('.modal-delete #rooms_delete').attr("data",dt);
      $('.modal-delete #rooms_delete').attr("hash",hs);
      //alert(dt);
    }); 
    $(document).on('click','#rooms_delete',function(e) {
      e.preventDefault();
      var dtt = $(this).attr("data");
      var hss = $(this).attr("hash");
      $.ajax({ 
            type: "POST",
            url: "<?php echo hdev_url::menu('app/setting');?>/"+hss+"/"+dtt,
            data: {req:'ajax'},
             beforeSend: function(){
              $('.wait').html($load_status);
              $('#rooms_delete').hide();
             },
            success:function(html){
                a = '<span class="text-danger">'+html+'</span>';
                $('.wait').html(a);
                setTimeout(function(){
                  $('.wait').html('');
                  $('#rooms_delete').show();
                }, 4000);
            },
            error: function(){
              $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
              $('#rooms_delete').show();
            }
          });
        return false; 
    });
    <?php endif ?>
    $(document).on('submit','#products_reg',function(e) {
      if($('.modal-reg #upic_a').val()) {
        e.preventDefault();

        $(this).ajaxSubmit({  
          target:   '.modal-reg .wait',  
          beforeSubmit: function() {
            $(".modal-reg #progress-bar").width('0%');
            $('.modal-reg .wait').html($load_status);
            $('.modal-reg #reg_products').hide();
          },
          uploadProgress: function (event, position, total, percentComplete){ 
            $(".modal-reg #progress-bar").width(percentComplete + '%');
            $(".modal-reg #progress-bar").html('<div id="progress-status">' + percentComplete +' %</div>');

          },
          success:function (){
              $('#reg_products').show();

            setTimeout(function(){
              $('.modal-reg .wait').html('');
            }, 4000);
          },
          resetForm: false 
        }); 
        return false; 
      }else{
       setTimeout(function(){
              $('.modal-reg .wait').html('Select what to upload first');
            }, 4000);
      }
    });
    <?php if (hdev_data::service('products_delete') || hdev_data::service('products_reover')): ?> 
    $(document).on('click','.prod_delete',function(e) {
      var p_name=$(this).attr("p_name");
      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");
      $('.modal-delete #p_name').html(p_name);
      $('.modal-delete #products_delete').attr("data","");
      $('.modal-delete #products_delete').attr("hash","");      
      $('.modal-delete #products_delete').attr("data",dt);
      $('.modal-delete #products_delete').attr("hash",hs);
      //alert(dt);
    }); 
    $(document).on('click','#products_delete',function(e) {
      e.preventDefault();
      var dtt = $(this).attr("data");
      var hss = $(this).attr("hash");
      $.ajax({ 
            type: "POST",
            url: "<?php echo hdev_url::menu('app/setting');?>/"+hss+"/"+dtt,
            data: {req:'ajax'},
             beforeSend: function(){
              $('.wait').html($load_status);
              $('#products_delete').hide();
             },
            success:function(html){
                a = '<span class="text-danger">'+html+'</span>';
                $('.wait').html(a);
                setTimeout(function(){
                  $('.wait').html('');
                  $('#products_delete').show();
                }, 4000);
            },
            error: function(){
              $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
              $('#products_delete').show();
            }
          });
        return false; 
    });
    <?php endif ?>

    <?php if (hdev_data::service('products_edit')): ?> 
    $(document).on('click','.sin_edit',function(e) {
      var sin_id_edit=$(this).attr("sin_id_edit");
      var p_name_edit=$(this).attr("p_name_edit");
      var p_unit_edit=$(this).attr("p_unit_edit");
      var qty_edit=$(this).attr("qty_edit");
      var total_buying_price_edit=$(this).attr("total_buying_price_edit");
      var sell_p_u_edit=$(this).attr("sell_p_u_edit");
      var total_selling_edit=$(this).attr("total_selling_edit");
      var profit_expected_edit=$(this).attr("profit_expected_edit");
      var mfg_date_edit=$(this).attr("mfg_date_edit");
      var exp_date_edit=$(this).attr("exp_date_edit");
      var supplier_edit=$(this).attr("supplier_edit");  

      $('.modal-edit #sin_id_edit').val(sin_id_edit);
      $('.modal-edit #p_name_edit').html(p_name_edit);
      $('.modal-edit #p_unit_edit').val(p_unit_edit);
      $('.modal-edit #qty_edit').val(qty_edit);
      $('.modal-edit #total_buying_price_edit').val(total_buying_price_edit);
      $('.modal-edit #sell_p_u_edit').val(sell_p_u_edit);
      $('.modal-edit #total_selling_edit').val(total_selling_edit);
      $('.modal-edit #profit_expected_edit').val(profit_expected_edit);
      $('.modal-edit #mfg_date_edit').val(mfg_date_edit); 
      $('.modal-edit #exp_date_edit').val(exp_date_edit);
      $('.modal-edit #supplier_edit').val(supplier_edit);   
      //alert(dt);
    }); 
    <?php endif ?>    
    <?php if (hdev_data::service('products_edit')): ?> 
    $(document).on('click','.prod_edit',function(e) {
      var p_id=$(this).attr("p_id");
      var c_id=$(this).attr("c_id");
      var b_id=$(this).attr("b_id");
      var p_name=$(this).attr("p_name");
      var p_price=$(this).attr("p_price");
      var p_unit=$(this).attr("p_unit");
      var p_desc=$(this).attr("p_desc");
          
      $('.modal-edit #p_id').val(p_id);
      $('.modal-edit #c_id').val(c_id);
      $('.modal-edit #b_id').val(b_id);
      $('.modal-edit #p_name').val(p_name);
      $('.modal-edit #p_price').val(p_price);
      $('.modal-edit #p_unit').val(p_unit);
      $('.modal-edit #p_desc').val(p_desc);  
      var plchd = $('.modal-edit #fpc').html();
      $('.modal-edit #fpc2').html(plchd);
      var vl = $('.modal-edit #fpc2 #upic_a').attr('name2');
      $('.modal-edit #fpc2 #upic_a').attr('name',vl);      
      //alert(dt);
    }); 
    $(document).on('submit','#products_edit',function(e) {
      if($('.modal-edit #fpc2 #upic_a').val()) {
        e.preventDefault();

        $(this).ajaxSubmit({  
          target:   '.modal-edit .wait',  
          beforeSubmit: function() {
            $(".modal-edit #progress-bar").width('0%');
            $('.modal-edit .wait').html($load_status);
            $('#edit_products').hide();
          },
          uploadProgress: function (event, position, total, percentComplete){ 
            $(".modal-edit #progress-bar").width(percentComplete + '%');
            $(".modal-edit #progress-bar").html('<div id="progress-status">' + percentComplete +' %</div>');

          },
          success:function (){
              $('#edit_products').show();

            setTimeout(function(){
              $('.modal-edit .wait').html('');
            }, 4000);
          },
          resetForm: false 
        }); 
        return false; 
      }else{
        //alert('12');
       var formData = jQuery('#products_edit').serialize();
       e.preventDefault();
        $.ajax({ 
              type: "POST",
              url: "<?php echo hdev_url::menu('up');?>",
              data: formData,
              beforeSend: function(){
                $('.modal-edit #edit_products').hide();
                $('.modal-edit .wait').html($load_status);
               },
              success:function(html){
                if (html == 'ok'){
                  
                }else{
                  a = '<span class="text-danger">'+html+'</span>';
                  
                  setTimeout(function(){
                    $('.modal-edit .wait').html(a);
                  }, 1500);
                  setTimeout(function(){
                    $('.modal-edit #edit_products').show();
                    $('.modal-edit .wait').html('');
                  }, 4000);
                }
              }, 
              error: function(){
                $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
                setTimeout(function(){
                    $('.modal-edit #edit_products').show();
                    $('.modal-edit .wait').html('');
                  }, 3000);
              }
            });
      }
    });
    <?php endif ?>
    <?php if (hdev_data::service('tools_delete') || hdev_data::service('tools_reover')): ?> 
    $(document).on('click','.eq_delete',function(e) {
      var t_name=$(this).attr("t_name");
      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");
      $('.modal-delete #t_name').html(t_name);
      $('.modal-delete #tools_delete').attr("data","");
      $('.modal-delete #tools_delete').attr("hash","");      
      $('.modal-delete #tools_delete').attr("data",dt);
      $('.modal-delete #tools_delete').attr("hash",hs);
      //alert(dt);
    }); 
    $(document).on('click','#tools_delete',function(e) {
      e.preventDefault();
      var dtt = $(this).attr("data");
      var hss = $(this).attr("hash");
      $.ajax({ 
            type: "POST",
            url: "<?php echo hdev_url::menu('app/setting');?>/"+hss+"/"+dtt,
            data: {req:'ajax'},
             beforeSend: function(){
              $('.wait').html($load_status);
              $('#tools_delete').hide();
             },
            success:function(html){
                a = '<span class="text-danger">'+html+'</span>';
                $('.wait').html(a);
                setTimeout(function(){
                  $('.wait').html('');
                  $('#tools_delete').show();
                }, 4000);
            },
            error: function(){
              $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
              $('#tools_delete').show();
            }
          });
        return false; 
    });
    <?php endif ?>
    <?php if (hdev_data::service('tools_edit')): ?> 
    $(document).on('click','.eq_edit',function(e) {
      var t_id=$(this).attr("t_id");
      var t_name=$(this).attr("t_name");
      var t_qty=$(this).attr("t_qty");
      var t_desc=$(this).attr("t_desc");
      var t_health=$(this).attr("t_health");
          
      $('.modal-edit #t_id').val(t_id);
      $('.modal-edit #t_name').val(t_name);
      $('.modal-edit #t_qty').val(t_qty);
      $('.modal-edit #t_desc').html(t_desc);
      $('.modal-edit #t_health').val(t_health);
    }); 
    <?php endif ?>
    <?php if (hdev_data::service('stock_delete')): ?> 
    $(document).on('click','.stock_delete_btn',function(e) {
      var stock_delete_id=$(this).attr("stock_delete_id");
      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");
      $('.modal-delete #stock_delete_id').html(stock_delete_id);
      $('.modal-delete #stock_delete_btn').attr("data","");
      $('.modal-delete #stock_delete_btn').attr("hash","");      
      $('.modal-delete #stock_delete_btn').attr("data",dt);
      $('.modal-delete #stock_delete_btn').attr("hash",hs);
      //alert(dt);
    });
    $(document).on('click','#stock_delete_btn',function(e) {
      e.preventDefault();
      var dtt = $(this).attr("data");
      var hss = $(this).attr("hash");
      $.ajax({ 
            type: "POST",
            url: "<?php echo hdev_url::menu('app/setting');?>/"+hss+"/"+dtt,
            data: {req:'ajax'},
             beforeSend: function(){
              $('.wait').html($load_status);
              $('#stock_delete_btn').hide();
             },
            success:function(html){
                a = '<span class="text-danger">'+html+'</span>';
                $('.wait').html(a);
                setTimeout(function(){
                  $('.wait').html('');
                  $('#stock_delete_btn').show();
                }, 4000);
            },
            error: function(){
              $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
              $('#stock_delete_btn').show();
            }
          });
        return false; 
    });
    <?php endif ?>
    <?php if (hdev_data::service('stock_in_delete')): ?> 
    $(document).on('click','.stock_in_delete_btn',function(e) {
      var sin_id_delete=$(this).attr("sin_id_delete");
      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");
      $('.modal-delete #sin_id_delete').html(sin_id_delete);
      $('.modal-delete #stock_in_delete').attr("data","");
      $('.modal-delete #stock_in_delete').attr("hash","");      
      $('.modal-delete #stock_in_delete').attr("data",dt);
      $('.modal-delete #stock_in_delete').attr("hash",hs);
      //alert(dt);
    }); 
    $(document).on('click','#stock_in_delete',function(e) {
      e.preventDefault();
      var dtt = $(this).attr("data");
      var hss = $(this).attr("hash");
      $.ajax({ 
            type: "POST",
            url: "<?php echo hdev_url::menu('app/setting');?>/"+hss+"/"+dtt,
            data: {req:'ajax'},
             beforeSend: function(){
              $('.wait').html($load_status);
              $('#stock_in_delete').hide();
             },
            success:function(html){
                a = '<span class="text-danger">'+html+'</span>';
                $('.wait').html(a);
                setTimeout(function(){
                  $('.wait').html('');
                  $('#stock_in_delete').show();
                }, 4000);
            },
            error: function(){
              $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
              $('#stock_in_delete').show();
            }
          });
        return false; 
    });
    <?php endif ?>  
    <?php if (hdev_data::service('user_edit')): ?> 
    $(document).on('click','#edit_user_btn',function(e) {
      e.preventDefault();
      var formData = jQuery('#user_edit').serialize();
      $.ajax({ 
            type: "POST",
            url: "<?php echo hdev_url::menu('up');?>",
            data: formData,
            beforeSend: function(){
              $('.wait').html($load_status);
              $('#edit_user_btn').hide();
             },
            success:function(html){
                a = '<span class="text-danger">'+html+'</span>';
                $('.wait').html(a);
                setTimeout(function(){
                  $('.wait').html('');
                  $('#edit_user_btn').show();
                }, 4000);
            },
            error: function(){
              $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
              $('#edit_user_btn').show();
            }
          });
        return false; 
    }); 
    <?php endif ?>   
    <?php if (hdev_data::service('self_change_user_pwd')): ?> 
      $(document).on('click','#self_sec_p_btn',function(e) {
          e.preventDefault();
          var formData = jQuery('#self_sec_p').serialize();
          $.ajax({ 
                type: "POST",
                url: "<?php echo hdev_url::menu('up');?>",
                data: formData,
                beforeSend: function(){
                  $('.wait').html($load_status);
                  $('#self_sec_p_btn').hide();
                 },
                success:function(html){
                  a = '<span class="text-danger">'+html+'</span>';
                  $('.wait').html(a);
                  setTimeout(function(){
                    $('.wait').html('');
                    $('#self_sec_p_btn').show();
                  }, 4000);
                },
                error: function(){
                  $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
                  $('#self_sec_p_btn').show();
                }
              });
          });
      <?php endif ?>
    });
  </script>
    </body>
</html>