<?php if (hdev_log::loged()): ?>
        <div class="page-header">
          <div class="row">
            <div class="col-md-12 col-sm-12" align="center">
              <div class="title">
                <h4>Working As : <span class="weight-600 font-30 text-blue">Super Admin</span></h4>
              </div>
            </div>
          </div>
        </div>
    <div class="pd-ltr-20">
      <div class="card-box pd-20 height-100-p mb-30">
        <div class="row align-items-center">
          <div class="col-md-4">
            <img src="<?php echo hdev_url::menu('icon/on.png'); ?>" alt="">
          </div>
          <div class="col-md-8">
            <h4 class="font-20 weight-500 mb-10 text-capitalize">
              Welcome to : <div class="weight-600 font-30 text-blue">Smart Shop Management System</div>
            </h4>
            <p class="font-18 max-width-600">A powerfull Stock management system</p>
          </div>
        </div>
      </div>
    </div>

<?php endif ?>