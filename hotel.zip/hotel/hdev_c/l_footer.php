        
        <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
        <script>window.jQuery || document.write('<script src="<?php echo hdev_url::menu('src/js/vendor/jquery-3.3.1.min.js'); ?>"><\/script>')</script>
        <script src="<?php echo hdev_url::menu('plugins/popper.js/dist/umd/popper.min.js'); ?>"></script>
        <script src="<?php echo hdev_url::menu('plugins/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
        <script src="<?php echo hdev_url::menu('plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js'); ?>"></script>
        <script src="<?php echo hdev_url::menu('plugins/screenfull/dist/screenfull.js'); ?>"></script>
        <script src="<?php echo hdev_url::menu('plugins/jquery-toast-plugin/dist/jquery.toast.min.js'); ?>"></script>
        <script src="<?php echo hdev_url::menu('dist/js/theme.js'); ?>"></script>
  <script type="text/javascript">
        function attach(aa='') {
      window.reload();
    }
  function resetToastPosition() {
    $('.jq-toast-wrap').removeClass('bottom-left bottom-right top-left top-right mid-center'); // to remove previous position class
    $(".jq-toast-wrap").css({
      "top": "",
      "left": "",
      "bottom": "",
      "right": ""
    }); //to remove previous position style
  }
    function login() {
      
        var formData = jQuery('#login_form').serialize();
        $.ajax({
          type: "POST",
          url: "<?php echo hdev_url::menu('login_i');?>",
          data: formData,
          beforeSend: function(){
            // Show image container
            $("#fsave").hide();
            $(".wait").show();
           },
          success:function(html){
            if (html == 'ok'){
             resetToastPosition();
                $.toast({
                  heading: 'Success',
                  text: '<?php echo hdev_lang::on("validation",'signedin'); ?>',
                  showHideTransition: 'slide',
                  icon: 'success',
                  loaderBg: '#f96868',
                  position: 'top-right'
                })
              var delay = 1000;
              setTimeout(function(){
                 window.location.href='<?php echo hdev_url::menu("r/home");?>';
              }, delay);
            }else
            {
              //alert(html);
              resetToastPosition();
              $.toast({
                heading: 'Error',
                text: '<?php echo hdev_lang::on("validation",'log_fair'); ?>',
                showHideTransition: 'slide',
                icon: 'error',
                loaderBg: '#f2a654',
                position: 'top-right'
              })
              $(".wait").hide();
              $("#fsave").show();
            }
          },
          complete:function(html){
            // Hide image container
           setTimeout(function(){
              //$("#fsave").show();
              $(".wait").hide();
            }, 3000);
           }
        });
    } 
  </script>
</body>
</html>