<?php
if (!function_exists("hdev_vd")) {
  function hdev_vd()
  {
    //default validation
    $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'executor'.DIRECTORY_SEPARATOR.'exec_v.php';
    include $regd;
  }
}
if (!function_exists("mini_loader")) {
  function mini_loader()
  {
    //default mini navigation
    $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'loader.php';
    return $regd;
  }
}
if (!function_exists("get_menu")) {
  function get_menu()
  {
    //default mini navigation
    $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'menu.php';
    return $regd;
  }
}
if (!function_exists("get_home")) {
  function get_home()
  {
    $home = "hdev_c/home";
    if (hdev_log::loged()) {
      switch (hdev_log::fid()) {
        case 'super_admin':
          $home = "hdev_c/home_admin";
          break;
        
        default:
          $home = "hdev_c/home";
          break;
      }
    }
    return $home;
  }
}
// Include router class 
$regd = getcwd().DIRECTORY_SEPARATOR."hdev_c".DIRECTORY_SEPARATOR."executor".DIRECTORY_SEPARATOR."hdev_parse.php";
include $regd;

$valid = array('login_i','up');
foreach ($valid as $vd) {
  hdev_route::add('/'.$vd, function() {
    hdev_vd();
    exit();
  });
} 
//add login page
hdev_route::add('/login', function() {
  if (hdev_log::loged()) {
    hdev_note::redirect(hdev_url::get_url_host());exit();
  }
  include getcwd().'/hdev_c/l_header.php';
  include getcwd().'/hdev_c/re_log_auth.php';
  include getcwd().'/hdev_c/l_footer.php';
  exit();
});
//add login page
hdev_route::add('/forgot', function() {
  if (hdev_log::loged()) {
    hdev_note::redirect(hdev_url::get_url_host());exit();
  }
  include getcwd().'/hdev_c/pass_reset.php';
  exit();
});
hdev_route::add('/register', function() {
  if (hdev_log::loged()) {
    hdev_note::redirect(hdev_url::get_url_host());exit();
  }
  include getcwd().'/hdev_c/l_header.php';
  include getcwd().'/hdev_c/re_reg_auth.php';
  include getcwd().'/hdev_c/l_footer.php';
  exit();
});

hdev_route::add('/all_mn', function() {
  include get_menu();
  exit();
});
// Add base route (startpage)
hdev_route::add('/', function() {
  //  if (!hdev_log::loged()) {
  //  hdev_note::redirect(hdev_url::get_url_host()."/login");exit();
  //}else{
    hdev_menu_url::body([hdev_lang::on("menu","home"),get_home(),"/r/home"]);
  //}
});

//full home page 
hdev_route::add('', function() {
  //if (!hdev_log::loged()) {
  //  hdev_note::redirect(hdev_url::get_url_host()."/login");exit();
  //}else{
    hdev_menu_url::body([hdev_lang::on("menu","home"),get_home(),"/r/home"]);
  //}
});
//full home page 
hdev_route::add('/a/b/c', function() {
  hdev_menu_url::body([hdev_lang::on("menu","home"),get_home(),"/r/home"]); 
  include mini_loader();
  exit();
});
//full home page 
hdev_route::add('/r/home', function() {
  hdev_menu_url::body([hdev_lang::on("menu","home"),get_home(),"/r/home"]);
});

hdev_route::add('/r/home/a/b/c', function() {
  hdev_menu_url::body([hdev_lang::on("menu","home"),get_home(),"/r/home"]); 
  include mini_loader();
  exit();
});
hdev_route::add('/home/(.*)/search', function($search) { 
  hdev_session::set('search',$search);
  hdev_menu_url::body(["Search Results","hdev_c/search","/r/home"]);
});

hdev_route::add('/home/(.*)/search/a/b/c', function($search) { 
  hdev_session::set('search',$search);
  hdev_menu_url::body(["Search Results","hdev_c/search","/r/home"]);
  include mini_loader();
  exit();
});
hdev_route::add('/r/profile', function() { 
  $sc = hdev_log::fid();
  switch ($sc) {
    case 'admin':
    case 'super_admin':
    case 'manager':
      hdev_menu_url::body(["Account info","hdev_c/2_dest/profile","/r/profile"]);
      break;     
    default:
      hdev_menu_url::body(["404","error","/error"]);
      break;
  }
});
hdev_route::add('/r/profile/a/b/c', function() { 
  $sc = hdev_log::fid();
  switch ($sc) {
    case 'admin':
    case 'super_admin':
    case 'manager':
      hdev_menu_url::body(["Account info","hdev_c/2_dest/profile","/r/profile"]);
      break; 
    default:
      hdev_menu_url::body(["404","error","/error"]);
      break;
  }
  include mini_loader();
  exit();
});
hdev_route::add('/s.js', function() {
  if (hdev_log::loged()) {
    //include 'executor/main_app_js.php';
    include 'executor/main_app_js_2.php';
  }
  hdev_log::close();
});

hdev_route::add('/gen.js', function() {
  if (hdev_log::loged()) {
    include 'executor/main_app_js.php';
  }
  hdev_log::close();
});

hdev_route::add('/script-1', function() {
    include 'hdev_c/main_app_js.php';
    exit;
});
hdev_route::add('/app/setting/(.*)/(.*)', function($auth,$data) {
  $csrf = new CSRF_Protect();
  $csrf->verifyRequest($auth);
  $data = hdev_data::decd($data);
  $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'executor'.DIRECTORY_SEPARATOR.'setting.php';
  include $regd;
  //$csrf->up_tk();
  hdev_log::close();
});
hdev_route::add('/app/report/(.*)/(.*)', function($auth,$data) {
  $csrf = new CSRF_Protect();
  $csrf->verifyRequest($auth);
  //$data = hdev_data::decd($data);
   $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'executor'.DIRECTORY_SEPARATOR.'TCPDF-main'.DIRECTORY_SEPARATOR.'config'.DIRECTORY_SEPARATOR.'tcpdf_config.php';
  include $regd;
  $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'executor'.DIRECTORY_SEPARATOR.'TCPDF-main'.DIRECTORY_SEPARATOR.'tcpdf.php';
  include $regd;   

  hdev_session::set('date',$data);

  $date = urldecode(hdev_session::get("date"));
  $chop = json_decode($date);
  $start = date('Y-m-d');
  $end = date('Y-m-d');
  if (isset($chop->from) && isset($chop->to) && !empty($chop->from) && !empty($chop->to)) {
    if ($chop->to > $chop->from) {
      $start = date_format(date_create($chop->from),"Y-m-d");
      $end = date_format(date_create($chop->to),"Y-m-d");
    }
  }
  hdev_session::set('start',$start);
  hdev_session::set('end',$end);
  
  $regd = getcwd().DIRECTORY_SEPARATOR.'hdev_c'.DIRECTORY_SEPARATOR.'report'.DIRECTORY_SEPARATOR.'sales_report.php';
  include $regd;
  exit();
  //$csrf->up_tk();
  hdev_log::close();
});
hdev_route::add('/auth/gen/(.*)', function($er_rasms_qqrrccdd) {
  if (hdev_log::loged()) {
    include 'executor/cds.php';
  }
  hdev_log::close();
});
hdev_route::add('/all/product', function() { 
  hdev_menu_url::body([hdev_lang::on("menu","product_info"),"hdev_c/dest/products_reg","/all/product"]);
});

hdev_route::add('/all/product/a/b/c', function() { 
  hdev_menu_url::body([hdev_lang::on("menu","product_info"),"hdev_c/dest/products_reg","/all/product"]);
  include mini_loader();
  exit();
});
hdev_route::add('/trash/product', function() { 
  hdev_menu_url::body([hdev_lang::on("menu","deleted_product"),"hdev_c/dest/products_trash","/trash/product"]);
});

hdev_route::add('/trash/product/a/b/c', function() { 
  hdev_menu_url::body([hdev_lang::on("menu","deleted_product"),"hdev_c/dest/products_trash","/trash/product"]);
  include mini_loader();
  exit();
});
hdev_route::add('/all/room', function() { 
  hdev_menu_url::body(["Rooms Info","hdev_c/dest/rooms_reg","/all/room"]);
});

hdev_route::add('/all/room/a/b/c', function() { 
  hdev_menu_url::body(["Rooms Info","hdev_c/dest/rooms_reg","/all/room"]);
  include mini_loader();
  exit();
});
hdev_route::add('/trash/room', function() { 
  hdev_menu_url::body(["Deleted Rooms","hdev_c/dest/rooms_trash","/trash/room"]);
});

hdev_route::add('/trash/room/a/b/c', function() { 
  hdev_menu_url::body(["Deleted Rooms","hdev_c/dest/rooms_trash","/trash/room"]);
  include mini_loader();
  exit();
});
hdev_route::add('/all/tool', function() { 
  hdev_menu_url::body(["Equipments info","hdev_c/dest/tool_reg","/all/tool"]);
});

hdev_route::add('/all/tool/a/b/c', function() { 
  hdev_menu_url::body(["Equipments info","hdev_c/dest/tool_reg","/all/tool"]);
  include mini_loader();
  exit();
});
hdev_route::add('/trash/tool', function() { 
  hdev_menu_url::body(["Deleted Equipments","hdev_c/dest/tool_trash","/trash/tool"]);
});

hdev_route::add('/trash/tool/a/b/c', function() { 
  hdev_menu_url::body(["Deleted Equipments","hdev_c/dest/tool_trash","/trash/tool"]);
  include mini_loader();
  exit();
});
hdev_route::add('/all/category', function() { 
  hdev_menu_url::body(["Categories Info","hdev_c/dest/cat_reg","/all/category"]);
});

hdev_route::add('/all/category/a/b/c', function() { 
  hdev_menu_url::body(["Categories Info","hdev_c/dest/cat_reg","/all/category"]);
  include mini_loader();
  exit();
});
hdev_route::add('/trash/category', function() { 
  hdev_menu_url::body(["Deleted Categories","hdev_c/dest/cat_trash","/trash/category"]);
});

hdev_route::add('/trash/category/a/b/c', function() { 
  hdev_menu_url::body(["Deleted Categories","hdev_c/dest/cat_trash","/trash/category"]);
  include mini_loader();
  exit();
});

hdev_route::add('/all/brand', function() { 
  hdev_menu_url::body(["Brands Info","hdev_c/dest/brand_reg","/all/brand"]);
});

hdev_route::add('/all/brand/a/b/c', function() { 
  hdev_menu_url::body(["Brands Info","hdev_c/dest/brand_reg","/all/brand"]);
  include mini_loader();
  exit();
});
hdev_route::add('/trash/brand', function() { 
  hdev_menu_url::body(["Deleted Brands","hdev_c/dest/brand_trash","/trash/brand"]);
});

hdev_route::add('/trash/brand/a/b/c', function() { 
  hdev_menu_url::body(["Deleted Brands","hdev_c/dest/brand_trash","/trash/brand"]);
  include mini_loader();
  exit();
});
hdev_route::add('/product/cart', function() { 
  hdev_menu_url::body(["Items in cart","hdev_c/dest/cart","/product/cart"]);
});

hdev_route::add('/product/cart/a/b/c', function() { 
  hdev_menu_url::body(["Items in cart","hdev_c/dest/cart","/product/cart"]);
  include mini_loader();
  exit();
});

hdev_route::add('/order/(.*)/receipt', function($receipt) { 
  hdev_session::set('order',$receipt);
  hdev_menu_url::body(["Order [order id : ".$receipt. "] Receipt","hdev_c/dest/receipt","/gen/report"]);
});

hdev_route::add('/order/(.*)/receipt/a/b/c', function($receipt) { 
  hdev_session::set('order',$receipt);
  hdev_menu_url::body(["Order [order id : ".$receipt. "] Receipt","hdev_c/dest/receipt","/gen/report"]);
  include mini_loader();
  exit();
});

hdev_route::add('/gen/report', function() { 
  hdev_menu_url::body(["Summarised report","hdev_c/dest/gen_report","/gen/report"]);
});

hdev_route::add('/gen/report/a/b/c', function() { 
  hdev_menu_url::body(["Summarised report","hdev_c/dest/gen_report","/gen/report"]);
  include mini_loader();
  exit();
});
hdev_route::add('/gen/report/(.*)/date', function($date) { 
  hdev_session::set('date',$date);
  hdev_menu_url::body(["Summarised Report","hdev_c/dest/gen_report","/gen/report"]);
});

hdev_route::add('/gen/report/(.*)/date/a/b/c', function($date) { 
  hdev_session::set('date',$date);
  hdev_menu_url::body(["Summarised Report","hdev_c/dest/gen_report","/gen/report"]);
  include mini_loader();
  exit();
});
hdev_route::add('/product/report', function() { 
  hdev_menu_url::body(["Products report","hdev_c/dest/product_report","/product/report"]);
});

hdev_route::add('/product/report/a/b/c', function() { 
  hdev_menu_url::body(["Products report","hdev_c/dest/product_report","/product/report"]);
  include mini_loader();
  exit();
});
hdev_route::add('/product/report/(.*)/date', function($date) { 
  hdev_session::set('date',$date);
  hdev_menu_url::body(["Products Report","hdev_c/dest/product_report","/product/report"]);
});

hdev_route::add('/product/report/(.*)/date/a/b/c', function($date) { 
  hdev_session::set('date',$date);
  hdev_menu_url::body(["Products Report","hdev_c/dest/product_report","/product/report"]);
  include mini_loader();
  exit();
});

hdev_route::add('/room/report', function() { 
  hdev_menu_url::body(["Rooms report","hdev_c/dest/room_report","/room/report"]);
});

hdev_route::add('/room/report/a/b/c', function() { 
  hdev_menu_url::body(["Rooms report","hdev_c/dest/room_report","/room/report"]);
  include mini_loader();
  exit();
});
hdev_route::add('/room/report/(.*)/date', function($date) { 
  hdev_session::set('date',$date);
  hdev_menu_url::body(["Rooms Report","hdev_c/dest/room_report","/room/report"]);
});

hdev_route::add('/room/report/(.*)/date/a/b/c', function($date) { 
  hdev_session::set('date',$date);
  hdev_menu_url::body(["Rooms Report","hdev_c/dest/room_report","/room/report"]);
  include mini_loader();
  exit();
});





/*-----------stock system------------*/

hdev_route::add('/stock/in', function() { 
  hdev_menu_url::body(["Stock In Registration","hdev_c/2_dest/stock_in","/stock/in"]);
});

hdev_route::add('/stock/in/a/b/c', function() { 
  hdev_menu_url::body(["Stock In Registration","hdev_c/2_dest/stock_in","/stock/in"]);
  include mini_loader();
  exit();
});
hdev_route::add('/trash/stock_in', function() { 
  hdev_menu_url::body(["Deleted stock in records","hdev_c/2_dest/stock_in_trash","/trash/stock_in"]);
});



hdev_route::add('/trash/stock_in/a/b/c', function() { 
  hdev_menu_url::body(["Deleted stock in records","hdev_c/2_dest/stock_in_trash","/trash/stock_in"]);
  include mini_loader();
  exit();
});

hdev_route::add('/stock/out', function() { 
  hdev_menu_url::body(["Stock Out Registration","hdev_c/2_dest/stock_out","/stock/out"]);
});

hdev_route::add('/stock/out/a/b/c', function() { 
  hdev_menu_url::body(["Stock out Registration","hdev_c/2_dest/stock_out","/stock/out"]);
  include mini_loader();
  exit();
});
hdev_route::add('/trash/stock_out', function() { 
  hdev_menu_url::body(["Deleted Stock out records","hdev_c/2_dest/stock_out_trash","/trash/stock_out"]);
});



hdev_route::add('/trash/stock_out/a/b/c', function() { 
  hdev_menu_url::body(["Deleted Stock out records","hdev_c/2_dest/stock_out_trash","/trash/stock_out"]);
  include mini_loader();
  exit();
});

hdev_route::add('/status/in_stock', function() { 
  hdev_menu_url::body(["Products In Stock status","hdev_c/2_dest/in_stock","/status/in_stock"]);
});



hdev_route::add('/status/in_stock/a/b/c', function() { 
  hdev_menu_url::body(["Products In Stock status","hdev_c/2_dest/in_stock","/status/in_stock"]);
  include mini_loader();
  exit();
});
hdev_route::add('/sales/report', function() { 
  hdev_menu_url::body(["Sales Report","hdev_c/2_dest/sales_report","/sales/report"]);
});



hdev_route::add('/sales/report/a/b/c', function() { 
  hdev_menu_url::body(["Sales Report","hdev_c/2_dest/sales_report","/sales/report"]);
  include mini_loader();
  exit();
});

hdev_route::add('/sales/report/(.*)/date', function($date) { 
  hdev_session::set('date',$date);
  hdev_menu_url::body(["Sales Report","hdev_c/2_dest/sales_report","/sales/report"]);
});

hdev_route::add('/sales/report/(.*)/date/a/b/c', function($date) { 
  hdev_session::set('date',$date);
  hdev_menu_url::body(["Sales Report","hdev_c/2_dest/sales_report","/sales/report"]);
  include mini_loader();
  exit();
});

hdev_route::add('/warn/exp', function() { 
  hdev_menu_url::body(["Products going to be expired","hdev_c/2_dest/expire_warning","/warn/exp"]);
});
hdev_route::add('/warn/exp/a/b/c', function() { 
  hdev_menu_url::body(["Products going to be expired","hdev_c/2_dest/expire_warning","/warn/exp"]);
  include mini_loader();
  exit();
});

hdev_route::add('/exp/products', function() { 
  hdev_menu_url::body(["Expired Products","hdev_c/2_dest/expired_products","/exp/products"]);
});
hdev_route::add('/exp/products/a/b/c', function() { 
  hdev_menu_url::body(["Expired Products","hdev_c/2_dest/expired_products","/exp/products"]);
  include mini_loader();
  exit();
});

hdev_route::add('/warn/out', function() { 
  hdev_menu_url::body(["Products going to be out of stock","hdev_c/2_dest/out_warning","/warn/out"]);
});
hdev_route::add('/warn/out/a/b/c', function() { 
  hdev_menu_url::body(["Products going to be out of stock","hdev_c/2_dest/out_warning","/warn/out"]);
  include mini_loader();
  exit();
});

hdev_route::add('/out/products', function() { 
  hdev_menu_url::body(["Out of stock Products","hdev_c/2_dest/out_products","/out/products"]);
});
hdev_route::add('/out/products/a/b/c', function() { 
  hdev_menu_url::body(["Out of stock Products","hdev_c/2_dest/out_products","/out/products"]);
  include mini_loader();
  exit();
});
///********************************backups****************************


// Add a 404 not found route
hdev_route::pathNotFound(function($path) { 
  // Do not forget to send a status header back to the client
  // The router will not send any headers by default
  // So you will have the full flexibility to handle this case
  header('HTTP/1.0 404 Not Allowed');
  hdev_menu_url::body(["error","hdev_c/error","/error"]);
});
 
// Add a 405 method not allowed route
hdev_route::methodNotAllowed(function($path, $method) {
  // Do not forget to send a status header back to the client
  // The router will not send any headers by default
  // So you will have the full flexibility to handle this case
  header('HTTP/1.0 405 Method Not Allowed');
  echo 'Error 405 :-(<br>';
  echo 'The requested path "'.$path.'" exists. But the request method "'.$method.'" is not allowed on this path!';
});

// Run the Router with the given Basepath
// If your script lives in the web root folder use a / or leave it empty
//hdev_route::unset_r(2);// remove a route

//var_export(hdev_route::all_req());exit;// all requests
/*$tg = array();
$reqs = hdev_route::all_req();
foreach ($reqs as $key => $value) {
  $tg[$value['expression']] = ['name'=>'','func'=>''];
} 
var_export($tg);
exit();*/
hdev_route::access('/');
//hdev_route::run('/'); 
//hdev_route::access('/', false, false, false, "http://o.rasms/r/profile_info");
//exit(hdev_route::get_active2());

//var_export(parse_url(hdev_url::menu(ltrim($_SERVER['REQUEST_URI'],'/'))));exit;
//echo hdev_route::get_active();
$rasms_stc = new hdev_url_service('',trim(hdev_route::get_active()));
//echo hdev_route::get_active();
//echo hdev_route::get_active2();exit();
//var_dump(hdev_route::get_active());
//var_dump($rasms_stc->error('alert'));exit();
//var_dump($rasms_stc->access());exit();
if ($rasms_stc->access()) {
  /// access granted
  //echo "granted";
  $rt = new hdev_db("default"); 
  if ($rt->connection_check()) {
    //var_dump($rt->connection_check());exit;
  }else {
    echo "<div style='width: 50%;margin-left:15%;margin-top:5%;'><fieldset>RASMS DATA STORE CHECKER<hr>Re-start the application to get this fixed <br> Or click <a href='".hdev_url::menu("")."'>Here</a><hr>&copy".date("Y")."- IZERE HIRWA ROGER - ".APP_NAME."<hr></fieldset><div>";
    echo '<meta content="2; '.hdev_url::menu("").'" http-equiv="refresh" />'; exit();
  }
    hdev_route::run('/'); 
}else{
  hdev_route::access('/', false, false, false, hdev_url::get_url_full());
  $tt = hdev_route::get_active2();
  if ($tt != "error") {
    hdev_note::message("access denied to request this page");
    $rasms_access_error = $rasms_stc->error('alert');
    hdev_menu_url::body(["Access denied !","error","/error"]);
  }else{
    hdev_menu_url::body(["404","error","/error"]);
  }
  
  ///call custom user func
}
//foreach (hdev_route::all_req() as $url) {
  //echo "\t'".$url['expression']."' => array ("."\n"."\t\t'name' => 'access to view [".$url['expression']."]',\n\t\t'error' => 'You can not access this page',\n\t\t),\n";
  //echo "\t\t\t'".$url['expression']."',\n";
//}exit();


// If your script lives in a subfolder you can use the following example
// Do not forget to edit the basepath in .htaccess if you are on apache
// hdev_route::run('/api/v1');

// Enable case sensitive mode, trailing slashes and multi match mode by setting the params to true
// hdev_route::run('/', true, true, true);

//authenticate bro
if (!hdev_log::loged()) {
  //hdev_note::message("You must Log in first To access Rasms system");
  //hdev_note::redirect(hdev_url::get_url_host()."/login");
}





////

//$js_controller="og";

?>