<?php 
  $group = hdev_data::groups(trim(hdev_session::get('stock')),['data']);
  $stock_status = array();
  if (is_array($group) && isset($group['g_id'])) {
    $stock_status = hdev_data::in_stock('',['external']);
?>
    <div class="pd-ltr-20">
      <div class="card-box pd-20 height-100-p mb-30">
        <div class="row align-items-center">
          <div class="col-md-4">
            <img src="<?php echo hdev_url::menu('icon/on.png'); ?>" alt="">
          </div>
          <div class="col-md-8">
            <h4 class="font-20 weight-500 mb-10 text-capitalize">
              Welcome To : <div class="weight-600 font-30 text-blue"><?php echo $group['g_name'] ?> stock</div>
            </h4>
            <table class="table border-bottom">
              <tr class="bg-secondary text-white">
                <th>Stock Reg. No</th>
                <td>: <?php echo $group['g_id']; ?></td>
              </tr>
              <tr>
                <th>Tell</th>
                <td>: <?php echo $group['tell']; ?></td>
              </tr>
              <tr>
                <th>Email</th>
                <td>: <?php echo $group['email']; ?></td>
              </tr>              
              <tr>
                <th>Location</th>
                <td>: <?php echo $group['g_location']; ?></td>
              </tr>
            </table>
          </div>
        </div>
      </div>
<?php
  }else{
?>
        <div class="page-header">
          <div class="row">
            <div class="col-md-12 col-sm-12 text-red" align="center">
              <div class="title">
                <h4 style="color: red !important;">This stock does not exist on our system</h4>
              </div>
            </div>
          </div>
        </div>
<?php
  }
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Products in This stock</h5>
              </div>
              <div class="card-body table-responsive p-2">
                  <table class="data-table table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort">Reg. no</th>
                      <th>Product</th>
                      <th>Description</th> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php foreach ($stock_status AS $stock) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $product = hdev_data::products($stock['p_id'],['data']);
                    ?>
                    <tr>
                      <td class="table-plus">
                        <?php echo $stock["p_id"]; ?>
                      </td>
                      <td>
                        <?php echo $product['p_name']; ?>
                      </td>
                      <td>
                        <?php echo $product['p_desc']; ?>
                      </td>                  
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>