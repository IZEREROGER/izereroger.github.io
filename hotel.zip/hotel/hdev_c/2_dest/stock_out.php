<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Stock Out registration</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">
                  <?php if (hdev_data::service('products_reg')): ?>
                  <button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fa fa-plus-circle"></i> Add new Stock Out record</button>&nbsp;
                  <?php endif ?>
                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table data-order='[[ 1, "desc" ]]' class="data-table table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort">Reg. no</th>
                      <th>Reg Date</th>
                      <th>Product</th>
                      <th>Selling Price per Unit</th>
                      <th>Quantity</th>
                      <th>Total Selling Price </th>
                      <th>Received By worker</th>
                      <?php if (hdev_data::service('products_delete') || hdev_data::service('products_edit')): ?>
                      <th><?php echo hdev_lang::on("form","action"); ?></th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::stock_out();
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $stock) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:stock_out_delete;id:".$stock['sout_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#prod_del_close;app:".$tkn.";".$build2);
                    ?>
                    <tr>
                      <td class="table-plus">
                        <?php echo $stock["sout_id"]; ?>
                      </td>
                      <td>
                        <?php echo $stock["sout_reg_date"]; ?>
                      </td>
                      <td>
                        <?php echo hdev_data::products(hdev_data::stock_in($stock['sin_id'],['data'])["p_id"],['data'])['p_name']; ?>
                      </td>
                      <td>
                        <?php echo $stock["sout_unit_price"]; ?>
                      </td>
                      <td>
                        <?php echo $stock["sout_qty"]; ?>
                      </td>
                      <td>
                        <?php echo $stock["sout_unit_price"]*$stock["sout_qty"]; ?>
                      </td>
                      <td>
                        <?php echo $stock["customer"]; ?>
                      </td>                                              
                      <?php if (hdev_data::service('products_delete') || hdev_data::service('products_edit')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('products_delete')): ?>
                          <button type="button" hash="<?php echo $tkn; ?>" sin_id_delete="<?php echo $stock['sout_id'] ?>" data="<?php echo $reject; ?>" rel="external" class="btn btn-danger stock_in_delete_btn"data-toggle="modal" data-target=".modal-delete"><i class="fa fa-trash"></i> <?php echo hdev_lang::on("form","delete"); ?> </button>
                           <?php endif ?>
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('stock_in')): ?>
<div class="modal fade modal-reg">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">add new stock Out record</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" id="stock_out">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
                $tkn = $csrf->getToken();
              ?>
              <input type="hidden" name="ref" value="stock_out"> 
            <div class="form-group">
              <label for="p_id">Select Product : </label>
              <select class="custom-select2 form-control" name="p_id" id="p_id" onchange="init_stock_in('reset');stock_in($(this).val(),'<?php echo $tkn ?>','sin_id','sin_ico');">
                <option value="">--Select Product--</option>
                <?php 
                  $prod = hdev_data::products();
                  foreach ($prod as $products) {
                ?>
                  <option value="<?php echo $products['p_id'] ?>"><?php echo $products['p_name'] ?></option>
                <?php
                  }
                 ?>
              </select>
            </div>
            <div class="form-group">
              <label for="sin_id">Select Stock in : </label>
              <div class="input-group">
              <select class="custom-select2 form-control" name="sin_id" id="sin_id" onchange="init_stock_in('set',$(this).val());">
                <option value="">- Select Stock in -</option>
              </select>
                <div class="input-group-append custom" id="sin_ico">
                  <span class="input-group-text"></span>
                </div>
                
              </div>
            </div>        
            <div class="form-group">
              <label for="p_unit">
                Buying Price per Unit :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="p_unit" id="p_unit" class="form-control" placeholder="Buying Price per Unit" required="true" readonly>
              </div>
            </div>  
            <div class="form-group">
              <label for="selling_price">
                Selling Price per Unit :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="selling_price" id="selling_price" class="form-control" placeholder="Selling Price per Unit" required="true" readonly>
              </div>
            </div>             
            <div class="form-group">
              <label for="qty">
                Quantity :
              </label>
              <div class="input-group mb-0">
                <input type="text" name="qty" id="qty" class="form-control" placeholder="Quantity" required="true" oninput="total_calculator('selling_price','qty','total_selling_price');">
              </div>
            </div> 
            <div class="form-group">
              <label for="total_selling_price">
                Total Selling Price :
              </label>
              <div class="input-group mb-0">
                <input type="text" id="total_selling_price" class="form-control" placeholder="Total Selling Price" required="true" readonly>
              </div>
            </div>  
            <div class="form-group">
              <label for="customer">
                Received By worker :
              </label>
              <div class="input-group mb-0">
                <input name="customer" id="customer" class="form-control" placeholder="Worker" type="text">
              </div>
            </div>                                                    
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="stock_out_btn" onclick="fm_submit('stock_out_btn','stock_out');"><i class="fa fa-save"></i> Save Stock Out Record</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>

<?php if (hdev_data::service('stock_in_delete')): ?> 
<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Recover The Following Stock Out record?</th>
                </tr>
                <tr>
                  <td>Stock Out id : </td>
                  <td id="sin_id_delete"></td>
                </tr>
                <tr>
                  <td colspan="2">Once you delete the stock out record you will not be able to recover it.</td>
                </tr>               
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="sk_del_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="stock_in_delete" data="" hash=""><i class="fa fa-times-circle"></i> Delete This Stock Out Record</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<script type="text/javascript">
  function init_stock_in(type='set',vall='') {
    if (vall == '' || type=="reset") {
      $('#selling_price').val('');
      $('#p_unit').val('');
      $('#qty').val('');
      $('#total_selling_price').val('');
    }else{
      var selling_price = $("#sin_id option[value='"+vall+"']").attr('selling_price');
      var p_unit = $("#sin_id option[value='"+vall+"']").attr('p_unit');
      $('#selling_price').val(selling_price)
      $('#p_unit').val(p_unit);
      $('#qty').val('');
      $('#total_selling_price').val('');
    }
  }
</script>