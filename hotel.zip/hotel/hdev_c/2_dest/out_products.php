<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Out of stock Products</h5>
              </div>
              <div class="card-body table-responsive p-2">
                  <table class="data-table table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort">Product ID</th>
                      <th>Product</th>
                      <th>Remaining Quantity</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::warning('',['out_products']);
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $stock) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      //$product = hdev_data::products($stock['p_id'],['data']);
                    ?>
                    <tr>
                      <td class="table-plus">
                        <?php echo $stock["p_id"]; ?>
                      </td>
                      <td>
                        <?php echo $stock['p_name']; ?>
                      </td>
                      <td>
                        <?php echo $stock['qty_balance'].' '.$stock['p_unit']; ?>
                      </td>                            
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>