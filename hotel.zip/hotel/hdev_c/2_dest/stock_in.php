<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Stock in registration</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">
                  <?php if (hdev_data::service('products_reg')): ?>
                  <button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fa fa-plus-circle"></i> Add new Stock in record</button>&nbsp;
                  <?php endif ?>
                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="data-table table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort">Reg. no</th>
                      <th>Reg Date</th>
                      <th>Product</th>
                      <th>Buying Price per Unit</th>
                      <th>Quantity</th>
                      <th>Total Buying Price</th>
                      <th>Selling Price per Unit</th>
                      <th>Total Selling Price </th>
                      <th>Supplier</th>
                      <th>Mfg Date</th>
                      <th>Exp Date</th>
                      <?php if (hdev_data::service('products_delete') || hdev_data::service('products_edit')): ?>
                      <th><?php echo hdev_lang::on("form","action"); ?></th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::stock_in();
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $stock) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:stock_in_delete;id:".$stock['sin_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#sk_del_close;app:".$tkn.";".$build2);
                      $p_name = hdev_data::products($stock["p_id"],['data'])['p_name'];
                    ?>

                    <tr>
                      <td class="table-plus">
                        <?php echo $stock["sin_id"]; ?>
                      </td>
                      <td>
                        <?php echo $stock["sin_reg_date"]; ?>
                      </td>
                      <td>
                        <?php echo $p_name; ?>
                      </td>
                      <td>
                        <?php echo $stock["price_unit"]; ?>
                      </td>
                      <td>
                        <?php echo $stock["sin_qty"]; ?>
                      </td>
                      <td>
                        <?php echo $stock["price_unit"]*$stock["sin_qty"]; ?>
                      </td>
                      <td>
                        <?php echo $stock["sell_price_unit"]; ?>
                      </td>     
                      <td>
                        <?php echo $stock["sell_price_unit"]*$stock["sin_qty"]; ?>
                      </td>      
                      <td>
                        <?php echo $stock["supplier"]; ?>
                      </td>           
                      <td>
                        <?php echo $stock["product_mfg_date"]; ?>
                      </td> 
                      <td>
                        <?php echo $stock["product_exp_date"]; ?>
                      </td>                                                                                            
                      <?php if (hdev_data::service('products_delete') || hdev_data::service('products_edit')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                           <?php if (hdev_data::service('products_edit')): ?>
                          <button type="button" rel="external" class="btn btn-success sin_edit" data-toggle="modal" sin_id_edit="<?php echo $stock['sin_id']; ?>" p_name_edit="<?php echo $p_name; ?>" p_unit_edit="<?php echo $stock['price_unit']; ?>" qty_edit="<?php echo $stock['sin_qty']; ?>" total_buying_price_edit="<?php echo $stock["price_unit"]*$stock["sin_qty"]; ?>" sell_p_u_edit="<?php echo $stock["sell_price_unit"]; ?>" total_selling_edit="<?php echo $stock["sell_price_unit"]*$stock["sin_qty"]; ?>" profit_expected_edit="<?php echo ($stock["sell_price_unit"]*$stock["sin_qty"])-($stock["price_unit"]*$stock["sin_qty"]); ?>" mfg_date_edit="<?php echo $stock["product_mfg_date"]; ?>" exp_date_edit="<?php echo $stock["product_exp_date"]; ?>" supplier_edit="<?php echo $stock["supplier"]; ?>" data-target=".modal-edit"><i class="fa fa-edit"></i> <?php echo hdev_lang::on("form","edit"); ?> </button>
                           <?php endif ?>
                          <?php if (hdev_data::service('products_delete')): ?>
                          <button type="button" hash="<?php echo $tkn; ?>" data="<?php echo $reject; ?>" rel="external" class="btn btn-danger stock_in_delete_btn" sin_id_delete="<?php echo $stock['sin_id']; ?>" data-toggle="modal" data-target=".modal-delete"><i class="fa fa-trash"></i> <?php echo hdev_lang::on("form","delete"); ?> </button>
                           <?php endif ?>
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('stock_in_delete')): ?> 
<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Delete The Following Stock in record?</th>
                </tr>
                <tr>
                  <td>Stock in id : </td>
                  <td id="sin_id_delete"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="sk_del_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="stock_in_delete" data="" hash=""><i class="fa fa-times-circle"></i> Delete This Stock in Record</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('stock_in')): ?>
<div class="modal fade modal-reg">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">ADD new stock in record</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" id="stock_in">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="stock_in"> 
            <div class="form-group">
              <label for="p_id">Select Product : </label>
              <select class="custom-select2 form-control" name="p_id" id="p_id" style="width: 100%; height: 38px;">
                <option value="">--Select Product--</option>
                <?php 
                  $prod = hdev_data::products();
                  foreach ($prod as $products) {
                ?>
                  <option value="<?php echo $products['p_id'] ?>"><?php echo $products['p_name'] ?></option>
                <?php
                  }
                 ?>
              </select>
            </div>
            <div class="form-group">
              <label for="p_unit">
                Buying Price per Unit :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="p_unit" id="p_unit" class="form-control" placeholder="Buying Price per Unit" required="true" oninput="total_calculator('p_unit','qty','total_buying_price');total_calculator('total_selling','total_buying_price','profit_expected','-');">
              </div>
            </div>            
            <div class="form-group">
              <label for="qty">
                Quantity :
              </label>
              <div class="input-group mb-0">
                <input type="text" name="qty" id="qty" class="form-control" placeholder="Quantity" required="true" oninput="total_calculator('p_unit','qty','total_buying_price');total_calculator('sell_p_u','qty','total_selling');total_calculator('total_selling','total_buying_price','profit_expected','-');">
              </div>
            </div> 
            <div class="form-group">
              <label for="total_buying_price">
                Total Buying Price :
              </label>
              <div class="input-group mb-0">
                <input type="text" id="total_buying_price" class="form-control" placeholder="Total Buying Price" required="true" readonly>
              </div>
            </div>  
            <div class="form-group">
              <label for="sell_p_u">
                Selling Price per Unit :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="sell_p_u" id="sell_p_u" class="form-control" placeholder="Selling Price per Unit" required="true" oninput="total_calculator('sell_p_u','qty','total_selling');total_calculator('total_selling','total_buying_price','profit_expected','-');">
              </div>
            </div> 
            <div class="form-group">
              <label for="total_selling">
                Total Selling Price :
              </label>
              <div class="input-group mb-0">
                <input type="text" id="total_selling" class="form-control" placeholder="Total Selling Price" required="true" readonly>
              </div>
            </div>
            <div class="form-group">
              <label for="profit_expected">
                Total Profit Expected :
              </label>
              <div class="input-group mb-0">
                <input type="text" id="profit_expected" class="form-control" placeholder="Total Profit Expected" required="true" readonly oninput="">
              </div>
            </div>   
            <div class="form-group">
              <label for="mfg_date">
                Manufacturing date(Mfg date) :
              </label>
              <div class="input-group mb-0">
                <input name="mfg_date" id="mfg_date" class="form-control" placeholder="DD MM YY" type="date">
              </div>
            </div>  
            <div class="form-group">
              <label for="exp_date">
                Expiration date(Exp date) :
              </label>
              <div class="input-group mb-0">
                <input name="exp_date" id="exp_date" class="form-control" placeholder="DD MM YY" type="date">
              </div>
            </div>
            <div class="form-group">
              <label for="supplier">
                Supplier :
              </label>
              <div class="input-group mb-0">
                <input type="text" name="supplier" id="supplier" class="form-control" placeholder="Supplier" required="true">
              </div>
            </div>                                                                       
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="stock_in_btn" onclick="fm_submit('stock_in_btn','stock_in');"><i class="fa fa-save"></i> Save Stock in Record</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>

<?php if (hdev_data::service('stock_in')): ?>
<div class="modal fade modal-edit">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit stock in record</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" id="stock_edit_in">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="sin_id" id="sin_id_edit" value="">
              <input type="hidden" name="ref" value="stock_in_edit"> 
            <div class="form-group">
              <label for="p_name_edit">Product : </label>
              <b class="form-control" id="p_name_edit"></b>
            </div>
            <div class="form-group">
              <label for="p_unit_edit">
                Buying Price per Unit :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="p_unit" id="p_unit_edit" class="form-control" placeholder="Buying Price per Unit" required="true" oninput="total_calculator('p_unit_edit','qty_edit','total_buying_price_edit');total_calculator('total_selling_edit','total_buying_price_edit','profit_expected_edit','-');">
              </div>
            </div>            
            <div class="form-group">
              <label for="qty_edit">
                Quantity :
              </label>
              <div class="input-group mb-0">
                <input type="text" name="qty" id="qty_edit" class="form-control" placeholder="Quantity" required="true" oninput="total_calculator('p_unit_edit','qty_edit','total_buying_price_edit');total_calculator('sell_p_u_edit','qty_edit','total_selling_edit');total_calculator('total_selling_edit','total_buying_price_edit','profit_expected_edit','-');">
              </div>
            </div> 
            <div class="form-group">
              <label for="total_buying_price_edit">
                Total Buying Price :
              </label>
              <div class="input-group mb-0">
                <input type="text" id="total_buying_price_edit" class="form-control" placeholder="Total Buying Price" required="true" readonly>
              </div>
            </div>  
            <div class="form-group">
              <label for="sell_p_u_edit">
                Selling Price per Unit :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="sell_p_u" id="sell_p_u_edit" class="form-control" placeholder="Selling Price per Unit" required="true" oninput="total_calculator('sell_p_u_edit','qty_edit','total_selling_edit');total_calculator('total_selling_edit','total_buying_price_edit','profit_expected_edit','-');">
              </div>
            </div> 
            <div class="form-group">
              <label for="total_selling_edit">
                Total Selling Price :
              </label>
              <div class="input-group mb-0">
                <input type="text" id="total_selling_edit" class="form-control" placeholder="Total Selling Price" required="true" readonly>
              </div>
            </div>
            <div class="form-group">
              <label for="profit_expected_edit">
                Total Profit Expected :
              </label>
              <div class="input-group mb-0">
                <input type="text" id="profit_expected_edit" class="form-control" placeholder="Total Profit Expected" required="true" readonly oninput="">
              </div>
            </div>   
            <div class="form-group">
              <label for="mfg_date_edit">
                Manufacturing date(Mfg date) :
              </label>
              <div class="input-group mb-0">
                <input name="mfg_date" id="mfg_date_edit" class="form-control" placeholder="DD MM YY" type="date">
              </div>
            </div>  
            <div class="form-group">
              <label for="exp_date_edit">
                Expiration date(Exp date) :
              </label>
              <div class="input-group mb-0">
                <input name="exp_date" id="exp_date_edit" class="form-control" placeholder="DD MM YY" type="date">
              </div>
            </div>
            <div class="form-group">
              <label for="supplier_edit">
                Supplier :
              </label>
              <div class="input-group mb-0">
                <input type="text" name="supplier" id="supplier_edit" class="form-control" placeholder="Supplier" required="true">
              </div>
            </div>                                                                       
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="stock_in_edit_btn" onclick="fm_submit('stock_in_edit_btn','stock_edit_in');"><i class="fa fa-save"></i> Save Stock in Record</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php endif ?>