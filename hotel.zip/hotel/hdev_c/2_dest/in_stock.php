<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Products in stock status</h5>
              </div>
              <div class="card-body table-responsive p-2">
                  <table class="data-table table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort">Reg. no</th>
                      <th>Product</th>
                      <th>Quantity</th>
                      <?php if (hdev_data::service('scv')): ?>
                      <th><?php echo hdev_lang::on("form","action"); ?></th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::in_stock();
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $stock) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $product = hdev_data::products($stock['p_id'],['data']);
                    ?>
                    <tr>
                      <td class="table-plus">
                        <?php echo $stock["p_id"]; ?>
                      </td>
                      <td>
                        <?php echo $product['p_name']; ?>
                      </td>
                      <td>
                        <?php echo $stock['qty'].' '.$product['p_unit']; ?>
                      </td>                                             
                      <?php if (hdev_data::service('scv')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                           <?php if (hdev_data::service('products_edit')): ?>
                          <button type="button" rel="external" class="btn btn-success prod_edit" data-toggle="modal" data-target=".modal-edit"><i class="fa fa-edit"></i> <?php echo hdev_lang::on("form","edit"); ?> </button>
                           <?php endif ?>
                          <?php if (hdev_data::service('products_delete')): ?>
                          <button type="button" hash="<?php echo $tkn; ?>" data="<?php echo $reject; ?>" rel="external" class="btn btn-danger prod_delete"data-toggle="modal" data-target=".modal-delete"><i class="fa fa-trash"></i> <?php echo hdev_lang::on("form","delete"); ?> </button>
                           <?php endif ?>
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>