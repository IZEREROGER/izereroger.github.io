<?php 
  $group = hdev_data::groups(hdev_log::gid(),['data']);
?>
<div class="content">
      <div class="container">       
        <div class="row" align="center">
          <div class="col-sm-12">
          	<div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">
                <h5 class="card-title m-0">Current Stock Info </h5>
              </div>
              <div class="card-body table-responsive p-0">
                <div class="row">
                  <div class="col-sm-3 border-bottom">
                    <div style="margin-top: 30%;">
                    <i class="fa fa-shopping-bag fa-5x"></i><br>
                    <i class="fa"><?php echo $group['g_name'] ?> Store </i>
                    </div> 
                  </div>
                  <div class="col-sm-9 border-left">
              	<table class="table table-hover border-left border-bottom text-nowrap">
                  <tbody>
                    <tr>
                      <td><?php echo hdev_lang::on("data","regno"); ?> :</td>
                      <td><span class='text-success'><?php echo hdev_data::get_admin(hdev_log::uid(),['data'])["a_id"]; ?></span></td>
                    </tr>
                    <tr>
                      <td>Stock name</td> 
                      <td>: <?php echo $group['g_name'] ?></td>
                    </tr>
                    <tr>
                      <td>Tell</td>
                      <td>: <?php echo $group['tell']; ?></td>
                    </tr>
                    <tr>
                      <td>Email</td>
                      <td>: <?php echo $group['email']; ?></td>
                    </tr>
                    <tr>
                      <td>Location</td>
                      <td>: <?php echo $group['g_location']; ?></td>
                    </tr>
                  </tbody>
                </table>
                  </div>
                </div>
                <br>
                <div class="btn-group">
                  <?php if (hdev_data::service('stock_edit')): ?> 
                  <button type="button" class="btn btn-primary user_editt" data-toggle="modal" data-target=".modal-edit">
                        <span class="fa fa-edit"></span>
                     Edit Stock info
                  </button>
                  <?php endif ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

<?php if (hdev_data::service('stock_edit')): ?> 
<div class="modal fade modal-edit"> 
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Stock info</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <form method="post" id="stock_edit">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="stock_edit">
            <div class="form-group">
              <label for="stock_name">
                Stock name :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="stock_name" id="stock_name" class="form-control" placeholder="Stock name" required="true" value="<?php echo $group['g_name'] ?>">
              </div>
            </div>
            <div class="form-group">
              <label for="stock_tell">
                Stock Telephone :
              </label>
              <div class="input-group mb-3">
                <input type="number" name="stock_tell" id="stock_tell" class="form-control" placeholder="Stock Telephone" required="true" value="<?php echo $group['tell']; ?>">
              </div>
              <div class="input-group mb-3" id="message_box_id">
              </div>              
            </div>
            <div class="form-group">
              <label for="stock_email">
                Stock email :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="stock_email" id="stock_email" class="form-control" placeholder="Stock email" required="true" value="<?php echo $group['email']; ?>">
              </div>
            </div>
            <div class="form-group">
              <label for="stock_location">
                Stock location :
              </label>
              <div class="input-group mb-3">
                <input type="email" name="stock_location" id="stock_location" class="form-control" placeholder="Stock location" required="required" value="<?php echo $group['g_location']; ?>">
              </div>
            </div>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="reg_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="stock_edit_btn" onclick="fm_submit('stock_edit_btn','stock_edit');"><i class="fa fa-save"></i> Save Stock Informations</button>
      </div>
      </form>
    </div>

    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>