<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Stock registration</h5>
              </div>
              <div class="card-body table-responsive p-2">
                  <table data-order='[[ 1, "desc" ]]' class="data-table table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort">Reg. no</th>
                      <th>Stock name</th>
                      <th>Tell</th>
                      <th>Email</th>
                      <th>Location</th>
                      <?php if (hdev_data::service('stock_reg') || hdev_data::service('stock_reg')): ?>
                      <th><?php echo hdev_lang::on("form","action"); ?></th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::groups('',['delete']);
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $group) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:stock_recover;id:".$group['g_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#sk_del_close;app:".$tkn.";".$build2);
                    ?>
                    <tr>
                      <td class="table-plus">
                        <?php echo $group["g_id"]; ?>
                      </td>
                      <td>
                        <?php echo $group['g_name'] ?>
                      </td>
                      <td>
                        <?php echo $group['tell']; ?>
                      </td>
                      <td>
                        <?php echo $group['email']; ?>
                      </td>
                      <td>
                        <?php echo $group['g_location']; ?>
                      </td>                                             
                      <?php if (hdev_data::service('stock_recover')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('stock_recover')): ?>
                          <button type="button" hash="<?php echo $tkn; ?>" stock_delete_id="<?php echo $group['g_id'] ?>" data="<?php echo $reject; ?>" rel="external" class="btn btn-secondary stock_delete_btn"data-toggle="modal" data-target=".modal-delete"><i class="fa fa-recycle"></i> <?php echo hdev_lang::on("form","recover"); ?> </button>
                           <?php endif ?>                         
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('stock_recover')): ?> 
<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Delete This Stock?</th>
                </tr>
                <tr>
                  <td>Stock id : </td>
                  <td id="stock_delete_id"></td>
                </tr>           
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="sk_del_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-success" id="stock_delete_btn" data="" hash=""><i class="fa fa-check-circle"></i> Recover This Stock in system</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>