<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Stock registration</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">
                  <?php if (hdev_data::service('stock_reg')): ?>
                  <button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fa fa-plus-circle"></i> Add new Stock in system</button>&nbsp;
                  <?php endif ?>
                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table data-order='[[ 1, "desc" ]]' class="data-table table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort">Reg. no</th>
                      <th>Stock name</th>
                      <th>Tell</th>
                      <th>Email</th>
                      <th>Location</th>
                      <?php if (hdev_data::service('stock_reg') || hdev_data::service('stock_reg')): ?>
                      <th><?php echo hdev_lang::on("form","action"); ?></th>
                      <?php endif ?> 
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::groups();
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $group) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:stock_delete;id:".$group['g_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#sk_del_close;app:".$tkn.";".$build2);
                    ?>
                    <tr>
                      <td class="table-plus">
                        <?php echo $group["g_id"]; ?>
                      </td>
                      <td>
                        <?php echo $group['g_name'] ?>
                      </td>
                      <td>
                        <?php echo $group['tell']; ?>
                      </td>
                      <td>
                        <?php echo $group['email']; ?>
                      </td>
                      <td>
                        <?php echo $group['g_location']; ?>
                      </td>                                             
                      <?php if (hdev_data::service('stock_edit') || hdev_data::service('stock_reg')): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('stock_reg')): ?>
                          <button type="button" stock_id="<?php echo $group["g_id"]; ?>" stock_name="<?php echo $group['g_name'] ?>" stock_tell="<?php echo $group['tell']; ?>" stock_email="<?php echo $group['email']; ?>" stock_location="<?php echo $group['g_location']; ?>" rel="external" class="btn btn-success stock_edit_btn"data-toggle="modal" data-target=".modal-edit"><i class="fa fa-edit"></i> <?php echo hdev_lang::on("form","edit"); ?> </button>
                           <?php endif ?>  
                          <?php if (hdev_data::service('stock_reg')): ?>
                          <button type="button" hash="<?php echo $tkn; ?>" stock_delete_id="<?php echo $group['g_id'] ?>" data="<?php echo $reject; ?>" rel="external" class="btn btn-danger stock_delete_btn"data-toggle="modal" data-target=".modal-delete"><i class="fa fa-trash"></i> <?php echo hdev_lang::on("form","delete"); ?> </button>
                           <?php endif ?>                         
                        </div>
                      </td>
                      <?php endif ?> 
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('stock_reg')): ?>
<div class="modal fade modal-reg"> 
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add new Stock in a system</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <form method="post" id="stock_reg">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="stock_reg">
            <div class="form-group">
              <label for="stock_name">
                Stock name :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="stock_name" id="stock_name" class="form-control" placeholder="Stock name" required>
              </div>
            </div>
            <div class="form-group">
              <label for="stock_tell">
                Stock Telephone :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="stock_tell" id="stock_tell" class="form-control" placeholder="Stock Telephone" required="true">
              </div>            
            </div>
            <div class="form-group">
              <label for="stock_email">
                Stock email :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="stock_email" id="stock_email" class="form-control" placeholder="Stock email" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="stock_location">
                Stock location :
              </label>
              <div class="input-group mb-3">
                <input type="email" name="stock_location" id="stock_location" class="form-control" placeholder="Stock location" required="required">
              </div>
            </div>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="reg_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="stock_reg_btn" onclick="fm_submit('stock_reg_btn','stock_reg');"><i class="fa fa-save"></i> Save Stock Informations</button>
      </div>
      </form>
    </div>

    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('stock_reg')): ?>
<div class="modal fade modal-edit"> 
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Stock Info</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <form method="post" id="stock_edit">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="stock_edit">
              <input type="hidden" name="stock_id" id="stock_id">

            <div class="form-group">
              <label for="stock_name">
                Stock name :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="stock_name" id="stock_name" class="form-control" placeholder="Stock name" required>
              </div>
            </div>
            <div class="form-group">
              <label for="stock_tell">
                Stock Telephone :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="stock_tell" id="stock_tell" class="form-control" placeholder="Stock Telephone" required="true">
              </div>            
            </div>
            <div class="form-group">
              <label for="stock_email">
                Stock email :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="stock_email" id="stock_email" class="form-control" placeholder="Stock email" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="stock_location">
                Stock location :
              </label>
              <div class="input-group mb-3">
                <input type="email" name="stock_location" id="stock_location" class="form-control" placeholder="Stock location" required="required">
              </div>
            </div>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#edit_close">
            
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="edit_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="stock_edit_btn" onclick="fm_submit('stock_edit_btn','stock_edit');"><i class="fa fa-save"></i> Save Stock Informations</button>
      </div>
      </form>
    </div>

    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('stock_delete')): ?> 
<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Delete This Stock?</th>
                </tr>
                <tr>
                  <td>Stock id : </td>
                  <td id="stock_delete_id"></td>
                </tr>           
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="sk_del_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="stock_delete_btn" data="" hash=""><i class="fa fa-times-circle"></i> Delete This Stock in system</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>