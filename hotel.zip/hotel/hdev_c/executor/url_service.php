<?php 
	$rasms_urls = array ( 

	'/login_i' => array (
		'name' => 'access to view [/login_i]',
		'error' => 'You can not access this page',
		),
	'/up' => array (
		'name' => 'access to view [/up]',
		'error' => 'You can not access this page',
		),
	'/login' => array (
		'name' => 'access to view [/login]',
		'error' => 'You can not access this page',
		),
	'/forgot' => array (
		'name' => 'access to view [/forgot]',
		'error' => 'You can not access this page',
		),
	'/register' => array (
		'name' => 'access to view [/register]',
		'error' => 'You can not access this page',
		),
	'/all_mn' => array (
		'name' => 'access to view [/all_mn]',
		'error' => 'You can not access this page',
		),
	'/' => array (
		'name' => 'access to view [/]',
		'error' => 'You can not access this page',
		),
	'' => array (
		'name' => 'access to view []',
		'error' => 'You can not access this page',
		),
	'/a/b/c' => array (
		'name' => 'access to view [/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/r/home' => array (
		'name' => 'access to view [/r/home]',
		'error' => 'You can not access this page',
		),
	'/r/home/a/b/c' => array (
		'name' => 'access to view [/r/home/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/home/(.*)/search' => array (
		'name' => 'access to view [/r/home]',
		'error' => 'You can not access this page',
		),
	'/home/(.*)/search/a/b/c' => array (
		'name' => 'access to view [/r/home/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/r/profile' => array (
		'name' => 'access to view [/r/profile]',
		'error' => 'You can not access this page',
		),
	'/r/profile/a/b/c' => array (
		'name' => 'access to view [/r/profile/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/s.js' => array (
		'name' => 'access to view [/s.js]',
		'error' => 'You can not access this page',
		),
	'/gen.js' => array (
		'name' => 'access to view [/gen.js]',
		'error' => 'You can not access this page',
		),
	'/script-1' => array (
		'name' => 'access to view [/script-1]',
		'error' => 'You can not access this page',
		),
	'/app/setting/(.*)/(.*)' => array (
		'name' => 'access to view [/app/setting/(.*)/(.*)]',
		'error' => 'You can not access this page',
		),
	'/app/report/(.*)/(.*)' => array (
		'name' => 'access to view [/app/report/(.*)/(.*)]',
		'error' => 'You can not access this page',
		),
	'/auth/gen/(.*)' => array (
		'name' => 'access to view [/auth/gen/(.*)]',
		'error' => 'You can not access this page',
		),
	'/all/product' => array (
		'name' => 'access to view [/all/product]',
		'error' => 'You can not access this page',
		),
	'/all/product/a/b/c' => array (
		'name' => 'access to view [/all/product/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/trash/product' => array (
		'name' => 'access to view [/trash/product]',
		'error' => 'You can not access this page',
		),
	'/trash/product/a/b/c' => array (
		'name' => 'access to view [/trash/product/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/all/room' => array (
		'name' => 'access to view [/all/room]',
		'error' => 'You can not access this page',
		),
	'/all/room/a/b/c' => array (
		'name' => 'access to view [/all/room/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/trash/room' => array (
		'name' => 'access to view [/trash/room]',
		'error' => 'You can not access this page',
		),
	'/trash/room/a/b/c' => array (
		'name' => 'access to view [/trash/room/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/all/room' => array (
		'name' => 'access to view [/all/product]',
		'error' => 'You can not access this page',
		),
	'/all/room/a/b/c' => array (
		'name' => 'access to view [/all/product/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/trash/room' => array (
		'name' => 'access to view [/trash/product]',
		'error' => 'You can not access this page',
		),
	'/trash/room/a/b/c' => array (
		'name' => 'access to view [/trash/product/a/b/c]',
		'error' => 'You can not access this page',
		),	
	'/all/tool' => array (
		'name' => 'access to view [/all/tool]',
		'error' => 'You can not access this page',
		),
	'/all/tool/a/b/c' => array (
		'name' => 'access to view [/all/tool/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/trash/tool' => array (
		'name' => 'access to view [/trash/tool]',
		'error' => 'You can not access this page',
		),
	'/trash/tool/a/b/c' => array (
		'name' => 'access to view [/trash/tool/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/all/category' => array (
		'name' => 'access to view [/all/category]',
		'error' => 'You can not access this page',
		),
	'/all/category/a/b/c' => array (
		'name' => 'access to view [/all/category/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/trash/category' => array (
		'name' => 'access to view [/trash/category]',
		'error' => 'You can not access this page',
		),
	'/trash/category/a/b/c' => array (
		'name' => 'access to view [/trash/category/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/all/brand' => array (
		'name' => 'access to view [/all/brand]',
		'error' => 'You can not access this page',
		),
	'/all/brand/a/b/c' => array (
		'name' => 'access to view [/all/brand/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/trash/brand' => array (
		'name' => 'access to view [/trash/brand]',
		'error' => 'You can not access this page',
		),
	'/trash/brand/a/b/c' => array (
		'name' => 'access to view [/trash/brand/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/product/cart' => array (
		'name' => 'access to view [/product/cart]',
		'error' => 'You can not access this page',
		),
	'/product/cart/a/b/c' => array (
		'name' => 'access to view [/product/cart/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/order/(.*)/receipt' => array (
		'name' => 'access to view [/order/(.*)/receipt]',
		'error' => 'You can not access this page',
		),
	'/order/(.*)/receipt/a/b/c' => array (
		'name' => 'access to view [/order/(.*)/receipt/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/gen/report' => array (
		'name' => 'access to view [/gen/report]',
		'error' => 'You can not access this page',
		),
	'/gen/report/a/b/c' => array (
		'name' => 'access to view [/gen/report/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/gen/report/(.*)/date' => array (
		'name' => 'access to view [/gen/report/(.*)/date]',
		'error' => 'You can not access this page',
		),
	'/gen/report/(.*)/date/a/b/c' => array (
		'name' => 'access to view [/gen/report/(.*)/date/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/product/report' => array (
		'name' => 'access to view [/product/report]',
		'error' => 'You can not access this page',
		),
	'/product/report/a/b/c' => array (
		'name' => 'access to view [/product/report/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/product/report/(.*)/date' => array (
		'name' => 'access to view [/product/report/(.*)/date]',
		'error' => 'You can not access this page',
		),
	'/product/report/(.*)/date/a/b/c' => array (
		'name' => 'access to view [/product/report/(.*)/date/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/room/report' => array (
		'name' => 'access to view [/room/report]',
		'error' => 'You can not access this page',
		),
	'/room/report/a/b/c' => array (
		'name' => 'access to view [/room/report/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/room/report/(.*)/date' => array (
		'name' => 'access to view [/room/report/(.*)/date]',
		'error' => 'You can not access this page',
		),
	'/room/report/(.*)/date/a/b/c' => array (
		'name' => 'access to view [/room/report/(.*)/date/a/b/c]',
		'error' => 'You can not access this page',
		),

	/*----------------------stock system -----------*/
	'/stock/in' => array (
		'name' => 'access to view [/stock/in]',
		'error' => 'You can not access this page',
		),
	'/stock/in/a/b/c' => array (
		'name' => 'access to view [/stock/in/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/trash/stock_in' => array (
		'name' => 'access to view [/trash/stock_in]',
		'error' => 'You can not access this page',
		),
	'/trash/stock_in/a/b/c' => array (
		'name' => 'access to view [/trash/stock_in/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/stock/out' => array (
		'name' => 'access to view [/stock/out]',
		'error' => 'You can not access this page',
		),
	'/stock/out/a/b/c' => array (
		'name' => 'access to view [/stock/out/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/trash/stock_out' => array (
		'name' => 'access to view [/trash/stock_out]',
		'error' => 'You can not access this page',
		),
	'/trash/stock_out/a/b/c' => array (
		'name' => 'access to view [/trash/stock_out/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/status/in_stock' => array (
		'name' => 'access to view [/status/in_stock]',
		'error' => 'You can not access this page',
		),
	'/status/in_stock/a/b/c' => array (
		'name' => 'access to view [/status/in_stock/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/sales/report' => array (
		'name' => 'access to view [/sales/report]',
		'error' => 'You can not access this page',
		),
	'/sales/report/a/b/c' => array (
		'name' => 'access to view [/sales/report/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/sales/report/(.*)/date' => array (
		'name' => 'access to view [/sales/report/(.*)/date]',
		'error' => 'You can not access this page',
		),
	'/sales/report/(.*)/date/a/b/c' => array (
		'name' => 'access to view [/sales/report/(.*)/date/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/warn/exp' => array (
		'name' => 'access to view [/warn/exp]',
		'error' => 'You can not access this page',
		),
	'/warn/exp/a/b/c' => array (
		'name' => 'access to view [/warn/exp/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/exp/products' => array (
		'name' => 'access to view [/exp/products]',
		'error' => 'You can not access this page',
		),
	'/exp/products/a/b/c' => array (
		'name' => 'access to view [/exp/products/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/warn/out' => array (
		'name' => 'access to view [/warn/out]',
		'error' => 'You can not access this page',
		),
	'/warn/out/a/b/c' => array (
		'name' => 'access to view [/warn/out/a/b/c]',
		'error' => 'You can not access this page',
		),
	'/out/products' => array (
		'name' => 'access to view [/out/products]',
		'error' => 'You can not access this page',
		),
	'/out/products/a/b/c' => array (
		'name' => 'access to view [/out/products/a/b/c]',
		'error' => 'You can not access this page',
		),							
	);
	//$all_services = array_keys($rasms_urls);
	//$tg = "";
	//foreach ($all_services as $key) {
	//	if ($key == "stud_delete") {
	//		$tg = 9;
	//	}
	//	if ($tg != 9) {
	//		echo "'".$key."' /*".$rasms_urls[$key]['name']."*/,\n";
	//	}
		
	//}
	$rasms_urls_users = array(
		'guest'=>array(
			'/forgot',
			'/all_mn',
			'/register' /*Access to login*/,
			'/login' /*Access to login*/,
			'/login_i' /*Access To view Login Page*/,
			'/up' /*Access to submit data*/,
			'/login_i',
			'',
			'/',
			'/r/home' /*Access to view homepage*/,
			'/r/home/a/b/c' /*Access to view homepage*/,
			'/r/home/page/(.*)' /*Access to view homepage*/,
			'/r/home/page/(.*)/a/b/c' /*Access to view homepage*/,
			'/home/(.*)/search',
			'/home/(.*)/search/a/b/c',
			'/script-1' /*Access to test*/,
		),
		'admin'=> array( /// was admin

			'/login_i',
			'/up',
			'/login',
			'/forgot',
			'/register',
			'/all_mn',
			'/',
			'',
			'/a/b/c',
			'/r/home',
			'/r/home/a/b/c',
			'/home/(.*)/search',
			'/home/(.*)/search/a/b/c',
			'/r/profile',
			'/r/profile/a/b/c',
			'/s.js',
			'/gen.js',
			'/script-1',
			'/app/setting/(.*)/(.*)',
			'/app/report/(.*)/(.*)',
			'/auth/gen/(.*)',
			'/all/room',
			'/all/room/a/b/c',
			'/trash/room',
			'/trash/room/a/b/c',
			'/product/cart',
			'/product/cart/a/b/c',
			'/order/(.*)/receipt',
			'/order/(.*)/receipt/a/b/c',
			'/gen/report',
			'/gen/report/a/b/c',
			'/gen/report/(.*)/date',
			'/gen/report/(.*)/date/a/b/c',
			'/product/report',
			'/product/report/a/b/c',
			'/product/report/(.*)/date',
			'/product/report/(.*)/date/a/b/c',
			'/room/report',
			'/room/report/a/b/c',
			'/room/report/(.*)/date',
			'/room/report/(.*)/date/a/b/c',
					
		),

		'manager'=> array( 
			'/login_i',
			'/up',
			'/login',
			'/forgot',
			'/register',
			'/all_mn',
			'/',
			'',
			'/a/b/c',
			'/r/home',
			'/r/home/a/b/c',
			'/home/(.*)/search',
			'/home/(.*)/search/a/b/c',
			'/r/profile',
			'/r/profile/a/b/c',
			'/s.js',
			'/gen.js',
			'/script-1',
			'/app/setting/(.*)/(.*)',
			'/app/report/(.*)/(.*)',
			'/auth/gen/(.*)',
			'/all/category',
			'/all/category/a/b/c',
			'/trash/category',
			'/trash/category/a/b/c',
			'/all/brand',
			'/all/brand/a/b/c',
			'/trash/brand',
			'/trash/brand/a/b/c',
			'/all/product',
			'/all/product/a/b/c',
			'/trash/product',
			'/trash/product/a/b/c',
			'/all/tool',
			'/all/tool/a/b/c',
			'/trash/tool',
			'/trash/tool/a/b/c',
			
			/*--------- stock system------------*/
			'/stock/in',
			'/stock/in/a/b/c',
			'/trash/stock_in',
			'/trash/stock_in/a/b/c',
			'/stock/out',
			'/stock/out/a/b/c',
			'/trash/stock_out',
			'/trash/stock_out/a/b/c',
			'/status/in_stock',
			'/status/in_stock/a/b/c',
			'/sales/report',
			'/sales/report/a/b/c',
			'/sales/report/(.*)/date',
			'/sales/report/(.*)/date/a/b/c',
			'/warn/exp',
			'/warn/exp/a/b/c',
			'/exp/products',
			'/exp/products/a/b/c',
			'/warn/out',
			'/warn/out/a/b/c',
			'/out/products',
			'/out/products/a/b/c',					
		),
	);
	
 ?>