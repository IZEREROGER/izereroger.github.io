<?php
define("APP_BASE_URL", rtrim(ltrim(hdev_url::menu(''),'/'),'/'));

if (!class_exists("hdev_route")) {
  $regpath = __DIR__;
  $regd = str_ireplace('\\', "/", $regpath).'/hdev_parse.php';

  include $regd;
}

  if ($_GET) {
    if (isset($_GET['logout'])) {
      hdev_log::out();
    }
  }


  /**
   * hdev_data all dat prefetch
   */
  class hdev_data
  {
    public static function search_word($word='')
    {
      $num = str_ireplace(' ', '', $word);
      //echo $word."<br>";
      $num_var = strlen($num);
      $fin_word = '%';
      for ($i=0; $i < $num_var; $i++) { 
        //$j = $i+1;
        $rn = substr($num, $i, 1);
        $fin_word .= $rn."%";
      }   
      return $fin_word;
    }
    public static function abbr($val='',$char=1)
    {
      $val = explode(" ", $val);
      $preserve = array('and','or',':');
      $char = (is_numeric($char) && $char > 0) ? $char : 1 ;
      $retur = "";
      if (is_array($val) && count($val) > 0) {
        foreach ($val as $vv) {
          if (strlen($vv) <= $char) {
            $vv = strtoupper($vv)." ";
          } elseif (!in_array(strtolower($vv), $preserve)) {
            $vv = strtoupper(substr($vv, 0,$char)).'.';
            //exit($vv);
          }else{
            $vv = $vv." ";
          }
          $retur .= $vv;
        }
      }
      return $retur;
    }
    public static function service($service=false)
    {
      $rasms_stc = new hdev_auth_service('',trim($service));
      return $rasms_stc->access();
    }

    public static function service_error($service=false)
    {
      $rasms_stc = new hdev_auth_service('',trim($service));
      return $rasms_stc->error("alert");
    }
    public static function compare_2($value='',$value2 = " ")
    {
      if ($value == $value2) {
        return true;
      }else{
        return false;
      }
    }
    public static function proof_link($proof='')
    {
      return hdev_url::menu('dist/img/proofs/'.$proof);
    }
    public static function id_valid($value='')
    {
      $retur = false;
      //echo strlen($value);
      if (empty($value)) {
        $retur = "ID Must not be empty";
      }elseif (!is_numeric($value)) {
        $retur = "ID must be in number format without space or any other non-numeric value";
      }elseif (strlen($value) != 16) {
        $retur = "ID must be 16 digits only";
      }
      return $retur;
    }
    public static function phone_valid($value='')
    {
      $retur = false;
      $t = "";
      if (!empty($value)) {
        $t = $value;
        $jk = strlen($t);
        $type = substr($t, 0, 2);
      }
      if (empty($value)) {
        $retur = 'Phone number can\'t be empty';
      }
      elseif ($type != "07") {
        $retur = 'Phone number must start with \'07\'';
      }
      elseif (!is_numeric($t)) {
        $retur = 'Phone number must contain only numbers (0-9)';
      }
      elseif ($jk != "10") {
        $retur = "Phone number must be 10 digits (07........)";
      }else{
        //echo $_POST['system_tel_nom'];
      }
      return $retur;
    }
    public static function tag_value($string="", $tagname)
    {
        /*$pattern = "#<\s*?".$tagname."\b[^>]*>(.*?)</".$tagname."\b[^>]*>#s";
        preg_match($pattern, $string, $matches);
        $match = (isset($matches[1])) ? $matches[1] : "" ;
        return $match;*/
        $ref1 = explode("<".$tagname.">", $string);
        $ref2 = (is_array($ref1) && isset($ref1[1])) ? explode("</".$tagname.">", $ref1[1]) : "" ;
        $ref3 = (is_array($ref2) && isset($ref2[0])) ? trim($ref2[0]) : "" ;
        return $ref3;
    }
    public static function directory($dir)
    {
      $retur = array();
      $ffs = scandir($dir);
      unset($ffs[array_search('.', $ffs, true)]);
      unset($ffs[array_search('..', $ffs, true)]);
      // prevent empty ordered elements
      if (count($ffs) < 1)
          return;
      foreach($ffs as $ff){
          if (!is_dir($dir.'/'.$ff)) {
            $file = $dir.'/'.$ff;
            array_push($retur, $file);
          }
      }
      return $retur;
    }
    function display($text)
    {
        //replace UTF-8
        $convertUT8 = array("\xe2\x80\x98", "\xe2\x80\x99", "\xe2\x80\x9c", "\xe2\x80\x9d", "\xe2\x80\x93", "\xe2\x80\x94", "\xe2\x80\xa6");
        $to = array("'", "'", '"', '"', '-', '--', '...');
        $text = str_replace($convertUT8,$to,$text);

        //replace Windows-1252
        $convertWin1252 = array(chr(145), chr(146), chr(147), chr(148), chr(150), chr(151), chr(133));
        $to = array("'", "'", '"', '"', '-', '--', '...');
        $text = str_replace($convertWin1252,$to,$text);

        //replace accents
        $convertAccents = array('À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ð', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'Ø', 'Ù', 'Ú', 'Û', 'Ü', 'Ý', 'ß', 'à', 'á', 'â', 'ã', 'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 'ÿ', 'A', 'a', 'A', 'a', 'A', 'a', 'C', 'c', 'C', 'c', 'C', 'c', 'C', 'c', 'D', 'd', 'Ð', 'd', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'H', 'h', 'H', 'h', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', '?', '?', 'J', 'j', 'K', 'k', 'L', 'l', 'L', 'l', 'L', 'l', '?', '?', 'L', 'l', 'N', 'n', 'N', 'n', 'N', 'n', '?', 'O', 'o', 'O', 'o', 'O', 'o', 'Œ', 'œ', 'R', 'r', 'R', 'r', 'R', 'r', 'S', 's', 'S', 's', 'S', 's', 'Š', 'š', 'T', 't', 'T', 't', 'T', 't', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'W', 'w', 'Y', 'y', 'Ÿ', 'Z', 'z', 'Z', 'z', 'Ž', 'ž', '?', 'ƒ', 'O', 'o', 'U', 'u', 'A', 'a', 'I', 'i', 'O', 'o', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', '?', '?', '?', '?', '?', '?');
        $to = array('A', 'A', 'A', 'A', 'A', 'A', 'AE', 'C', 'E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'D', 'N', 'O', 'O', 'O', 'O', 'O', 'O', 'U', 'U', 'U', 'U', 'Y', 's', 'a', 'a', 'a', 'a', 'a', 'a', 'ae', 'c', 'e', 'e', 'e', 'e', 'i', 'i', 'i', 'i', 'n', 'o', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'u', 'y', 'y', 'A', 'a', 'A', 'a', 'A', 'a', 'C', 'c', 'C', 'c', 'C', 'c', 'C', 'c', 'D', 'd', 'D', 'd', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'E', 'e', 'G', 'g', 'G', 'g', 'G', 'g', 'G', 'g', 'H', 'h', 'H', 'h', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'I', 'i', 'IJ', 'ij', 'J', 'j', 'K', 'k', 'L', 'l', 'L', 'l', 'L', 'l', 'L', 'l', 'l', 'l', 'N', 'n', 'N', 'n', 'N', 'n', 'n', 'O', 'o', 'O', 'o', 'O', 'o', 'OE', 'oe', 'R', 'r', 'R', 'r', 'R', 'r', 'S', 's', 'S', 's', 'S', 's', 'S', 's', 'T', 't', 'T', 't', 'T', 't', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'W', 'w', 'Y', 'y', 'Y', 'Z', 'z', 'Z', 'z', 'Z', 'z', 's', 'f', 'O', 'o', 'U', 'u', 'A', 'a', 'I', 'i', 'O', 'o', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'U', 'u', 'A', 'a', 'AE', 'ae', 'O', 'o');
        $text = str_replace($convertAccents,$to,$text);

        //Encode the characters
        $text = htmlentities($text);

        //normalize the line breaks (here because it applies to all text)
        $text = str_replace("\r\n", "\n", $text);
        $text = str_replace("\r", "\n", $text);

        //decode the <code> tags
        $codeOpen = htmlentities('<').'code'.htmlentities('>');
        if (strpos($text, $codeOpen))
        {
            $text = str_replace($codeOpen, html_entity_decode(htmlentities('<')) . "code" . html_entity_decode(htmlentities('>')), $text);
        }
        $codeOpen = htmlentities('<').'/code'.htmlentities('>');
        if (strpos($text, $codeOpen))
        {
            $text = str_replace($codeOpen, html_entity_decode(htmlentities('<')) . "/code" . html_entity_decode(htmlentities('>')), $text);
        }

        //match everything between <code> and </code>, the msU is what makes this work here, ADD this to REGEX archive
        $regex = '/<code>(.*)<\/code>/msU';
        $code = preg_match($regex, $text, $matches);
        if ($code == 1)
        {
            if (is_array($matches) && count($matches) >= 2)
            {
                $newcode = $matches[1];

                $newcode = nl2br($newcode);
            }

        //remove <code>and this</code> from $text;
        $text = str_replace('<code>' . $matches[1] . '</code>', 'PLACEHOLDERCODE1', $text);

        //convert the line breaks to paragraphs
        $text = '<p>' . str_replace("\n\n", '</p><p>', $text) . '</p>';
        $text = str_replace("\n" , '<br />', $text);
        $text = str_replace('</p><p>', '</p>' . "\n\n" . '<p>', $text);

        $text = str_replace('PLACEHOLDERCODE1', '<code>'.$newcode.'</code>', $text);
        }
        else
        {
            $code = false;
        }

        if ($code == false)
        {
            //convert the line breaks to paragraphs
            $text = '<p>' . str_replace("\n\n", '</p><p>', $text) . '</p>';
            $text = str_replace("\n" , '<br />', $text);
            $text = str_replace('</p><p>', '</p>' . "\n\n" . '<p>', $text);
        }
        $text = "<span>".ltrim(rtrim($text,"</p>"),"<p>")."</span>";
        return $text;
    }
    public static function currency($val,$gid="")
    {
      $gid = hdev_log::gid();
      return $val." frw";
    }
    public static function date($date='',$ref=1)
    {
      $retur = '';
      if ($ref == 1) {
        $retur = date_format(date_create($date),"Y-m-d");
      }elseif ($ref == 2) {
        $retur =  date_format(date_create($date),"d/m/Y");
      }elseif ($ref == 'input') {
        $retur =  date_format(date_create($date),"m-d-Y");
      }elseif ($ref == 'date_time') {
        $retur =  date_format(date_create($date),"d/m/Y h:i:s");
      }elseif ($ref == '3') {
        $retur =  date_format(date_create($date),"d/m/Y <br> h:i:s");
      }

      return $retur;
    }
    public static function timer($value,$req)
    {
      if ($req == "time") {
        $dteee=date_create($value);
        $dtt3 = date_format($dteee,"h:i:s");
        return $dtt3;
      }elseif ($req == "date") {
        $dteee=date_create($value);
        $dtt3 = date_format($dteee," d/m/Y");
        return $dtt3;
      }
    }
    public static function f_up($value='')
    {
      $regd = 'dest/book';
      return $regd;
    }
    public static function download_from_link($value,$type)
    {
      $rt = trim($value);
      $rtt = str_ireplace(array("book","/"), array("bst","_"), $rt);
      if (trim(substr($type, 0, 1)) != ".") {
        $type = ".".$type;
      }
      $file = $rtt.$type;
      $official_file = "/".trim($file);
      return $official_file;
    }
    public static function img_up()
    {
      $t = hdev_url::menu('dist/img/');
      return $t;
    }
    public static function product_images($hash,$prefetch="")
    {
      if (!empty($hash) && $prefetch == "") {
        $return = array();
        $exp = ".,*HDEV_prod*.,";
        $product = explode($exp, $hash);
        if (is_array($product) && count($product) > 0) {
          for ($i=0; $i < count($product); $i++) { 
            $a = hdev_url::menu("dist/img/products/");
            array_push($return, $a.$product[$i]);
          }
        }
        
        return $return;
      }else{
        $return = array();
        $exp = ".,*HDEV_prod*.,";
        $product = explode($exp, $hash);
        if (count($product) > 0) {
          for ($i=0; $i < count($product); $i++) { 
            $fileName = $product[$i];
            $regpath = __DIR__;
            $target_path = realpath(str_ireplace('\\', "/", $regpath).'/../dist/img/products')."\\".$fileName;

            if(is_file($target_path) && file_exists($target_path))
            {
              array_push($return, $target_path);
            }
          }
        }
        return $return;
      }
    }
    public static function password_enc($value='')
    {
      return md5($value);
    }
    public static function encd($value)
    {
      $ht = str_ireplace(array(1,2,3,4,5,6,7,8,9,0), array(":@:,",".[","].",",[","],","*[","]*","{","|:|,",":||:"), $value);
      $ht = base64_encode($ht);
      $rtt = substr(md5(date("h:i:s")), 0,5);
      $yh = "hdev_".$rtt.$ht;
      return $yh;
    }
    public static function decd($value)
    {
      $value = substr($value, 5+5);
      $value = base64_decode($value);
      $ht = str_ireplace(array(":@:,",".[","].",",[","],","*[","]*","{","|:|,",":||:"), array(1,2,3,4,5,6,7,8,9,0), $value);
      return $ht;
    }
    public static function get_attend($var='',$ref='')
    {
      $resp = false;
      $resp = ($var == 1) ? true : false ;
      if ($ref == '') {
        if ($resp) {
          $retur = "Active";
        }else{
          $retur = "<b style=\"color: red;\">Not active</b>";
        }
      }elseif ($ref = 'valid') {
        $retur = $resp;
      }
      return $retur;
    }
    public static function get_sex($ref)
    {
      $ref = strtolower($ref);
      if ($ref == "m") {
        return "Male";
      }elseif ($ref == "f") {
        return "Female";
      }else{
        return $ref;
      }
    }
    public static function tx_ref($prefix="ht-ref",$rent_id="") { 
      $csrf = new CSRF_Protect();
      $reqford = $csrf->getToken();
      $rf = strtolower($prefix).'-'.md5($reqford.rand().$rent_id.time().rand(20,time()));
      return $rf;
    } 
    public static function in_date_range($in='',$start='',$end='')
    {
      $start = hdev_data::date($start);
      $end = hdev_data::date($end);
      $in = hdev_data::date($in);
      $start = strtotime($start);
      $end = strtotime($end);
      $check = strtotime($in);
      return (($start <= $check ) && ($check <= $end));
    }
    public static function log_user($unm,$psw,$ref='')
    {
      $rt = new hdev_db(); 
      $tab = $rt->table("all_users"); 
      $username = $unm;
      $password = hdev_data::password_enc($psw);
      $ret="no";
      $sql = $rt->select("SELECT * FROM $tab WHERE (email=:user) AND password=:pass",[[":user",$username],[":pass",$password]]);
      //var_dump($sql);exit;
      if (count($sql)==1 && !empty($sql)) {
         foreach ($sql as $row) {
          if (!empty($row["u_id"]) && !empty($row["email"])) {
            if ($ref=='') {
              $_SESSION['ffunct'] = $row['role'];
              $_SESSION['us_r_n'] = $row["email"];
              $_SESSION['msg_id_id'] = $row["u_id"];
              $_SESSION['g_id'] = "";
              $_SESSION['sg_id'] = "";
            }
            $ret = "yes";
          }
         }
       } 
      return $ret;
    }
    public static function active_user($res="")
    {
      if (hdev_log::loged()) {
        $funct = hdev_log::fid();
        $u = hdev_log::uid();
        $resp = array();
        switch ($funct) {
          case 'admin':
          case 'super_admin':
          case 'manager':
            $ret = hdev_data::get_admin($u,['data']);
            $resp['name'] = $ret['names'];
            $resp['username'] = $ret['names'];
            $resp['email'] = $ret['email'];
            $resp['fid'] = ucfirst($funct);
          break;      
          default:
            $resp['name'] = "";
            $resp['username'] = "";
            $resp['email'] = ""; 
            $resp['fid'] = ucfirst($funct);           
          break;
        }
        if (isset($resp[$res])) {
          return $resp[$res];
        }else{
          return "";
        }
      }
    }
    public static function get_admin($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("main_auths");
      $group = hdev_log::gid();
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE names !='' AND status=1");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "count") {
        $v_ref = $rt->select("SELECT COUNT(*) AS all_rec FROM $tab WHERE names !=''");
        $rett = 0;
        if (isset($v_ref[0]) && isset($v_ref[0]['all_rec'])) {
          $rett = (is_numeric($v_ref[0]['all_rec']) && $v_ref[0]['all_rec'] > 0) ? $v_ref[0]['all_rec'] : 0 ;
        }
        return $rett;
      }
      elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE names !=''");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "exist") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE u_id = :u_id AND status=1");
        if (isset($v_ref[0]['u_id']) && !empty($v_ref[0]['u_id'])) {
          $retur = "yes";
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE u_id = :u_id",[[":u_id",$l_id]]);
        if (isset($v_ref[0]['u_id']) && !empty($v_ref[0]['u_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "valid") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE u_id = :u_id AND status=1",[[":u_id",$l_id]]);
        if (isset($v_ref[0]['u_id']) && !empty($v_ref[0]['u_id'])) {
          $retur = $v_ref[0];
        }else{
          $retur = false;
        }
        return $retur;
      }
      elseif (isset($param[0]) && $param[0] == "tel") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE tel = :a_tel AND status=1",[[":a_tel",$l_id]]);
        if (isset($v_ref[0]['u_id']) && !empty($v_ref[0]['u_id'])) {
          $retur = $v_ref;
        }else{
          $retur = false;
        }
        return $retur;
      }
    }
    public static function products($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("products");
      $group = hdev_log::gid();
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $search = hdev_session::get('search');
        if (!empty($search)) {
          $search = hdev_data::search_word($search);
          $v_ref = $rt->select("SELECT * FROM $tab WHERE p_name LIKE :sc AND p_status=1",[[':sc',$search]]);
        }else{
          $v_ref = $rt->select("SELECT * FROM $tab WHERE p_name !='' AND p_status=1");
        }
        
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE p_name !='' AND p_status != 2");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "active_count") {
        $v_ref = $rt->select("SELECT count(*) as all_rec FROM $tab WHERE p_name !='' AND p_status = 1");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }elseif (isset($param[0]) && $param[0] == "delete") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE p_name !='' AND p_status = 0 ");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "delete_count") {
        $v_ref = $rt->select("SELECT count(*) as all_rec FROM $tab WHERE p_name !='' AND p_status = 0");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }
      elseif (isset($param[0]) && $param[0] == "exist") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE p_id = :p_id AND p_status=1");
        if (isset($v_ref[0]['p_id']) && !empty($v_ref[0]['p_id'])) {
          $retur = "yes";
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE p_id = :p_id",[[":p_id",$l_id]]);
        if (isset($v_ref[0]['p_id']) && !empty($v_ref[0]['p_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "valid") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE p_id = :p_id AND p_status=1");
        if (isset($v_ref[0]['p_id']) && !empty($v_ref[0]['p_id'])) {
          $retur = $v_ref[0];
        }else{
          $retur = false;
        }
        return $retur;
      }
    }
    public static function rooms($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("rooms");
      $group = hdev_log::gid();
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE r_name !='' AND r_status=1");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE r_name !='' AND r_status != 2");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "active_count") {
        $v_ref = $rt->select("SELECT count(*) as all_rec FROM $tab WHERE r_name !='' AND r_status = 1");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }elseif (isset($param[0]) && $param[0] == "delete") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE r_name !='' AND r_status = 0 ");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "delete_count") {
        $v_ref = $rt->select("SELECT count(*) as all_rec FROM $tab WHERE r_name !='' AND r_status = 0");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }
      elseif (isset($param[0]) && $param[0] == "exist") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE r_id = :r_id AND r_status=1");
        if (isset($v_ref[0]['r_id']) && !empty($v_ref[0]['r_id'])) {
          $retur = "yes";
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE r_id = :r_id",[[":r_id",$l_id]]);
        if (isset($v_ref[0]['r_id']) && !empty($v_ref[0]['r_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "valid") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE r_id = :r_id AND r_status=1");
        if (isset($v_ref[0]['r_id']) && !empty($v_ref[0]['r_id'])) {
          $retur = $v_ref[0];
        }else{
          $retur = false;
        }
        return $retur;
      }
    }    
    public static function tool_health($value='')
    {
      $retur = "";
      if ($value == 1) {
        $retur = "<button class='btn btn-success' type='button'>Very good</button>";
      }elseif ($value == 2) {
        $retur = "<button class='btn btn-info' type='button'>Good</button>";
      }elseif ($value == 3) {
        $retur = "<button class='btn btn-warning' type='button'>Bad</button>";
      }elseif ($value == 4) {
        $retur = "<button class='btn btn-danger' type='button'>Subjected for replacement</button>";
      }
      return $retur;
    }
    public static function tools($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("tools");
      $group = hdev_log::gid();
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE t_name !='' AND t_status=1");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE t_name !='' AND t_status != 2");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "active_count") {
        $v_ref = $rt->select("SELECT count(*) as all_rec FROM $tab WHERE t_name !='' AND t_status = 1");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }elseif (isset($param[0]) && $param[0] == "delete") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE t_name !='' AND t_status = 0 ");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "delete_count") {
        $v_ref = $rt->select("SELECT count(*) as all_rec FROM $tab WHERE t_name !='' AND t_status = 0");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE t_id = :t_id",[[":t_id",$l_id]]);
        if (isset($v_ref[0]['t_id']) && !empty($v_ref[0]['t_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }
    }    
    public static function category($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("category");
      $group = hdev_log::gid();
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE c_name !='' AND c_status=1");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE c_name !='' AND c_status != 2");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "active_count") {
        $v_ref = $rt->select("SELECT count(*) as all_rec FROM $tab WHERE c_name !='' AND c_status = 1");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }elseif (isset($param[0]) && $param[0] == "delete") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE c_name !='' AND c_status = 0 ");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "delete_count") {
        $v_ref = $rt->select("SELECT count(*) as all_rec FROM $tab WHERE c_name !='' AND c_status = 0");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }
      elseif (isset($param[0]) && $param[0] == "exist") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE c_id = :c_id AND c_status=1",[[":c_id",$l_id]]);
        if (isset($v_ref[0]['c_id']) && !empty($v_ref[0]['c_id'])) {
          $retur = "yes";
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE c_id = :c_id",[[":c_id",$l_id]]);
        if (isset($v_ref[0]['c_id']) && !empty($v_ref[0]['c_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "valid") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE c_id = :c_id AND c_status=1");
        if (isset($v_ref[0]['c_id']) && !empty($v_ref[0]['c_id'])) {
          $retur = $v_ref[0];
        }else{
          $retur = false;
        }
        return $retur;
      }
    }
    public static function brand($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("brand");
      $group = hdev_log::gid();
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE b_name !='' AND b_status=1");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE b_name !='' AND b_status != 2");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "active_count") {
        $v_ref = $rt->select("SELECT count(*) as all_rec FROM $tab WHERE b_name !='' AND b_status = 1");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }elseif (isset($param[0]) && $param[0] == "delete") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE b_name !='' AND b_status = 0 ");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "delete_count") {
        $v_ref = $rt->select("SELECT count(*) as all_rec FROM $tab WHERE b_name !='' AND b_status = 0");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }
      elseif (isset($param[0]) && $param[0] == "exist") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE b_id = :b_id AND b_status=1",[[":b_id",$l_id]]);
        if (isset($v_ref[0]['b_id']) && !empty($v_ref[0]['b_id'])) {
          $retur = "yes";
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE b_id = :b_id",[[":b_id",$l_id]]);
        if (isset($v_ref[0]['b_id']) && !empty($v_ref[0]['b_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "valid") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE b_id = :b_id AND b_status=1");
        if (isset($v_ref[0]['b_id']) && !empty($v_ref[0]['b_id'])) {
          $retur = $v_ref[0];
        }else{
          $retur = false;
        }
        return $retur;
      }
    }  
    public static function cart($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("cart");
      $me = hdev_log::me();
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE cart_id !='' AND cart_request = :me",[[':me',$me]]);
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "product") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE cart_id !='' AND cart_request = :me AND cart_type='product'",[[':me',$me]]);
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "product_sum") {
        $retur['sm_price'] = 0;
        $v_ref = $rt->select("SELECT SUM(cart_price*cart_qty) AS sm_price FROM $tab WHERE cart_id !='' AND cart_request = :me AND cart_type='product'",[[':me',$me]]);
        if (isset($v_ref[0]['sm_price']) && !empty($v_ref[0]['sm_price'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "room") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE cart_id !='' AND cart_request = :me AND cart_type='room'",[[':me',$me]]);
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "room_sum") {
        $retur['sm_price'] = 0;
        $v_ref = $rt->select("SELECT SUM(cart_price*cart_qty) AS sm_price FROM $tab WHERE cart_id !='' AND cart_request = :me AND cart_type='room'",[[':me',$me]]);
        if (isset($v_ref[0]['sm_price']) && !empty($v_ref[0]['sm_price'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE cart_id = :cart_id",[[":cart_id",$l_id]]);
        if (isset($v_ref[0]['cart_id']) && !empty($v_ref[0]['cart_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }
    } 
    public static function order($l_id="",$param=[1])
    {
      $start = hdev_session::get('start');
      $end = hdev_session::get('end');
      $cm_id = hdev_session::get('cm_id');
      if ((empty($start) || empty($end) || $start == "" || $end == "") || $end < $start) {
          $start = date('Y-m-d');
          $end = date('Y-m-d');
      }

      $rt = new hdev_db();
      $tab = $rt->table("order");
      $me = hdev_log::me();
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE o_id !='' AND (reg_date LIKE CONCAT(:endd, '%') OR reg_date LIKE CONCAT(:start, '%') OR reg_date BETWEEN :start AND :endd)",[[':start',$start],[':endd',$end]]);
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "product") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE o_id !='' AND cart_type='product'");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "room") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE o_id !='' AND cart_type='room'");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE o_id = :o_id",[[":o_id",$l_id]]);
        if (isset($v_ref[0]['o_id']) && !empty($v_ref[0]['o_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "hash") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE o_hash = :o_id",[[":o_id",$l_id]]);
        if (isset($v_ref[0]['o_id']) && !empty($v_ref[0]['o_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }
    }
    public static function product_report($l_id="",$param=[1])
    {
      $start = hdev_session::get('start');
      $end = hdev_session::get('end');
      $cm_id = hdev_session::get('cm_id');
      if ((empty($start) || empty($end) || $start == "" || $end == "") || $end < $start) {
          $start = date('Y-m-d');
          $end = date('Y-m-d');
      }

      $rt = new hdev_db();
      $tab = $rt->table("product_order");
      $me = hdev_log::me();
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE po_id !='' AND (po_reg_date LIKE CONCAT(:endd, '%') OR po_reg_date LIKE CONCAT(:start, '%') OR po_reg_date BETWEEN :start AND :endd)",[[':start',$start],[':endd',$end]]);
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "sum") {
        $retur['sm_price'] = 0;
        $retur['sm_qty'] = 0;
        $v_ref = $rt->select("SELECT SUM(po_qty) AS sm_qty, SUM(po_price*po_qty) AS sm_price FROM $tab WHERE (po_reg_date LIKE CONCAT(:endd, '%') OR po_reg_date LIKE CONCAT(:start, '%') OR po_reg_date BETWEEN :start AND :endd)",[[':start',$start],[':endd',$end]]);
        if (isset($v_ref[0]['sm_qty']) && !empty($v_ref[0]['sm_qty'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "order") {
        $retur = array();
        $v_ref = $rt->select("SELECT * FROM $tab WHERE o_id = :o_id",[[":o_id",$l_id]]);
        if (isset($v_ref[0]['po_id']) && !empty($v_ref[0]['po_id'])) {
          $retur = $v_ref;
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "order_sum") {
        $retur['sm_price'] = 0;
        $v_ref = $rt->select("SELECT SUM(po_price*po_qty) AS sm_price FROM $tab WHERE o_id = :o_id",[[":o_id",$l_id]]);
        if (isset($v_ref[0]['sm_price']) && !empty($v_ref[0]['sm_price'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE po_id = :po_id",[[":po_id",$l_id]]);
        if (isset($v_ref[0]['po_id']) && !empty($v_ref[0]['po_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }
    }   
    public static function room_report($l_id="",$param=[1])
    {
      $start = hdev_session::get('start');
      $end = hdev_session::get('end');
      $cm_id = hdev_session::get('cm_id');
      if ((empty($start) || empty($end) || $start == "" || $end == "") || $end < $start) {
          $start = date('Y-m-d');
          $end = date('Y-m-d');
      }

      $rt = new hdev_db();
      $tab = $rt->table("room_order");
      $me = hdev_log::me();
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE ro_id !='' AND (ro_reg_date LIKE CONCAT(:endd, '%') OR ro_reg_date LIKE CONCAT(:start, '%') OR ro_reg_date BETWEEN :start AND :endd)",[[':start',$start],[':endd',$end]]);
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "sum") {
        $retur['sm_price'] = 0;
        $v_ref = $rt->select("SELECT SUM(ro_days*ro_unit_price) AS sm_price FROM $tab WHERE (ro_reg_date LIKE CONCAT(:endd, '%') OR ro_reg_date LIKE CONCAT(:start, '%') OR ro_reg_date BETWEEN :start AND :endd)",[[':start',$start],[':endd',$end]]);
        if (isset($v_ref[0]['sm_price']) && !empty($v_ref[0]['sm_price'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "order") {
        $retur = array();
        $v_ref = $rt->select("SELECT * FROM $tab WHERE o_id = :o_id",[[":o_id",$l_id]]);
        if (isset($v_ref[0]['ro_id']) && !empty($v_ref[0]['ro_id'])) {
          $retur = $v_ref;
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "order_sum") {
        $retur['sm_price'] = 0;
        $v_ref = $rt->select("SELECT SUM(ro_days*ro_unit_price) AS sm_price FROM $tab WHERE o_id = :o_id",[[":o_id",$l_id]]);
        if (isset($v_ref[0]['sm_price']) && !empty($v_ref[0]['sm_price'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE ro_id = :ro_id",[[":ro_id",$l_id]]);
        if (isset($v_ref[0]['ro_id']) && !empty($v_ref[0]['ro_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }
    }


    /*----------------------stock management-------------------------*/
    public static function stock_in($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("stock_in");
      $group = hdev_log::gid();
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE sin_id !='' AND sin_status=1 ");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE sin_id !='' AND sin_status != 2 ");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "active_count") {
        $v_ref = $rt->select("SELECT count(*) as all_rec FROM $tab WHERE sin_id !='' AND sin_status = 1 ");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }elseif (isset($param[0]) && $param[0] == "approve") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE sin_id !='' AND sin_status = 2 ");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "approve_count") {
        $v_ref = $rt->select("SELECT count(*) as all_rec FROM $tab WHERE sin_id !='' AND sin_status = 2 ");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }elseif (isset($param[0]) && $param[0] == "delete") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE sin_id !='' AND sin_status = 0 ");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "delete_count") {
        $v_ref = $rt->select("SELECT count(*) as all_rec FROM $tab WHERE sin_id !='' AND sin_status = 0 ");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }
      elseif (isset($param[0]) && $param[0] == "exist") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE sin_id = :sin_id AND sin_status=1 ",[[":p_id",$l_id]]);
        if (isset($v_ref[0]['sin_id']) && !empty($v_ref[0]['sin_id'])) {
          $retur = "yes";
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE sin_id = :sin_id ",[[":sin_id",$l_id]]);
        if (isset($v_ref[0]['sin_id']) && !empty($v_ref[0]['sin_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "valid") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE sin_id = :sin_id AND sin_status=1",[[":sin_id",$l_id]]);
        if (isset($v_ref[0]['sin_id']) && !empty($v_ref[0]['sin_id'])) {
          $retur = $v_ref[0];
        }else{
          $retur = false;
        }
        return $retur;
      }
    }  
    public static function stock_out($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("stock_out");
      $group = hdev_log::gid();
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE sout_id !='' AND sout_status=1");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE sout_id !='' AND sin_status != 2");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "active_count") {
        $v_ref = $rt->select("SELECT count(*) as all_rec FROM $tab WHERE sout_id !='' AND sout_status = 1");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }elseif (isset($param[0]) && $param[0] == "approve") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE sin_id !='' AND sout_status = 2");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "approve_count") {
        $v_ref = $rt->select("SELECT count(*) as all_rec FROM $tab WHERE sout_id !='' AND sout_status = 2");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }elseif (isset($param[0]) && $param[0] == "delete") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE sout_id !='' AND sout_status = 0");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "delete_count") {
        $v_ref = $rt->select("SELECT count(*) as all_rec FROM $tab WHERE sout_id !='' AND sout_status = 0");
        $ret = ($v_ref[0]["all_rec"] > 0) ? $v_ref[0]["all_rec"] : "" ;
        return $ret;
      }
      elseif (isset($param[0]) && $param[0] == "exist") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE sout_id = :sout_id AND sout_status=1",[[":p_id",$l_id]]);
        if (isset($v_ref[0]['sout_id']) && !empty($v_ref[0]['sout_id'])) {
          $retur = "yes";
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE sout_id = :sout_id",[[":sout_id",$l_id]]);
        if (isset($v_ref[0]['sout_id']) && !empty($v_ref[0]['sout_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "valid") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE sin_id = :sin_id AND sin_status=1",[[":sin_id",$l_id]]);
        if (isset($v_ref[0]['sin_id']) && !empty($v_ref[0]['sin_id'])) {
          $retur = $v_ref[0];
        }else{
          $retur = false;
        }
        return $retur;
      }
    }       
    public static function in_stock($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("stock_detail");
      $group = hdev_log::gid();
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT p_id,SUM(qty_balance) AS qty FROM `$tab` WHERE qty_balance > 0 AND product_exp_date >= CURRENT_DATE()  GROUP BY p_id ORDER BY p_id");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == 'external') {
        $group = trim(hdev_session::get('stock'));
        $v_ref = $rt->select("SELECT p_id,SUM(qty_balance) AS qty FROM `$tab` WHERE qty_balance > 0 AND product_exp_date >= CURRENT_DATE()  GROUP BY p_id ORDER BY p_id");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "details") {
        $v_ref = $rt->select("SELECT * FROM `$tab` WHERE qty_balance > 0 AND product_exp_date >= CURRENT_DATE()  GROUP BY p_id ORDER BY p_id");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "stock") {
        $v_ref = $rt->select("SELECT * FROM `$tab` WHERE qty_balance > 0 AND product_exp_date >= CURRENT_DATE()  AND p_id=:p_id ORDER BY sin_reg_date ASC",[['p_id',$l_id]]);
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "data" ) {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE sin_id = :sin_id AND product_exp_date >= CURRENT_DATE() ",[[":sin_id",$l_id]]);
        if (isset($v_ref[0]['sin_id']) && !empty($v_ref[0]['sin_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      } 
    }
    public static function report($l_id="",$param=[1])
    {
      $start = hdev_session::get('start');
      $end = hdev_session::get('end');
      $cm_id = hdev_session::get('cm_id');
      if ((empty($start) || empty($end) || $start == "" || $end == "") || $end < $start) {
          $start = date('Y-m-d');
          $end = date('Y-m-d');
      }
      $rt = new hdev_db();
      $tab = $rt->table("stock_detail");
      $group = hdev_log::gid();
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT a.p_id,b.p_name,SUM(a.sout_qty) AS qty,SUM(a.price_unit*a.sout_qty) as buy_price,SUM(a.sell_price_unit*a.sout_qty) as sell_price,(SUM(a.sell_price_unit*a.sout_qty)-SUM(a.price_unit*a.sout_qty)) AS income FROM `stock_status` a INNER JOIN h_products b ON(a.p_id=b.p_id) WHERE a.sout_reg_date BETWEEN :start AND :endd GROUP BY a.p_id",[[':start',$start],[':endd',$end]]);
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "sum") {
        $v_ref = $rt->select("SELECT SUM(a.sout_qty) AS qty,SUM(a.price_unit*a.sout_qty) as buy_price,SUM(a.sell_price_unit*a.sout_qty) as sell_price,(SUM(a.sell_price_unit*a.sout_qty)-SUM(a.price_unit*a.sout_qty)) AS income FROM `stock_status` a INNER JOIN h_products b ON(a.p_id=b.p_id) WHERE a.sout_reg_date BETWEEN :start AND :endd",[[':start',$start],[':endd',$end]]);
        $retur['qty'] = '0';
        $retur['buy_price'] = '0';
        $retur['sell_price'] = '0';
        $retur['income'] = '0';

        if (!is_null($v_ref) && is_array($v_ref) && isset($v_ref[0]) && isset($v_ref[0]['qty']) && !empty($v_ref[0]['qty'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }
    }    
    public static function warning($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("stock_detail");
      $group = hdev_log::gid();
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 'warn_exp') {
        $v_ref = $rt->select("SELECT a.*,b.p_name,b.p_unit FROM `stock_detail_transactions` a INNER JOIN h_products b ON (a.p_id=b.p_id) where a.product_exp_date BETWEEN CURRENT_DATE() AND ADDDATE(CURRENT_DATE(), INTERVAL 3 DAY) AND a.qty_balance > 0");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == 'exp_products') {
        $v_ref = $rt->select("SELECT a.*,b.p_name,b.p_unit FROM `stock_detail_transactions` a INNER JOIN h_products b ON (a.p_id=b.p_id) where a.product_exp_date < CURRENT_DATE() AND a.qty_balance > 0");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == 'warn_exp_count') {
        $v_ref = $rt->select("SELECT a.*,b.p_name,b.p_unit FROM `stock_detail_transactions` a INNER JOIN h_products b ON (a.p_id=b.p_id) where a.product_exp_date BETWEEN CURRENT_DATE() AND ADDDATE(CURRENT_DATE(), INTERVAL 3 DAY) AND a.qty_balance > 0 GROUP BY a.p_id");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == 'exp_products_count') {
        $v_ref = $rt->select("SELECT a.*,b.p_name,b.p_unit FROM `stock_detail_transactions` a INNER JOIN h_products b ON (a.p_id=b.p_id) where a.product_exp_date < CURRENT_DATE() AND a.qty_balance > 0 GROUP BY a.p_id");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "warn_out") {
        $v_ref = $rt->select("SELECT a.p_id,b.p_unit,b.p_name,SUM(a.qty_balance) AS qty_balance FROM `$tab` a INNER JOIN h_products b ON(a.p_id=b.p_id) WHERE a.qty_balance <= 10 and qty_balance > 0 GROUP BY b.p_id ORDER BY b.p_id");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "out_products") {
        $v_ref = $rt->select("SELECT a.p_id,b.p_unit,b.p_name,SUM(a.qty_balance) AS qty_balance FROM `$tab` a INNER JOIN h_products b ON(a.p_id=b.p_id) WHERE a.qty_balance <= 0 GROUP BY b.p_id ORDER BY b.p_id");
        return $v_ref;
      }
    }                                           
  }
?>