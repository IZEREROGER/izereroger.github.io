<?php 
	$rasms_service = array( 
	/* ALL REQUEST ACCESS */ 
	'login' => array(
		'name'=>"Access to login",
		'error'=>"Access denied to you to login"
		),
	'send_reset_code' => array(
		'name'=>"Access to login",
		'error'=>"Access denied to you to login"
		),	
	'enter_code' => array(
		'name'=>"Access to login",
		'error'=>"Access denied to you to login"
		),		
	'reset_password' => array(
		'name'=>"Access to login",
		'error'=>"Access denied to you to login"
		),		
	'user_edit' => array(
		'name'=>"Access to Edit User",
		'error'=>"Access denied to you to Edit User"
		),	
	'self_change_user_pwd' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),
	'category_reg' => array(
		'name'=>"Access to register cooperative product",
		'error'=>"Access denied to you to register cooperative product"
		),	
	'category_edit' => array(
		'name'=>"Access to edit cooperative product",
		'error'=>"Access denied to you to edit cooperative product"
		),	
	'category_delete' => array(
		'name'=>"Access to delete cooperative product",
		'error'=>"Access denied to you to delete cooperative product"
		),	
	'category_recover' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),		
	'brand_reg' => array(
		'name'=>"Access to register cooperative product",
		'error'=>"Access denied to you to register cooperative product"
		),	
	'brand_edit' => array(
		'name'=>"Access to edit cooperative product",
		'error'=>"Access denied to you to edit cooperative product"
		),	
	'brand_delete' => array(
		'name'=>"Access to delete cooperative product",
		'error'=>"Access denied to you to delete cooperative product"
		),	
	'brand_recover' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),				
	'products_reg' => array(
		'name'=>"Access to register cooperative product",
		'error'=>"Access denied to you to register cooperative product"
		),	
	'products_edit' => array(
		'name'=>"Access to edit cooperative product",
		'error'=>"Access denied to you to edit cooperative product"
		),	
	'products_delete' => array(
		'name'=>"Access to delete cooperative product",
		'error'=>"Access denied to you to delete cooperative product"
		),	
	'products_recover' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),	
	'rooms_reg' => array(
		'name'=>"Access to register cooperative product",
		'error'=>"Access denied to you to register cooperative product"
		),	
	'rooms_edit' => array(
		'name'=>"Access to edit cooperative product",
		'error'=>"Access denied to you to edit cooperative product"
		),	
	'rooms_delete' => array(
		'name'=>"Access to delete cooperative product",
		'error'=>"Access denied to you to delete cooperative product"
		),	
	'rooms_recover' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),		
	'add_to_cart' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),
	'edit_to_cart' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),	
	'count_cart' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),	
	'cart_items' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),
	'cart_delete' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),	
	'generate_receipt' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),	
	'tools_reg' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),	
	'tools_edit' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),	
	'tools_delete' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),	
	'tools_recover' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),						
	/*----------- stock system ------------*/
	'stock_in' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),		
	'stock_in_bind' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),		
	'stock_out' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),	
	'stock_in_edit' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),	
	'stock_in_delete' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),	
	'stock_in_recover' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),
	'stock_out_delete' => array(
		'name'=>"Access to recover cooperative member",
		'error'=>"Access denied to you to recover cooperative product"
		),																										
	);

	//$all_services = array_keys($rasms_service);
	//$tg = "";
	//foreach ($all_services as $key) {
	//	if ($key == "stud_delete") {
	//		$tg = 9;
	//	}
	//	if ($tg == '') {
	//		echo "'".$key."' /*".$rasms_service[$key]['name']."*/,\n";
	//	}
	//	
	//}exit();
	//$pts = implode(",", $all_services);

	//echo $pts."<br><br><br><br><br><br><br>";
	//print_r($all_services);

	$rasms_service_users = array(
		'guest'=>array(
			'enter_code',
			'reset_password',
			'send_reset_code',
			'login' /*Access to login*/,
			'location_select'/** access to select locations in ajax*/,
		),
		'admin'=> array( //// was admin
			'login' /*Access to login*/,
			'send_reset_code' /*Access to login*/,
			'enter_code' /*Access to login*/,
			'reset_password' /*Access to login*/,
			'user_edit' /*Access to Edit User*/,
			'self_change_user_pwd' /*Access to Change user password*/,
			'category_reg' /*Access to register cooperative product*/,
			'category_edit' /*Access to edit cooperative product*/,
			'category_delete' /*Access to delete cooperative product*/,
			'category_recover' /*Access to recover cooperative member*/,	
			'brand_reg' /*Access to register cooperative product*/,
			'brand_edit' /*Access to edit cooperative product*/,
			'brand_delete' /*Access to delete cooperative product*/,
			'brand_recover' /*Access to recover cooperative member*/,					
			'products_reg' /*Access to register cooperative product*/,
			'products_edit' /*Access to edit cooperative product*/,
			'products_delete' /*Access to delete cooperative product*/,
			'products_recover' /*Access to recover cooperative member*/,
			'rooms_reg' /*Access to register cooperative product*/,
			'rooms_edit' /*Access to edit cooperative product*/,
			'rooms_delete' /*Access to delete cooperative product*/,
			'rooms_recover' /*Access to recover cooperative member*/,			
			'add_to_cart',
			'edit_to_cart',
			'count_cart',
			'cart_items',
			'cart_delete',
			'generate_receipt',
			'tools_reg',
			'tools_edit',
			'tools_delete',
			'tools_recover',
			/*------------- stock system -----*/
			'sales_view',			
			//'sales_delete',
			'sales_recover',
			'sales_approve',
			'sales_reject',
			'sales_delete_approve',
			'sales_delete_reject',
			'stock_in',
			'stock_in_bind',
			'stock_out',
			'stock_in_edit',
			'stock_in_delete',
			'stock_in_recover',
			'stock_out_delete',
		),
		'manager'=> array( //// was admin
			'login' /*Access to login*/,
			'send_reset_code' /*Access to login*/,
			'enter_code' /*Access to login*/,
			'reset_password' /*Access to login*/,
			'user_edit' /*Access to Edit User*/,
			'self_change_user_pwd' /*Access to Change user password*/,
			'category_reg' /*Access to register cooperative product*/,
			'category_edit' /*Access to edit cooperative product*/,
			'category_delete' /*Access to delete cooperative product*/,
			'category_recover' /*Access to recover cooperative member*/,	
			'brand_reg' /*Access to register cooperative product*/,
			'brand_edit' /*Access to edit cooperative product*/,
			'brand_delete' /*Access to delete cooperative product*/,
			'brand_recover' /*Access to recover cooperative member*/,					
			'products_reg' /*Access to register cooperative product*/,
			'products_edit' /*Access to edit cooperative product*/,
			'products_delete' /*Access to delete cooperative product*/,
			'products_recover' /*Access to recover cooperative member*/,
			'count_cart',
			'cart_items',
			'cart_delete',
			'generate_receipt',
			'tools_reg',
			'tools_edit',
			'tools_delete',
			'tools_recover',
			/*------------- stock system -----*/
			'sales_view',			
			//'sales_delete',
			'sales_recover',
			'sales_approve',
			'sales_reject',
			'sales_delete_approve',
			'sales_delete_reject',
			'stock_in',
			'stock_in_bind',
			'stock_out',
			'stock_in_edit',
			'stock_in_delete',
			'stock_in_recover',
			'stock_out_delete',
		),		
	);
 ?>