<?php  
	define('base_path', '/hotel/');
	define("APP_NAME", "E-HOTEL");
	define('APP_MASK', 'E-HOTEL');
	define("district", "Kicukiro District");
	define('tel', '0788888888');
	define('currency', 'Frw');
	define('working_dev','dev');//prod in production // dev in development
	define('type', 'no');//secure in production // no in development

	define('APP_PREFIX', 'JNV-pay');
	define('SMS_SENDER', '');
	define('SMS_USERNAME', '');
	define('SMS_PASSWORD', '');
	define("APP_VERSION", "1.1");
	define('APP_PROGRAMMER', ['name'=>'Marie Curie','email'=>'me@gmail.com']);
	define('APP_SQLITE_DB',"janvier");


	define('dbhost',"localhost");
	define('db',"hdev_hotel");
	define('db_preview',"hdev_hotel");
	define('dbpass_preview', '');
	define('dbusr_preview', 'root');	
	define('dbpass', '');
	define('dbusr', 'root');
	define('dbport', '3306');
	define('dbport_preview', '3306');
	define('db_remote', 'st_soft');
	define('dbusr_remote', 'roger');	
	define('dbpass_remote', 'qwe');
	define('dbport_remote', '3309');

	/*define('dbhost',"bugbilbqalmry3wgxvwr-mysql.services.clever-cloud.com");
	define('db',"bugbilbqalmry3wgxvwr");
	define('db_preview',"bugbilbqalmry3wgxvwr");
	define('dbpass_preview', '64nYkgG3TXaRBLyMaoJh');
	define('dbusr_preview', 'uoxzlrkzagzji9m9');	
	define('dbpass', '64nYkgG3TXaRBLyMaoJh');
	define('dbusr', 'uoxzlrkzagzji9m9');
	define('dbport', '3306');
	define('dbport_preview', '3306');
	define('db_remote', 'st_soft');
	define('dbusr_remote', 'roger');	
	define('dbpass_remote', 'qwe');
	define('dbport_remote', '3309');*/
	//error_reporting(0);
 ?>