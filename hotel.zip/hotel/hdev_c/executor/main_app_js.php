<?php
//header('Content-type: script/javascript');
$script = array(
  "plugins/bootstrap/js/bootstrap.bundle.js",
  "plugins/pace-progress/pace.js",
  "plugins/overlayScrollbars/js/jquery.overlayScrollbars.js",
  "dist/js/adminlte.js",
  /*"dist/js/demo.js",*/
  "plugins/datatables/jquery.dataTables.js",
  "plugins/datatables-bs4/js/dataTables.bootstrap4.js",
  "plugins/datatables-responsive/js/dataTables.responsive.js",
  "plugins/datatables-responsive/js/responsive.bootstrap4.js",
  "plugins/datatables-buttons/js/dataTables.buttons.js",
  "plugins/datatables-buttons/js/buttons.bootstrap4.js",
  "plugins/datatables-fixedcolumns/js/dataTables.fixedColumns.js",
  "plugins/jszip/jszip.js",
  "plugins/pdfmake/pdfmake.js",
  "plugins/pdfmake/vfs_fonts.js",
  "plugins/datatables-buttons/js/buttons.html5.js",
  "plugins/datatables-buttons/js/buttons.print.js",
  "plugins/datatables-buttons/js/buttons.colVis.js",
  "plugins/bs-stepper/js/bs-stepper.js",
  "plugins/ajax/sl.js",
  "plugins/ajax/former.js",
); 
/**
 * js require
 */
class hdev_js
{
  
  public static function disp($script=array())
  {
      $r2 = getcwd().DIRECTORY_SEPARATOR;
      foreach ($script as $js) {
        $js_full = hdev_url::menu($js);
        echo "dynamicallyLoadScript('".$js_full."');";
      }
  }
}
?>
function dynamicallyLoadScript(url) {
    var script = document.createElement("script");
    script.src = url;
    document.body.appendChild(script);
}
<?php
hdev_js::disp($script);
 ?>