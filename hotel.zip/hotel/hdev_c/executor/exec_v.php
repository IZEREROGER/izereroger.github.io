<?php  
	//sleep(5);
	if ($_POST) {
		//var_dump($_POST);
		if (!empty($_POST['ref'])) { 
			$rasms_stc = new hdev_auth_service('',trim($_POST['ref']));
			if ($rasms_stc->access()) {
				/// access granted 
			}else{
			  $rasms_stc->error('danger');
			}

  		switch ($_POST['ref']) {
  			case 'login':
  				
				if (!empty($_POST['usn']) && !empty($_POST['psw'])) {
					hdev_v::login($_POST["usn"],$_POST['psw']);
				}else{
					hdev_note::message(hdev_lang::on("validation","log_fair"));
	        		//hdev_note::redirect(hdev_url::get_url_host()."/h/login");
				}
 
			break;
			case 'location_select':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest($_POST['cover']);
				if (isset($_POST['type']) && !empty($_POST['type'])) {
      				switch ($_POST['type']) {
      					case 'district':
      						$province = (isset($_POST['prov'])) ? $_POST['prov'] : "" ;
      						echo hdev_data::locations("district",$province);
      					break;
      					case 'sector':
      						$province = (isset($_POST['prov'])) ? $_POST['prov'] : "" ;
      						$district = (isset($_POST['dist'])) ? $_POST['dist'] : "" ;
      						echo hdev_data::locations("sector",$province,$district);
      					break;
						case 'cell':
      						$province = (isset($_POST['prov'])) ? $_POST['prov'] : "" ;
      						$district = (isset($_POST['dist'])) ? $_POST['dist'] : "" ;
							$sector = (isset($_POST['sect'])) ? $_POST['sect'] : "" ;
      						echo hdev_data::locations("cell",$province,$district,$sector);
      					break;
      					case 'village':
      						$province = (isset($_POST['prov'])) ? $_POST['prov'] : "" ;
      						$district = (isset($_POST['dist'])) ? $_POST['dist'] : "" ;
							$sector = (isset($_POST['sect'])) ? $_POST['sect'] : "" ;  
      						$cell = (isset($_POST['cell'])) ? $_POST['cell'] : "" ;
      						echo hdev_data::locations("village",$province,$district,$sector,$cell);
      					break;
      					default:
      						echo "<option>Try again!</option>";
      					break;
      				}
      				
				}else{
					echo "all fields are required";
				}
			break;
			case 'send_reset_code':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['tell'])) {
					$tel = $_POST['tell'];
					if (hdev_data::phone_valid($tel)) {
      					exit(hdev_data::phone_valid($tel));
      				}
					$user = hdev_data::get_admin($tel,['tel']);
					$send_code = 0;
					if (is_array($user) && count($user) > 0) {
						$code = rand();
						$mask1 = time();
						$sent = md5($code.$mask1);
						$sent_og = strtoupper(substr($sent, 0, 6));
						//$sent_og = 1234;

						$code2 = $csrf->getToken();
						$mask2 = $sent_og.'-'.$code2.'-'.$tel;
						$mask = md5($mask2);
						$stmg = "Your Reset Code Is: ".$sent_og;
						hdev_note::live_sms($tel,$stmg);
						$send_code = 1;

					}
					if ($send_code == 1) {
						$return['act'] = "success";
						$return['message'] = "Code Sent to: ".$tel;
						$return['mask'] = $mask;
						$return['tel'] = $tel;
					}else{
						$return['act'] = "error";
						$return['message'] = "Something went Wrong Try again later";
					}
      				echo json_encode($return);
				}else{
					$return['act'] = "error";
					$return['message'] = "Telephone number can't be empty";
					echo json_encode($return);
				}
			break;	
			case 'enter_code':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['mask']) && !empty($_POST['tel']) && !empty($_POST['code'])) {
					$mask = $_POST['mask'];
					$code = $_POST['code'];
					$tel = $_POST['tel'];

					$sent_og = strtoupper(trim($code));
					$code2 = $csrf->getToken();
					$mask2 = $sent_og.'-'.$code2.'-'.$tel;
					$mask_code = md5($mask2);


					if ($mask_code == $mask) {
						$user = hdev_data::get_admin($tel,['tel']);
						$profiles = "";
						foreach ($user as $users) {
							$profiles .= '<option value="'.$users['u_id'].'">'.$users['email'].'</option>';
						}
						if ($profiles != "") {
							$return['act'] = "success";
							$return['message'] = "Entered Code Validated !";
							$return['profiles'] = $profiles;
							$return['mask2'] = $mask.'-'.$code;
							$return['tel'] = $tel;
						}else{
							$return['act'] = "error";
							$return['message'] = "Something went Wrong Try again later";
						}
					}else{
						$return['act'] = "error";
						$return['message'] = "Code Entered is invalid or expired.";
					}
      				echo json_encode($return);
				}else{
					$return['act'] = "error";
					$return['message'] = "All Fields are required";
					echo json_encode($return);
				}
			break;	
			case 'reset_password':
					//var_dump($_POST);
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['mask']) && !empty($_POST['tel']) && !empty($_POST['user']) && !empty($_POST['pass_1']) && !empty($_POST['pass_2'])) {
					$mask = $_POST['mask'];
					$tel = $_POST['tel'];
					$user = $_POST['user'];
					$pass_1 = $_POST['pass_1'];
					$pass_2 = $_POST['pass_2'];

					$mask_part = explode('-', $mask);
					if (isset($mask_part[0]) && isset($mask_part[1])) {
						$code = $mask_part[1];
						$mask = $mask_part[0];
					}else{
						$code = 0;
						$mask = 1;
					}

					$sent_og = strtoupper(trim($code));
					$code2 = $csrf->getToken();
					$mask2 = $sent_og.'-'.$code2.'-'.$tel;
					$mask_code = md5($mask2);


					if ($mask_code == $mask) {
						if ($pass_1 == $pass_2) {
							$rt = new hdev_db();
							$tab = $rt->table('all_users');
							$password = hdev_data::password_enc($pass_1);
							$ck = $rt->insert("UPDATE `$tab` SET `password` = :password WHERE `u_id` = :a_id AND `tel` = :tel",[[':tel',$tel],[':a_id',$user],[':password',$password]]);
							
						}else{
							$ck = "no";
							$pw = 1;
						}
      					if ($ck == "ok") {
							$return['act'] = "success";
							//$return['user'] = $user;
							$return['message'] = "Password For: [".$tel."] changed succesfull, You can now log in with the new password.";
							//$csrf->up_tk();
						}else{
							$return['act'] = "error";
							$return['message'] = (isset($pw)) ? "two passwords doesn't match" : 'Something went Wrong Try again later' ;;
						}
					}else{
						$return['act'] = "error";
						$return['message'] = "Code Entered is invalid or expired.";
					}
      				echo json_encode($return);
				}else{
					//var_dump($_POST);
					$return['act'] = "error";
					$return['message'] = "All Fields are required";
					echo json_encode($return);
				}
			break;
			case 'add_to_cart':
				//$csrf = new CSRF_Protect();
    			//$csrf->verifyRequest();
				if (!empty($_POST['type']) && !empty($_POST['ref_id']) && !empty($_POST['price']) && !empty($_POST['qty'])) {

					$type = $_POST['type'];
					$ref_id = $_POST['ref_id'];
					$price = $_POST['price'];
					$qty = $_POST['qty'];
					$ext = $_POST['ext'];
					if ($type == "room" && empty($ext)) {
						exit("Please Room number is required");
					}
					$me = hdev_log::me();
					$rt = new hdev_db();
      				$tab = $rt->table("cart"); 

      				$ck = $rt->insert("INSERT INTO `$tab` (`cart_id`, `cart_type`, `cart_ref_id`, `cart_qty`, `cart_price`, `cart_request`, `ext_info`) VALUES (NULL, :type, :ref_id, :qty, :price, :me, :ext)",[[':qty',$qty],[':type',$type],[':ref_id',$ref_id],[':price',$price],[':me',$me],[':ext',$ext]]);
      				if ($ck == "ok") {
      					//$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("New Room added to cart",$_POST['mod_close']);
      					}else{
      						hdev_note::success("New Room added to cart");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;
			case 'edit_to_cart':
				//$csrf = new CSRF_Protect();
    			//$csrf->verifyRequest();
				if (!empty($_POST['cart_id']) && !empty($_POST['qty']) && $_POST['qty'] > 0) {

					$type = $_POST['type'];
					$cart_id = $_POST['cart_id'];
					$qty = $_POST['qty'];

					$me = hdev_log::me();
					$rt = new hdev_db();
      				$tab = $rt->table("cart"); 

      				$ck = $rt->insert("UPDATE `$tab` SET `cart_qty` = :qty WHERE `cart_id` = :cart_id;",[[':qty',$qty],[':cart_id',$cart_id]]);
      				if ($ck == "ok") {
      					//$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("cart updated",$_POST['mod_close']);
      					}else{
      						hdev_note::success("cart updated");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;			
			case 'count_cart':
				echo count(hdev_data::cart());	
			break;
			case 'cart_items':
				$data = '
				<h4 class="header">Products in cart</h4>
                <div class="notifications-wrap">
                ';
               	foreach (hdev_data::cart('',['product']) as $product) {
	                $data .='
	                    <div href="#" class="media">
	                        <span class="d-flex">
	                            <i class="fa fa-luggage-cart"></i> 
	                        </span>
	                        <span class="media-body">
	                            <span class="heading-font-family media-heading">'.hdev_data::products($product['cart_ref_id'],['data'])['p_name'].'</span> 
	                            <span class="media-content">qty:'.$product['cart_qty'].', Price: '.($product['cart_qty']*$product['cart_price']).' Frw'.'</span>
	                        </span>
	                    </div>
	                ';
               	 	
               	 } 
               	 $data .='</div>';
				$data .= '
				<h4 class="header">Rooms in cart</h4>
                <div class="notifications-wrap">
                ';
               	foreach (hdev_data::cart('',['room']) as $room) {
	                $data .='
	                    <div href="#" class="media">
	                        <span class="d-flex">
	                            <i class="fa fa-home"></i> 
	                        </span>
	                        <span class="media-body">
	                            <span class="heading-font-family media-heading">'.$room['ext_info'].' room'.'</span> 
	                            <span class="media-content">Days:'.$room['cart_qty'].', Price: '.($room['cart_qty']*$room['cart_price']).' Frw'.'</span>
	                        </span>
	                    </div>
	                ';
               	 	
               	 } 
               	 $data .='<div class="footer"><a href="'.hdev_url::menu('product/cart').'"><span class="fa fa-eye"></span> See all Cart details <span class="fa fa-shopping-cart"></span></a></div></div>';   
               	 echo $data;
			break;
			case 'generate_receipt':
				//$csrf = new CSRF_Protect();
    			//$csrf->verifyRequest();
				if (!empty($_POST['hash']) && !empty($_POST['client_name'])) {

					$csrf = new CSRF_Protect();
    				$csrf->verifyRequest($_POST['hash']);	

    				$reff = hdev_data::tx_ref();
					$client_name = $_POST['client_name'];

					$me = hdev_log::me();
					$rt = new hdev_db();
      				$tab = $rt->table("order"); 

      				$ck = $rt->insert("INSERT INTO `$tab` (`o_id`, `client`, `reg_date`, `o_hash`) VALUES (NULL, :client_name, current_timestamp(), :reff)",[[':client_name',$client_name],[':reff',$reff]]);
      				if ($ck == "ok") {
      					$retur = hdev_data::order($reff,['hash']);
      					if (isset($retur['o_id'])) {
      						$o_id = $retur['o_id'];
      					}else{
      						echo hdev_lang::on("validation","error_try_again");
      						exit();
      					}
      					foreach (hdev_data::cart('',['product']) as $product) {

      						$p_id = $product['cart_ref_id'];
							$price = $product['cart_price'];
							$qty = $product['cart_qty'];

      						$tab = $rt->table("product_order");
      						$ck1 = $rt->insert("INSERT INTO `$tab` (`po_id`, `p_id`, `o_id`, `po_price`, `po_qty`, `po_status`, `po_reg_date`) VALUES (NULL, :p_id, :o_id, :price, :qty, '1', current_timestamp())",[[':p_id',$p_id],[':o_id',$o_id],[':price',$price],[':qty',$qty]]);
      						if ($ck1 == "ok") {
      							$cart_id = $product['cart_id'];
      							$tab = $rt->table("cart");
      							$ck3 = $rt->insert("DELETE FROM `$tab` WHERE `cart_id` = :cart_id",[[":cart_id",$cart_id]]);
      						}

      					}

      					foreach (hdev_data::cart('',['room']) as $room) {

      						$r_id = $room['cart_ref_id'];
							$price = $room['cart_price'];
							$qty = $room['cart_qty'];
							$ext = $room['ext_info'];

      						$tab = $rt->table("room_order");
      						$ck2 = $rt->insert("INSERT INTO `$tab` (`ro_id`, `o_id`, `r_id`, `ro_days`, `ro_unit_price`, `ro_reg_date`, `ro_status`, `ext_info`) VALUES (NULL, :o_id, :r_id, :qty, :price, current_timestamp(), '1', :ext)",[[':r_id',$r_id],[':o_id',$o_id],[':price',$price],[':qty',$qty],[':ext',$ext]]);
      						if ($ck2 == "ok") {
      							$cart_id = $room['cart_id'];
      							$tab = $rt->table("cart");
      							$ck4 = $rt->insert("DELETE FROM `$tab` WHERE `cart_id` = :cart_id",[[":cart_id",$cart_id]]);
      						}

      					}

      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::message('New Receipt Generated, Receipt_id:'.$o_id);
      						hdev_note::redirect(hdev_url::menu('order/'.$o_id.'/receipt'));
      						//hdev_note::success("New Receipt Generated, Receipt_id:".$o_id,$_POST['mod_close']);
      					}else{
      						hdev_note::message('New Receipt Generated, Receipt_id:'.$o_id);
      						hdev_note::redirect(hdev_url::menu('order/'.$o_id.'/receipt'));
      						//hdev_note::success("New Receipt Generated, Receipt_id:".$o_id);
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;
			case 'category_reg':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['c_name']) && !empty($_POST['c_desc'])) {

					$c_name = $_POST['c_name'];
					$c_desc = $_POST['c_desc'];
					$rt = new hdev_db();
      				$tab = $rt->table("category"); 

      				$ck = $rt->insert("INSERT INTO `$tab` (`c_id`, `c_name`, `c_desc`, `c_status`, `c_reg_date`) VALUES (NULL, :c_name, :c_desc, '1', current_timestamp());",[[':c_name',$c_name],[':c_desc',$c_desc]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("New category added successfully",$_POST['mod_close']);
      					}else{
      						hdev_note::success("New category added successfully");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;	
			case 'category_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['c_name']) && !empty($_POST['c_desc']) && !empty($_POST['c_id'])) {

					$c_name = $_POST['c_name'];
					$c_desc = $_POST['c_desc'];
					$c_id = $_POST['c_id'];
					$rt = new hdev_db();
      				$tab = $rt->table("category"); 

      				$ck = $rt->insert("UPDATE `$tab` SET `c_name` = :c_name, `c_desc` = :c_desc WHERE `c_id` = :c_id",[[':c_id',$c_id],[':c_name',$c_name],[':c_desc',$c_desc]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("category info updated successfully",$_POST['mod_close']);
      					}else{
      						hdev_note::success("category info updated successfully");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;	
			case 'brand_reg':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['c_name']) && !empty($_POST['c_desc'])) {

					$c_name = $_POST['c_name'];
					$c_desc = $_POST['c_desc'];
					$rt = new hdev_db();
      				$tab = $rt->table("brand"); 

      				$ck = $rt->insert("INSERT INTO `$tab` (`b_id`, `b_name`, `b_desc`, `b_status`, `b_reg_date`) VALUES (NULL, :c_name, :c_desc, '1', current_timestamp());",[[':c_name',$c_name],[':c_desc',$c_desc]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("New brand added successfully",$_POST['mod_close']);
      					}else{
      						hdev_note::success("New brand added successfully");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;	
			case 'brand_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['c_name']) && !empty($_POST['c_desc']) && !empty($_POST['c_id'])) {

					$c_name = $_POST['c_name'];
					$c_desc = $_POST['c_desc'];
					$c_id = $_POST['c_id'];
					$rt = new hdev_db();
      				$tab = $rt->table("brand"); 

      				$ck = $rt->insert("UPDATE `$tab` SET `b_name` = :c_name, `b_desc` = :c_desc WHERE `b_id` = :c_id",[[':c_id',$c_id],[':c_name',$c_name],[':c_desc',$c_desc]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("brand info updated successfully",$_POST['mod_close']);
      					}else{
      						hdev_note::success("brand info updated successfully");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;				
			case 'rooms_reg':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['r_name']) && !empty($_POST['r_price']) && !empty($_POST['r_desc']) && isset($_FILES['prod_pic']) && is_array($_FILES['prod_pic'])) {
					$r_name = $_POST['r_name'];
					$r_price = $_POST['r_price'];
					$r_desc = $_POST['r_desc'];

					$rt = new hdev_db();
      				$tab = $rt->table("rooms"); 
      				$user = hdev_log::uid();
					$up_files_array = $_FILES['prod_pic'];
      				$countfiles = count($up_files_array['name']);
					$files_array = array();
					for($i = 0;$i < $countfiles; $i++){
						if (file_exists($up_files_array["tmp_name"][$i])) {
							$file_type = $up_files_array["type"][$i]; //returns the mimetype
							$allowed = array("image/jpeg", "image/gif", "image/png");
							if(!in_array($file_type, $allowed)) {
							}else{
								$ckup="";
								// Check file size
								if ($up_files_array["size"][$i] > 50000000) {
								    $ckup = 1;
								}

								$fileData = pathinfo(basename($up_files_array["name"][$i]));
								$fileName = "Room"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
								$regpath = __DIR__;
								$target_path = getcwd()."\dist\img\products\\".$fileName;
								while(file_exists($target_path))
								{
								    $fileName = "Room"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
									$regpath = __DIR__;
									$target_path = getcwd()."\dist\img\products\\".$fileName;
								}
		 						if ($ckup == "") {
									if (move_uploaded_file($up_files_array["tmp_name"][$i], $target_path))
									{
										array_push($files_array, $fileName);
									}
								}
							}
						}
					}
					$reft = "";
					$exp = ".,*HDEV_prod*.,";
					foreach ($files_array as $key) {
						$reft .= $exp.$key;
					}
					if (strlen($reft) > strlen($exp)) {
						$reft = substr($reft, strlen($exp));
					}
					$upphoto = explode($exp, $reft);
					$var = count($upphoto);
					if (isset($upphoto) && !empty($upphoto) && $var >= 0 && isset($upphoto[0]) && !empty($upphoto[0]) && strlen($upphoto[0]) > 25) {
							$r_pic = $reft;

		      				$ck = $rt->insert("INSERT INTO `$tab` (`r_id`, `r_name`, `r_desc`, `r_price`, `r_pic`, `r_status`, `r_reg_date`) VALUES (NULL, :r_name, :r_desc, :r_price, :r_pic, '1', current_timestamp())",[[':r_name',$r_name],[':r_desc',$r_desc],[':r_price',$r_price],[':r_pic',$r_pic]]);
		      				if ($ck == "ok") {
		      					$csrf->up_tk();
		      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
		      						hdev_note::success("New Category added successfully",$_POST['mod_close']);
		      					}else{
		      						hdev_note::success("New Category added successfully");
		      					}
		      				}else{
		      					echo hdev_lang::on("validation","error_try_again");
		      				}
	      				}else{
	      					echo "something went wrong try again later";
	      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;				
			case 'rooms_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['r_id']) && !empty($_POST['r_name']) && !empty($_POST['r_price']) && !empty($_POST['r_desc'])) {
					$r_id = $_POST['r_id'];
					$r_name = $_POST['r_name'];
					$r_price = $_POST['r_price'];
					$r_desc = $_POST['r_desc'];

					$rt = new hdev_db();
      				$tab = $rt->table("rooms"); 
      				$user = hdev_log::uid();
      				if (isset($_FILES) && is_array($_FILES) && isset($_FILES['prod_pic']) && is_array($_FILES['prod_pic'])) {
      					$up_files_array = $_FILES['prod_pic'];
      					$countfiles = count($up_files_array['name']);
      				}else{
      					$up_files_array = array();
      					$countfiles = count($up_files_array);
      				}
					
					$files_array = array();
					for($i = 0;$i < $countfiles; $i++){
						if (file_exists($up_files_array["tmp_name"][$i])) {
							$file_type = $up_files_array["type"][$i]; //returns the mimetype
							$allowed = array("image/jpeg", "image/gif", "image/png");
							if(!in_array($file_type, $allowed)) {
							}else{
								$ckup="";
								// Check file size
								if ($up_files_array["size"][$i] > 50000000) {
								    $ckup = 1;
								}

								$fileData = pathinfo(basename($up_files_array["name"][$i]));
								$fileName = "Room"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
								$regpath = __DIR__;
								$target_path = getcwd()."\dist\img\products\\".$fileName;
								while(file_exists($target_path))
								{
								    $fileName = "Room"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
									$regpath = __DIR__;
									$target_path = getcwd()."\dist\img\products\\".$fileName;
								}
		 						if ($ckup == "") {
									if (move_uploaded_file($up_files_array["tmp_name"][$i], $target_path))
									{
										array_push($files_array, $fileName);
									}
								}
							}
						}
					}
					$reft = "";
					$exp = ".,*HDEV_prod*.,";
					foreach ($files_array as $key) {
						$reft .= $exp.$key;
					}
					if (strlen($reft) > strlen($exp)) {
						$reft = substr($reft, strlen($exp));
					}
					$upphoto = explode($exp, $reft);
					$var = count($upphoto);
					if (isset($upphoto) && !empty($upphoto) && $var >= 0 && isset($upphoto[0]) && !empty($upphoto[0]) && strlen($upphoto[0]) > 25) {
							$r_pic = $reft;
		      				$ck = $rt->insert("UPDATE `$tab` SET `r_name` = :r_name, `r_desc` = :r_desc , `r_price` = :r_price, `r_pic` = :r_pic WHERE `r_id` = :r_id",[[':r_id',$r_id],[':r_name',$r_name],[':r_desc',$r_desc],[':r_price',$r_price],[':r_pic',$r_pic]]);
		      				if ($ck == "ok") {
		      					$csrf->up_tk();
		      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
		      						hdev_note::success("Room info edited successfully. "."Reg. no. : ".$r_id,$_POST['mod_close']);
		      					}else{
		      						hdev_note::success("Room info edited successfully. "."Reg. no. : ".$r_id);
		      					}
		      				}else{
		      					echo hdev_lang::on("validation","error_try_again");
		      				}
	      				}else{
		      				$ck = $rt->insert("UPDATE `$tab` SET `r_name` = :r_name, `r_desc` = :r_desc , `r_price` = :r_price WHERE `r_id` = :r_id",[[':r_id',$r_id],[':r_name',$r_name],[':r_desc',$r_desc],[':r_price',$r_price]]);
		      				if ($ck == "ok") {
		      					$csrf->up_tk();
		      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
		      						hdev_note::success("Room info edited successfully. "."Reg. no. : ".$r_id,$_POST['mod_close']);
		      					}else{
		      						hdev_note::success("Room info edited successfully. "."Reg. no. : ".$r_id);
		      					}
		      				}else{
		      					echo hdev_lang::on("validation","error_try_again");
		      				}
	      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;		
			case 'products_reg':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['c_id']) && !empty($_POST['b_id']) && !empty($_POST['p_name']) && !empty($_POST['p_price']) && !empty($_POST['p_unit']) && !empty($_POST['p_desc']) && isset($_FILES['prod_pic']) && is_array($_FILES['prod_pic'])) {
					$c_id = $_POST['c_id'];
					$b_id = $_POST['b_id'];
					$p_name = $_POST['p_name'];
					$p_price = $_POST['p_price'];
					$p_unit = $_POST['p_unit'];
					$p_desc = $_POST['p_desc'];										
					$rt = new hdev_db();
      				$tab = $rt->table("products"); 
      				$user = hdev_log::uid();
					$up_files_array = $_FILES['prod_pic'];
      				$countfiles = count($up_files_array['name']);
					$files_array = array();
					for($i = 0;$i < $countfiles; $i++){
						if (file_exists($up_files_array["tmp_name"][$i])) {
							$file_type = $up_files_array["type"][$i]; //returns the mimetype
							$allowed = array("image/jpeg", "image/gif", "image/png");
							if(!in_array($file_type, $allowed)) {
							}else{
								$ckup="";
								// Check file size
								if ($up_files_array["size"][$i] > 50000000) {
								    $ckup = 1;
								}

								$fileData = pathinfo(basename($up_files_array["name"][$i]));
								$fileName = "Product"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
								$regpath = __DIR__;
								$target_path = getcwd()."\dist\img\products\\".$fileName;
								while(file_exists($target_path))
								{
								    $fileName = "Product"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
									$regpath = __DIR__;
									$target_path = getcwd()."\dist\img\products\\".$fileName;
								}
		 						if ($ckup == "") {
									if (move_uploaded_file($up_files_array["tmp_name"][$i], $target_path))
									{
										array_push($files_array, $fileName);
									}
								}
							}
						}
					}
					$reft = "";
					$exp = ".,*HDEV_prod*.,";
					foreach ($files_array as $key) {
						$reft .= $exp.$key;
					}
					if (strlen($reft) > strlen($exp)) {
						$reft = substr($reft, strlen($exp));
					}
					$upphoto = explode($exp, $reft);
					$var = count($upphoto);
					if (isset($upphoto) && !empty($upphoto) && $var >= 0 && isset($upphoto[0]) && !empty($upphoto[0]) && strlen($upphoto[0]) > 25) {
							$p_pic = $reft;
		      				$ck = $rt->insert("INSERT INTO `$tab` (`p_id`, `c_id`, `b_id`, `p_name`, `p_unit`, `p_desc`, `p_pic`, `p_price`, `p_status`, `p_reg_date`) VALUES (NULL, :c_id, :b_id, :p_name, :p_unit, :p_desc, :p_pic, :p_price, '1', current_timestamp())",[[':c_id',$c_id],[':b_id',$b_id],[':p_name',$p_name],[':p_unit',$p_unit],[':p_desc',$p_desc],[':p_pic',$p_pic],[':p_price',$p_price]]);
		      				if ($ck == "ok") {
		      					$csrf->up_tk();
		      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
		      						hdev_note::success("new Product added successfully",$_POST['mod_close']);
		      					}else{
		      						hdev_note::success("new Product added successfully");
		      					}
		      				}else{
		      					echo hdev_lang::on("validation","error_try_again");
		      				}
	      				}else{
	      					echo "something went wrong try again later";
	      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;
			case 'products_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['p_id']) && !empty($_POST['c_id']) && !empty($_POST['b_id']) && !empty($_POST['p_name']) && !empty($_POST['p_price']) && !empty($_POST['p_unit']) && !empty($_POST['p_desc'])) {
					$p_id = $_POST['p_id'];
					$c_id = $_POST['c_id'];
					$b_id = $_POST['b_id'];
					$p_name = $_POST['p_name'];
					$p_price = $_POST['p_price'];
					$p_unit = $_POST['p_unit'];
					$p_desc = $_POST['p_desc'];										
					$rt = new hdev_db();
      				$tab = $rt->table("products"); 
      				$user = hdev_log::uid();
      				if (isset($_FILES) && is_array($_FILES) && isset($_FILES['prod_pic']) && is_array($_FILES['prod_pic'])) {
      					$up_files_array = $_FILES['prod_pic'];
      					$countfiles = count($up_files_array['name']);
      				}else{
      					$up_files_array = array();
      					$countfiles = count($up_files_array);
      				}
					
					$files_array = array();
					for($i = 0;$i < $countfiles; $i++){
						if (file_exists($up_files_array["tmp_name"][$i])) {
							$file_type = $up_files_array["type"][$i]; //returns the mimetype
							$allowed = array("image/jpeg", "image/gif", "image/png");
							if(!in_array($file_type, $allowed)) {
							}else{
								$ckup="";
								// Check file size
								if ($up_files_array["size"][$i] > 50000000) {
								    $ckup = 1;
								}

								$fileData = pathinfo(basename($up_files_array["name"][$i]));
								$fileName = "Product"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
								$regpath = __DIR__;
								$target_path = getcwd()."\dist\img\products\\".$fileName;
								while(file_exists($target_path))
								{
								    $fileName = "Product"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
									$regpath = __DIR__;
									$target_path = getcwd()."\dist\img\products\\".$fileName;
								}
		 						if ($ckup == "") {
									if (move_uploaded_file($up_files_array["tmp_name"][$i], $target_path))
									{
										array_push($files_array, $fileName);
									}
								}
							}
						}
					}
					$reft = "";
					$exp = ".,*HDEV_prod*.,";
					foreach ($files_array as $key) {
						$reft .= $exp.$key;
					}
					if (strlen($reft) > strlen($exp)) {
						$reft = substr($reft, strlen($exp));
					}
					$upphoto = explode($exp, $reft);
					$var = count($upphoto);
					if (isset($upphoto) && !empty($upphoto) && $var >= 0 && isset($upphoto[0]) && !empty($upphoto[0]) && strlen($upphoto[0]) > 25) {
							$p_pic = $reft;
		      				$ck = $rt->insert("UPDATE `$tab` SET `c_id` = :c_id, `b_id` = :b_id, `p_name` = :p_name, `p_unit` = :p_unit, `p_desc` = :p_desc, `p_pic` = :p_pic, `p_price` = :p_price WHERE `p_id` = :p_id",[[':c_id',$c_id],[':b_id',$b_id],[':p_name',$p_name],[':p_unit',$p_unit],[':p_desc',$p_desc],[':p_pic',$p_pic],[':p_price',$p_price],[':p_id',$p_id]]);
		      				if ($ck == "ok") {
		      					$csrf->up_tk();
		      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
		      						hdev_note::success("Product edited successfully. "."Reg. no. : ".$p_id,$_POST['mod_close']);
		      					}else{
		      						hdev_note::success("Product edited successfully. "."Reg. no. : ".$p_id);
		      					}
		      				}else{
		      					echo hdev_lang::on("validation","error_try_again");
		      				}
	      				}else{
		      				$ck = $rt->insert("UPDATE `$tab` SET `c_id` = :c_id, `b_id` = :b_id, `p_name` = :p_name, `p_unit` = :p_unit, `p_desc` = :p_desc, `p_price` = :p_price WHERE `p_id` = :p_id",[[':c_id',$c_id],[':b_id',$b_id],[':p_name',$p_name],[':p_unit',$p_unit],[':p_desc',$p_desc],[':p_price',$p_price],[':p_id',$p_id]]);
		      				if ($ck == "ok") {
		      					$csrf->up_tk();
		      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
		      						hdev_note::success("Product edited successfully. "."Reg. no. : ".$p_id,$_POST['mod_close']);
		      					}else{
		      						hdev_note::success("Product edited successfully. "."Reg. no. : ".$p_id);
		      					}
		      				}else{
		      					echo hdev_lang::on("validation","error_try_again");
		      				}
	      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;	
			case 'tools_reg':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['t_name']) && !empty($_POST['t_qty']) && !empty($_POST['t_desc']) && !empty($_POST['t_health'])) {

					$t_name = $_POST['t_name'];
					$t_qty = $_POST['t_qty'];
					$t_desc = $_POST['t_desc'];
					$t_health = $_POST['t_health'];
					$rt = new hdev_db();
      				$tab = $rt->table("tools"); 
      				$user = hdev_log::uid();
      				$group = hdev_log::gid();

      				$ck = $rt->insert("INSERT INTO `h_tools` (`t_id`, `t_name`, `t_desc`, `t_qty`, `t_health`, `t_status`, `t_update`) VALUES (NULL, :t_name, :t_desc, :t_qty, :t_health, '1', current_timestamp())",[[':t_name',$t_name],[':t_desc',$t_desc],[':t_qty',$t_qty],[':t_health',$t_health]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("New equipment added successfully",$_POST['mod_close']);
      					}else{
      						hdev_note::success("New equipment added successfully");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;		
			case 'tools_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['t_id']) && !empty($_POST['t_name']) && !empty($_POST['t_qty']) && !empty($_POST['t_desc']) && !empty($_POST['t_health'])) {
					$t_id = $_POST['t_id'];
					$t_name = $_POST['t_name'];
					$t_qty = $_POST['t_qty'];
					$t_desc = $_POST['t_desc'];
					$t_health = $_POST['t_health'];
					$rt = new hdev_db();
      				$tab = $rt->table("tools"); 
      				$user = hdev_log::uid();
      				$group = hdev_log::gid();

      				$ck = $rt->insert("UPDATE `$tab` SET `t_name` = :t_name, `t_desc` = :t_desc, `t_qty` = :t_qty, `t_health` = :t_health WHERE `t_id` = :t_id",[[':t_id',$t_id],[':t_name',$t_name],[':t_desc',$t_desc],[':t_qty',$t_qty],[':t_health',$t_health]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("Equipment info modified successfully",$_POST['mod_close']);
      					}else{
      						hdev_note::success("Equipment info modified successfully");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;	
			/*------------------stock system------------------------*/
			case 'stock_in':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['p_id']) && !empty($_POST['p_unit']) && !empty($_POST['qty']) && !empty($_POST['sell_p_u']) && !empty($_POST['mfg_date']) && !empty($_POST['exp_date']) && !empty($_POST['supplier'])) {

					$p_id = $_POST['p_id'];
					$p_unit = $_POST['p_unit'];
					$qty = $_POST['qty'];
					$sell_p_u = $_POST['sell_p_u'];		
					$mfg_date = $_POST['mfg_date'];
					$exp_date = $_POST['exp_date'];
					$supplier = $_POST['supplier'];		

					$rt = new hdev_db();
      				$tab = $rt->table("stock_in"); 
      				$user = hdev_log::uid();

      				$ck = $rt->insert("INSERT INTO `$tab` (`sin_id`, `p_id`, `price_unit`, `sell_price_unit`, `sin_qty`, `supplier`, `product_mfg_date`, `product_exp_date`, `sin_reg_date`, `sin_status`, `sin_reg_by`) VALUES (NULL, :p_id, :p_unit, :sell_p_u, :qty, :supplier, :mfg_date, :exp_date, current_timestamp(), '1', :user)",[[':p_id',$p_id],[':p_unit',$p_unit],[':qty',$qty],[':sell_p_u',$sell_p_u],[':mfg_date',$mfg_date],[':exp_date',$exp_date],[':supplier',$supplier],[':user',$user]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("Stock in record added successfull",$_POST['mod_close'],1);
      					}else{
      						hdev_note::success("Stock in record added successfull");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;
			case 'stock_in_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['sin_id']) && !empty($_POST['p_unit']) && !empty($_POST['qty']) && !empty($_POST['sell_p_u']) && !empty($_POST['mfg_date']) && !empty($_POST['exp_date']) && !empty($_POST['supplier'])) {

					$sin_id = $_POST['sin_id'];
					$p_unit = $_POST['p_unit'];
					$qty = $_POST['qty'];
					$sell_p_u = $_POST['sell_p_u'];		
					$mfg_date = $_POST['mfg_date'];
					$exp_date = $_POST['exp_date'];
					$supplier = $_POST['supplier'];		

					$stock = hdev_data::in_stock($sin_id,['data']);

					if ($qty < $stock['sout_qty']) {
						exit('Error: The stock quantity can\'t be bellow'.$stock['sout_qty'].', becaouse on that stock in you already stocked out the products='.$stock['sout_qty']);
					}
					$rt = new hdev_db();
      				$tab = $rt->table("stock_in"); 
      				$user = hdev_log::uid();
      				$group = hdev_log::gid();
      				$ck = $rt->insert("UPDATE `stock_in` SET `price_unit` = :p_unit, `sell_price_unit` = :sell_p_u, `sin_qty` = :qty, `supplier` = :supplier, `product_mfg_date` = :mfg_date, `product_exp_date` = :exp_date WHERE `sin_id` = :sin_id",[[':sin_id',$sin_id],[':p_unit',$p_unit],[':qty',$qty],[':sell_p_u',$sell_p_u],[':mfg_date',$mfg_date],[':exp_date',$exp_date],[':supplier',$supplier]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("Stock in record modified successfull",$_POST['mod_close'],1);
      					}else{
      						hdev_note::success("Stock in record modified successfull");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;			
			case 'stock_out':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['sin_id']) && !empty($_POST['qty']) && !empty($_POST['customer'])) {

					$sin_id = $_POST['sin_id'];
					$qty = $_POST['qty'];
					$customer = $_POST['customer'];
					$stock = hdev_data::in_stock($sin_id,['data']);
					//$stock = hdev_data::stock_in($sin_id,['data']);
					$sell_price = $stock['sell_price_unit'];
					if (!is_numeric($_POST['qty']) || $_POST['qty'] <= 0) {
						exit('Error: Selling quantity must be greater than zero.');
					}
					if ($qty > $stock['qty_balance']) {
						exit('Error: The selected stock doesn\'t have enough products quantity to perform the requested Transaction. select onother stock or decrease the selling quantity.');
					}

					$rt = new hdev_db();
      				$tab = $rt->table("stock_out"); 
      				$user = hdev_log::uid();
      				//$ck = "no";
      				$ck = $rt->insert("INSERT INTO `$tab` (`sout_id`, `sin_id`, `sout_unit_price`, `sout_qty`, `customer`, `sout_reg_date`, `sout_reg_by`, `sout_status`) VALUES (NULL, :sin_id, :sell_price, :qty, :customer, current_timestamp(), :user, '1')",[[':sin_id',$sin_id],[':qty',$qty],[':customer',$customer],[':sell_price',$sell_price],[':user',$user]]);
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success("Stock out record added successfull",$_POST['mod_close'],1);
      					}else{
      						hdev_note::success("Stock out record added successfull");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;			
			case 'stock_in_bind':
				$csrf = new CSRF_Protect(); 
    			$csrf->verifyRequest($_POST['hash_mask']);
    			$return = '<option>--Select stock in to use in Transaction--</option>';
    			$rtn = "";
				if (!empty($_POST['p_id'])) {
					foreach (hdev_data::in_stock($_POST['p_id'],['stock']) as $stock) {
						$id = $stock['sin_id'];
						$prod = hdev_data::products($stock['p_id'],['data']);
						$p_name = $prod['p_name'];
						$unit = $prod['p_unit'];
						$reg_date = $stock['sin_reg_date'];
						$qty = $stock['qty_balance'];
						$qty_unit = $qty.' '.$unit;
						$selling_price = $stock['sell_price_unit'];
						$p_unit = $stock['price_unit'];
						$rtn .= '<option selling_price="'.$selling_price.'" p_unit="'.$p_unit.'" value="'.$id.'">'.$id.'. '.$p_name.' || '.$qty_unit.' || '.$reg_date.'</option>';
					}
				}
				if ($rtn == "") {
					$return="";
					$rtn = "<option value=''>--This product is out of stock--</option>";
				}
				echo $return.$rtn;
			break;		
			case 'user_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (isset($_POST['name']) && isset($_POST['n_id']) && isset($_POST['email']) && isset($_POST['tel'])) {
					$name = $_POST['name'];
					$n_id = $_POST['n_id'];
					$email = $_POST['email'];
					$tel = $_POST['tel'];
      				if (hdev_data::phone_valid($tel)) {
      					exit(hdev_data::phone_valid($tel));
      				}
      				if (hdev_data::id_valid($n_id)) {
      					exit(hdev_data::id_valid($n_id));
      				}
					$id = hdev_log::uid();
					$rt = new hdev_db();
		      		$tab = $rt->auth_tbl();

					switch (hdev_log::fid()) {
						case 'admin':
						case 'super_admin':
						case 'manager':
		      				$ck = $rt->insert("UPDATE $tab SET `n_id` = :n_id, `names` = :name, `tel` = :tel, `email` = :email WHERE `u_id` = :id",[[":id",$id],[':n_id',$n_id],[':name',$name],[":email",$email],[":tel",$tel]]);
						break;					
						default:
							exit(hdev_lang::on("validation","not_change_info"));
							break;
					}

      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success(hdev_lang::on("validation","info_changed"),$_POST['mod_close'],1);
      					}else{
      						hdev_note::success(hdev_lang::on("validation","info_changed"),'',1);
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;			
			case 'self_change_user_pwd':
				$csrf = new CSRF_Protect(); 
    			$csrf->verifyRequest();
				if (!empty($_POST['old_password']) && !empty($_POST['new_password']) && !empty($_POST['confirm_password'])) {
					$id = hdev_log::uid();
					$new_password = $_POST['new_password'];
					$confirm_password = $_POST['confirm_password'];
					$old_password = $_POST['old_password'];

					if ($new_password != $confirm_password) {
						exit(hdev_lang::on("validation","passwords_not_match"));
					}

					$password = hdev_data::password_enc($new_password);
					$old_password_hash = hdev_data::password_enc($old_password);
					$id = hdev_log::uid();
					$rt = new hdev_db();
		      		$tab = $rt->auth_tbl();

					switch (hdev_log::fid()) {
						case 'admin':
						case 'super_admin':
						case 'manager':
							$old_password_db = hdev_data::get_admin(hdev_log::uid(),['data'])["password"];
							$user = hdev_data::get_admin(hdev_log::uid(),['data'])["names"];
							if ($old_password_hash != $old_password_db) {
								exit(hdev_lang::on("validation","incorrect_current_password"));
							}
      						$ck = $rt->insert("UPDATE $tab SET `password` = :pwd WHERE `u_id` = :id",[[':pwd',$password],[':id',$id]]);
						break;					
						default:
							exit(hdev_lang::on("validation","not_change_password"));
							break;
					}
      				if ($ck == "ok") {
      					$csrf->up_tk();
      					if (isset($_POST['mod_close']) && !empty($_POST['mod_close'])) {
      						hdev_note::success(hdev_lang::on("validation","password_changed").". User: \" <u>".$user."</u> \"",$_POST['mod_close']);
      					}else{
      						hdev_note::success(hdev_lang::on("validation","password_changed").". User: \" <u>".$user."</u> \"");
      					}
      				}else{
      					echo hdev_lang::on("validation","error_try_again");
      				}

				}else{
					echo hdev_lang::on("validation","all_fields");
				}
			break;
			default:
				echo "404! Sorry we can't see what you are looking for please refesh this page and try again.";
			break;
		}
		}
	}
 ?>