  <?php
    //$langg = $_SESSION['lang'];
    //$lang = $_SESSION['exp']; 
    $menutop = array(
      "1" => array(
        "name" => hdev_lang::on("menu","home"),
        "trees" => "1",
        "icon" => "fa fa-home",
        "link" => "r...home"
      ),
      "2" => array(
        "name" => hdev_lang::on("menu","about"),
        "trees" => "1",
        "icon" => "fas fa-book",
        "link" => "r...about"
      ),
      "3" => array(
        "name" => hdev_lang::on("menu","contact"),
        "trees" => "1",
        "icon" => "fas fa-phone fa-3x",
        "link" => "r...contact"
      )
    );

  ?> 
<?php
    $menumask = array("hm", "prof","category","brand","product","room","tool","cart","rep","stockin","stockout","stock_status","warn","report");
    $menumain = array(
      "hm" => array(
        "name" => hdev_lang::on("menu","home"), 
        "trees" => "1",
        "icon" => "fa fa-home",
        "link" => "r...home",
        "power" => ""
      ),
      "prof" => array(
        "name" => hdev_lang::on("menu","profile")."^^".hdev_lang::on("menu","my_profile")."^^"."Stock info",
        "trees" => "2",
        "icon" => "fa fa-cog  ^^  fa fa-user ^^ fa fa-shopping-bag",
        "link" => "# ^^  r...profile^^  stock...profile",
        "power" => "no"
      ),
      "category" => array(
        "name" => "Categories"."^^"."Categories Info"."^^"."Deleted Categories", 
        "trees" => "2",
        "icon" => "fa fa-box ^^ fa fa-box ^^ fa fa-trash",
        "link" => "# ^^ all...category ^^ trash...category",
        "power"=> ""
      ), 
      "brand" => array(
        "name" => "Brands"."^^"."Brands Info"."^^"."Deleted Brands", 
        "trees" => "2",
        "icon" => "fa fa-box-open ^^ fa fa-box-open ^^ fa fa-trash",
        "link" => "# ^^ all...brand ^^ trash...brand",
        "power"=> ""
      ),       
      "product" => array(
        "name" => hdev_lang::on("menu","product")."^^".hdev_lang::on("menu","product_info")."^^".hdev_lang::on("menu","deleted_product"), 
        "trees" => "2",
        "icon" => "fa fa-boxes ^^ fa fa-boxes ^^ fa fa-trash",
        "link" => "# ^^ all...product ^^ trash...product",
        "power"=> ""
      ), 
      "room" => array(
        "name" => "Rooms"."^^"."Rooms info"."^^"."Deleted Rooms", 
        "trees" => "2",
        "icon" => "fa fa-hotel ^^ fa fa-hotel ^^ fa fa-trash",
        "link" => "# ^^ all...room ^^ trash...room",
        "power"=> ""
      ),       
      "tool" => array(
        "name" => "Equipments"."^^"."Equipments info"."^^"."Deleted Equipments", 
        "trees" => "2",
        "icon" => "fa fa-toolbox ^^ fa fa-toolbox ^^ fa fa-trash",
        "link" => "# ^^ all...tool ^^ trash...tool",
        "power"=> ""
      ),       
      "cart" => array(
        "name" => "Add more items to cart", 
        "trees" => "1",
        "icon" => "fa fa-luggage-cart",
        "link" => "product...cart",
        "power"=> ""
      ),   
      "rep" => array(
        "name" => "Sales Reports"."^^"."Products sales report"."^^"."Rooms Income Report"."^^"."Summarised Report", 
        "trees" => "2",
        "icon" => "fa fa-file-contract ^^ fa fa-file-alt ^^ fa fa-file-alt ^^ fa fa-file-alt",
        "link" => "# ^^ product...report ^^ room...report ^^gen...report ",
        "power"=> ""
      ),   
/*--------------- stock system ------------------*/
      "stockin" => array(
        "name" => "Stock In"."^^"."Stock In Registration"."^^"."Stock In Deleted Transactions", 
        "trees" => "2",
        "icon" => "fa fa-cubes ^^ fa fa-cubes ^^ fa fa-trash",
        "link" => "# ^^ stock...in ^^ trash...stock_in",
        "power"=> ""
      ),  
      "stockout" => array(
        "name" => "Stock Out"."^^"."Stock Out Registration"."^^"."Stock Out Deleted Transactions", 
        "trees" => "2",
        "icon" => "fa fa-box-open ^^ fa fa-box-open ^^ fa fa-trash",
        "link" => "# ^^ stock...out ^^ trash...stock_out",
        "power"=> ""
      ),   
      "stock_status" => array(
        "name" => "Stock Status"."^^"."Products In Stock status", 
        "trees" => "2",
        "icon" => "fa fa-file-archive ^^ fa fa-file-archive",
        "link" => "# ^^ status...in_stock",
        "power"=> ""
      ),
      "warn" => array(
        "name" => "Warnings"."^^"."Products Going to Expire"."^^"."Expired products"."^^"."Products Going to be out of stock"."^^"."Out of stock products", 
        "trees" => "2",
        "icon" => "fa fa-exclamation-triangle ^^ fa fa-exclamation-circle ^^ fa fa-exclamation-circle ^^ fa fa-exclamation-circle ^^ fa fa-exclamation-circle",
        "link" => "# ^^ warn...exp ^^ exp...products ^^ warn...out ^^ out...products",
        "power"=> ""
      ),      
      "report" => array(
        "name" => "Sales report", 
        "trees" => "1",
        "icon" => "fa fa-file-contract",
        "link" => "sales...report",
        "power"=> ""
      ),                                    
    );
  ?>
            <header class="header-top" header-theme="light">
                <div class="container-fluid">
                    <div class="d-flex justify-content-between">
                        <div class="top-menu d-flex align-items-center">
                            <button type="button" class="btn-icon mobile-nav-toggle d-lg-none"><span></span></button>
                            <span class="nav-link text-nowrap"><h4><?php echo APP_NAME; ?> &nbsp;</h4></span>
                        </div>
                        <div class="top-menu d-flex align-items-center">
                          <?php if (hdev_log::loged()) {
                          ?>
                            <?php if (hdev_data::service('add_to_cart')): ?>
                            <div class="dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="notiDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fa fa-shopping-cart"></i><span class="badge bg-danger" id="cart_val"></span></a>
                                <div class="dropdown-menu dropdown-menu-right notification-dropdown" aria-labelledby="notiDropdown" id="cart_items">
                                    <h4 class="header">No products in cart</h4>
                                </div>
                            </div>
                            <?php endif ?>
                            <div class="dropdown">
                                <a class="dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="fa fa-user-secret fa-3x avatar"></span><i style="font-weight: bold;padding: 10px;" class="bg-light"><?php echo hdev_data::active_user('name'); ?></i></a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                                    <a class="dropdown-item" href="<?php echo hdev_url::menu('r/profile') ?>"><i class="ik ik-user dropdown-icon"></i> Profile</a>
                                    <a class="dropdown-item" href="<?php echo hdev_url::menu('?logout=ok') ?>"><i class="ik ik-power dropdown-icon"></i> Logout</a>
                                </div>
                            </div>
                          <?php
                          }else{
                          ?>
                            <button class="btn btn-success" type="button" onclick="window.location.href='<?php echo hdev_url::menu('login'); ?>';"><span class="fa fa-power-off"></span> Sign in</button>
                          <?php
                          } ?>
                        </div>
                    </div>
                </div>
            </header>





            <!--left nav -->
            <div class="page-wrap">
                <div class="app-sidebar colored">
                    <div class="sidebar-header">
                        <a class="header-brand" href="index.html">
                            <div class="logo-img">
                               <img src="<?php echo hdev_url::menu("icon/LOGO.png") ?>" style="height: : 40px; width: 30px;" class="header-brand-img" alt="App-img"> 
                            </div>
                            <span class="text"><?php echo APP_NAME; ?></span>
                        </a>
                        <button type="button" class="nav-toggle"><i data-toggle="expanded" class="ik ik-toggle-right toggle-icon"></i></button>
                        <button id="sidebarClose" class="nav-close"><i class="ik ik-x"></i></button>
                    </div>
                    
                    <div class="sidebar-content">
                        <div class="nav-container">
                            <nav id="main-menu-navigation" class="navigation-main">
                            <?php 
                              for ($i=0; $i < count($menumask); $i++) { 
                                $mmenu = $menumask;
                                hdevmenu::mainmenu($menumain[$mmenu[$i]]['trees'],$menumain[$mmenu[$i]]['name'],$menumain[$mmenu[$i]]['link'],$menumain[$mmenu[$i]]['icon'],$menumain[$mmenu[$i]]['power']);
                              }
                            ?> 
                            </nav>
                        </div>
                    </div>
                </div>