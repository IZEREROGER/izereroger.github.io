<?php if (1==5 || !hdev_log::loged()): ?>
<h2>Welecome to <?php echo APP_NAME; ?></h2>
<div id="app_data" align="center">
  <div class="card" style="height: 100%;">
    <div class="card-header"><h5>Products in system</h5>
    </div>
    <div class="card-body table-responsive p-2">
        <div class="card-group mb-30">
        <?php 
          $counter = 0;
          $counter_group = 1;
          $ck = hdev_data::products();
          $maxer = (is_array($ck)) ? count($ck) : '' ;
          $maxer_rec = ($maxer%3);
          foreach ($ck as $product) {
            $counter++;
        ?>
          <div class="card card-box">
             <?php if (isset(hdev_data::product_images($product["p_pic"])[0]) && !empty(hdev_data::product_images($product["p_pic"])[0])) {
             $key = hdev_data::product_images($product["p_pic"])[0];
             ?>
             <img class="card-img-top" src="<?php echo $key ?>" alt="image">
             <?php }else{ ?>
                <i class="icon-copy fa fa-shopping-bag fa-5x card-img-top" aria-hidden="true"></i>
             <?php } ?>
            <div class="card-body">
              <p class="card-text bg-secondary text-white"><?php echo $product['p_price']; ?> Frw</p>
              <h5 class="card-title bg-primary text-white"><?php echo $product['p_name']; ?></h5>
              <p class="card-text"><small class="text-muted"> in stock</small></p>
            </div>
          </div>
        <?php
            if (($counter%3) == 0) {
              echo '</div><div class="card-group mb-30">';
              $counter_group++;
            }
          }
         ?>
        <?php 
          if ($counter == $maxer) {
            //echo $maxer_rec;
            if ($maxer_rec == 1) {
              echo '<div class="card card-box"></div>';
              echo '<div class="card card-box"></div>';
            }elseif ($maxer_rec == 2) {
              echo '<div class="card card-box"></div>';
            }
          }
         ?>
        </div>
    </div>
  </div>
  </div>
<?php endif ?>
<?php if (hdev_log::loged()): ?>
<div id="app_data" align="center">
  <div class="card" style="height: 100%;">
    <div class="card-header" align="center" style="text-align: center!important;"><h5>Products in system</h5>
    </div>
    <div class="card-body table-responsive p-2">


          <div class="owl-carousel owl-theme card-group oww">
          <?php for ($i=0; $i < 6; $i++) { ?>
                    <div class="item border-secondary border-top border-right border-left border-bottom card-body ">
                      card <?php echo $i ?> for testing
                    </div> 
          <?php } ?>
        </div>




        <div class="card-group mb-30">
        <?php 
          $counter = 0;
          $counter_group = 1;
          $ck = hdev_data::products();
          $maxer = (is_array($ck)) ? count($ck) : 0 ;
          $maxer_rec = ($maxer%3);
          foreach ($ck as $product) {
            $counter++;
        ?>
          <div class="card card-box">
             <?php if (isset(hdev_data::product_images($product["p_pic"])[0]) && !empty(hdev_data::product_images($product["p_pic"])[0])) {
             $key = hdev_data::product_images($product["p_pic"])[0];
             ?>
             <img class="card-img-top" src="<?php echo $key ?>" alt="image">
             <?php }else{ ?>
                <i class="icon-copy fa fa-shopping-bag fa-5x card-img-top" aria-hidden="true"></i>
             <?php } ?>
            <div class="card-body">
              <p class="card-text bg-secondary text-white"><?php echo $product['p_price']; ?> Frw</p>
              <h5 class="card-title bg-primary text-white"><?php echo $product['p_name']; ?></h5>
              <p class="card-text"><small class="text-muted"> in stock</small></p>
            </div>
            <div class="card-footer">
              <button type="button" class="btn btn-secondary btn-block add_to_cart" id="prod_<?php echo $product['p_id']; ?>_btn" price="<?php echo $product['p_price']; ?>" o_type="product" ref_id="<?php echo $product['p_id']; ?>" qty="1">Add To cart <span class="fa fa-cart-plus"></span></button>
            </div>
          </div>
        <?php
            if (($counter%3) == 0) {
              echo '</div><div class="card-group mb-30">';
              $counter_group++;
            }
          }
         ?>
        <?php 
          if ($counter == $maxer) {
            //echo $maxer_rec;
            if ($maxer_rec == 1) {
              echo '<div class="card card-box"></div>';
              echo '<div class="card card-box"></div>';
            }elseif ($maxer_rec == 2) {
              echo '<div class="card card-box"></div>';
            }
          }
         ?>
        </div>
    </div>
  </div>
  </div>
<?php
if(1==1){

  }else{
?>
        <div class="page-header">
          <div class="row">
            <div class="col-md-12 col-sm-12 text-red" align="center">
              <div class="title">
                <h4 style="color: red !important;">This stock does not exist on our system</h4>
              </div>
            </div>
          </div>
        </div>
<?php
  }
 ?>
<?php endif ?>








