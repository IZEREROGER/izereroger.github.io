<?php
//============================================================+
// File name   : example_003.php
// Begin       : 2008-03-04
// Last Update : 2013-05-14
//
// Description : Example 003 for TCPDF class
//               Custom Header and Footer
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: Custom Header and Footer
 * @author Nicola Asuni
 * @since 2008-03-04
 */

// Include the main TCPDF library (search for installation path).
//require_once('tcpdf_include.php');


// Extend the TCPDF class to create custom Header and Footer
class MYPDF extends TCPDF {

	//Page header
	public function Header3() {
		// Logo
		$image_file = getcwd().DIRECTORY_SEPARATOR."icon".DIRECTORY_SEPARATOR.'rep_ico.jpg';
		$this->Image($image_file, 10, 10, 15, '', 'JPG', '', 'T', false, 300, '', false, false, 0, false, false, false);
		// Set font
		$this->SetFont('helvetica', 'B', 20);
		// Title
		$this->Cell(0, 15, APP_NAME, 0, false, 'C', 0, '', 0, false, 'M', 'M');
		$html = "<div><br><div>Sales Report<im src='".$image_file."'></div> <hr>";
		$this->writeHTML($html, true, false, true, false, '');
	}

	// Page footer
	public function Footer() {
		// Position at 15 mm from bottom
		$this->SetY(-15);
		// Set font
		$this->SetFont('helvetica', 'I', 8);
		// Page number
		$this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages()." - Printed by :".hdev_data::active_user("fid")." - ' ".hdev_data::active_user("username")." '", 0, false, 'C', 0, '', 0, false, 'T', 'M');

	}
}

// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor(APP_NAME);
$pdf->SetTitle('Official Sales Report');
$pdf->SetSubject('Sales report');
$pdf->SetKeywords('Sales,report');


$group = hdev_data::groups(hdev_log::gid(),['data']);
// set default header data
//$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);
$image_file = getcwd().DIRECTORY_SEPARATOR."icon".DIRECTORY_SEPARATOR.'rep_ico.jpg';
$pdf->SetHeaderData($image_file, PDF_HEADER_LOGO_WIDTH, "(".$group['g_id'].") ".$group['g_name']." Stock"." \n", "Tel : ".$group['tell']." \n"."Email : ".$group['email']." \n"."Location : ".$group['g_location']." \non ".date('d/m/Y'));

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// set font
$pdf->SetFont('times', '', 12);

// add a page
$pdf->AddPage('L', 'A4');


$from = hdev_session::get('start');
$to = hdev_session::get('end');
$disp = '';
  if (!empty($to) && !empty($from)) {
    $disp .= "Viewing Sales Report from : ";
    $disp .= date_format(date_create($from),"d/m/Y"); 
    $disp .= " - to : "; 
    $disp .= date_format(date_create($to),"d/m/Y");
  }
    $head='
    <h2 align="center">'.$disp.'</h2>
		<table style="width: 100%;border-collapse: collapse;" border="1px">
		    <thead>
          <tr style="padding: 10px;">
            <th><h4>Product #</h4></th>
            <th><h4>Product Name</h4></th>
            <th><h4>Sold Quantity</h4></th>
            <th><h4>Total buying Price</h4></th>
            <th><h4>Total Selling Price</h4></th>
            <th><h4>Profit/Loss</h4></th>
            <th><h4>Observation</h4></th>
          </tr>
		    </thead>
		    <tbody>
    ';
    $body = "";
    $ck = hdev_data::report();
    $sum = hdev_data::report('',['sum']);
    foreach ($ck AS $stock) { 
    	$stt = ($stock['income'] > 0) ? "Profit" : "Loss";
    	$body .= '
                    <tr>
                      <td>'.$stock["p_id"].'</td>
                      <td>'.$stock['p_name'].'</td>
                      <td>'.$stock['qty'].'</td>
                      <td>'.number_format($stock["buy_price"],2).constant('currency').'</td>
                      <td>'.number_format($stock['sell_price'],2).constant('currency').'</td>
                      <td>'.number_format($stock['income'],2).constant('currency').'</td>
                      <td>'.$stt.'</td>
                    </tr>
    	';
    } 
    $sum_stt = ($sum['income'] > 0) ? "Profit" : "Loss";
    $foot = '
                    <tr>
                    	<th colspan="2">Total</th>
                      <td>'.$sum['qty'].'</td>
                      <td>'.number_format($sum["buy_price"],2).constant('currency').'</td>
                      <td>'.number_format($sum['sell_price'],2).constant('currency').'</td>
                      <td>'.number_format($sum['income'],2).constant('currency').'</td>
                      <td>'.$sum_stt.'</td>
                    </tr>
			    </tbody>
			</table>
	    ';
// set some text to print
$html = $head.$body.$foot;
/*var_dump($html);
exit();*/

// print a block of text using Write()
$pdf->writeHTML($html, true, false, true, false, '');

// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('Sales report.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+
