<?php if ((!isset($_GET) || !isset($_GET['tb']) || $_GET['tb'] != "ok") && !isset($js_controller)): ?>
                <div class="main-content">
                    <div class="container-fluid">
                        <div class="page-header">
                            <div class="row align-items-end bg-white">
                                <div class="col-lg-8">
                                    <div class="page-header-title">
                                        <!--<i class="ik ik-box bg-blue"></i>-->
                                            <h5><?php echo $_SESSION['act_url'][0]; ?></h5>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <nav class="breadcrumb-container" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a href="<?php echo hdev_url::get_url_host(); ?>"><i class="fa fa-home"> <?php echo hdev_lang::on("menu",'home') ?></i></a>
                                            </li>
                                            <li class="breadcrumb-item active" aria-current="page"><?php echo $_SESSION['act_url'][0]; ?></li>
                                        </ol>
                                    </nav>
                                </div>
                            </div>
                        </div>
                        <div class="main__data">
                          <?php 
                            if (!empty($_SESSION['act_url'])) {
                              if (!empty($_SESSION['act_url'][0]) && !empty($_SESSION['act_url'][1])) {
                                if (file_exists($_SESSION['act_url'][1].".php")) {
                                  if (hdev_menu_url::url_req($_SESSION['act_url'][0],"user") == "y") {
                                    include $_SESSION['act_url'][1].".php";
                                  }else{
                                    //exit("1");
                                    include 'error.php';
                                  }
                                }else{
                                  //exit("2");
                                  include 'error.php';
                                }
                              }else{
                                /*var_dump($_SESSION);
                                exit("3");*/
                                include 'error.php';
                              }
                            }else{
                              //exit("4");
                              include 'error.php';
                            }
                          ?>
                        </div>
                    </div>
                </div>
<?php endif ?>