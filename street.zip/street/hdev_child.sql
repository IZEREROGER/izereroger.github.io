-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2022 at 11:10 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hdev_child`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `auth_engine`
-- (See below for the actual view)
--
CREATE TABLE `auth_engine` (
`a_id` int(11)
,`a_username` mediumtext
,`a_email` mediumtext
,`a_password` mediumtext
,`a_role` varchar(7)
,`a_status` int(11)
);

-- --------------------------------------------------------

--
-- Table structure for table `center`
--

CREATE TABLE `center` (
  `cn_id` int(11) NOT NULL,
  `cn_name` text NOT NULL,
  `cn_location` text NOT NULL,
  `cn_username` text NOT NULL,
  `cn_tel` text NOT NULL,
  `cn_password` text NOT NULL,
  `cn_status` int(11) NOT NULL DEFAULT 1,
  `cn_reg_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `child`
--

CREATE TABLE `child` (
  `ch_id` int(11) NOT NULL,
  `cn_id` int(11) NOT NULL,
  `ch_nid` text NOT NULL,
  `ch_name` text NOT NULL,
  `ch_sex` text NOT NULL,
  `ch_born` date NOT NULL,
  `ch_desc` longtext NOT NULL,
  `ch_status` int(11) NOT NULL DEFAULT 1,
  `ch_reg_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `child_request`
--

CREATE TABLE `child_request` (
  `cr_id` bigint(100) NOT NULL,
  `sp_id` int(11) NOT NULL,
  `cr_num` int(11) NOT NULL,
  `cr_desc` text NOT NULL,
  `cr_status` int(11) NOT NULL DEFAULT 1,
  `cr_reg_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `child_transfer`
--

CREATE TABLE `child_transfer` (
  `ct_id` int(11) NOT NULL,
  `cr_id` bigint(100) NOT NULL,
  `ch_id` int(11) NOT NULL,
  `sp_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `ct_status` int(11) NOT NULL DEFAULT 1,
  `ct_reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `ct_can_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `police_officer`
--

CREATE TABLE `police_officer` (
  `p_id` int(11) NOT NULL,
  `p_name` text NOT NULL,
  `p_nid` text NOT NULL,
  `p_tel` text NOT NULL,
  `p_username` text NOT NULL,
  `p_password` text NOT NULL,
  `p_reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `p_status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `police_officer`
--

INSERT INTO `police_officer` (`p_id`, `p_name`, `p_nid`, `p_tel`, `p_username`, `p_password`, `p_reg_date`, `p_status`) VALUES
(1, 'Aline', '123465556', '0785569911', 'aline', '202cb962ac59075b964b07152d234b70', '2022-03-05 17:27:02', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sponsor`
--

CREATE TABLE `sponsor` (
  `sp_id` int(11) NOT NULL,
  `sp_type` text NOT NULL,
  `sp_name` text NOT NULL,
  `sp_nid` text NOT NULL,
  `sp_tel` text NOT NULL,
  `sp_username` text NOT NULL,
  `sp_password` text NOT NULL,
  `sp_location` text NOT NULL,
  `sp_desc` longtext NOT NULL,
  `sp_status` int(11) NOT NULL DEFAULT 1,
  `sp_reg_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure for view `auth_engine`
--
DROP TABLE IF EXISTS `auth_engine`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `auth_engine`  AS  select `police_officer`.`p_id` AS `a_id`,`police_officer`.`p_username` AS `a_username`,`police_officer`.`p_tel` AS `a_email`,`police_officer`.`p_password` AS `a_password`,'admin' AS `a_role`,`police_officer`.`p_status` AS `a_status` from `police_officer` union select `sponsor`.`sp_id` AS `a_id`,`sponsor`.`sp_username` AS `a_username`,`sponsor`.`sp_tel` AS `a_email`,`sponsor`.`sp_password` AS `a_password`,'sponsor' AS `a_role`,`sponsor`.`sp_status` AS `a_status` from `sponsor` union select `center`.`cn_id` AS `a_id`,`center`.`cn_username` AS `a_username`,`center`.`cn_tel` AS `a_email`,`center`.`cn_password` AS `a_password`,'center' AS `a_role`,`center`.`cn_status` AS `a_status` from `center` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `center`
--
ALTER TABLE `center`
  ADD PRIMARY KEY (`cn_id`);

--
-- Indexes for table `child`
--
ALTER TABLE `child`
  ADD PRIMARY KEY (`ch_id`);

--
-- Indexes for table `child_request`
--
ALTER TABLE `child_request`
  ADD PRIMARY KEY (`cr_id`),
  ADD KEY `sp_id` (`sp_id`);

--
-- Indexes for table `child_transfer`
--
ALTER TABLE `child_transfer`
  ADD PRIMARY KEY (`ct_id`),
  ADD KEY `ch_id` (`ch_id`),
  ADD KEY `p_id` (`p_id`),
  ADD KEY `sp_id` (`sp_id`),
  ADD KEY `cr_id` (`cr_id`);

--
-- Indexes for table `police_officer`
--
ALTER TABLE `police_officer`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `sponsor`
--
ALTER TABLE `sponsor`
  ADD PRIMARY KEY (`sp_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `center`
--
ALTER TABLE `center`
  MODIFY `cn_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `child`
--
ALTER TABLE `child`
  MODIFY `ch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `child_request`
--
ALTER TABLE `child_request`
  MODIFY `cr_id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `child_transfer`
--
ALTER TABLE `child_transfer`
  MODIFY `ct_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `police_officer`
--
ALTER TABLE `police_officer`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sponsor`
--
ALTER TABLE `sponsor`
  MODIFY `sp_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `child`
--
ALTER TABLE `child`
  ADD CONSTRAINT `child_ibfk_1` FOREIGN KEY (`ch_id`) REFERENCES `center` (`cn_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `child_request`
--
ALTER TABLE `child_request`
  ADD CONSTRAINT `child_request_ibfk_1` FOREIGN KEY (`sp_id`) REFERENCES `sponsor` (`sp_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `child_transfer`
--
ALTER TABLE `child_transfer`
  ADD CONSTRAINT `child_transfer_ibfk_1` FOREIGN KEY (`ch_id`) REFERENCES `child` (`ch_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `child_transfer_ibfk_2` FOREIGN KEY (`p_id`) REFERENCES `police_officer` (`p_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `child_transfer_ibfk_3` FOREIGN KEY (`sp_id`) REFERENCES `sponsor` (`sp_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `child_transfer_ibfk_4` FOREIGN KEY (`cr_id`) REFERENCES `child_request` (`cr_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
