<?php if (hdev_log::loged() && hdev_log::fid() == "member"): ?>
<div id="app_data">
<?php
hdev_session::set('start',date('Y-m-d'));
hdev_session::set('end',date('Y-m-d'));
$sum1 = hdev_data::memb_sales('',['sum']);
$base = "my/sales";
$link = json_encode(array("cm_id"=>hdev_log::uid(),"from"=>hdev_session::get('start'),"to"=>hdev_session::get('end')));
$link = hdev_url::menu($base)."/".urlencode($link)."/report/member";
?>
  <div class="row border-bottom">
    <div class="col-sm-12" align="center">
      <h4 class="mb-2 bg-primary p-2"><?php echo hdev_lang::on('form','today')." : ".hdev_session::get('start'); ?></h4>
    </div>
    <hr>
    <div class="col-sm-12">
      <!-- small box -->
      <div class="small-box bg-primary">
        <div class="inner">
          <h3><?php echo number_format($sum1['cm_inc'],2).constant('currency'); ?></h3>
          <p><?php echo hdev_lang::on('form','today'); ?> : <?php echo hdev_lang::on('data','total_sales'); ?></p>
        </div>
        <div class="icon">
          <i class="fa fa-money-bill-wave"></i>
        </div>
        <a href="<?php echo $link; ?>" class="small-box-footer"><?php echo hdev_lang::on('data','more_info'); ?> <i class="fas fa-arrow-circle-right"></i></a>
      </div>
    </div>       
  </div>
  <?php
  hdev_session::set('start',hdev_data::groups(hdev_log::gid(),['data'])['g_cur_year_start']);
  hdev_session::set('end',hdev_data::groups(hdev_log::gid(),['data'])['g_cur_year_end']);
  $sum1 = hdev_data::memb_sales('',['sum']);
  $base = "my/sales";
  $link = json_encode(array("cm_id"=>hdev_log::uid(),"from"=>hdev_session::get('start'),"to"=>hdev_session::get('end')));
  $link = hdev_url::menu($base)."/".urlencode($link)."/report/member";
  ?>
  <div class="row border-bottom">
    <div class="col-sm-12" align="center">
      <h4 class="mb-2 bg-primary p-2"><?php echo hdev_lang::on('form','this_year')." : ".hdev_session::get('start').".....".hdev_session::get('end'); ?></h4>
    </div>
    <hr>
    <div class="col-sm-12">
      <!-- small box -->
      <div class="small-box bg-primary">
        <div class="inner">
          <h3><?php echo number_format($sum1['cm_inc'],2).constant('currency'); ?></h3>
          <p><?php echo hdev_lang::on('form','this_year'); ?> : <?php echo hdev_lang::on('data','total_sales'); ?></p>
        </div>
        <div class="icon">
          <i class="fa fa-money-bill-wave"></i>
        </div>
        <a href="<?php echo $link; ?>" class="small-box-footer"><?php echo hdev_lang::on('data','more_info'); ?> <i class="fas fa-arrow-circle-right"></i></a>
      </div>
    </div>
  </div>
</div>
<?php endif ?>