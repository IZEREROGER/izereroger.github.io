<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Deleted Sponsors</h5>
              </div>
              <div class="card-body table-responsive p-2">
                
                  <table data-order='[[ 0, "desc" ]]' id="rasms_all_tables" class="dt-responsive table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort">Reg. no</th>
                      <th>type</th>
                      <th>Name</th>
                      <th>ID/TIN</th>
                      <th>Tel</th>
                      <th>Username</th>
                      <th>Location</th>
                      <th>Description</th>
                      <th>Reg. Date</th>
                      <?php if (hdev_data::service("delete_sponsor") || hdev_data::service("edit_sponsor")): ?>
                      <th>Action</th>
                      <?php endif ?>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::sponsor("",['delete']);
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $group) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:recover_sponsor;id:".$group['sp_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#sk_del_close;app:".$tkn.";".$build2);                     

                    ?>
                    <tr>
                      <td class="table-plus">
                        <?php echo $group["sp_id"]; ?>
                      </td>
                      <td>
                        <?php echo hdev_data::sponsor_type($group["sp_type"]); ?>
                      </td>
                      <td>
                        <?php echo $group['sp_name']; ?>
                      </td>
                      <td>
                        <?php echo $group['sp_nid']; ?>
                      </td>
                      <td>
                        <?php echo $group['sp_tel'] ?>
                      </td>
                      <td>
                        <?php echo $group['sp_username']; ?>
                      </td> 
                      <td>
                        <?php echo $group['sp_location'] ?>
                      </td>
                      <td>
                        <?php echo $group['sp_desc'] ?>
                      </td>                                         
                      <td>
                        <?php echo $group['sp_reg_date']; ?>
                      </td> 
                      <?php if (hdev_data::service("delete_sponsor") || hdev_data::service("edit_sponsor")): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('edit_animal')): ?>
                          <button type="button" rel="external" fa_id="<?php echo$group['fa_id'] ?>" an_id="<?php echo $group['an_id']; ?>" m_id="<?php echo $group['m_id']; ?>" fa_uid="<?php echo $group['fa_uid']; ?>" fa_pic="<?php echo $group['fa_pic']; ?>" fa_desc="<?php echo $group['fa_desc']; ?>" fa_born="<?php echo $group['fa_born']; ?>" class="btn btn-success edit_ani_btn" data-toggle="modal" data-target=".modal-edit"><i class="fa fa-edit"></i> <?php echo hdev_lang::on("form","edit"); ?> </button>
                           <?php endif ?>  
                          <?php if (hdev_data::service('delete_sponsor')): ?>
                          <button type="button" set_btn='fm_set_clk' e_tit="Are you Sure That You Want To Recover This sponsor?" ref_id="<?php echo $group['sp_id']; ?>" data="<?php echo $reject; ?>" hash="<?php echo $tkn; ?>" rel="external" class="btn btn-secondary fm_pre_set" data-toggle="modal" data-target=".modal-set" ><i class="fa fa-recycle"></i> Recover</button>
                           <?php endif ?>              
                        </div>
                      </td>
                      <?php endif ?>                   
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('sponsor_reg')): ?>
<div class="modal fade modal-reg"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">New Sponsor Registration</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <form method="post" id="sponsor_reg">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="sponsor_reg">   
            <div class="form-group">
              <label for="sp_type">
                Sponsor Type :
              </label>
              <div class="input-group mb-3">
                <select type="text" class="form-control" name="sp_type" id="sp_type">
                  <option value="">Select Sponsor type</option>
                  <option value="1">Individual sponsor</option>
                  <option value="2">Company Sponsor</option>
                </select>
              </div>
            </div>                    
            <div class="form-group">
              <label for="sp_nid">
                Sponsor Id/TIN :
              </label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="sp_nid" id="sp_nid" placeholder="Sponsor ID">
              </div>
            </div>
            <div class="form-group">
              <label for="sp_name">
                Sponsor name :
              </label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="sp_name" id="sp_name" placeholder="Sponsor name">
              </div>
            </div> 
            <div class="form-group">
              <label for="sp_tel">
                Sponsor Tel :
              </label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="sp_tel" id="sp_tel" placeholder="Sponsor Tel">
              </div>
            </div>
            <div class="form-group">
              <label for="sp_username">
                Sponsor Username :
              </label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="sp_username" id="sp_username" placeholder="Sponsor Username">
              </div>
            </div> 
            <div class="form-group">
              <label for="sp_password">
                Sponsor Password :
              </label>
              <div class="input-group mb-3">
                <input type="password" class="form-control" name="sp_password" id="sp_password" placeholder="Password">
              </div>
            </div>                            
            <div class="form-group">
              <label for="sp_desc">
                Sponsor Description :
              </label>
              <div class="input-group mb-3">
                <textarea type="text" class="form-control" name="sp_desc" id="sp_desc" placeholder="Sponsor Description"></textarea>
              </div>
            </div>      
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="reg_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="sponsor_reg_btn" onclick="fm_submit('sponsor_reg_btn','sponsor_reg');"><i class="fa fa-save"></i> Add New Sponsor</button>
      </div>
      </form>
    </div>

    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('edit_animal')): ?>
<div class="modal fade modal-edit"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Modify Animal Info</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <form method="post" id="edit_animal">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="fa_id" id="fa_id" value="">
              <input type="hidden" name="ref" value="edit_animal">
            <div class="form-group">
              <label for="an_id">
                Animal Category :
              </label>
              <div class="input-group mb-3">
                <select name="an_id" id="an_id" class="form-control">
                  <option value="">Select Category</option>
                  <?php foreach (hdev_data::animal_category() as $cat): ?>
                    <option value="<?php echo $cat['an_id'] ?>">(<?php echo $cat['an_id'] ?>) - <?php echo $cat['an_name'] ?></option>  
                  <?php endforeach ?>
                </select>
              </div>
            </div> 
            <div class="form-group">
              <label for="m_id">
                Animal Owner :
              </label>
              <div class="input-group mb-3">
                <select name="m_id" id="m_id" class="form-control">
                  <option value="">Select Owner</option>
                  <?php foreach (hdev_data::members() as $meme): ?>
                    <option value="<?php echo $meme['m_id'] ?>">(<?php echo $meme['m_nid'] ?>) - <?php echo $meme['m_name'] ?></option>  
                  <?php endforeach ?>
                </select>
              </div>
            </div>            
            <div class="form-group">
              <label for="fa_uid">
                Animal Unique Id :
              </label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="fa_uid" id="fa_uid" placeholder="Animal Unique Id">
              </div>
            </div>
            <div class="form-group">
              <label for="fa_pic">
                Animal Picture :
              </label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="fa_pic" id="fa_pic" placeholder="Animal Picture">
              </div>
            </div>            
            <div class="form-group">
              <label for="fa_desc">
                Animal Description :
              </label>
              <div class="input-group mb-3">
                <textarea type="text" name="fa_desc" id="fa_desc" class="form-control" placeholder="Animal Description" required="true"></textarea>
              </div>            
            </div>
            <div class="form-group">
              <label for="fa_born">
                Animal Born Today ? :
              </label>
              <div class="input-group mb-3">
                <select name="fa_born" id="fa_born" class="form-control">
                  <option value="">Select Answer</option>
                  <option value="1">Yes</option>
                  <option value="2">No</option>
                </select>
              </div>
            </div>            
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="reg_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="edit_animal_btn" onclick="fm_submit('edit_animal_btn','edit_animal');"><i class="fa fa-save"></i> Save Animal info</button>
      </div>
      </form>
    </div>

    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('delete_animal')): ?> 
<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Delete This Animal Category?</th>
                </tr>
                <tr>
                  <td>Stock id : </td>
                  <td id="animal_id"></td>
                </tr>           
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="sk_del_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="delete_animal_btn" data="" hash=""><i class="fa fa-times-circle"></i> Delete This Animal Category</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>

<?php if (hdev_data::service('delete_sponsor')): ?> 
<div class="modal fade modal-set" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2" id="e_tit"></th>
                </tr>
                <tr>
                  <td>Record id : </td>
                  <td id="ref_id"></td>
                </tr>           
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="sk_del_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="fm_set_clk" data="" hash="" onclick="fm_app('fm_set_clk')"><i class="fa fa-times-circle"></i> </button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>