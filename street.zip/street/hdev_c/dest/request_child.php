<?php 
//echo   hdev_backup::backup();
//  exit();//
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card" style="height: 100%;">
              <div class="card-header"><h5>Children request Info</h5>
              </div>
              <div class="card-body table-responsive p-2">

                <div class="btn-group">
                  <?php if (hdev_data::service('request_child')): ?>
                  <button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fa fa-plus-circle"></i>Submit New Children request</button>&nbsp;
                  <?php endif ?>
                </div>
                
                  <table data-order='[[ 0, "desc" ]]' id="rasms_all_tables" class="dt-responsive table table-bordered table-hover table-striped text-nowrap" id="">
                  <thead class="border-top">
                    <tr>
                      <th class="table-plus datatable-nosort">Reg. no</th>
                      <th>Number of children requested</th>
                      <th>Number of children Received</th>
                      <th>Reg. Date</th>
                      <?php if (hdev_data::service("delete_sponsor") || hdev_data::service("edit_sponsor")): ?>
                      <th>Action</th>
                      <?php endif ?>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                      $ck = hdev_data::child_request();
                      //var_dump($ck);
                     ?>
                    <?php foreach ($ck AS $group) { 
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken();
                      $build2 = "ref:delete_sponsor;id:".$group['cr_id'].";src:1;from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $reject = hdev_data::encd("mod_close:#sk_del_close;app:".$tkn.";".$build2);                     

                    ?>
                    <tr>
                      <td class="table-plus">
                        <?php echo $group["cr_id"]; ?>
                      </td>
                      <td>
                        <?php echo $group['cr_num']; ?> Children
                      </td>
                      <td>
                        0
                      </td>
                      <td>
                        <?php echo $group['cr_reg_date']; ?>
                      </td>
                      <?php if (hdev_data::service("delete_sponsor") || hdev_data::service("edit_sponsor")): ?>
                      <td>
                        <div class="btn-group btn-group-sm">
                          <?php if (hdev_data::service('edit_sponsor')): ?>
                          <button type="button" rel="external" sp_id="<?php echo $group['sp_id'] ?>" sp_type="<?php echo $group['sp_type'] ?>" sp_nid="<?php echo $group['sp_nid'] ?>" sp_name="<?php echo $group['sp_name'] ?>" sp_tel="<?php echo $group['sp_tel'] ?>" sp_username="<?php echo $group['sp_username'] ?>" sp_location="<?php echo $group['sp_location'] ?>" sp_desc="<?php echo $group['sp_desc'] ?>" class="btn btn-success edit_sp_btn" data-toggle="modal" data-target=".modal-edit"><i class="fa fa-edit"></i> <?php echo hdev_lang::on("form","edit"); ?> </button>
                           <?php endif ?>  
                          <?php if (hdev_data::service('delete_sponsor')): ?>
                          <button type="button" set_btn='fm_set_clk' e_tit="Are you Sure That You Want To delete This sponsor?" ref_id="<?php echo $group['sp_id']; ?>" data="<?php echo $reject; ?>" hash="<?php echo $tkn; ?>" rel="external" class="btn btn-danger fm_pre_set" data-toggle="modal" data-target=".modal-set" ><i class="fa fa-trash"></i> Delete</button>
                           <?php endif ?>              
                        </div>
                      </td>
                      <?php endif ?>                   
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>
<?php if (hdev_data::service('request_child')): ?>
<div class="modal fade modal-reg"> 
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Chldren requesting form</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <form method="post" id="request_child">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="request_child">  
            <fieldset class="border-top border-bottom text-danger">
              Fill this form Carefully beacuse any mistake is seriaously punished!
            </fieldset>         
            <hr>    
            <div class="form-group">
              <label for="cr_num">
                Number of Children requesting for :
              </label>
              <div class="input-group mb-3">
                <input type="text" class="form-control" name="cr_num" id="cr_num" placeholder="Number of Children requesting for">
              </div>
            </div>                                    
            <div class="form-group">
              <label for="cr_desc">
                Child request Description :
              </label>
              <div class="input-group mb-3">
                <textarea type="text" class="form-control" name="cr_desc" id="cr_desc" placeholder="Briefly explain why you need those children"></textarea>
              </div>
            </div>      
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="reg_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="request_child_btn" onclick="fm_submit('request_child_btn','request_child');"><i class="fa fa-save"></i> Send Request</button>
      </div>
      </form>
    </div>

    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('delete_animal')): ?> 
<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Delete This Animal Category?</th>
                </tr>
                <tr>
                  <td>Stock id : </td>
                  <td id="animal_id"></td>
                </tr>           
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="sk_del_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="delete_animal_btn" data="" hash=""><i class="fa fa-times-circle"></i> Delete This Animal Category</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>

<?php if (hdev_data::service('delete_sponsor')): ?> 
<div class="modal fade modal-set" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Accept</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <table class="table border-bottom">
                <tr>
                  <th colspan="2" id="e_tit"></th>
                </tr>
                <tr>
                  <td>Record id : </td>
                  <td id="ref_id"></td>
                </tr>           
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="sk_del_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-danger" id="fm_set_clk" data="" hash="" onclick="fm_app('fm_set_clk')"><i class="fa fa-times-circle"></i> </button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>