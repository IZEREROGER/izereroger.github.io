<?php 
	$rasms_service = array( 
	/* ALL REQUEST ACCESS */ 
	'login' => array(
		'name'=>"Access to login",
		'error'=>"Access denied to you to login"
		),
	'user_edit' => array(
		'name'=>"Access to Edit User",
		'error'=>"Access denied to you to Edit User"
		),	
	'self_change_user_pwd' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),	
	'center_reg' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),	
	'delete_center' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),	
	'recover_center' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),	
	'edit_center' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),		
	'child_reg' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),	
	'edit_child' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),	
	'recover_child' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),	
	'delete_child' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),					
	'sponsor_reg' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),	
	'delete_sponsor' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),	
	'edit_sponsor' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),
	'recover_sponsor' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),	
	'approve_sponsor' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),
	'reject_sponsor' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),
	'request_child' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),	
	'approve_request' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),
	'reject_request' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),		
	'pr_grant_child' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),	
	'transfer_child' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),	
	'delete_sponsored' => array(
		'name'=>"Access to Change user password",
		'error'=>"Access denied to you to Change user password"
		),					
	);

	//$all_services = array_keys($rasms_service);
	//$tg = "";
	//foreach ($all_services as $key) {
	//	if ($key == "stud_delete") {
	//		$tg = 9;
	//	}
	//	if ($tg == 9) {
	//		echo "'".$key."' /*".$rasms_service[$key]['name']."*/,\n";
	//	}
		
	//}
	//$pts = implode(",", $all_services);

	//echo $pts."<br><br><br><br><br><br><br>";
	//print_r($all_services);

	$rasms_service_users = array(
		'guest'=>array(
			'land_lord_reg',
			'tenant_reg',
			'login' /*Access to login*/,
			'houses_rent',
			'location_select'/** access to select locations in ajax*/,
			'houses_rent',
			'req_house_prices'/*request rent houses price*/,
			"sponsor_reg"
		),
		'admin'=> array( //// was admin
			'login' /*Access to login*/,
			'user_edit' /*Access to edit user*/,
			'self_change_user_pwd'/** access to change password*/,
			'center_reg',
			'delete_center',
			'edit_center',
			'recover_center',
			"child_reg",
			'sponsor_reg',
			"delete_sponsor",
			"edit_sponsor",
			"recover_sponsor",
			"edit_child",
			"recover_child",
			"delete_child",
			"approve_sponsor",
			"reject_sponsor",
			"approve_request",
			"reject_request",
			"pr_grant_child",
			"transfer_child",
			"delete_sponsored"

		),
		'sponsor'=> array( //// was admin
			'login' /*Access to login*/,
			'user_edit' /*Access to edit user*/,
			'self_change_user_pwd'/** access to change password*/,
			'request_child',

		),		
		'agent'=> array( //// was admin
			'login' /*Access to login*/,
			'user_edit' /*Access to edit user*/,
			'self_change_user_pwd',
			'location_select'/** access to select locations in ajax*/,
		),		
	);
 ?>