<?php  
	define("APP_NAME", "RASMS System V.5");
	define("APP_VERSION", "1.1");
	define('APP_PROGRAMMER', ['name'=>'Izere Hirwa Roger','email'=>'izereroger1@gmail.com']);
	define('db',"o_le");
	define('db_preview',"o_le_preview");
	define('dbpass_preview', '');
	define('dbusr_preview', 'root');	
	define('dbpass', '');
	define('dbusr', 'root');
	define('db_remote', 'st_soft');
	define('dbusr_remote', 'roger');	
	define('dbpass_remote', 'qwe');
	define('dbport_remote', '3309');
	define('school_code', 'rasms_mtvet');
	//auth check 
	define("roger_draft", "hdev_c3538TVVTQU1WVSBUVkVUIFNDSE9PTA==");
	define('ad_us_pw', "hdev_79b11Li4uUk9HLi4=");
	//error_reporting(0);
 ?>