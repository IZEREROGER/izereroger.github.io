<?php  
	//HDEV GMS DEFINITIONS
	$language_definition = array("kiny","eng");
	$lang=array( 
		"menu"=>array(
				"kiny"=>array(
					"home"=>"Ahabanza",
					"services"=>"Serivisi",
					"servicesall"=>"Serivisi Zose",
					"about"=>"Ibyerekeye ".APP_NAME,
					"contact"=>"Tuvugishe",
					"lang"=>"Ururimi",
					"logout"=> "Gusohoka",
					"login"=>"Injira",
					"settings"=>"Amagenamiterere",
					"coop_settings"=>"Amagenamiterere ya Koperative",
					"coop_edit"=>"Hindura Amakuru ya Koperative",
					"profile" => "Umwirondoro",
					"my_profile" => "Umwirondoro Wanjye",
					"user_reg"=>"Users registration",					
				),
				"eng"=>array(
					"home"=>"Home",
					"services"=>"Services",
					"servicesall"=>"All Services",
					"about"=>"About ".APP_NAME,
					"contact"=>"Contact us",
					"lang"=>"Language",
					"logout"=> "Log out",
					"login"=>"Log in",
					"settings"=>"Settings",
					"coop_settings"=>"Co-operative settings",
					"coop_edit"=>"Edit Co-operative Info",
					"profile" => "Profile",
					"my_profile" => "My profile",
					"user_reg"=>"Users registration",					
				)
			),
		"form"=>array(
				"kiny" => array(
					"load"=> "Mwihangane... ibyo mwasabye birimo gukorwa!!!",
					"username" => "Izina rikuranga",
					"password" => "Ijambobanga",
					"signin" => "injira",
					"login" => "Injira",
					"login_at"=>"Injira Kuri",
					"signin_form" => "Kwinjira",
					"today"=>"Uyumunsi",
					"this_year"=>"Uyumwaka",
					"action"=>"Igikorwa",
					"edit" =>"Hindura",
					"edit_info"=>"Hindura Amakuru",
					"save_info"=>"Bika amakuru",
					"change_password"=>"Hindura ijambobanga",
					"view" => "Reba",
					"delete" => "Siba",
					"recover"=> "Garura",
					"reject"=>"Anga Amakuru",
					"approve"=>"Emeza amakuru",
					"close" => "Funga",
					"from" => "Kuva",
					"to" => "Kugera",
					"accept"=>"Emeza",										
				),
				"eng"=>array(
					"load"=> "loading... please wait!!!",
					"username" => "Username",
					"password" => "Password",
					"signin" => "Sign in",
					"login" => "Log in",
					"login_at" => "Login At",
					"signin_form" => "Sign in form",
					"today"=>"Today",
					"this_year"=>"This Year",
					"action"=>"Action",
					"edit" =>"Edit",
					"edit_info"=>"Edit info",
					"save_info"=>"Bika amakuru",
					"change_password"=>"Change Password",
					"view" => "View",
					"delete" => "Delete",
					"recover"=> "Recover",
					"reject"=>"Reject",
					"approve"=>"Approve",
					"close" => "Close",
					"from" => "From",
					"to" => "To",					
					"save_member"=>"Save Member Info",
					"accept"=>"Accept",				
				)
			),

		"data"=>array(
			"kiny" => array(

				),
			"eng" => array(

				)
			),
		"validation"=>array(
			"kiny" => array(
				"signedin" => "winjiye",
				"confirm_logout"=>"nibyo koko urashaka Gusohoka?",
				"log_fair" => "Ntakonti ihuye nibyo mwanditse",
				"error_try_again" => "Havutse ikibazo, mwongere mugerageze mukanya",
				"check_conn" => "Reba neza ko ufite internet connection",
				"all_fields" => "Uzuza imyanya yose",
				"saving" => "Birimo kubikwa ... Tegereza!!!",
				"loading" => "Ibyo mwasabye birimo Gushakishwa.....",
				"processing" => "Mwihangane Ibyo mwasabye birimo gukorwa",
				"not_found"=>"Ntabyabonetse",
				"saved" => "Byabitswe Neza !!!",
				"passwords_not_match"=>"ijambobanga rishya ntabwo rihura niryo mwanditse urisubiramo",
				"incorrect_current_password"=>"ijambobanga usanzwe ukoresha mwanditse ntabwo ariryo",
				"not_change_password"=>"Ntiwemerewe kwihindurira ijambobanga",
				"password_changed"=>"Ijambobanga ryahinduwe neza",
				"not_change_info"=>"Ntiwemerewe kwihindurira amakuru",
				"info_changed"=>"amakuru ya konti yawe yahinduwe neza ",			
				),
			"eng" => array(
				"signedin" => "Signed in!!",
				"confirm_logout"=>"Are you sure, you want to logout?",
				"log_fair" => "No account found for what you provided",
				"error_try_again" => "Something Went Wrong, try again later",
				"check_conn" => "Error: check your internet connection",
				"all_fields" => "Fill all fields",
				"saving" => "Saving... wait!!!",
				"loading" => "Loading.....",
				"processing" => "Processing ... please wait",
				"not_found"=>"Not found",
				"saved" => "Saved !!!",
				"passwords_not_match"=>"New passwords does not match",
				"incorrect_current_password"=>"Provided current Password is incorrect",
				"not_change_password"=>"Access denied You can't change Password",
				"password_changed"=>"Password Changed successfully",
				"not_change_info"=>"Access Denied, you can't change your info",
				"info_changed"=>"Your account info changed",			

				)
			)
	);
	///initialise language function to receceive and array of language definitions
	hdev_lang::reset();
	hdev_lang::set($lang);
	if (empty($_SESSION["lang"])) {
		$_SESSION["lang"] ="ang";
	}
	if ($_GET) {
		if (isset($_GET['lang'])) {
	      if (!empty($_GET['lang'])) {
	        if (in_array($_GET['lang'], $language_definition)) {
	        	$_SESSION['lang'] = $_GET['lang'];
	        	hdev_note::message("Ururimi rwahinduwe neza----Language changed");
	        	if (!empty($_GET["nxt"])) {
	        		hdev_note::redirect(hdev_url::activate($_GET["nxt"]));
	        	}
	        	else{
	        		hdev_note::redirect(hdev_url::get_url_host());
	        	}
	        }else{
	        	hdev_note::message("Ururimi wahisemo ntirwashoboye kuboneka --- Language selected does not exist");
	        	if (!empty($_GET["nxt"])) {
	        		hdev_note::redirect(hdev_url::activate($_GET["nxt"]));
	        	}
	        	else{
	        		hdev_note::redirect(hdev_url::get_url_host());
	        	}
	        }
	      }
	    }		
	}
	//$langg = $_SESSION['lang'];
	//$_SESSION['exp'] = $lang;
 ?>