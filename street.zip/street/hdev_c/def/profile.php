<div class="content">
      <div class="container">       
        <div class="row" align="center">
          <div class="col-sm-12">
          	<div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header">
                <h5 class="card-title m-0"><?php echo hdev_lang::on("menu","my_profile"); ?> </h5>
              </div>
              <div class="card-body table-responsive p-0">
                <div class="row">
                  <div class="col-sm-3 border-bottom">
                    <div style="margin-top: 30%;">
                    <i class="fa fa-user fa-5x"></i><br>
                    <i class="fa"><?php echo APP_NAME; ?> </i>
                    </div>
                  </div>
                  <div class="col-sm-9 border-left">
              	<table class="table table-hover border-left border-bottom text-nowrap">
                  <tbody>
                    <tr>
                      <td><?php echo hdev_lang::on("data","names"); ?> :</td> 
                      <td><?php echo hdev_data::get_admin(hdev_log::uid(),['data'])["a_name"]; ?></td>
                    </tr>
                    <tr>
                      <td><?php echo hdev_lang::on("data","username_me"); ?> :</td>
                      <td><?php echo hdev_data::get_admin(hdev_log::uid(),['data'])["a_username"]; ?></td>
                    </tr>
                    <tr>
                      <td><?php echo hdev_lang::on("data","sex"); ?> :</td>
                      <td><?php echo hdev_data::get_admin(hdev_log::uid(),['data'])["a_sex"]; ?></td>
                    </tr>
                    <tr>
                      <td>Role :</td>
                      <td><?php echo hdev_data::get_admin(hdev_log::uid(),['data'])["a_role"]; ?></td>
                    </tr>
                    <tr>
                      <td><?php echo hdev_lang::on("data","tel"); ?> :</td>
                      <td><?php echo hdev_data::get_admin(hdev_log::uid(),['data'])["a_tel"]; ?></td>
                    </tr>
                    <tr>
                      <td><?php echo hdev_lang::on("data","email"); ?> :</td>
                      <td><?php echo hdev_data::get_admin(hdev_log::uid(),['data'])["a_email"]; ?></td>
                    </tr>
                    <tr>
                      <td><?php echo hdev_lang::on("data","nid"); ?> :</td>
                      <td><?php echo hdev_data::get_admin(hdev_log::uid(),['data'])["a_nid"]; ?></td>
                    </tr>
                    <tr>
                      <td><?php echo hdev_lang::on("data","regno"); ?> :</td>
                      <td><span class='text-success'><?php echo hdev_data::get_admin(hdev_log::uid(),['data'])["a_id"]; ?></span></td>
                    </tr>
                  </tbody>
                </table>
                  </div>
                </div>
                <br>
                <div class="btn-group">
                  <?php if (hdev_data::service('user_edit')): ?> 
                  <button type="button" class="btn btn-primary user_editt" data-toggle="modal" data-target=".modal-edit">
                        <span class="fa fa-edit"></span>
                     <?php echo hdev_lang::on('form','edit_info'); ?>
                  </button>
                  <?php endif ?>
                  <?php if (hdev_data::service('self_change_user_pwd')): ?> 
                  <button type="button" class="btn btn-success user_editt" data-toggle="modal" data-target="#modal-default">
                        <span class="fa fa-unlock"></span>
                     <?php echo hdev_lang::on('form','change_password'); ?>
                  </button>
                  <?php endif ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

<?php if (hdev_data::service('self_change_user_pwd')): ?> 
<div class="modal fade" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo hdev_lang::on('form','change_password'); ?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form method="post" id="self_sec_p">
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <input type="hidden" name="ref" value="self_change_user_pwd">
              <div class="form-group">
              <label for="r_acc_name">
                <?php echo hdev_lang::on('data','current_password'); ?> :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fa fa-unlock"></span>
                  </div>
                </div>
                <input type="password" id="old_password" name="old_password" class="form-control" required="true" placeholder="<?php echo hdev_lang::on('data','current_password'); ?>">
              </div>
            </div>
              <div class="form-group">
              <label for="r_acc_name">
                <?php echo hdev_lang::on('data','new_password'); ?> :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fa fa-lock"></span>
                  </div>
                </div>
                <input type="password" name="new_password" class="form-control" placeholder="<?php echo hdev_lang::on('data','new_password'); ?>" required="true">
              </div>
            </div>
            <div class="form-group">
              <label for="r_acc_name">
                <?php echo hdev_lang::on('data','re_type_new_password'); ?> :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fa fa-lock"></span> 
                  </div>
                </div>
                <input type="password" name="confirm_password" id="cfp" class="form-control" placeholder="<?php echo hdev_lang::on('data','re_type_new_password'); ?>" required="true">
              </div>
            </div>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#prof_edit_close">
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="prof_edit_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="submit" class="btn btn-primary" id="self_sec_p_btn"><i class="fa fa-save"></i><?php echo hdev_lang::on('form','change_password'); ?></button>
      </div>
    </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>
<?php if (hdev_data::service('user_edit')): ?> 
<div class="modal fade modal-edit"> 
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title"><?php echo hdev_lang::on('form','edit_info'); ?></h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <form method="post" id="user_edit">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                $csrf = new CSRF_Protect();
                $csrf->echoInputField();
              ?>
              <input type="hidden" name="ref" value="user_edit">
            <div class="form-group">
              <label for="name">
                <?php echo hdev_lang::on("data","names"); ?> :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fa fa-user-alt"></span>
                  </div>
                </div>
                <input type="text" name="name" id="name" class="form-control" placeholder="<?php echo hdev_lang::on("data","names"); ?>" required="true" value="<?php echo hdev_data::get_admin(hdev_log::uid(),['data'])["a_name"]; ?>">
              </div>
            </div>
            <div class="form-group">
              <label for="n_id">
                <?php echo hdev_lang::on("data","nid"); ?> :
              </label>
              <div class="input-group mb-0">
                
                <div class="input-group-prepend">
                  <div class="input-group-text" id="input_icon_id">
                    <span class="fa fa-user-tag"></span>
                  </div>
                </div>
                <input type="number" oninput="id_validator($(this).val(),'#input_icon_id','#message_box_id','#edit_user_btn')"  name="n_id" id="n_id" class="form-control" placeholder="<?php echo hdev_lang::on("data","nid"); ?>" required="true" value="<?php echo hdev_data::get_admin(hdev_log::uid(),['data'])["a_nid"]; ?>">
              </div>
              <div class="input-group mb-3" id="message_box_id">
              </div>              
            </div>
            <div class="form-group">
              <label for="username_r">
                <?php echo hdev_lang::on("data","username_me"); ?> :
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fa fa-user-tag"></span>
                  </div>
                </div>
                <input type="text" name="username" id="username_r" class="form-control" placeholder="<?php echo hdev_lang::on("data","username_me"); ?>" required="true" value="<?php echo hdev_data::get_admin(hdev_log::uid(),['data'])["a_username"]; ?>">
              </div>
            </div>
            <div class="form-group">
              <label for="sex">
                <?php echo hdev_lang::on("data","sex"); ?> :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fa fa-user-friends"></span>
                  </div>
                </div>
                <select class="form-control" name="sex" id="sex" >
                  <option value=""><?php echo hdev_lang::on("data","sex"); ?></option>
                  <option value="Male"<?php if (1==2): ?> selected="selected" <?php endif ?>>Male</option>
                  <option value="Female"<?php if (1==2): ?> selected="selected" <?php endif ?>>Female</option>
                </select>
              </div>
            </div> 
            <div class="form-group">
              <label for="email">
                <?php echo hdev_lang::on("data","email"); ?> :
              </label>
              <div class="input-group mb-3">
                <div class="input-group-prepend">
                  <span class="input-group-text">@</span>
                </div>
                <input type="email" name="email" id="email" class="form-control" placeholder="<?php echo hdev_lang::on("data","email"); ?>" required="required" value="<?php echo hdev_data::get_admin(hdev_log::uid(),['data'])["a_email"]; ?>">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fa fa-envelope"></span>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <label for="tel">
                <?php echo hdev_lang::on("data","tel"); ?>:
              </label>
              <div class="input-group mb-3">
                
                <div class="input-group-prepend">
                  <div class="input-group-text">
                    <span class="fa fa-phone"></span>
                  </div>
                </div>
                <input type="text" id="tel" name="tel" class="form-control" placeholder="<?php echo hdev_lang::on("data","tel"); ?>" required="true" maxlength="10" value="<?php echo hdev_data::get_admin(hdev_log::uid(),['data'])["a_tel"]; ?>">
              </div>
            </div>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#reg_close">
            
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="reg_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="edit_user_btn"><i class="fa fa-save"></i> Save Info</button>
      </div>
      </form>
    </div>

    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>