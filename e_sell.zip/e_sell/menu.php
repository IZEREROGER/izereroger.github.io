 <?php 
    $menutop = array(
      "1" => array(
        "name" => "Home",
        "trees" => "1",
        "icon" => "fas fa-home",
        "link" => "h...home"
      ),
      "2" => array(
        "name" => $lang["menu"][$langg]["about"],
        "trees" => "1",
        "icon" => "fas fa-book",
        "link" => "h...about"
      ),
      "3" => array(
        "name" => $lang["menu"][$langg]["contact"],
        "trees" => "1",
        "icon" => "fas fa-phone fa-3x",
        "link" => "h...contact"
      ),
      "4" => array(
        "name" => "View as admin",
        "trees" => "1",
        "icon" => "fas fa-user-secret",
        "link" => "v...b"
      ),
    );
  ?>
    <?php
      $menumask = array();
      $menumain = array();
      if (!empty(hdev_data::get_cat())) {
        foreach (hdev_data::get_cat() as $cat) {
          array_push($menumask, $cat["c_name"]);
        }
      }
      if (count($menumask) > 0) {
        foreach (hdev_data::get_cat() as $cat) {
          $menumain[$cat["c_name"]]=hdev_data::get_cat_products($cat['c_id']);
        }
      }
    ?>
      <style type="text/css">
    #status{
      background-image:url(<?php echo hdev_url::menu('dist/img/loading2.gif');?>); /* path to your loading animation */
    }
  </style>
  <nav class="main-header navbar navbar-expand navbar-dark navbar-gray text-sm top_nav ">
    <div class="container">
      <a href="<?php echo hdev_url::get_url_host(); ?>" class="navbar-brand">
        <img src="<?php echo hdev_url::menu('dist/img/hdev_app2.png');?>" alt="<?php echo APP_NAME; ?> Logo" class="brand-image img-circle elevation-3"
             style="opacity: .8;height: auto;width: 2.1rem;">
        <span class="font-weight-light"><?php echo "<b>".APP_NAME."</b>"; ?></span>
      </a>
      <!-- Right navbar links -->
      <ul class="order-1 order-md-3 navbar-nav navbar-no-expand ml-auto">
        <!-- SEARCH FORM -->
        <form class="form-inline ml-0 ml-md-3" method="get" action="<?php echo hdev_url::menu('ss');?>">
          <div class="input-group input-group-sm">
            <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search" name="q" value="<?php echo (isset($_GET['q'])) ? $_GET['q'] : ""; ?>">
            <div class="input-group-append">
              <button class="btn btn-navbar" type="submit">
                <i class="fas fa-search"></i>
              </button>
            </div>
          </div> 
        </form>
      </ul>
      </div>
  </nav>
<nav class="main-header navbar navbar-expand-md navbar-dark navbar-gray text-sm top_nav" id="of_head">
      <button class="navbar-toggler order-1" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="<?php echo $lang['menu'][$langg]['services']; ?>" title="<?php echo $lang['menu'][$langg]['services']; ?>" id="mhead">
        <span class="navbar-toggler-icon"></span>
        <?php echo $lang['menu'][$langg]['menu']; ?>
      </button>
      <div class="collapse navbar-collapse order-3" id="navbarCollapse">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
          <?php 
              hdevmenu::topmenu($menutop[1]['trees'],$menutop[1]['name'],$menutop[1]['link'],$menutop[1]['icon']);
          ?>
          <?php 
              hdevmenu::topmenu($menutop[2]['trees'],$menutop[2]['name'],$menutop[2]['link'],$menutop[2]['icon']);
          ?>
          <?php 
              hdevmenu::topmenu($menutop[3]['trees'],$menutop[3]['name'],$menutop[3]['link'],$menutop[3]['icon']);
          ?>
          <?php
            if (hdev_log::admin()) {
            hdevmenu::topmenu($menutop[4]['trees'],$menutop[4]['name'],$menutop[4]['link'],$menutop[4]['icon']);
            }
          ?>
           <?php if (1==0) { ?>
           <li class="nav-item dropdown">
            <a id="dropdownSubMenu1" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="ind nav-link dropdown-toggle"><i class="fas fa-language"></i>&nbsp; Ururimi/Language</a>
            <ul aria-labelledby="dropdownSubMenu1" class="dropdown-menu border-0 shadow">
              <li><a href="<?php echo hdev_url::menu('?lang=kiny&nxt='.hdev_url::next(hdev_url::get_url_full()));?>" class="dropdown-item">Ikinyarwanda </a></li>
              <li><a href="<?php echo hdev_url::menu('?lang=eng&nxt='.hdev_url::next(hdev_url::get_url_full()));?>" class="dropdown-item">English</a></li>
            </ul>
          </li>
          <?php 
             # code...
           } ?>
          <div id="google_translate_element" class="nav-item bg-white"></div>
                  <!-- Messages Dropdown Menu -->
        <li class="nav-item dropdown cart_parent" style="display: none;">

          <a class="nav-link bg-info" data-toggle="dropdown" href="#">
             Cart&nbsp;<i class="fa fa-shopping-cart fa-3x"></i><i class="fa fa-caret-down"></i>
            <span class="badge badge-danger navbar-badge badge_cart"></span>
          </a>
          <div class="dropdown-menu dropdown-menu-xl dropdown-menu-right">
          <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                  <a href="<?php echo hdev_url::menu('h/cartv'); ?>">
                  <button class="btn btn-secondary">
                    <i class="fa fa-eye"></i>
                    View Shopping cart
                    <i class="fa fa-shopping-cart"></i>
                  </button>
                  </a>
                </h3>
                <div class="card-tools">
                  <a href="<?php echo hdev_url::menu('h/cartv'); ?>">
                  <button class="btn btn-secondary">
                    <i class="fa fa-edit"></i>
                    Edit Cart
                    <i class="fa fa-shopping-cart"></i>
                  </button>
                  </a>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0 osc" style="height: 300px;">
                <table class="table table-head-fixed table-bordered text-nowrap">
                  <thead>
                    <th class="bg-primary">Size</th>
                      <th class="bg-primary">Qty.</th>
                      <th class="bg-primary">Product Image</th>
                      <th class="bg-primary">Product Name</th>
                      <th class="bg-primary">Price in $.</th>
                  </thead>
                  <tbody class="cart_product">
                    <tr>
                      <td colspan="4">
                        #
                      </td> 
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </li>
        </ul>
      </div>

      <!-- Right navbar links -->
      <ul class="order-1 order-md-3 navbar-nav navbar-no-expand ml-auto">
      <li style="display: none;" class="cart_parent_2 nav-item nav-link navbar-toggler order-1 bg-secondary text-white" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" >
             Cart &nbsp;<i class="fa fa-shopping-cart fa-3x"></i>
            <span class="badge badge-danger navbar-badge badge_cart"></span>
      </li>
        <!-- Notifications Dropdown Menu -->
        <?php
          if (hdev_log::loged()) {
        ?>
        <!-- Notifications Dropdown Menu -->
      <!--<li class="nav-item">
        <a class="nav-link" href="<?php echo hdev_url::menu('h/msg'); ?>" title="Messages">
          Messages
          <i class="fa fa-envelope"></i>
          <span class="badge badge-danger navbar-badge ctmg"></span>
        </a>
      </li>-->
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="fa fa-cogs"></i>
          Settings
        </a>
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <a href="<?php echo hdev_url::menu("h/v") ?>" class="dropdown-item">
            <i class="fas fa-user-cog mr-0"></i> Profile
          </a>
          <div class="dropdown-divider"></div>
          <a href="<?php echo hdev_url::menu('h/order'); ?>" class="dropdown-item">
            <i class="fas fa-boxes mr-0"></i> Orders
          </a>
          <div class="dropdown-divider"></div>
          
                <a class="ind dropdown-item" href="#" onclick="logout('<?php echo hdev_url::menu('up?logout=truek');?>');" rel='external'>
                  <i class="fas fa-power-off" title="log out"></i>&nbsp;
              <?php
                  //echo $lang["menu"][$langg]["logout"]."<b>( ".hdev_data::post_user(hdev_data::dec($_SESSION['uid']),"username")." )</b>";
                  echo $lang["menu"][$langg]["logout"]."<b>(".hdev_data::get_user(hdev_data::decd($_SESSION['uid'])).")</b>";
              ?>
                </a>
              
        </div>
      </li>
      <?php
        }
      ?>
        
              <?php
                if (hdev_log::loged()) {
                  echo "";
                }else{
                  ?>
                  <li class="nav-item">
                  <a class="nav-link bg-primary" href="<?php echo hdev_url::menu('h/login');?>">
                    <i class="fas fa-power-off" title=""></i>&nbsp;
                          <?php
                            echo $lang["form"][$langg]["signin"];
                            ?>
                          </a>
                  </li>
                  <li class="nav-item">
                         <a href="#" class="nav-link bg-success ftb" data-toggle="modal" data-target=".modal-reg"><i class="fas fa-plus-circle" style="text-align: center;"></i> Shop registration</a>;
                  </li>
              <?php
                }
               ?>
      </ul>
  </nav>
<?php if (1==2) {
?>
    <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-navy elevation-4" id="left_nav">
    <!-- Brand Logo -->
    <a href="<?php echo hdev_url::menu('');?>" id="brandy2" class="brand-link">
      <img src="<?php echo hdev_url::menu('dist/img/hdev_app2.png');?>" alt="<?php echo "<b>".APP_NAME."</b>"; ?>" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light"><?php echo "<b>".APP_NAME."</b>"; ?></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo hdev_url::menu('dist/img/hdev_app2.png');?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info"> 
          <a href="#" class="d-block"><?php echo ucfirst(hdev_log::user()); ?></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false" id="get_category">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
            <li class="nav-item">
              <a class="nav-link ind" data-widget="pushmenu" href="#"><i class="fas fa-times"></i></a>
            </li>
            <?php 
            // category views
            ?>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  
<?php
} ?>