<?php 
  if (hdev_log::loged()) {
    hdev_note::redirect(hdev_url::menu(""));
  }
 ?>
  <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">

  <title><?php echo APP_NAME; ?> --- AUTH</title>

  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/fontawesome-free/css/all.min.css'); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo hdev_url::menu('dist/css/adminlte.min.css');?>">
  <link rel="stylesheet" href="<?php echo hdev_url::menu('dist/css/main.css');?>">
  <link rel="stylesheet" href="<?php echo hdev_url::menu('dist/css/lgn.css');?>">
  <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css');?>">
   <link rel="ICON" type="ICON/ico" href="<?php echo hdev_url::menu('dist/img/rasms.ico');?>">
  <!-- Google Font: Source Sans Pro -->
  <!--<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">-->
</head>
<body style="background : url('<?php echo hdev_url::menu('dist/img/always_grey.png'); ?>') repeat rgba(68, 68, 68, 0.9);">
  <style type="text/css">
    #status{
      background-image:url(<?php echo hdev_url::menu('dist/img/loading2.gif');?>); /* path to your loading animation */
    }
  </style>
  <!-- Preloader -->
<div id="preloader">
  <div id="status">&nbsp;  <br><i><?php echo hdev_lang::on("form","load"); ?></i><br></div>
</div>

<div>
<div>