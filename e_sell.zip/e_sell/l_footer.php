  </div>
</div>
<!-- ./wrapper -->
<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src="<?php echo hdev_url::menu('plugins/jquery/jquery.min.js');?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo hdev_url::menu('plugins/bootstrap/js/bootstrap.bundle.min.js');?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo hdev_url::menu('dist/js/adminlte.min.js');?>"></script>
<!-- SweetAlert2 -->
<script src="<?php echo hdev_url::menu('plugins/sweetalert2/sweetalert2.min.js');?>"></script>
<script src="<?php echo hdev_url::menu('plugins/ajax/former.js');?>"></script>
<!-- font awesome -->
<script type="text/javascript" src="<?php echo hdev_url::menu('dist/js/demo.js');?>"></script>
<!-- Preloader -->

<script type="text/javascript">
  //<![CDATA[
    $(window).on('load', function() { // makes sure the whole site is loaded 
      $('#status').fadeOut(); // will first fade out the loading animation 
            $('#preloader').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website. 
            $('body').delay(350).css({'overflow':'visible'});
    })
  //]]>
</script> 
<script type="text/javascript">
  $load_status= $('<span><img src="<?php echo hdev_url::menu('dist/img/loading2.gif');?>"/></span><i>&nbsp;&nbsp;wait...!!!</i>');
  $saved = $('<span class="text-success"><?php echo hdev_lang::on("validation","saved"); ?></span>');
  $min_wait = $('<span class="text-success"><?php echo hdev_lang::on("validation","loading"); ?></span>');
    function id_validator(val_text='',input_icon='',message_box='',sub_btn='') {

    if (val_text.length != 16) {
      errors = "Id must be 16 digits";
      var a = '<span class="text-danger">'+errors+'</span>';
      $(sub_btn).hide();
      $(message_box).html(a);
      $(input_icon).html('<span class="fa fa-times-circle text-danger"></span>');
    }else{
      $(sub_btn).show();
      $(message_box).html('');
      $(input_icon).html('<span class="fa fa-check-circle text-success"></span>');
    }
  }
    function attach(aa='') {
      window.reload();
    }
    function login() {
      //alert('helloooooo');
          const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: fsave,
          timer: 3000
        });
        var formData = jQuery('#login_form').serialize();
        $.ajax({
          type: "POST",
          url: "<?php echo hdev_url::menu('login_i');?>",
          data: formData,
          beforeSend: function(){
            // Show image container
            $("#fsave").hide();
            $(".wait").show();
           },
          success:function(html){
            if (html == 'ok'){
              Toast.fire({
                type: 'success',
                title: 'Authorised'
              });
              var delay = 1000;
              setTimeout(function(){
                 window.location.href='<?php echo hdev_url::menu("h/home");?>';
              }, delay);
            }else
            {
            //alert(html);
              Toast.fire({
                type: 'error',
                title: 'Please Check your username and Password and try again'
              });
            }
          },
          complete:function(html){
            // Hide image container
           setTimeout(function(){
              //$("#fsave").show();
              $(".wait").hide();
            }, 3000);
           }
        });
    }

    $(document).ready(function() { 
     $('#reg_shop').submit(function(e) {  
      if($('#shop_image').val()) {
        e.preventDefault();

        $(this).ajaxSubmit({  
          target:   '.wait',  
          beforeSubmit: function() {
            $("#progress-bar").width('0%');
            $('.wait').html($load_status);
            $('#reg_shops').hide();
          },
          uploadProgress: function (event, position, total, percentComplete){ 
            $("#progress-bar").width(percentComplete + '%');
            $("#progress-bar").html('<div id="progress-status">' + percentComplete +' %</div>');

          },
          success:function (){
              $('#reg_shops').show();

            setTimeout(function(){
              $('.wait').html('');
            }, 9000);
          },
          resetForm: false 
        }); 
        return false; 
      }else{
        a = '<span class="text-danger">Choose what to upload first</span>';
        $('.wait').html(a);
        setTimeout(function(){
          $('.wait').html('');
        }, 3000);
        return false;
      }
    });
  }); 
     jQuery(document).ready(function(){


    jQuery("#register_form").submit(function(e){
        const Toast = Swal.mixin({
          toast: true,
          position: 'top-end',
          showConfirmButton: fsave,
          timer: 3000
        });
        e.preventDefault();
        var formData = jQuery(this).serialize();
        $.ajax({
          type: "POST",
          url: "<?php echo hdev_url::menu('login_i');?>",
          data: formData,
          beforeSend: function(){
            // Show image container
            $("#fsave").hide();
            $(".wait").show();
           },
          success:function(html){
            if (html == 'ok'){

              Toast.fire({
                type: 'success',
                title: 'Authorised'
              });
              
              setTimeout(function(){
                 window.location.href='<?php echo hdev_url::menu("h/success");?>';
              }, delay);
            }else{
              var delay = 9000;
              $('#resp').html(html);
              setTimeout(function(){
                 $('#resp').html('');
              }, delay);
            }
          },
          complete:function(html){
            // Hide image container
           setTimeout(function(){
              $("#fsave").show();
              $(".wait").hide();
            }, 3000);
           }
        });
      });
     })
</script>
</body>
</html>