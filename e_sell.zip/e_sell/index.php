<?php 
  $link = ['executor/include','catch','head'];
  foreach ($link as $linkage) {
    include $linkage.'.php';
  }
  if (isset($_SESSION['mtkn']) && !empty($_SESSION['mtkn'])) {
  	if (hdev_data::decd($_SESSION['mtkn'])=="11" && hdev_log::admin()) {
  		include "menu2.php";
  	}elseif (hdev_log::loged() && hdev_log::super_admin()) {
      include 'menu3.php';
    }else{ 
  		include 'menu.php';
  	}
  }else{
  	include 'menu.php';
  }
  $link = ['body','footer'];
  foreach ($link as $linkage) {
    include $linkage.'.php';
  }
 ?>