<?php 
	//HDEV GMS DEFINITIONS
	$language_definition = array("kiny","eng");
	$lang=array( 
		"menu"=>array(
				"kiny"=>array(
					"home"=>"Ububiko",
					"announce"=>"Amatangazo",
					"media" => "Itangaza Makuru",
					"news" => "Amakuru",
					"leasson" => "Inyigisho",
					"posted" => "Byashyizweho",
					"ideas" => "Ibitekerezo",
					"forum" => "Urubuga rw'ibitekerezo",
					"lv_msg" => "Siga Ubutumwa",
					"name" =>"Amazina",
					"services"=>"Serivisi",
					"servicesall"=>"Serivisi zose",
					"about"=>"Ibyerekeye ".APP_NAME,
					"contact"=>"Tuvugishe",
					"lang"=>"Ururimi",
					"settings"=>"Amagenamiterere",
					"group"=>"Itsinda",
					"members"=>"Abanyamuryango",
					"accountsetup"=>"Ibyerekeye Konti",
					"accounts" => "Konti",
					"acc_m" =>"kanti z'Abanyamuryango",
					"payment"=>"Ubwizigame",
					"feesetup"=>"Fees setup",
					"loanmanage"=>"Inguzanyo",
					"externals"=>"Ibindi Bikorwa",
					"extincome"=>"Ibyinjije amafaranga",
					"extexpense"=>"Ibatwaye amafaranga",
					"savingdivision"=>"Kubikuza Ubwizigame",
					"logout"=>"Gusohoka",
					"notifications"=> "amamenyesha",
					"menu"=>"Ibirimo",
					"profile"=>"Ipaji yanjye",
					"create_post"=>"Inkuru nshya"
				),
				"eng"=>array(
					"home"=>"Store",
					"announce"=>"Announcements",
					"media" => "Media",
					"news" => "News",
					"leasson" => "Leasson",
					"posted" => "Posted",
					"ideas" => "Ideas",
					"forum" => "Forum",
					"lv_msg" => "Leave  message",
					"name" =>"Names",
					"services"=>"Services",
					"servicesall"=>"All Services",
					"about"=>"About ".APP_NAME,
					"contact"=>"Contact us",
					"lang"=>"Language",
					"settings"=>"Settings",
					"group"=>"Group settings",
					"members"=>"Members",
					"accountsetup"=>"Accounts Setup",
					"accounts" => "Accounts",
					"acc_m" =>"Members Accounts",
					"payment"=>"Savings",
					"feesetup"=>"Fess Setup",
					"loanmanage"=>"Loans Management",
					"externals"=>"Other activities",
					"extincome"=>"External icome",
					"extexpense"=>"EXtera expenses",
					"savingdivision"=>"Withdraw Savings",
					"logout"=>"Log out",
					"notifications"=> "Notifications",
					"menu"=>"menu",
					"profile"=>"profile",
					"create_post"=>"Inkuru nshya"
				)
			),
		"form"=>array(
				"kiny" => array(
					"load"=> "Mwihangane... ibyo mwasabye birimo gukorwa!!!",
					"username" => "Izina rikuranga",
					"password" => "Ijambobanga",
					"signin" => "injira",
					"signin_form" => "Kwinjira",
					"edit" =>"hindura",
					"view" => "Reba",
					"delete" => "Siba",
					"close" => "Funga",

				),
				"eng"=>array(
					"load"=> "loading... please wait!!!",
					"username" => "Username",
					"password" => "password",
					"signin" => "Sign in",
					"signin_form" => "Sign in form",
					"edit" =>"Edit",
					"view" => "View",
					"delete" => "Delete",
					"close" => "Close",

					
				)
			),
		"data"=>array(
			"kiny" => array(
				),
			"eng" => array(
					"gp_inf"=> "Group Info",
					"gp_cd" => "Group reg code",
					"gp_nm" => "Group name",
					"gp_ln" => "Group location",
					"stm_access" => "System access",
					"gp_dt" => "Group Reg Date",
					"ed_gp" => "Edit Group Info",
					"stm_gn_user" => "SYSTEM GENERAL USER",
					"gp_adminst" =>"Group Administration",
					"gp_secretary" => "Group Seretary(s)",
					"gp_cashier" => "Group Cashier(s)",
					"gp_audit" => "Group Auditor(s)",
					"gp_manager" => "Group Manager(s)",
					"acc_top" => "Current accounts",
					"acc_reg_new" => "New Account Registration",
					"acc_print" => "Print",
					"no" => "N<sup><u>O</u></sup>",
					"sys_id" => "System ID",
					"save_as"=> "Save as",
					"acc_share_amount" => "Share amount",
					"reg_date" => "Reg Date",
					"action" => "Action",
					"acc_name" => "Account name",
					"acc_hld" => "Account Holders",
					"acc_share_amount" => "Share Amount",
					"acc_edit" => "Edit account",
					"acc_name" => "Account name",
					"acc_view" => "Account view",
					"acc_save_new" => "Save new account",
					"acc_status" => "Account Status",
					"save_change" => "Save Changes",
					"m_nid" => "N. ID",
					"memb_top" => "Current Members",
					"memb_tel" => "Tell no",
					"memb_acc_types" => "Account types",
					"memb_shares" => "Member Shares",
					"memb_tot_shares" => "Total Share amount",
					"memb_share_details" => "shares details",
					"member_reg_new" => "Register new Member",
					"memb_edit" => "Edit Member Information",
					"member_view" => "View member",
					"memb_nid" => "Member National Identity Card Number",
					"memb_name" => "Member Name",
					"memb_fname" => "Member First Name",
					"memb_lname" => "Member Last Name",
					"memb_4ne" => "Member Phone number",
					"memb_pass" => "Member Passcode",
					"memb_save_new" =>"Save new Member",
					"memb_w_acc" => "Members with this account",
					"all_acc_shares" => "All account shares",
					"all_shares_amount" => "All shares mount",

				)
			),
		"validation"=>array(
			"kiny" => array(
				"signedin" => "winjiye",
				"log_fair" => "Ntakonti ihuye nibyo mwanditse",
				"acc_exist" => "that account name already exists try diferrent one",
				"error_try_again" => "error try again later",
				"share_numeric" => "share amount must be numeric",
				"all_fields" => "uzuza imyanya yose",
				"acc_name_exist" => "Acount with provided name already exists",
				"acc_up_not_exist" => "the account desired to be updated does not exist",
				"acc_cnt_up" => "can't update this account with provided changes please try again",
				"acc_ref_cnt" => "can't match account name and referenced account",
				"saving" => "Saving... wait!!!",
				"loading" => "loading.....",
				"saved" => "Saved !!!",
				"acc_undetect" => "no account detected refresh a page and try again",
				"check_conn" => "error  check your internet connection",
				"member_exist" => "A member with id/phone number provided already exists",
				"member_notfound" => "member desired to be updated does not exist",
				"error_try_part" => "few records were not updated",
				"l_found" => "Found and Fetched",
				"l_not_found" => "No records found",
				"memb_address_not_found" => "Member identification failed please try again"
				),
			"eng" => array(
				"signedin" => "Signed in!!",
				"log_fair" => "No ccount found for what you provided",
				"acc_exist" => "that account name already exists try diferrent one",
				"error_try_again" => "error try again later",
				"share_numeric" => "share amount must be numeric",
				"all_fields" => "Fill all fields",
				"acc_name_exist" => "Acount with provided name already exists",
				"acc_up_not_exist" => "the account desired to be updated does not exist",
				"acc_cnt_up" => "can't update this account with provided changes please try again",
				"acc_ref_cnt" => "can't match account name and referenced account",
				"saving" => "Saving... wait!!!",
				"loading" => "loading.....",
				"saved" => "Saved !!!",
				"acc_undetect" => "no account detected refresh a page and try again",
				"check_conn" => "error  check your internet connection",
				"member_exist" => "A member with id/phone number provided already exists",
				"member_notfound" => "member desired to be updated does not exist",
				"error_try_part" => "few records were not updated",
				"l_found" => "Found and Fetched",
				"l_not_found" => "No records found",
				"memb_address_not_found" => "Member identification failed please try again"
				)
			)
	);
	if (empty($_SESSION["lang"])) {
		$_SESSION["lang"] ="eng";
	}
	if ($_GET) {
		if (isset($_GET['lang'])) {
	      if (!empty($_GET['lang'])) {
	        if (in_array($_GET['lang'], $language_definition)) {
	        	$_SESSION['lang'] = $_GET['lang'];
	        	hdev_note::message("Ururimi rwahinduwe neza----Language changed");
	        	if (!empty($_GET["nxt"])) {
	        		hdev_note::redirect(hdev_url::activate($_GET["nxt"]));
	        	}
	        	else{
	        		hdev_note::redirect(hdev_url::get_url_host());
	        	}
	        }else{
	        	hdev_note::message("Ururimi wahisemo ntirwashoboye kuboneka --- Language selected does not exist");
	        	if (!empty($_GET["nxt"])) {
	        		hdev_note::redirect(hdev_url::activate($_GET["nxt"]));
	        	}
	        	else{
	        		hdev_note::redirect(hdev_url::get_url_host());
	        	}
	        }
	      }
	    }		
	}
	$langg = $_SESSION['lang'];

	$_SESSION['exp'] = $lang;
 ?>