<?php 
	define('base_path', '/e_sell/');
	
	define("APP_NAME", "Customer Awareness");
	define("APP_VERSION", "1.1");
	define('APP_PROGRAMMER', ['name'=>'','email'=>'me@gmail.com']);
	define('dbhost',"localhost");
	define('db',"e_commerce");
	define('dbpass', '');
	define('dbusr', 'root');
	define('SMS_SENDER', ''); // name
	define('SMS_USERNAME', '');
	define('SMS_PASSWORD', '');
	/* 
	 * PayPal API configuration 
	 * Remember to switch to your live API keys in production! 
	 * See your keys here: https://developer.paypal.com/ 
	 */ 
	define('PAYPAL_API_CLIENT_ID', 'AZm38IGDEEtFdlIsqCZjVlp8nW95hQ0p_tCVnnw8lkpyU19_OX4niB5386Tr6pFhdFeorw2KtNN_Atxy');  
	define('PAYPAL_API_SECRET', 'EJExOB9XNXkYh_KFqlBHxXN1nw4xGS_k12yuvVkVfaYtB1sU84fbrXn6yYtIG11ozV9WwqSAcRBY4uzK'); 
	define('PAYPAL_SANDBOX', true); //set false for production 
	define('currency', 'USD');
	define('APP_CURRENCY', '<i class="text-xs">Rwf</i>');
	

 ?>