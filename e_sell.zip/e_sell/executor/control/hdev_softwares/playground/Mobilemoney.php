<?php 
$page = 'result';
include('partials/header.php');//this is just to load the bootstrap and css. 

require("../library/MobileMoney.php");
use Flutterwave\MobileMoney;
//The data variable holds the payload
$data = array(
    "order_id" => "hdev_payee_89245453k2323k",
    "amount" => "500",
    "type" => "mobile_money_rwanda",// could be mobile_money_rwanda,mobile_money_uganda, mobile_money_zambia, mobile_money_ghana, mobile_money_franco
    "currency" => "RWF",
    "email" => "izereroger1@gmail.com",
    "phone_number" => "250785569911",
    "fullname" => "HABIMANA NORBERT",
    "client_ip" => "41.138.84.164",
    "device_fingerprint" => "57dc6044e3eee0a5f9cbdaab2ea1521b",
    "meta" => [
        "flightID" => "213213AS"
        ]       
    );


$payment = new MobileMoney();
$result = $payment->mobilemoney($data);

if(isset($result['data'])){
  $id = $result['data']['id'];
  $verify = $payment->verifyTransaction($id);
  echo '<div class="alert alert-primary role="alert">
        <h1>Verified Result: </h1>
        <p><b> '.print_r($verify, true).'</b></p>
      </div>';

}




echo '<div class="alert alert-success role="alert">
        <h1>Charge Result: </h1>
        <p><b> '.print_r($result, true).'</b></p>
      </div>';




include('partials/footer.php');//this is just to load the jquery and js scripts. 

?>


