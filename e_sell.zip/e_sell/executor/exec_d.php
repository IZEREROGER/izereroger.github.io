<?php 
//exit($data);
	if (isset($data) && !empty($data)) {}else{exit('validation failed');}
	$store = explode(';', $data);
	$HDEV =array();
	if (is_array($store) && count($store)>0) {
		foreach ($store as $stt) {
			$store2 = explode(':', $stt);
			if (is_array($store2) && count($store2) == 2) {
				$HDEV[$store2[0]]=$store2[1];
			}
		}
		
	}else{exit('validation failed');}
	
	if (is_array($HDEV) && count($HDEV) > 0 && isset($HDEV['ref'])) {
	}else{
		exit("validation Failed!");
	}
	/*$rasms_stc = new hdev_auth_service('',trim($HDEV['ref']));
	if ($rasms_stc->access()) {
		/// access granted 
	}else{
	  $disp = $rasms_stc->error('alert');
	  $HDEV['ref'] = "";

	  $from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');
	  hdev_note::message($disp);
	  hdev_note::redirect($from);
	  exit();
	}*/
	if (!hdev_log::admin() && !hdev_log::super_admin()) {
		$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');
		hdev_note::message("not allowed to perfom this action");
	  	hdev_note::redirect($from);
	  	exit();
	}
	$csrf = new CSRF_Protect();
  	$csrf->verifyRequest($HDEV['app']);
	switch ($HDEV['ref']) {
		case 'user_delete':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("products");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');
      			$ck = hdev_data::user_st("off",$id);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				hdev_note::message('User Deleted');
      				hdev_note::redirect($from);
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;	
		case 'user_recover':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("products");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');
      			$ck = hdev_data::user_st("on",$id);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				hdev_note::message('User Recovered His/Her user needs to be changed by admin');
      				hdev_note::redirect($from);
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;
		case 'product_delete':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("products");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `p_status` = :status WHERE `b_id` = :id;",[[":id",$id],[":status",'0']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				hdev_note::message('Product Deleted');
      				hdev_note::redirect($from);
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;	
		case 'product_recover':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("products");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `p_status` = :status WHERE `b_id` = :id;",[[":id",$id],[":status",'1']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				hdev_note::message('Product Recovered');
      				hdev_note::redirect($from);
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;				
		case 'brand_delete':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("brand");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `b_status` = :status WHERE `c_id` = :id;",[[":id",$id],[":status",'0']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				hdev_note::message('Brand Deleted');
      				hdev_note::redirect($from);
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;	
		case 'brand_recover':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("brand");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `b_status` = :status WHERE `c_id` = :id;",[[":id",$id],[":status",'1']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				hdev_note::message('Brand Recovered');
      				hdev_note::redirect($from);
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;	
		case 'cat_delete':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("category");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `c_status` = :status WHERE `c_id` = :id;",[[":id",$id],[":status",'0']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				hdev_note::message('Category Deleted');
      				hdev_note::redirect($from);
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;	
		case 'cat_recover':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("category");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `c_status` = :status WHERE `c_id` = :id;",[[":id",$id],[":status",'1']]);
	      		if ($ck == "ok") {
      				$csrf->up_tk();
      				hdev_note::message('Category Recovered');
      				hdev_note::redirect($from);
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;
		case 'shop_delete':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("groups");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `g_status` = :status WHERE `g_id` = :id;",[[":id",$id],[":status",'0']]);
	      		if ($ck == "ok") {
	      			$dta = hdev_data::groups($id,['data']);
	      			if (isset($dta['g_name'])) {
	      				$tel = $dta['tell'];
	      				hdev_note::live_sms($tel,'Hello '.$dta['g_name'].' shop, your shop is now deleted on '.constant('APP_NAME').' call administrators for more thank you!');
	      			}
      				$csrf->up_tk();
      				hdev_note::message('Shop deleted successfull');
      				hdev_note::redirect($from);
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;
		case 'shop_recover':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("groups");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `g_status` = :status WHERE `g_id` = :id;",[[":id",$id],[":status",'1']]);
	      		if ($ck == "ok") {
	      			$dta = hdev_data::groups($id,['data']);
	      			if (isset($dta['g_name'])) {
	      				$tel = $dta['tell'];
	      				hdev_note::live_sms($tel,'Hello '.$dta['g_name'].' shop, your shop is now recovered on '.constant('APP_NAME').' you can now continue selling, thank you!');
	      			}
      				$csrf->up_tk();
      				hdev_note::message('Shop Recovered successfull');
      				hdev_note::redirect($from);
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;		
		case 'shop_approve':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("groups");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `g_status` = :status WHERE `g_id` = :id;",[[":id",$id],[":status",'1']]);
	      		if ($ck == "ok") {
	      			$dta = hdev_data::groups($id,['data']);
	      			if (isset($dta['g_name'])) {
	      				$tel = $dta['tell'];
	      				hdev_note::live_sms($tel,'Hello '.$dta['g_name'].' shop, your shop is now approved and allowed to start selling on '.constant('APP_NAME').' thank you!');
	      			}
      				$csrf->up_tk();
      				hdev_note::message('Shop request approved successfull');
      				hdev_note::redirect($from);
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;	
		case 'shop_reject':
			if (isset($HDEV['id']) && !empty($HDEV['id']) && isset($HDEV['src']) && !empty($HDEV['src'])) {
				$id = trim($HDEV['id']);
				$src = trim($HDEV['src']);
				$rt = new hdev_db();
      			$tab = $rt->table("groups");
      			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');

      			$ck = $rt->insert("UPDATE `$tab` SET `g_status` = :status WHERE `g_id` = :id;",[[":id",$id],[":status",'3']]);
	      		if ($ck == "ok") {
	      			$dta = hdev_data::groups($id,['data']);
	      			if (isset($dta['g_name'])) {
	      				$tel = $dta['tell'];
	      				hdev_note::live_sms($tel,'Hello '.$dta['g_name'].' shop, your shop registration request is rejected please contact '.constant('APP_NAME').' administrators for more, thank you!');
	      			}
      				$csrf->up_tk();
      				hdev_note::message('Shop request rejected successfull');
      				hdev_note::redirect($from);
      			}else{
      				echo "something went wrong try again later";
      			}
			}
		break;	
		default:
			$from = (!is_null(trim($HDEV['from'])) && !empty(trim($HDEV['from']))) ? urldecode(trim($HDEV['from'])) : hdev_url::menu('');
			hdev_note::message('we cannot handle what you requested try again later');
			hdev_note::redirect($from);
		break;
	}

 ?>