<?php 
	$l = ['set','real_executor','exp'];
	foreach ($l as $linkage) {
		$regpath = __DIR__;
  		$regd = str_ireplace('\\', "/", $regpath);
    	include $regd.'/'.$linkage.'.php';
  	}

 ?>