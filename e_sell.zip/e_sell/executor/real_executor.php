<?php
  session_start();
  if ($_GET) {
    if (!empty($_GET['logout'])) {
      hdev_log::out();
    }
  }
  define("APP_BASE_URL", rtrim(ltrim(hdev_url::menu(''),'/'),'/'));
    /**
   * limiting sql results
   */
  class hdev_pager 
  {
    
    private static $limit = null;
    private static $curr_page = null;
    private static $rows_ret = null;
    private static $url = null;
    function __construct($ref_url="")
    {
      self::$url = hdev_url::menu($ref_url);
    }
    public static function reset()
    {
      self::$limit = "";
    }
    public static function set($page='',$rows='')
    {
      self::$curr_page = (is_numeric($page)) ? $page : 1 ;//curent page
      self::$rows_ret = $rows;//all rows
      $start = $page;
      $end = $rows;
      if ($start == 0 || $start == 1 || empty($start) || !is_numeric($start)) {
        $start = 0;
      }
      if (isset($end) && is_numeric($end) && !empty($end) && $end != 0) {
        $init = ($end*$start)-$end;
        if ($start == 0) {
          $init = 0;
        }
        self::$limit = " LIMIT ".$init.",".$end;
      }else{
        self::$limit = "";
      }
    }
    public static function limit($ref='get')
    {
      return self::$limit;
    }
    public static function page()
    {
      return self::$curr_page;
    }
    public static function rows()
    {
      return self::$rows_ret;
    }
    public static function page_row($max=0,$r_name="Records")
    {
      $return = '
        <div class="border-top border-left border-right border-bottom p-1">
          <div class="row">
      ';
      $btnv = ceil($max/self::rows());
      if ($btnv != 0) {
        $return .= '
          <div class="col-sm-2">
            <span class="btn btn-secondary">Page '.self::page()." in ".$btnv.' pages</span>
            </div>';
        $return .= '
          <div class="col-sm-8" align="center">
          <div class="btn-group iii_menu">';
        $pg = self::page();
        $prev = $pg-1;
        $next = $pg+1;
        if ($pg != 1) {
          $return .= '
            <button type="button" rel="external" url="'.self::$url.'" page="1" class="btn btn-sm btn-success pager_control"><i class="fa fa-angle-double-left"></i></button>
          ';
        }
        if ($prev > 0) {
          $return .= '
            <button type="button" rel="external" url="'.self::$url.'" page="'.$prev.'" class="btn btn-sm btn-success pager_control"><i class="fa fa-angle-left"></i></button>
          ';
        }
        for ($i=1; $i <= $btnv; $i++) { 
          $gg = ($i==$pg) ? "btn-primary " : "btn-secondary" ;
          $ic = ($i==$pg) ? "fa fa-file" : "fa fa-file-alt" ;
          $tg = $i-$pg;
          if ($tg > 3 || $tg < -3) {
          }else{
            $return .= '
              <button type="button" rel="external" url="'.self::$url.'" page="'.$i.'" class="btn btn-sm pager_control '.$gg.'"><b><i class="'./*$ic*/"".'">'.$i.'</i></b></button>
              ';
          }
        }
        if ($next <= $btnv) {
          $return .= '
            <button type="button" rel="external" url="'.self::$url.'" page="'.$next.'" class="btn btn-sm btn-success pager_control"><i class="fa fa-angle-right"></i></button>
          ';
        }
        if ($pg != $btnv) {
          $return .= '
            <button type="button" rel="external" url="'.self::$url.'" page="'.$btnv.'" class="btn btn-sm btn-success pager_control"><i class="fa fa-angle-double-right"></i></button>
          ';
        }
        $return .= '
            </div>
          </div>
          <div class="col-sm-2">
        ';
        if ($pg != $btnv) {
          $ptt = $pg*self::rows();
          $return .= "Showing ".$ptt." ".$r_name.", <br>In ".$max." ".$r_name.".";
        }elseif ($pg == $btnv) {
          $return .= "Showing ".$max." ".$r_name.", <br>In ".$max." ".$r_name." .";
        }
        $return .= '
          </div>
        ';
      }else{
        $return .= '
          <div class="col-sm-12">
            --
          </div>
        ';
      }
      $return .= '
        </div>
      </div>
      <hr/>
      ';
      echo $return;
    }
  }
  class PaypalExpress{ 
      public $paypalEnv       = PAYPAL_SANDBOX?'sandbox':'production'; 
      public $paypalURL       = PAYPAL_SANDBOX?'https://api.sandbox.paypal.com/v1/':'https://api.paypal.com/v1/'; 
      public $paypalClientID  = PAYPAL_API_CLIENT_ID; 
      private $paypalSecret   = PAYPAL_API_SECRET; 
       
      public static function validate($paymentID, $paymentToken, $payerID, $productID){ 
          $ch = curl_init(); 
          curl_setopt($ch, CURLOPT_URL, $this->paypalURL.'oauth2/token'); 
          curl_setopt($ch, CURLOPT_HEADER, false); 
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
          curl_setopt($ch, CURLOPT_POST, true); 
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
          curl_setopt($ch, CURLOPT_USERPWD, $this->paypalClientID.":".$this->paypalSecret); 
          curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials"); 
          $response = curl_exec($ch); 
          curl_close($ch); 
           
          if(empty($response)){ 
              return false; 
          }else{ 
              $jsonData = json_decode($response); 
              $curl = curl_init($this->paypalURL.'payments/payment/'.$paymentID); 
              curl_setopt($curl, CURLOPT_POST, false); 
              curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false); 
              curl_setopt($curl, CURLOPT_HEADER, false); 
              curl_setopt($curl, CURLOPT_RETURNTRANSFER, true); 
              curl_setopt($curl, CURLOPT_HTTPHEADER, array( 
                  'Authorization: Bearer ' . $jsonData->access_token, 
                  'Accept: application/json', 
                  'Content-Type: application/xml' 
              )); 
              $response = curl_exec($curl); 
              curl_close($curl); 
               
              // Transaction data 
              $result = json_decode($response); 
               
              return $result; 
          } 
       
      } 
  }
    /**
   * session data 
   */
  class hdev_session
  {
    private static $sess = array();
    public static function reset()
    {
      self::$sess = array();
    }
    public static function set($name='',$value='')
    {
      if (!empty($name)) {
        self::$sess[$name] = $value;
      }
    }
    public static function get($name)
    {
      if (count(self::$sess) > 0 && isset(self::$sess[$name]) && !is_null(self::$sess[$name])) {
        return self::$sess[$name];
      }else{
        return "";
      }
    }

  }

  /**
   * 
   */
  class hdev_log 
  {
    
    public static function out() 
    {
      $_SESSION['ui'] = "ik";
      $_SESSION["uid"] = "";
      $_SESSION['funct'] = "";
      $_SESSION['user'] = "";
      session_destroy();
      hdev_note::redirect(hdev_url::menu("h/home"));
    }
    public static function gid($v=1) 
    {
      return $_SESSION['gid'];
    }
    public static function sid($value='')
    {
      if (isset($_SESSION['shop']) && !empty($_SESSION['shop'])) {
        return hdev_data::decd($_SESSION['shop']);
      }else{
        return "";
      }
    }
    public static function ip()
    {
      $ip = getenv("REMOTE_ADDR");
      return $ip;
    }
    public static function log_id($v=1)
    {
      if (!empty($_SESSION['uid'])) {
        return hdev_data::decd($_SESSION['uid']);
      }else{
        return false;
      }
      
    }
    public static function loged()
    {
      if (!empty($_SESSION['uid'])) {
        return true;
      }else{
        return false;
      }
    }
    public static function user()
    {
      if (!empty($_SESSION['uid']) && isset($_SESSION['funct'])) {
        if (hdev_log::admin()) {
          $return = "Shop Manager";
        }elseif (hdev_log::super_admin()) {
          $return = "Admin";
        }else{
          $return = hdev_data::decd($_SESSION['funct']);;
        }
        return $return;;
      }else{
        return "Guest";
      }
    }
    public static function super_admin()
    {
      if (!empty($_SESSION['uid']) && isset($_SESSION['funct']) && (hdev_data::decd($_SESSION['funct']) == "super_admin")) {
        return true;
      }else{
        return false;
      }
    }
    public static function admin()
    {
      if (!empty($_SESSION['uid']) && isset($_SESSION['funct']) && (hdev_data::decd($_SESSION['funct']) == "admin")) {
        return true;
      }else{
        return false;
      }
    }
    public static function o_uid($v=1)
    {
      if (!empty($_SESSION['uid'])) {
        return $_SESSION['uid']; 
      }else{
        return "";
      }
    }
    public static function uid($v=1)
    {
      if (!empty($_SESSION['uid'])) {
        return hdev_data::decd($_SESSION['uid']); 
      }else{
        return "";
      }
    }
  }
  /**
     *  craete menu of data
     */

    class hdevmenu
    {
       public static function hdevstr($str)
       {
         return str_ireplace(array("'",'"'), array('\'',"\""), $str);
       }
       public static function message($msg)
       {
         echo '
          <script>alert(\''.$msg.'\')</script>
         ';
       }
       public static function nd_nav($min)
        {
           $urlk = trim($_SESSION['nd_url'][1]);
           if ($min == $urlk) {
            echo " btn-primary";
           }else{
            echo " btn-secondary";
           }
        }
       public static function topmenu($trees,$name,$link,$icon,$id='')
       {
         if (empty($_SESSION["act_url"])) {
            //$urlk = $urlk = trim(str_ireplace(hdev_url::get_url_min(), "", hdev_url::get_url_full()));
          }else{
            if (empty($_SESSION["act_url"][2])) {
              //$urlk = $urlk = trim(str_ireplace(hdev_url::get_url_min(), "", hdev_url::get_url_full()));
            }else{
              $urlk = trim(hdev_url::menu($_SESSION['act_url'][2]));

            }
          }
        if (empty($name)) {
          echo "";
        }elseif ($trees == "1") {
            $id = (!empty($id)) ? ' id=\''.$id.'\'' : '' ;
            $view = '<li class="nav-item">';
            if (!empty($link)) {
              $linka = explode("...", $link);
              if (count($linka) == 2) {
                $urlka = hdev_url::menu(trim($linka[0]).'/'.trim($linka[1]));
                if ($urlk == $urlka) {
                  $view .='<a  href="'.hdev_url::menu(trim($linka[0]).'/'.trim($linka[1])).'" class="lift nav-link active"'.$id. ' title="'.APP_NAME.'---' .self::hdevstr($name).'"">';
                }else{
                  $view .='<a  href="'.hdev_url::menu(trim($linka[0]).'/'.trim($linka[1])).'" class="lift nav-link"'.$id. ' title="'.APP_NAME.'---' .self::hdevstr($name).'"">';
                }
              }
              else{
                $view .='<a  href="'.hdev_url::menu(trim($linka[0]).'/'.trim($linka[1])).'" class="lift nav-link"'.$id. ' title="'.APP_NAME.'---' .self::hdevstr($name).'"">';
              }
            }else{
              $view .='<a  href="'.hdev_url::menu(trim($linka[0]).'/'.trim($linka[1])).'" class="lift nav-link"'.$id. ' title="'.APP_NAME.'---' .self::hdevstr($name).'"">';
            }
            if (!empty($icon)) {
              $view .= '<i class="'.$icon.'"></i>&nbsp;';
            }
            if (!empty($link)) {
              $view .=self::hdevstr($name).'</a>';
            }
              
            $view .= "</li>";
            echo $view;
         }
       }
       public static function mainmenu($trees,$name,$link,$icon,$js='')
       {
        $urlk = trim(hdev_url::menu($_SESSION['act_url'][2]));
        $jss = ($js == "no") ? "" : "liftk" ;
        if (empty($name)) {
        }elseif ($trees == "1") {
            $view = '<li class="nav-item">';

            if (!empty($link)) {
              $linka = explode("...", $link);
              if (count($linka) == 2) {
                $urlka = hdev_url::menu(trim($linka[0]).'/'.trim($linka[1]));
                if ($urlk == $urlka) {
                  $view .='<a href="'.$urlka.'" class="nav-link active '.$jss.'" '.'title="'.APP_NAME.'---' .self::hdevstr($name).'">';
                }else{
                  $view .='<a href="'.$urlka.'" class="nav-link '.$jss.'" '.'title="'.APP_NAME.'---' .self::hdevstr($name).'">';
                }
              }
              else{
                $view .='<a href="'.$urlka.'" class="nav-link '.$jss.'" '.'title="'.APP_NAME.'---' .self::hdevstr($name).'">';
              }
            }else{
              $view .='<a href="'.$urlka.'" class="nav-link '.$jss.'"> '.'title="'.APP_NAME.'---' .self::hdevstr($name).'">';
            }
            if (!empty($icon)) {
              $view .= '<i class="nav-icon '.trim($icon).'"></i><p>';
            }
            if (!empty($link)) {
              $view .=self::hdevstr(trim($name)).'</p></a>';
            }
              
            $view .= "</li>";
            echo $view;
         }elseif ($trees == "2") {
           $view="";
           $name = explode("^^", $name);
           $link = explode("^^", $link);
           $icon = explode("^^", $icon);
           if (count($name)==count($link) && count($name)==count($icon) ) {
            
            $urkmult =array();

            for ($i=1; $i <= count($name)-1; $i++) {
                $linka = explode("...", $link[$i]);
                if (!empty($link)) {
                  if (count($linka) == 2) {
                    $urlka = hdev_url::menu(trim($linka[0]).'/'.trim($linka[1]));
                    if ($urlk == $urlka) {
                      array_push($urkmult, "y");
                    }
                  }
                }      
              }
              if (in_array("y", $urkmult)) {
                $view = '<li class="nav-item has-treeview menu-open">
                        <a href="#" class="ind nav-link active">';
              }else{
                $view = '<li class="nav-item has-treeview">
                         <a href="#" class="ind nav-link">';
              }

            $view .='
                <i class="nav-icon ';
            $view .= trim($icon[0]);
            $view .='"></i>
                <p>';
            $view.=self::hdevstr(trim($name[0]));
            $view.='<i class="right fas fa-angle-left"></i>
                </p>
              </a>
              <ul class="nav nav-treeview">';
              for ($i=1; $i <= count($name)-1; $i++) {
                $linka = explode("...", $link[$i]);
                $view.='<li class="nav-item">';
                if (!empty($link)) {
                  if (count($linka) == 2) {
                    $urlka = hdev_url::menu(trim($linka[0]).'/'.trim($linka[1]));
                    if ($urlk == $urlka) {
                      $view .='<a href="'.$urlka.'" class="nav-link active '.$jss.'" '.'title="'.APP_NAME.'---' .self::hdevstr($name[$i]).'">';
                    }else{
                      $view .='<a href="'.$urlka.'" class="nav-link '.$jss.'" '.'title="'.APP_NAME.'---' .self::hdevstr($name[$i]).'">';
                    }
                  }
                  else{
                    $view .='<a href="'.$urlka.'" class="nav-link '.$jss.'" '.'title="'.APP_NAME.'---' .self::hdevstr($name[$i]).'">';
                  }
                }else{
                  $view .='<a href="'.$urlka.'" class="nav-link '.$jss.'" '.'title="'.APP_NAME.'---' .self::hdevstr($name[$i]).'">';
                }
                $view.='<i class=" '.trim($icon[$i]).' nav-icon"></i>';
                $view.='<p>'.self::hdevstr(trim($name[$i])).'</p>';
                $view.='</a>
                        </li>';     
                    
              }
            $view.='
                    </ul>
                  </li>';
           }
          echo $view;
         }
       }
    }
    
	/** get current urls 
	  * include plugins linkage
	  */
	 class hdev_url
	 {
    public static function img($url)
    {
        $urlParts = pathinfo($url);
        $extension = $urlParts['extension'];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $response = curl_exec($ch);
        curl_close($ch);
        $base64 = 'data:image/' . $extension . ';base64,' . base64_encode($response);
        return $base64;

    }
        public static function prot()
        {
            $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
            return $protocol;
        }
        public static function get_url_host()
        {
            $protocol = self::prot();
            $url_host = $protocol . $_SERVER['HTTP_HOST'];
            return $url_host;
        }
        public static function get_url_min()
        {
            $url_query = $_SERVER['QUERY_STRING'];
            return "?".$url_query;
        }
        public static function get_url_full()
        {
            $protocol = $protocol = self::prot();
            $url_full = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
            return $url_full;
        }
    public static function get_url_part()
    {
      $url_all = self::get_url_full();
      $mini = self::get_url_min();
      $ret = str_ireplace($mini, "", $url_all);
      return rtrim(ltrim($ret,"/"),"/");
    }
    public static function without_get()
    {
      $full = self::get_url_full();
      $min = self::get_url_min();
      $ret = str_ireplace($min, "", $full);
      return $ret;
    }
        public static function menu($link)
        {
            $ref = self::get_url_host();
            $fer = $ref.constant('base_path').$link;
            return $fer;
        }
    public static function next($value)
    {
      $ref = urlencode($value);
      return $ref;
    }
    public static function activate($value)
    {
      $ref = urldecode($value);
      return $ref;
    }
	 }

	/**
	 * display messge
	 */
	class hdev_note
	{
		public static function message($value,$disp='0',$ref="no")
		{
      if ($disp == "0" || $disp=="1") {
        $val = "";
        $val .= "<script>alert('";
        $val .= $value;
        $val .= "')</script>";
        echo $val;
      }
			
			if ($disp == "1") {
			 self::redirect(hdev_url::get_url_full());
			}
      if ($ref =="1") {
        $val = "";
        $val .= "<script>alert('";
        $val .= $value;
        $val .= "--- please contact the programmer : ";
        $val .= APP_PROGRAMMER['email'];
        $val .= "');</script>";
        //log::out();
      }
		}
    public static function server_msg($msg,$type='js')
    {
      if (!empty($msg)) {
        if ($type == 'js') {
          echo $msg;
        }
      }
    }
    public static function server_message($msg="")
    {
      echo $msg;
    }
    public static function message_2($val="",$ref=2)
    {
      if ($ref == 1) {
        $msg = "
        <div class='alert alert-secondary'>
            <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
            <i>".$val."</i>
          </div>";
      }elseif ($ref == 2) {
        $msg = "
          <div class='alert alert-warning'>
              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
              <i>".$val."</i>
          </div>";
      }elseif ($ref == 3) {
        $msg = "
          <div class='alert alert-danger'>
              <a href='#' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
              <i>".$val."</i>
          </div>";
      }
      return $msg;
    }
    public static function redirect($var)
    {
      $vk = "<script>window.location.href='".$var."';</script>";
      echo $vk;
    }
    public static function live_sms($tel='',$msg='')
    {
      if (!hdev_data::phone_valid($tel) && !empty($msg)) {
        $data=array(
          "sender"=>constant('SMS_SENDER'),
          "recipients"=>"+25".$tel,
          "message"=>addslashes($msg),
        );

       $url="https://www.intouchsms.co.rw/api/sendsms/.json";
       $data=http_build_query($data);
       $username=constant('SMS_USERNAME');
       $password=constant('SMS_PASSWORD');

       $ch=curl_init();
       curl_setopt($ch,CURLOPT_URL,$url);
       curl_setopt($ch,CURLOPT_USERPWD,$username.":".$password);
       curl_setopt($ch,CURLOPT_POST,true);
       curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
       curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,0);
       curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
       $result=curl_exec($ch);
       $httpcode=curl_getinfo($ch,CURLINFO_HTTP_CODE);
       curl_close($ch);
        // code...
      }
    }
	} 
	/**
	 * routing assisstant
	 */
	class hdev_menu_url
	{
		public static function body($value)
		{
			$_SESSION['act_url'] = array();
			$_SESSION['act_url'] = $value;
		}
		public static function url_req($url,$user)
		{
			if (!empty($url) && !empty($user)) {
				return "y";
			}
		}
    public static function body_nd($val)
    {
      $_SESSION['nd_url'] = array();
      $_SESSION['nd_url'] = $val;
    }
	}
  /**
   * language activation
   */
  class hdev_lang
  {
    
    public static function on($pre,$view)
    {
      if (!empty($pre) && !empty($view)) {
        if (isset($_SESSION['exp'][$pre][$_SESSION['lang']][$view])) {
          if (!empty($_SESSION['exp'][$pre][$_SESSION['lang']][$view])) {
            return $_SESSION['exp'][$pre][$_SESSION['lang']][$view];
          }else{
            return $_SESSION['exp'][$pre]['eng'][$view];
          }
        }else{
          return $_SESSION['exp'][$pre]['eng'][$view];
        }
      }else{
        return $_SESSION['exp'][$pre]['eng'][$view];
      }
    }
  }
  
    /**
 * A simple CSRF class to protect forms against CSRF attacks. The class uses
 * PHP sessions for storage.
 * @link https://hdevsoftwares.business.site
 * @author Izere Hirwa Roger
 *
 */
class CSRF_Protect
{
  /**
   * The namespace for the session variable and form inputs
   * @var string
   */
  private $namespace;
  
  /**
   * Initializes the session variable name, starts the session if not already so,
   * and initializes the token
   * 
   * @param string $namespace
   */
  public function __construct($namespace = 'tkd')
  {
    $this->namespace = $namespace;
    
    if (session_id() === '')
    {
      session_start();
    }
    
    $this->setToken();
  }
  
  /**
   * Return the token from persistent storage
   * 
   * @return string
   */
  public function getToken()
  {
    return $this->readTokenFromStorage();
  }
  
  /**
   * Verify if supplied token matches the stored token
   * 
   * @param string $userToken
   * @return boolean
   */
  public function isTokenValid($userToken)
  {
    return ($userToken === $this->readTokenFromStorage());
  }
  
  /**
   * Echoes the HTML input field with the token, and namespace as the
   * name of the field
   */
  public function echoInputField()
  {
    $token = $this->getToken();
    echo "<input type=\"hidden\" name=\"{$this->namespace}\" value=\"{$token}\" />";
  }
  
  /**
   * Verifies whether the post token was set, else dies with error
   */
  public function verifyRequest($var="")
  {
    if ($var == "") {
      if (!$this->isTokenValid($_POST[$this->namespace]))
      {
        die("Data validation failed.");
      }
    }else{
      if (!$this->isTokenValid($var))
      {
        die("Data validation failed.");
      }
    }
    
  }
  
  /**
   * Generates a new token value and stores it in persisent storage, or else
   * does nothing if one already exists in persisent storage
   */
  private function setToken()
  {
    $storedToken = $this->readTokenFromStorage();
    
    if ($storedToken === '')
    {
      $token = md5(uniqid(rand(), TRUE));
      $this->writeTokenToStorage($token);
    }
  }
  
  public function up_tk()
  {
      $token = md5(uniqid(rand(), TRUE));
      $this->writeTokenToStorage($token);
  }
  /**
   * Reads token from persistent sotrage
   * @return string
   */
  private function readTokenFromStorage() 
  {
    if (isset($_SESSION[$this->namespace]))
    {
      return $_SESSION[$this->namespace];
    }
    else
    {
      return '';
    }
  }
  
  /**
   * Writes token to persistent storage
   */
  private function writeTokenToStorage($token)
  {
    $_SESSION[$this->namespace] = $token;
  }
}
	/**
	 * db execution
	 */
	class hdev_db
	{
		public $conn = "";
		function table($pref)
    {
      $table = array(
              "user"=>"myusers",
              "category"=>"b_category",
              "products"=>"b_store",
              "cart"=>"cart",
              "brand"=>"b_brand",
              "order"=>"orders",
              "order_parent"=>"order_details",
              "chat_menu"=>"chat_mask",
              "chat_msg"=>"chat_msg",
              "location"=>"locations",
              "groups"=>"h_groups",
              "payouts"=>"shop_payments",
              "post"=>"posts"
            );
      return $table[$pref];
    }
		function __construct($connn='mysqli')
		{
			if ($connn == "mysqli") {
				$servername = dbhost;
				$username = dbusr;
				$password = dbpass;
				$dbname = db;
        $this->auto_con = $connn;
				$this->conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);	
			}elseif ($connn == "sqlite") {
        //exit(__DIR__);
        $direct = __DIR__.DIRECTORY_SEPARATOR.'commerce.db';
        //exit($direct);
         $this->conn = new PDO("sqlite:".$direct);
      }
		}
    public function last_id()
    {
      $con = $this->conn;
      $last_id = $con->lastInsertId();
      return $last_id;
    }
		function select($query = "SELECT 1=1",$params = [""])
		{
			try {
			    $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			    $stmt = $this->conn->prepare($query);
			    if (is_array($params) && count($params) > 0) {
			     	foreach ($params as $pd) {
			     		if (!empty($pd)) {
			     			$regpd = $pd;
			     			if (count($regpd)==2) {
			     				$stmt->bindParam($regpd[0], $regpd[1]);
			     			}
			     		}
			     	}
			     }
			    $stmt->execute();
			    $stmt->setFetchMode(PDO::FETCH_ASSOC);
			    $res = $stmt->fetchAll(); 
			}
			catch(PDOException $e) {
				$res = array("Error: ",$e->getMessage());
			}
			//hdev_note::message(var_dump($res));
			return $res;
			$conn = null;
		}
    function insert($query,$params= null)
    {
      try {
          $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
          $stmt = $this->conn->prepare($query);
          if (is_array($params) && count($params) > 0) {
            foreach ($params as $pd) {
              if (!empty($pd)) {
                $regpd = $pd;
                if (count($regpd)==2) {
                  $stmt->bindParam($regpd[0], $regpd[1]);
                }
              }
            }
           }
          $stmt->execute();
          $rett = "ok";
          }
      catch(PDOException $e)
          {
          echo "error : ".$e->getMessage();
          $rett = "no";
          }
      return $rett;
      $conn = null;
    }

	}
  /**
   * hdev_data all dat prefetch
   */
  class hdev_data
  {
    public static function id_valid($value='')
    {
      $retur = false;
      //echo strlen($value);
      if (empty($value)) {
        $retur = "ID Must not be empty";
      }elseif (!is_numeric($value)) {
        $retur = "ID must be in number format without space or any other non-numeric value";
      }elseif (strlen($value) != 16) {
        $retur = "ID must be 16 digits only";
      }
      return $retur;
    }
    public static function phone_valid($value='')
    {
      $retur = false;
      $t = "";
      if (!empty($value)) {
        $t = $value;
        $jk = strlen($t);
        $type = substr($t, 0, 2);
      }
      if (empty($value)) {
        $retur = 'Phone number can\'t be empty';
      }
      elseif ($type != "07") {
        $retur = 'Phone number must start with \'07\'';
      }
      elseif (!is_numeric($t)) {
        $retur = 'Phone number must contain only numbers (0-9)';
      }
      elseif ($jk != "10") {
        $retur = "Phone number must be 10 digits (07........)";
      }else{
        //echo $_POST['system_tel_nom'];
      }
      return $retur;
    }
    public static function currency($val,$gid="")
    {
      $gid = hdev_log::gid();
      return $val." frw";
    }
    public static function date($date)
    {
      return $date;
    }
    public static function timer($value,$req)
    {
      if ($req == "time") {
        $dteee=date_create($value);
        $dtt3 = date_format($dteee,"h:i:s");
        return $dtt3;
      }elseif ($req == "date") {
        $dteee=date_create($value);
        $dtt3 = date_format($dteee," d/m/Y");
        return $dtt3;
      }
    }
    public static function f_up($value='')
    {
      $regd = 'dest/book';
      return $regd;
    }
    public static function download_from_link($value,$type)
    {
      $rt = trim($value);
      $rtt = str_ireplace(array("book","/"), array("bst","_"), $rt);
      if (trim(substr($type, 0, 1)) != ".") {
        $type = ".".$type;
      }
      $file = $rtt.$type;
      $official_file = "/".trim($file);
      return $official_file;
    }
    public static function img_up()
    {
      $t = hdev_url::menu('dist/img/');
      return $t;
    }
    public static function tx_id() { 
      $csrf = new CSRF_Protect();
      $reqford = $csrf->getToken();
      $rf = md5($reqford.time().rand(20,time()));
      return $rf;
    } 
    public static function order_hash($var)
    {
      $q = hdev_data::tx_id();
      $rt = new hdev_db();
      $tab = $rt->table("order");
      $check = $rt->select("SELECT COUNT(*) AS cc FROM $tab where trx_id = :h OR trx_id = :hh",[[":h","1".$var],[":hh","2".$var]]);
      if (isset($check[0]['cc']) && $check[0]["cc"] > 0) {
        $r = "";
        for ($i=0; $i < 6; $i++) { 
          $r .= $q.rand(21,time()).$check[0]["cc"].rand(15,time().rand(10,time()));
        }
        $hs = md5($r);
        $var = md5($hs);
      }
      return $var;

    }
    public static function order_hash_ok($hash)
    {
      $rt = new hdev_db();
      $tab = $rt->table("order");
      $check = $rt->select("SELECT COUNT(*) AS cc FROM $tab where trx_id = :h OR trx_id = :hh",[[":h","1".$hash],[":hh","2".$hash]]);
      if (isset($check[0]['cc']) && $check[0]["cc"] > 0) {
        $ret = "no";
      }else{
        $ret = "yes";
      }
      if ($ret == "no") {
        return false;
      }else{
        return true;
      }
    }
    
    public static function product_images($hash,$prefetch="")
    {
      if (!empty($hash) && $prefetch == "") {
        $return = array();
        $exp = ".,*HDEV_prod*.,";
        $product = explode($exp, $hash);
        if (is_array($product) && count($product) > 0) {
          for ($i=0; $i < count($product); $i++) { 
            $a = hdev_url::menu("dist/img/products/");
            array_push($return, $a.$product[$i]);
          }
        }
        
        return $return;
      }else{
        $return = array();
        $exp = ".,*HDEV_prod*.,";
        $product = explode($exp, $hash);
        if (count($product) > 0) {
          for ($i=0; $i < count($product); $i++) { 
            $fileName = $product[$i];
            $regpath = __DIR__;
            $target_path = realpath(str_ireplace('\\', "/", $regpath).'/../dist/img/products')."\\".$fileName;

            if(is_file($target_path) && file_exists($target_path))
            {
              array_push($return, $target_path);
            }
          }
        }
        return $return;
      }
    }
    public static function enc($value,$v='link')
    {
      if ($v="link"){
        $ht = str_ireplace(array(1,2,3,4,5,6,7,8,9,0,"b","B","o","O","k","K","..."), array("j","t","l","m","n","u","p","q","r","s",".[","].",",[","],","*[","]*","{"), $value);
        $ht = base64_encode($ht);
        $ht = $ht;
        $dt= date("d-m-Y h:i:s");
        $dt = str_ireplace(array("-",":"), array("!,^","^,$"), $dt);
        $dt = str_ireplace(array(1,2,3,4,5,6,7,8,9,0,"b","B","o","O","k","K","..."), array("j","t","l","m","n","u","p","q","r","s",".[","].",",[","],","*[","]*","{"), $dt);
        $end = substr(md5($dt), 6);
        $pre = base64_encode($dt);
        $prev = strlen($pre);
        $prev1 = strlen($ht);
        $prevv = "hdev_".$prev."kl".$pre.$prev1."gl".$ht.$end;
        $prevv = urlencode($prevv);
        return $prevv;
     }
    }
    public static function order_status($id)
    {
      switch ($id) {
        case 'p':
          return "<span style='padding: 10px;' class='bg-primary'>Pending</span>";
        break;
        case 'x':
          return "<span style='padding: 10px;' class='bg-danger'>Canceled</span>";
        break;
        case 'c':
          return "<span style='padding: 10px;' class='bg-success'>completed</span>";
        break;
        default:
          echo "";
          break;
      }
    }
    public static function sex($sex)
    {
      switch ($sex) { 
        case 'm':
          return "Male";
        break;
        case 'f':
          return "Female";
        break;
        
        default:
          return "";
          break;
      }
    }
    public static function encd($value)
    {
      $ht = str_ireplace(array(1,2,3,4,5,6,7,8,9,0), array(":@:,",".[","].",",[","],","*[","]*","{","|:|,",":||:"), $value);
      $ht = base64_encode($ht);
      $rtt = substr(md5(date("h:i:s")), 0,5);
      $yh = "hdev_".$rtt.$ht;
      return $yh;
    }
    public static function dec($value,$v='link')
    {
      if ($v == "link") {
        $mine = urldecode($value);
        $pro = substr($mine, 0,5); //must be hdev_v
        $mine = substr($mine, 5);
        $min = explode("kl", $mine); // must be at least 2
        $r1 = $min[0]; // must be numeric
        $ct1 = strlen($r1)+2;
        $mine = substr($mine, $ct1);
        $rr1 = substr($mine, 0,$r1);
        $z = base64_decode($rr1);
        $zz = str_ireplace(array("j","t","l","m","n","u","p","q","r","s",".[","].",",[","],","*[","]*","{"), array(1,2,3,4,5,6,7,8,9,0,"b","B","o","O","k","K","..."), $z);
        $zz = str_ireplace(array("!,^","^,$"), array("-",":"),$zz);
        $mine = substr($mine, $r1);
        $min2 = explode("gl", $mine); //must be at least 2
        $r2 = $min2[0]; //must be numeric
        $ct2 = strlen($r2)+2;
        $mine = substr($mine, $ct2);
        $rr2 = substr($mine, 0, $r2);
        $z2 = base64_decode($rr2);
        $z3 = str_ireplace(array("j","t","l","m","n","u","p","q","r","s",".[","].",",[","],","*[","]*","{"), array(1,2,3,4,5,6,7,8,9,0,"b","B","o","O","k","K","..."), $z2);
        $link = str_ireplace("...", "/", $z3);
       //$rr1 = substr(, start)
        //return $prevv;
        $id = explode("/", $link);
        $id = trim($id[1]);
        $rt = array("link"=>$link,"time"=>$zz,"id"=>$id);
        return $rt;
      }
    }
    public static function password_enc($value='')
    {
      return md5($value);
    }
    public static function decd($value)
    {
      $value = substr($value, 5+5);
      $value = base64_decode($value);
      $ht = str_ireplace( array(":@:,",".[","].",",[","],","*[","]*","{","|:|,",":||:"), array(1,2,3,4,5,6,7,8,9,0), $value);
      return $ht;
    }
    public static function pay_method($ref='',$type='')
    {
      $ret = "";
      $ref = substr($ref, 0, 1);
      if ($type == "") {
        if ($ref == "1") {
          $ret = "paypal";
        }elseif ($ref == "2") {
          $ret = "momo";
        }
      }elseif ($type == "all") {
        if ($ref == "1") {
          $ret = "PayPal";
        }elseif ($ref == "2") {
          $ret = "Mobile Money";
        }

      }
      return $ret;
    }
    public static function search_word($word='')
    {
      $num = str_ireplace(' ', '', $word);
      //echo $word."<br>";
      $num_var = strlen($num);
      $fin_word = '%';
      for ($i=0; $i < $num_var; $i++) { 
        //$j = $i+1;
        $rn = substr($num, $i, 1);
        $fin_word .= $rn."%";
      }   
      return $fin_word;
    }
    public static function search($s)
    {
      $rt = new hdev_db();
      $tab = $rt->table("category");
      $tab2 = $rt->table("products"); 
      $tab3 = $rt->table("brand"); 
      $s = hdev_data::search_word($s); 
      $ref =$rt->select("SELECT * FROM $tab WHERE c_name LIKE :os OR c_link LIKE :os limit 0,6",[[":os",$s]]);
      $ref2 =$rt->select("SELECT * FROM $tab2 where b_name LIKE :os OR b_desc LIKE :os OR b_pic LIKE :os OR b_link LIKE:os limit 0,6",[[":os",$s]]);
      $ref3 =$rt->select("SELECT * FROM $tab3 WHERE c_name LIKE :os OR c_link LIKE :os limit 0,6",[[":os",$s]]);
      //var_dump(count($ref)."______".count($ref2));
      $return = array();
      if (count($ref) > 0) {
        foreach ($ref as $p1) {
          if (isset($p1['c_name']) &&  !empty($p1['c_name']) && isset($p1['c_link']) && !empty($p1['c_link'])) {
            array_push($return, ["ref"=>"category","name"=>$p1['c_name'],"link"=>$p1['c_link'],"ic1"=>"fa fa-cart-arrow-down","ic2"=>"fa fa-book"]);
          } 
        }
      }
      if (count($ref2) > 0) {
        foreach ($ref2 as $p2) {
          if (isset($p2['b_name']) &&  !empty($p2['b_name']) && isset($p2['b_link']) && !empty($p2['b_link'])) {
            array_push($return, ["ref"=>"book","name"=>$p2['b_name'],"link"=>$p2['b_link'],"ic1"=>"fa fa-shopping-bag","ic2"=>$p2['b_pic'],'id'=>$p2['b_id'],'price'=>$p2['b_price']]);
          }
        }
      }
      if (count($ref3) > 0) {
        foreach ($ref3 as $p1) {
          if (isset($p1['c_name']) &&  !empty($p1['c_name']) && isset($p1['c_link']) && !empty($p1['c_link'])) {
            array_push($return, ["ref"=>"Brand","name"=>$p1['c_name'],"link"=>$p1['c_link'],"ic1"=>"fas fa-briefcase","ic2"=>"fas fa-briefcase"]);
          } 
        }
      }
      return $return;

    }
    public static function username_e($unm)
    {
      $rt = new hdev_db();
      
      $tab = $rt->table("user");

      $nm = "";
      $name="";
      $post="";

      $ref =$rt->select("SELECT * FROM $tab WHERE username = :unm",[[":unm",$unm]]);

      if (count($ref) > 0) {
        return "no";
      }else{
        return "yes";
      }
    }
    public static function user($v=1,$idd='')
    {
      if (!empty($idd)) {
        $id = $idd;
      }else{
        $id = trim(hdev_log::log_id());
      }
      $rt = new hdev_db();
      $tab = $rt->table("user");
      $ref =$rt->select("SELECT * FROM $tab WHERE id = :user",[[":user",$id]]);
      if ($v == 1) {
        if (is_array($ref)) { 
          return $ref[0];
        }else{
          return "n";
        }
      }elseif ($v == "*") {
        $tab = $rt->table("user");
        $ref =$rt->select("SELECT * FROM $tab WHERE tell !='0788888888' AND address != '98'");
        return $ref;
      }
    }
    public static function user_st($ref,$idd)
    {
      $id = $idd;
      $rt = new hdev_db();
      $tab = $rt->table("user");

      if ($ref == "view") {
        $ref =$rt->select("SELECT * FROM $tab WHERE id = :user AND password != :ps",[[":user",$id],[":ps",""]]);
        if (count($ref) > 0 && count($ref) == 1) {
          return "on";
        }else{
          return "off";
        } 
      }elseif ($ref == "on") {
        $pw = hdev_data::encd("hdev_data_password_recovery");
        $sql = $rt->insert("UPDATE $tab SET password = :st WHERE id = :if",[[':st',$pw], [':if',$id]]);
          if ($sql == "ok") {
            return "ok";
          }else{
            return "no";
          }
      }elseif ($ref == "off") {
        $pw = "";
        $sql = $rt->insert("UPDATE $tab SET password = :st WHERE id = :if",[[':st',$pw], [':if',$id]]);
          if ($sql == "ok") {
            return "ok";
          }else{
            return "no";
          }
      }
    }
    public static function user_icon($id='')
    {
      $ret_icon = "fa fa-times text-purple";
      if (!empty($id)) {
        $user_chk = trim(hdev_data::user(1,$id)['post']);
        if ($user_chk == "user") {
          $ret_icon = "fa fa-user-circle text-primary";
        }else{
          $ret_icon = "fa fa-user-tie text-purple";
        }
      }
      return $ret_icon;
    }
    public static function log_user($unm,$psw,$rf="")
    {
      $rt = new hdev_db();
      $tab = $rt->table("user");
      $nm = "";
      $name="";
      $post="";
      if ($rf == "") {
      $ref =$rt->select("SELECT * FROM $tab WHERE username = :unm AND password = :psw AND ((post='user' OR post='super_admin') OR (post = 'admin' AND group_exist(g_id) = 1))",[[":unm",$unm],[":psw",hdev_data::password_enc($psw)]]);
      }elseif ($rf == "id") {
        $ref =$rt->select("SELECT * FROM $tab WHERE id = :unm AND password = :psw",[[":unm",$unm],[":psw",hdev_data::password_enc($psw)]]);
      }elseif ($rf == "id2") {
        $ref =$rt->select("SELECT * FROM $tab WHERE id = :unm",[[":unm",$unm]]);
      }
      if (isset($ref[0]['username']) && !empty($ref[0]['username'])) {
        return $ref[0];
      }else{
        return "no";
      }
      
    }
    public static function get_user($id)
    {
      return ucfirst(hdev_data::decd($_SESSION['user']))." (".$id.")";
    }
    public static function groups($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("groups");
      $group = hdev_log::sid();
      $v_ref = array();
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE g_id !='' AND g_status=1");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE g_id !=''");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "delete") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE g_id !='' AND g_status=0");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "exist") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE g_id = :g_id AND g_status=1",[[":g_id",$l_id]]);
        if (isset($v_ref[0]['g_id']) && !empty($v_ref[0]['g_id'])) {
          $retur = "yes";
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE g_id = :g_id",[[":g_id",$l_id]]);
        if (isset($v_ref[0]['g_id']) && !empty($v_ref[0]['g_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "request") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE g_status = 2");
        if (isset($v_ref[0]['g_id']) && !empty($v_ref[0]['g_id'])) {
          $retur = $v_ref;
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "reject") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE g_status = 3");
        if (isset($v_ref[0]['g_id']) && !empty($v_ref[0]['g_id'])) {
          $retur = $v_ref;
        }
        return $retur;
      }

      elseif (isset($param[0]) && $param[0] == "hash") {
        $retur = 0;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE g_hash = :hash",[[":hash",$l_id]]);
        if (isset($v_ref[0]['g_id']) && !empty($v_ref[0]['g_id'])) {
          $retur = $v_ref[0]['g_id'];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "valid") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE g_id = :g_id AND g_status=1",[[":g_id",$l_id]]);
        if (isset($v_ref[0]['g_id']) && !empty($v_ref[0]['g_id'])) {
          $retur = $v_ref[0];
        }else{
          $retur = false;
        }
        return $retur;
      }
    }
    public static function locations($ret='province',$prov="",$dist="",$sect="",$cell="")
    {
      $rt = new hdev_db();
      $tab = $rt->table("location");
      $v_ref = array();
      if ($ret == "all") {
        $v_ref = $rt->select("SELECT * FROM `$tab` WHERE loc_id=:id",[[':id',$prov]]);
        $ret = false;
        if (is_array($v_ref) && count($v_ref) > 0) {
          $ret = $v_ref[0];
        }
      }elseif ($ret == "mini") {
        $v_ref = $rt->select("SELECT * FROM `$tab` WHERE loc_id=:id",[[':id',$prov]]);
        $ret = false;
        if (is_array($v_ref) && count($v_ref) > 0) {
          $ret = $v_ref[0]['loc_province']." / ".$v_ref[0]['loc_district']." / ".$v_ref[0]['loc_sector']." / ".$v_ref[0]['loc_cell']." / ".$v_ref[0]['loc_village'];
        }
      }elseif ($ret == "all_districts") {
        $v_ref = $rt->select("SELECT loc_province,loc_district,ship_price FROM `$tab` WHERE loc_status=1 GROUP BY loc_district ORDER BY loc_province ASC");
        $ret = $v_ref;
      }elseif ($ret == "price") {
        $v_ref = $rt->select("SELECT ship_price AS price FROM `$tab` WHERE loc_id=:id",[[':id',$prov]]);
        $ret = 0;
        if (is_array($v_ref) && count($v_ref) > 0) {
          $ret = (isset($v_ref[0]['price'])) ? $v_ref[0]['price'] : 0 ;
        }
      }
      elseif ($ret == "province") {
        $v_ref = $rt->select("SELECT DISTINCT loc_province FROM `$tab` WHERE loc_status=1 ORDER BY loc_province ASC");
        $ret = '<option value="">---Select Province---</option>';
        foreach ($v_ref as $retloc) {
          $ret.="<option value='".$retloc['loc_province']."'>".$retloc['loc_province']."</option>";
        }
      }elseif ($ret == "district") {
        $v_ref = $rt->select("SELECT DISTINCT loc_district FROM `$tab` WHERE loc_status=1 AND loc_province=:prov ORDER BY loc_district ASC",[[':prov',$prov]]);
        $ret = '<option value="">---Select District---</option>';
        foreach ($v_ref as $retloc) {
          $ret.="<option value='".$retloc['loc_district']."'>".$retloc['loc_district']."</option>";
        }
      }elseif ($ret == "sector") {
        $v_ref = $rt->select("SELECT DISTINCT loc_sector FROM `$tab` WHERE loc_status=1 AND loc_province=:prov AND loc_district=:dist ORDER BY loc_sector ASC",[[':prov',$prov],[':dist',$dist]]);
        $ret = '<option value="">---Select Sector---</option>';
        foreach ($v_ref as $retloc) {
          $ret.="<option value='".$retloc['loc_sector']."'>".$retloc['loc_sector']."</option>";
        }
      }elseif ($ret == "cell") {
        $v_ref = $rt->select("SELECT DISTINCT loc_cell FROM `$tab` WHERE loc_status=1 AND loc_province=:prov AND loc_district=:dist AND loc_sector=:sect ORDER BY loc_cell ASC",[[':prov',$prov],[':dist',$dist],[':sect',$sect]]);
        $ret = '<option value="">---Select Cell---</option>';
        foreach ($v_ref as $retloc) {
          $ret.="<option value='".$retloc['loc_cell']."'>".$retloc['loc_cell']."</option>";
        }
      }elseif ($ret == "village") {
        $v_ref = $rt->select("SELECT DISTINCT loc_village,loc_id FROM `$tab` WHERE loc_status=1 AND loc_province=:prov AND loc_district=:dist AND loc_sector=:sect AND loc_cell=:cell ORDER BY loc_village ASC",[[':prov',$prov],[':dist',$dist],[':sect',$sect],[':cell',$cell]]);
        $ret = '<option value="">---Select Village---</option>';
        //print_r($cell);
        foreach ($v_ref as $retloc) {
          //print_r($v_ref);
          $ret.="<option value='".$retloc['loc_id']."'>".$retloc['loc_village']."</option>";
        }
      }
      return $ret;
    }
    public static function get_cart($v = "1", $s="")
    {
      $rt = new hdev_db();
      $tab = $rt->table("cart");
      $u = hdev_log::uid();
      $ip = hdev_log::ip();
      $u2 = (!empty($u) && is_numeric($u) && $u > 0) ? $u : '-1' ;
      $csrf = new CSRF_Protect();
      $hash = $csrf->getToken();
      if (!isset($_SESSION['cart_hash']) || empty(trim($_SESSION['cart_hash']))) {
        $_SESSION['cart_hash'] = $hash;
      }
      $hash = $_SESSION['cart_hash'];
      if (hdev_log::loged()) {
        // code...
      $QR = $rt->insert("DELETE FROM `$tab` WHERE user_id=:user AND tx_track != :hash",[[":user",$u],[":hash",$hash]]);
      }else{
        $QR = $rt->insert("DELETE FROM `$tab` WHERE ip_add=:user AND user_id < 0 AND tx_track != :hash",[[":user",$ip],[":hash",$hash]]);
      }
      //exit($hash);
      //When user is logged in then we will count number of item in cart by using user session id
      if ($u !="" && !empty($u)) {
        $sql = $rt->select("SELECT COUNT(*) AS cc FROM $tab WHERE user_id = :uid",[[":uid",$u]]);
        $sql1 = $rt->select("SELECT * FROM $tab WHERE user_id = :uid",[[":uid",$u]]);
      }else{
        $sql = $rt->select("SELECT COUNT(*) AS cc FROM $tab WHERE ip_add = :uid and user_id < 0",[[":uid",$ip]]);
        $sql1 = $rt->select("SELECT * FROM $tab WHERE ip_add = :uid and user_id < 0",[[":uid",$ip]]);
        }
        if (isset($sql[0]['cc'])) {
          $sql = $sql[0]['cc'];
        }
        if ($v == 1) {
          return $sql;
        }elseif ($s == 1) {
          $sql2 = $rt->select("SELECT * FROM $tab WHERE id = :id",[[":id",$v]]);
          if (isset($sql2[0])) {
            return $sql2[0];
          }else{
            return array();
          }
          
        }
        elseif ($v == 2) {
          return $sql1;
        }
      
    }
    public static function get_single_order($s="")
    {
      $rt = new hdev_db();
      $tab = $rt->table("order");
      $u = hdev_log::uid();
      $ip = hdev_log::ip();

      if (1==1) {
          $sql4 = $rt->select("SELECT * FROM $tab WHERE order_id = :uid ORDER BY reg_date DESC",[[":uid",$s]]);
          if (isset($sql4[0]) && !empty($sql4[0])) {
            $rf = array();
            array_push($rf, $sql4);
            return $rf;
          }else{
            return "no";
          }
        }
    }
    public static function order_menu($l_id="",$param=[1])
    {
      $rt = new hdev_db();
      $tab = $rt->table("order_parent");

      $from = (isset($_SESSION['from'])) ? $_SESSION['from'] : "" ;
      $to = (isset($_SESSION['to'])) ? $_SESSION['to'] : "" ;
      $l_date = "";
      if (!empty($to) && !empty($from)) {
        $to = date_format(date_create($to),"Y-m-d");
        $from = date_format(date_create($from),"Y-m-d");
        $l_date = "AND reg_date BETWEEN '".$from."' AND '".$to."'";
      }
      $u = hdev_log::uid();
      $v_ref = array();
      $main_shop = hdev_log::sid();
      $valid1 = "1=1 AND";
      $valid2 = "1=1";
      if (hdev_log::admin()) {
        $valid1 = "order_shop(tx_ref, $main_shop) > 0 AND";
        $valid2 = "order_shop(tx_ref, $main_shop) > 0";
      }
      
      if (isset($param[0]) && $param[0] == 1) {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE $valid1 user_id = :user $l_date ORDER BY reg_date DESC",[[':user',$u]]);
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE $valid2 ORDER BY reg_date DESC");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "exist") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE $valid1 o_id = :l_id",[[":l_id",$l_id]]);
        if (isset($v_ref[0]['o_id']) && !empty($v_ref[0]['o_id'])) {
          $retur = "yes";
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE o_id = :l_id",[[":l_id",$l_id]]);
        if (isset($v_ref[0]['o_id']) && !empty($v_ref[0]['o_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data2") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE tx_ref = :l_id",[[":l_id",$l_id]]);
        if (isset($v_ref[0]['o_id']) && !empty($v_ref[0]['o_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "valid") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE o_id = :l_id",[[":l_id",$l_id]]);
        if (isset($v_ref[0]['o_id']) && !empty($v_ref[0]['o_id'])) {
          $retur = $v_ref[0];
        }else{
          $retur = false;
        }
        return $retur;
      }elseif ($param[0] == "custom") {
          $s = $param;
          $num0 = (isset($s['ref']) && !empty($s['ref'])) ? $s["ref"] : "";
          $num1 = (isset($s['pg']) && !empty($s['pg'])) ? $s["pg"] : "1";
          $num2 = hdev_session::get('return');
          $lmt = new hdev_pager(hdev_session::get("pager_url"));
          $limit = $lmt->limit();
         // var_dump($limit);exit();
          $sqlall = "";
          if ($num2 == "all") {
            if ($num0 == "all") {
              $sqlall = $rt->select("SELECT * FROM $tab WHERE $valid1 user_id != :uid $l_date ORDER BY reg_date DESC",[[":uid",""]]);
            }elseif ($num0 == "count") {
              $sqlall1 = $rt->select("SELECT * FROM $tab WHERE $valid1 user_id != :uid $l_date ORDER BY reg_date DESC",[[":uid",""]]);
              $sqlall = count($sqlall1);
            }elseif ($num0 == "pg") {
              $sqlall = $rt->select("SELECT * FROM $tab WHERE $valid1 user_id != :uid $l_date ORDER BY reg_date DESC".$limit,[[":uid",""]]);
            }elseif ($num0 == "amount") {
              $sqlall1 = $rt->select("SELECT SUM(total_price) AS amount FROM $tab WHERE $valid1 user_id != :uid $l_date ORDER BY reg_date DESC".$limit,[[":uid",""]]);
              //$sqlall = 1;
              //var_dump($)
              if (isset($sqlall1[0]['amount'])) {
                $sqlall = $sqlall1[0]['amount'];
              }
            }
          }elseif ($num2 == "pending") {
            if ($num0 == "all") {
              $sqlall = $rt->select("SELECT * FROM $tab WHERE $valid1 user_id != :uid AND payment_status = :st $l_date ORDER BY reg_date DESC",[[":uid",""],[":st","w"]]);
            }elseif ($num0 == "count") {
              $sqlall1 = $rt->select("SELECT * FROM $tab WHERE $valid1 user_id != :uid AND payment_status = :st != :uid $l_date ORDER BY reg_date DESC",[[":uid",""],[":st","w"]]);
              $sqlall = count($sqlall1);
            }elseif ($num0 == "pg") {
              $sqlall = $rt->select("SELECT * FROM $tab WHERE $valid1 user_id != :uid AND payment_status = :st != :uid $l_date ORDER BY reg_date DESC".$limit,[[":uid",""],[":st","w"]]);
            }elseif ($num0 == "amount") {
              $sqlall1 = $rt->select("SELECT SUM(total_price) AS amount FROM $tab WHERE $valid1 user_id != :uid AND payment_status = :st != :uid $l_date ORDER BY reg_date DESC",[[":uid",""],[":st","w"]]);
              //$sqlall = 1;
              //var_dump($)
              if (isset($sqlall1[0]['amount'])) {
                $sqlall = $sqlall1[0]['amount'];
              }
            }
          }elseif ($num2 == "complete") {
            if ($num0 == "all") {
              $sqlall = $rt->select("SELECT * FROM $tab WHERE $valid1 user_id != :uid AND payment_status = :st $l_date ORDER BY reg_date DESC",[[":uid",""],[":st","approved"]]);
            }elseif ($num0 == "count") {
              $sqlall1 = $rt->select("SELECT * FROM $tab WHERE $valid1 user_id != :uid AND payment_status = :st != :uid $l_date ORDER BY reg_date DESC",[[":uid",""],[":st","approved"]]);
              $sqlall = count($sqlall1);
            }elseif ($num0 == "pg") {
              $sqlall = $rt->select("SELECT * FROM $tab WHERE $valid1 user_id != :uid AND payment_status = :st != :uid $l_date ORDER BY reg_date DESC".$limit,[[":uid",""],[":st","approved"]]);
            }elseif ($num0 == "amount") {
              $sqlall1 = $rt->select("SELECT SUM(total_price) as amount FROM $tab WHERE $valid1 user_id != :uid AND payment_status = :st != :uid $l_date ORDER BY reg_date DESC".$limit,[[":uid",""],[":st","approved"]]);
              //$sqlall = 1;
              //var_dump($)
              if (isset($sqlall1[0]['amount'])) {
                $sqlall = $sqlall1[0]['amount'];
              }
            }
          }elseif ($num2 == "cancel") {
            if ($num0 == "all") {
              $sqlall = $rt->select("SELECT * FROM $tab WHERE $valid1 user_id != :uid AND payment_status = :st $l_date ORDER BY reg_date DESC",[[":uid",""],[":st","x"]]);
            }elseif ($num0 == "count") {
              $sqlall1 = $rt->select("SELECT * FROM $tab WHERE $valid1 user_id != :uid AND payment_status = :st != :uid $l_date ORDER BY reg_date DESC",[[":uid",""],[":st","x"]]);
              $sqlall = count($sqlall1);
            }elseif ($num0 == "pg") {
              $sqlall = $rt->select("SELECT * FROM $tab WHERE $valid1 user_id != :uid AND payment_status = :st != :uid $l_date ORDER BY reg_date DESC".$limit,[[":uid",""],[":st","x"]]);
            }
          }elseif ($num0 == "amount") {
              $rt->select("SELECT SUM(total_price) AS amount FROM $tab WHERE $valid1 user_id != :uid AND payment_status = :st != :uid $l_date ORDER BY reg_date DESC".$limit,[[":uid",""],[":st","x"]]);

              if (isset($sqlall1[0]['amount'])) {
                $sqlall = $sqlall1[0]['amount'];
              }
            }
          return $sqlall;
        }
    }
    public static function get_order($v = "1", $s="")
    {
      $rt = new hdev_db();
      $tab = $rt->table("order");
      $u = hdev_log::uid();
      $ip = hdev_log::ip(); 

      //When user is logged in then we will count number of item in cart by using user session id
      if ($u !="" && !empty($u)) {
        $sql = $rt->select("SELECT COUNT(*) AS cc FROM $tab WHERE user_id = :uid",[[":uid",$u]]);
        $sql1 = $rt->select("SELECT * FROM $tab WHERE user_id = :uid ORDER BY reg_date DESC",[[":uid",$u]]);
      }else{
        $sql = "";
        $sql1 = array();
      }
        if (isset($sql[0]['cc'])) {
          $sql = $sql[0]['cc'];
        }
        if ($v == 1) {
          return $sql;
        }elseif ($s == 1) {
          $sql2 = $rt->select("SELECT * FROM $tab WHERE id = :id ORDER BY reg_date DESC",[[":id",$v]]);
          return $sql2[0];
        }
        elseif ($v == 2) {
          return $sql1;
        }elseif ($v == 4) {
          $ret = array();
          $ref_v = $rt->select("SELECT * FROM $tab WHERE trx_id = :id ORDER BY reg_date DESC",[[":id",$s]]);
          return $ref_v;
        }
        elseif ($v = 3) {
          $num0 = (isset($s['ref']) && !empty($s['ref'])) ? $s["ref"] : "";
          $num1 = (isset($s['pg']) && !empty($s['pg'])) ? $s["pg"] : "1";
          $num2 = (isset($s['v']) && !empty($s['v'])) ? $s["v"] : "" ;
         // var_dump($limit);exit();

          if (empty($num1) || $num1 == 1) {
            $num1 =0;
          }else{
            $num1 = ($num1*10)-10; 
          }
          if (!is_numeric($num1)) {
            $num1 = 0;
          }
          $sqlall = "";
          if ($num2 == "all") {
            if ($num0 == "all") {
              $sqlall = $rt->select("SELECT * FROM $tab WHERE user_id != :uid ORDER BY reg_date DESC",[[":uid",""]]);
            }elseif ($num0 == "count") {
              $sqlall1 = $rt->select("SELECT * FROM $tab WHERE user_id != :uid ORDER BY reg_date DESC",[[":uid",""]]);
              $sqlall = count($sqlall1);
            }elseif ($num0 == "pg") {
              $sqlall = $rt->select("SELECT * FROM $tab WHERE user_id != :uid ORDER BY reg_date DESC LIMIT ".$num1.",10 ",[[":uid",""]]);
            }
          }elseif ($num2 == "pending") {
            if ($num0 == "all") {
              $sqlall = $rt->select("SELECT * FROM $tab WHERE user_id != :uid AND p_status = :st ORDER BY reg_date DESC",[[":uid",""],[":st","p"]]);
            }elseif ($num0 == "count") {
              $sqlall1 = $rt->select("SELECT * FROM $tab WHERE user_id AND p_status = :st != :uid ORDER BY reg_date DESC",[[":uid",""],[":st","p"]]);
              $sqlall = count($sqlall1);
            }elseif ($num0 == "pg") {
              $sqlall = $rt->select("SELECT * FROM $tab WHERE user_id AND p_status = :st != :uid ORDER BY reg_date DESC LIMIT ".$num1.",10 ",[[":uid",""],[":st","p"]]);
            }
          }elseif ($num2 == "complete") {
            if ($num0 == "all") {
              $sqlall = $rt->select("SELECT * FROM $tab WHERE user_id != :uid AND p_status = :st ORDER BY reg_date DESC",[[":uid",""],[":st","c"]]);
            }elseif ($num0 == "count") {
              $sqlall1 = $rt->select("SELECT * FROM $tab WHERE user_id AND p_status = :st != :uid ORDER BY reg_date DESC",[[":uid",""],[":st","c"]]);
              $sqlall = count($sqlall1);
            }elseif ($num0 == "pg") {
              $sqlall = $rt->select("SELECT * FROM $tab WHERE user_id AND p_status = :st != :uid ORDER BY reg_date DESC LIMIT ".$num1.",10 ",[[":uid",""],[":st","c"]]);
            }
          }elseif ($num2 == "cancel") {
            if ($num0 == "all") {
              $sqlall = $rt->select("SELECT * FROM $tab WHERE user_id != :uid AND p_status = :st ORDER BY reg_date DESC",[[":uid",""],[":st","x"]]);
            }elseif ($num0 == "count") {
              $sqlall1 = $rt->select("SELECT * FROM $tab WHERE user_id AND p_status = :st != :uid ORDER BY reg_date DESC",[[":uid",""],[":st","x"]]);
              $sqlall = count($sqlall1);
            }elseif ($num0 == "pg") {
              $sqlall = $rt->select("SELECT * FROM $tab WHERE user_id AND p_status = :st != :uid ORDER BY reg_date DESC LIMIT ".$num1.",10 ",[[":uid",""],[":st","x"]]);
            }
          }
          return $sqlall;
        }
      
    }
    public static function single_id($type)
    {
      if ($type == "cat") {
        $rt = new hdev_db();
        $tab = $rt->table("category");
        $rand=rand(20,time());
        $ref2 =$rt->select("SELECT * FROM $tab where c_rand = :cid ORDER BY views DESC",[[":cid",$rand]]);
        if (is_array($ref2) && isset($ref2[0]) && count($ref2[0]) > 3) {
          $rand = rand(25,time()*2)/time();
          $ref2 =$rt->select("SELECT * FROM $tab where c_rand = :cid ORDER BY views DESC",[[":cid",$rand]]);
          if (is_array($ref2) && isset($ref2[0]) && count($ref2[0]) > 3) {
            return "no";
          }else{
            return $rand;
          }
        }else{
          return $rand;
        }
      }elseif ($type == "brand") {
        $rt = new hdev_db();
        $tab = $rt->table("brand");
        $rand=rand(20,time());
        $ref2 =$rt->select("SELECT * FROM $tab where c_rand = :cid ORDER BY views DESC",[[":cid",$rand]]);
        if (is_array($ref2) && isset($ref2[0]) && count($ref2[0]) > 3) {
          $rand = rand(25,time()*2)/time();
          $ref2 =$rt->select("SELECT * FROM $tab where c_rand = :cid ORDER BY views DESC",[[":cid",$rand]]);
          if (is_array($ref2) && isset($ref2[0]) && count($ref2[0]) > 3) {
            return "no";
          }else{
            return $rand;
          }
        }else{
          return $rand;
        }
      }elseif ($type == "book") {
        $rt = new hdev_db();
        $tab = $rt->table("products");
        $rand=rand(20,time());
        $ref2 =$rt->select("SELECT * FROM $tab where b_rand = :cid",[[":cid",$rand]]);
        if (is_array($ref2) && isset($ref2[0]) && count($ref2[0]) > 3) {
          $rand = rand(25,time()*2)/time();
          $ref2 =$rt->select("SELECT * FROM $tab where b_rand = :cid",[[":cid",$rand]]);
          if (is_array($ref2) && isset($ref2[0]) && count($ref2[0]) > 3) {
            return "no";
          }else{
            return $rand;
          }
        }else{
          return $rand;
        }
      }
    }
    public static function order_sub_msg()
    {
      $rt = new hdev_db();
      $tab = $rt->table("chat_menu");
      $u = hdev_log::uid();
      $ip = hdev_log::ip(); 
      if (hdev_log::loged()) {
        if (hdev_log::admin()) {
          $sql = $rt->select("SELECT * FROM $tab WHERE admin_id = :aid ORDER BY reg_date DESC",[[":aid",$u]]);
        }else{
          $sql = $rt->select("SELECT * FROM $tab WHERE user_id = :aid ORDER BY reg_date DESC",[[":aid",$u]]);
        }
        return $sql;
      }else{
        return array();
      }
    }
    public static function chat_mask_e($id='')
    {
      $rt = new hdev_db();
      $tab = $rt->table("chat_menu");
      $u = hdev_log::uid();
      $sql = $rt->select("SELECT * FROM $tab WHERE chat_id = :aid ORDER BY reg_date DESC",[[":aid",$id]]);

      if (isset($sql[0]['chat_id']) && !empty($sql[0]['chat_id'])) {
        if ($u == $sql[0]['admin_id'] || $u == $sql[0]['user_id']) {
          return true;
        }else{
          return false;
        }
      }else{
        return false;
      }
    }
    public static function order_msg($id="")
    {
      if ($id == "") {
        $id = hdev_data::last_new_message();
        if ($id == "") {
          $id = "";
        }
      }
      $rt = new hdev_db();
      $tab = $rt->table("chat_msg");
      $u = hdev_log::uid();
      $ip = hdev_log::ip(); 
      $sql = $rt->select("SELECT * FROM $tab WHERE mask_id = :mid",[[':mid',$id]]);
      return $sql;
    }

    public static function order_msg_new($id="",$v="count")
    {
      if ($id == "") {
        $id = hdev_data::last_new_message();
      }
      $rt = new hdev_db();
      $tab = $rt->table("chat_msg");
      $u = hdev_log::uid();
      $ip = hdev_log::ip(); 
      $order_sub_msg = hdev_data::order_sub_msg();
      //var_dump($order_sub_msg);
      $return = array("0","0");
      if ($v == "count") {
        if (hdev_log::loged()) {
          if (hdev_log::admin()) {
            //var_dump($order_sub_msg[0]['chat_id']);exit();
            $rer = 0;
            $km = array();
            $kids = array();
            foreach ($order_sub_msg as $mgk) {
              if (isset($mgk['chat_id'])) {
                $mid = $mgk['chat_id'];
                $sql = $rt->select("SELECT DISTINCT user_id FROM $tab WHERE mask_id = :mid AND user_id != :log AND status != :st",[[':mid',$mid],[':log',$u],[':st','c']]);
                $sql2 = $rt->select("SELECT * FROM $tab WHERE mask_id = :mid AND user_id != :log AND status != :st",[[':mid',$mid],[':log',$u],[':st','c']]);
                foreach ($sql2 as $qq) {
                  if (isset($qq['status'])) {
                    //array_push($km, $qq['status']);
                    if ($qq["status"] != "x") {
                      
                      if (array_push($km, "no")) {
                        array_push($kids, $qq['msg_id']);
                      }else{
                        array_push($km, "yes");
                      }
                      //
                    }else{
                      array_push($km, "yes");
                    }
                  }else{
                     array_push($km, "yes");
                  }
                }
                $rer += count($sql);
              }
            }
             if ($rer <= 0) {
                $return = array("0","no");
              }else{
                if (in_array("no", $km)) {
                  $return = array($rer,"yes",json_encode($kids));
                }else{
                  $return = array($rer,"no",json_encode($kids));//no
                }
                
              }
          }else{
            //var_dump($order_sub_msg[0]['chat_id']);exit();
            $rer = 0;
            $km = array();
            $kids = array();
            foreach ($order_sub_msg as $mgk) {
              if (isset($mgk['chat_id'])) {
                $mid = $mgk['chat_id'];
                $sql = $rt->select("SELECT DISTINCT user_id FROM $tab WHERE mask_id = :mid AND user_id != :log AND status != :st",[[':mid',$mid],[':log',$u],[':st','c']]);
                $sql2 = $rt->select("SELECT * FROM $tab WHERE mask_id = :mid AND user_id != :log AND status != :st",[[':mid',$mid],[':log',$u],[':st','c']]);

                foreach ($sql2 as $qq) {
                  if (isset($qq['status'])) {
                    //array_push($km, $qq['status']);
                    if ($qq["status"] != "x") {
                      
                      if (array_push($km, "no")) {
                        array_push($kids, $qq['msg_id']);
                      }else{
                        array_push($km, "yes");
                      }
                      //
                    }else{
                      array_push($km, "yes");
                    }
                  }else{
                     array_push($km, "yes");
                  }
                }
                $rer += count($sql);
              }
            }
             if ($rer <= 0) {
                $return = array("0","no");
              }else{
                if (in_array("no", $km)) {
                  $return = array($rer,"yes",json_encode($kids));
                }else{
                  $return = array($rer,"no",json_encode($kids));//no
                }
                
              }
        }
        //$sql = $rt->select("SELECT * FROM $tab WHERE user_id = :mid",[[':mid',$id]]);
        //$return = count($sql);
      }
      return $return;
      }
    }

    public static function order_msg_seen($id = "")
    {
      $rt = new hdev_db();
      $tab = $rt->table("chat_msg");
      $u = hdev_log::uid();

      $sql = $rt->insert("UPDATE $tab SET status = :st WHERE msg_id = :o AND user_id != :if",[[':st',"c"], [':if',$u],[':o',$id]]);

      return "ok";
    }
    public static function order_msg_seen_alert($id)
    {
      $rt = new hdev_db();
      $tab = $rt->table("chat_msg");
      $u = hdev_log::uid();

      $sql = $rt->select("SELECT * FROM $tab WHERE msg_id = :mid",[[':mid',$id]]);
      if (isset($sql[0]['msg_id']) && !empty($sql[0]['msg_id'])) {
        if (isset($sql[0]['status']) && !empty($sql[0]['status'])) {
          return $sql[0]['status'];
        }else{
          return "";
        }
      }else{
        return "";
      }
    }
    public static function last_new_message()
    {
     $rt = new hdev_db();
      $tab = $rt->table("chat_msg");
      $u = hdev_log::uid(); 
      $ip = hdev_log::ip(); 

      $sql = $rt->select("SELECT * FROM $tab WHERE user_id = :mid ORDER BY msg_reg DESC",[[':mid',$u]]);
      if (isset($sql[0]['mask_id']) && !empty($sql[0]['mask_id'])) {
        return $sql[0]['mask_id'];
      }else{
        $sqql = hdev_data::order_sub_msg();
        if (isset($sqql[0]['mask_id']) && !empty($sqql[0]['mask_id'])) {
          return $sqql[0]['mask_id'];
        }else{
          return "";
        }
      }
    }
    public static function last_new_message_menu($id)
    {
      if ($id == "") {
        $id = hdev_data::last_new_message();
      }
      $rt = new hdev_db();
      $tab = $rt->table("chat_msg");
      $u = hdev_log::uid();
      $ip = hdev_log::ip(); 
      $sql = $rt->select("SELECT * FROM $tab WHERE mask_id = :mid ORDER BY msg_reg DESC",[[':mid',$id]]);
      if (isset($sql[0]['msg']) && !empty($sql[0]['msg'])) {
        return $sql[0];
      }else{
        return array("msg"=>"Start chat Now!!!","msg_reg"=>"");
      }
      
    }
    public static function duplication_checker($var)
    {
      if ($var['type'] == "cat") {
        $name = $var['name'];
        $name = strtolower($name);
        $rt = new hdev_db();
        $tab = $rt->table("category");
        $rand=rand(20,time());
        $ref2 =$rt->select("SELECT * FROM $tab where Lcase(c_name) = :cid ORDER BY views DESC",[[":cid",$name]]);
        if (is_array($ref2) && isset($ref2[0]) && count($ref2[0]) > 3) {
          return "yes";
        }else{
          return "no";
        }
      }elseif ($var['type'] == "brand") {
        $name = $var['name'];
        $name = strtolower($name);
        $rt = new hdev_db();
        $tab = $rt->table("brand");
        $rand=rand(20,time());
        $ref2 =$rt->select("SELECT * FROM $tab where Lcase(c_name) = :cid ORDER BY views DESC",[[":cid",$name]]);
        if (is_array($ref2) && isset($ref2[0]) && count($ref2[0]) > 3) {
          return "yes";
        }else{
          return "no";
        }
      }elseif ($var['type'] == "book") {
        $name = $var['name'];
        $name = strtolower($name);
        $rt = new hdev_db();
        $tab = $rt->table("products");
        $rand=rand(20,time());
        $ref2 =$rt->select("SELECT * FROM $tab where Lcase(b_name) = :cid",[[":cid",$name]]);
        if (is_array($ref2) && isset($ref2[0]) && count($ref2[0]) > 3) {
          return "yes";
        }else{
          return "no";
        }
      }
    }
    public static function data_link($p)
    {
      $type = $p['type'];
      $rand = $p['rand'];
      if ($type == "cat") {
        $rt = new hdev_db();
        $tab = $rt->table("category");
        $ref2 =$rt->select("SELECT * FROM $tab where c_rand = :cid ORDER BY views DESC",[[":cid",$rand]]);
        if (is_array($ref2) && isset($ref2[0]) && count($ref2[0]) > 3) {
          foreach ($ref2 as $ik) {
            $rtg = $ik["c_id"];
          }
          if (isset($rtg) && !empty($rtg)) {
            $link = "cat/".$rtg;
            $ref3 =$rt->select("SELECT * FROM $tab where c_link = :cid ORDER BY views DESC",[[":cid",$link]]);
            if (is_array($ref3) && isset($ref3[0]) && count($ref3[0]) > 3) {
              return "no";
            }else{
              $tg = $rt->insert("UPDATE $tab SET c_link = :lk WHERE c_rand = :rand",[["lk",$link],["rand",$rand]]);
              if ($tg=="ok") {
                $tgl = $rt->insert("UPDATE $tab SET c_rand_check = :lk WHERE c_rand = :rand",[["lk","yes"],["rand",$rand]]);
                $tgll = $rt->insert("UPDATE $tab SET c_rand = :lk WHERE c_rand_check = :rand",[["lk",""],[":rand","yes"]]);
                return "ok";
              }else{
                return "no";
              }
            }
          }else{
            return "no";
          }
        }else{
          return "no";
        }
      }elseif ($type == "brand") {
        $rt = new hdev_db();
        $tab = $rt->table("brand");
        $ref2 =$rt->select("SELECT * FROM $tab where c_rand = :cid ORDER BY views DESC",[[":cid",$rand]]);
        if (is_array($ref2) && isset($ref2[0]) && count($ref2[0]) > 3) {
          foreach ($ref2 as $ik) {
            $rtg = $ik["c_id"];
          }
          if (isset($rtg) && !empty($rtg)) {
            $link = "brand/".$rtg;
            $ref3 =$rt->select("SELECT * FROM $tab where c_link = :cid ORDER BY views DESC",[[":cid",$link]]);
            if (is_array($ref3) && isset($ref3[0]) && count($ref3[0]) > 3) {
              return "no";
            }else{
              $tg = $rt->insert("UPDATE $tab SET c_link = :lk WHERE c_rand = :rand",[["lk",$link],["rand",$rand]]);
              if ($tg=="ok") {
                $tgl = $rt->insert("UPDATE $tab SET c_rand_check = :lk WHERE c_rand = :rand",[["lk","yes"],["rand",$rand]]);
                $tgll = $rt->insert("UPDATE $tab SET c_rand = :lk WHERE c_rand_check = :rand",[["lk",""],[":rand","yes"]]);
                return "ok";
              }else{
                return "no";
              }
            }
          }else{
            return "no";
          }
        }else{
          return "no";
        }
      }elseif ($type == "book") {
        $rt = new hdev_db();
        $tab = $rt->table("products");
        $ref2 =$rt->select("SELECT * FROM $tab where b_rand = :cid",[[":cid",$rand]]);
        if (is_array($ref2) && isset($ref2[0]) && count($ref2[0]) > 3) {
          foreach ($ref2 as $ik) {
            $rtg = $ik["b_id"];
          }
          if (isset($rtg) && !empty($rtg)) {
            $link = "book/".$rtg;
            $ref3 =$rt->select("SELECT * FROM $tab where b_link = :cid",[[":cid",$link]]);
            if (is_array($ref3) && isset($ref3[0]) && count($ref3[0]) > 3) {
              return "no";
            }else{
              $tg = $rt->insert("UPDATE $tab SET b_link = :lk WHERE b_rand = :rand",[["lk",$link],["rand",$rand]]);
              if ($tg=="ok") {
                $tgl = $rt->insert("UPDATE $tab SET b_rand_check = :lk WHERE b_rand = :rand",[["lk","yes"],["rand",$rand]]);
                $tgll = $rt->insert("UPDATE $tab SET b_rand = :lk WHERE b_rand_check = :rand",[["lk",""],[":rand","yes"]]);
                return "ok";
              }else{
                return "no";
              }
            }
          }else{
            return "no";
          }
        }else{
          return "no";
        }
      }
    }
    public static function create_category($p){
      $rt = new hdev_db();
      $tab = $rt->table("category");
      $name = $p['name'];
      $desc = $p['desc'];
      $rand = $p['rand'];
      $ck = hdev_data::duplication_checker(["name"=>$name,"type"=>"cat"]);
      if ($ck == "no") {
        $fg = $rt->insert("INSERT INTO $tab (c_name,c_desc,c_rand) VALUES (:c_nane,:descj,:rand)",[[':c_nane',$name],[':descj',$desc],[':rand',$rand]]);
        if ($fg == "ok") {
          $fgr = hdev_data::data_link(["type"=>"cat","rand"=>$rand]);
          if ($fgr!="no") {
            echo "ok";
          }else{
            $fgb = $rt->insert("DELETE FROM $tab WHERE c_rand = :rand",["c_rand",$rand]);
            echo "try again later!";
          }
        }else{
          echo "Try again or contact system administrator!";
        }
      }else{
        return "That category already exists";
      } 
    }
    public static function create_brand($p){
      $rt = new hdev_db();
      $tab = $rt->table("brand");
      $name = $p['name'];
      $desc = $p['desc'];
      $rand = $p['rand'];
      $ck = hdev_data::duplication_checker(["name"=>$name,"type"=>"brand"]);
      if ($ck == "no") {
        $fg = $rt->insert("INSERT INTO $tab (c_name,c_desc,c_rand) VALUES (:c_nane,:descj,:rand)",[[':c_nane',$name],[':descj',$desc],[':rand',$rand]]);
        if ($fg == "ok") {
          $fgr = hdev_data::data_link(["type"=>"brand","rand"=>$rand]);
          if ($fgr!="no") {
            echo "ok";
          }else{
            $fgb = $rt->insert("DELETE FROM $tab WHERE c_rand = :rand",["c_rand",$rand]);
            echo "try again later!";
          }
        }else{
          echo "Try again or contact system administrator!";
        }
      }else{
        return "That Brand already exists";
      }
    }
    public static function create_products($p) 
    {
      $rt = new hdev_db();
      $tab = $rt->table("products");
      $shop = hdev_log::sid();
      $name = $p['name'];
      $desc = $p['desc'];
      $rand = $p['rand'];
      $link = urlencode($p['link']);
      $cat = $p['cat'];
      $brand = $p['brand'];
      $price = $p['price'];
      $pic = $p['pic'];
      $size = $p['size'];
      $ck = hdev_data::duplication_checker(["name"=>$name,"type"=>"book"]);
      if ($ck == "no") {
        $fg = $rt->insert("INSERT INTO $tab (g_id,c_id, b_name,b_size, b_desc, b_elink, b_rand,b_brand,b_price,b_pic) VALUES (:sid,:c_id,:b_name,:b_size,:descj,:link,:rand,:brand,:price,:pic)",[[":sid",$shop],[":c_id",$cat],[':b_name',$name],[':b_size',$size],[':descj',$desc],[':link',$link],[':rand',$rand],[":brand",$brand],[":price",$price],[':pic',$pic]]);
        if ($fg == "ok") {
          $fgr = hdev_data::data_link(["type"=>"book","rand"=>$rand]);
          if ($fgr!="no") {
            hdev_note::message("ok");
            hdev_note::redirect(hdev_url::menu("h/home"));
          }else{
            $fgb = $rt->insert("DELETE FROM $tab WHERE b_rand = :rand",["c_rand",$rand]);

            foreach (hdev_data::product_images($p['pic'],1) as $fileName){
              if(file_exists($fileName))
              {
                if (unlink($fileName)) {}
              }
            }
                    
            
            echo "try again later!";
          }
        }else{
          echo "Try again or contact system administrator!";
        }
      }else{
        return "That Product already exists";
      }
    }
  public static function edit_products($p) 
    {
      $rt = new hdev_db();
      $tab = $rt->table("products");
      $name = $p['name'];
      $desc = $p['desc'];
      $rand = $p['rand'];
      $link = urlencode($p['link']);
      $cat = $p['cat'];
      $brand = $p['brand'];
      $price = $p['price'];
      $pic = $p['pic'];
      $mask = $p['mask'];
      $size = $p['size'];
      //$ck = hdev_data::duplication_checker(["name"=>$name,"type"=>"book"]);
      $ck = "no";
      if ($ck == "no") {
        if (!empty($pic)) {
          $pic2 = hdev_data::get_products($mask,"menu")["pic"];
          $prod_h = hdev_data::product_images($pic2,1);
          if (count($prod_h) > 0) {
            foreach ($prod_h as $fileName){
              if(file_exists($fileName))
              {
                if (unlink($fileName)) {}
              }
            }
          }
          $fg = $rt->insert("UPDATE $tab SET `b_name` = :bnm,`b_size`=:b_size, `b_desc` = :descp, `b_pic` = :pic, `b_price` = :price,`b_brand` = :brand,`c_id` = :cat WHERE `b_id` = :id ",[[":bnm",$name],[':b_size',$size],[":descp",$desc],[':pic',$pic],[":price",$price],[":brand",$brand],[":cat",$cat],[":id",$mask]]);
        }else{
          $fg = $rt->insert("UPDATE $tab SET `b_name` = :bnm,`b_size`=:b_size, `b_desc` = :descp, `b_price` = :price,`b_brand` = :brand,`c_id` = :cat WHERE `b_id` = :id ",[[":bnm",$name],[':b_size',$size],[":descp",$desc],[":price",$price],[":brand",$brand],[":cat",$cat],[":id",$mask]]);
        }
        if ($fg == "ok") {
            hdev_note::message("Edited!!");
            hdev_note::redirect(hdev_url::menu("h/products"));
        }else{
          echo "Try again or contact system administrator!";
        }
      }else{
        return "That Product already exists";
      }
    }
    public static function get_cat($cat="",$v="menu",$limit="a")
    {
      $rt = new hdev_db();
      $tab = $rt->table("category");
      $returna = "";
      if ($limit=="a") {
        $ref =$rt->select("SELECT * FROM $tab ORDER BY views DESC");
        if ($cat != "*") {
          $ref2 =$rt->select("SELECT * FROM $tab where c_id = :cid ORDER BY views DESC",[[":cid",$cat]]);
        }else{
          $ref2 =$rt->select("SELECT * FROM $tab where c_id != :cid ORDER BY views DESC",[[":cid",""]]);
        }
        
      }elseif(is_array($limit) && count($limit)>1 && isset($limit['type']) && !empty($limit['type'])){

        $num0 = (isset($limit["type"])) ? $limit["type"]: "";
        $num1 = (isset($limit['pg']) && !empty($limit['pg'])) ? $limit["pg"] : "1" ;
        $num2 = 6;
       // var_dump($limit);exit(); 

        if (empty($num1) || $num1 == 1) {
          $num1 =0;
        }else{
          $num1 = ($num1*$num2)-$num2; 
        }
        if (!is_numeric($num1)) {
          $num1 = 0;
        }
        if (!is_numeric($num2)) {
          $num2 = 6;
        }
        if ($cat != "*") {
          $ref =$rt->select("SELECT * FROM $tab ORDER BY views DESC LIMIT ".$num1.",6");
          $ref2 =$rt->select("SELECT * FROM $tab where c_id = :cid ORDER BY views DESC LIMIT ".$num1.",6",[[":cid",$cat]]);
        }else{
          $ref =$rt->select("SELECT * FROM $tab ORDER BY views DESC LIMIT ".$num1.",6");
          $ref2 =$rt->select("SELECT * FROM $tab where c_id != :cid ORDER BY views DESC LIMIT ".$num1.",6",[[":cid",""]]);
        }
        
        if ($num0 == "count") {
          $returna= count($rt->select("SELECT * FROM $tab ORDER BY views DESC"));
        }

      }else{
        $ref =$rt->select("SELECT * FROM $tab ORDER BY views DESC LIMIT 0,8");
        if ($cat !="*") {
          $ref2 =$rt->select("SELECT * FROM $tab where c_id = :cid ORDER BY views DESC LIMIT 0,8",[[":cid",$cat]]);
        }else{
          $ref2 =$rt->select("SELECT * FROM $tab where c_id != :cid ORDER BY views DESC LIMIT 0,8",[[":cid",""]]);
        }
        
      }
      $a = ""; 
      if ($v=="menu") {
      
        if (count($ref) > 0) {
            return $ref;
        }else{
          return "";
        }
      }elseif ($v=="info") {
        if (count($ref2) > 0) {
          foreach ($ref2 as $refd) {
            $nm = ucfirst($refd["c_name"]);
            $lk = $refd["c_link"];
            $desc = ucfirst($refd['c_desc']);
          }
          return array("name"=>$nm,"link"=>$lk,"desc"=>$desc);
        }else{
          return $returna;
        }
      }else{
          return $returna;
      }
    }
    public static function get_brand($cat="",$v="menu",$limit="a")
    {
      $rt = new hdev_db();
      $tab = $rt->table("brand");
      $returna = "";
      if ($limit=="a") {
        $ref =$rt->select("SELECT * FROM $tab ORDER BY views DESC");
        if ($cat != "*") {
          $ref2 =$rt->select("SELECT * FROM $tab where c_id = :cid ORDER BY views DESC",[[":cid",$cat]]);
        }else{
          $ref2 =$rt->select("SELECT * FROM $tab where c_id != :cid ORDER BY views DESC",[[":cid",""]]);
        }
        
      }elseif(is_array($limit) && count($limit)>1 && isset($limit['type']) && !empty($limit['type'])){

        $num0 = (isset($limit["type"])) ? $limit["type"]: "";
        $num1 = (isset($limit['pg']) && !empty($limit['pg'])) ? $limit["pg"] : "1" ;
        $num2 = 6;
       // var_dump($limit);exit();

        if (empty($num1) || $num1 == 1) {
          $num1 =0;
        }else{
          $num1 = ($num1*$num2)-$num2; 
        }
        if (!is_numeric($num1)) {
          $num1 = 0;
        }
        if (!is_numeric($num2)) {
          $num2 = 6;
        }
        if ($cat != "*") {
          $ref =$rt->select("SELECT * FROM $tab ORDER BY views DESC LIMIT ".$num1.",6");
          $ref2 =$rt->select("SELECT * FROM $tab where c_id = :cid ORDER BY views DESC LIMIT ".$num1.",6",[[":cid",$cat]]);
        }else{
          $ref =$rt->select("SELECT * FROM $tab ORDER BY views DESC LIMIT ".$num1.",6");
          $ref2 =$rt->select("SELECT * FROM $tab where c_id != :cid ORDER BY views DESC LIMIT ".$num1.",6",[[":cid",""]]);
        }
        
        if ($num0 == "count") {
          $returna= count($rt->select("SELECT * FROM $tab ORDER BY views DESC"));
        }

      }else{
        $ref =$rt->select("SELECT * FROM $tab ORDER BY views DESC LIMIT 0,8");
        if ($cat !="*") {
          $ref2 =$rt->select("SELECT * FROM $tab where c_id = :cid ORDER BY views DESC LIMIT 0,8",[[":cid",$cat]]);
        }else{
          $ref2 =$rt->select("SELECT * FROM $tab where c_id != :cid ORDER BY views DESC LIMIT 0,8",[[":cid",""]]);
        }
        
      }
      $a = ""; 
      if ($v=="menu") {
      
        if (count($ref) > 0) {
            return $ref;
        }else{
          return "";
        }
      }elseif ($v=="info") {
        if (count($ref2) > 0) {
          foreach ($ref2 as $refd) {
            $nm = ucfirst($refd["c_name"]);
            $lk = $refd["c_link"];
            $desc = ucfirst($refd['c_desc']);
          }
          return array("name"=>$nm,"link"=>$lk,"desc"=>$desc);
        }else{
          return $returna;
        }
      }else{
          return $returna;
      }
    }
    public static function get_products($b_id,$v="menu",$limit="")
    {
      $rt = new hdev_db();
      $tab = $rt->table("products");
      $ck_me_1 = " 1=1 ";
      $ck_me_2 = " AND 1=1 ";
      if (hdev_log::loged() && hdev_log::admin()) {
        $gp = hdev_log::sid();
        $ck_me_1 = " product_exist(b_id,'".$gp."') ";
        $ck_me_2 = " AND product_exist(b_id,'".$gp."') ";
      }

      $table_cat = $rt->table("category");;
      $table_brand = $rt->table("brand");
      $ref = "";
      if ($v=="top") {
        $ref =$rt->select("SELECT * FROM $tab a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1  and a.p_status=1 $ck_me_2 ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC LIMIT 0,10");
      }elseif ($v == "*") {
        $num1 = 0;
        if (is_array($limit) && count($limit)>1) {
          $num0 = $limit[0];
          $num1 = (isset($limit[1]) && !empty($limit[1])) ? $limit[1] : "1" ;
          $num2 = 1;
         // var_dump($limit);exit();

          if (empty($num1) || $num1 == 1) {
            $num1 =0;
          }else{
            $num1 = ($num1*$num2)-$num2; 
          }
          if (!is_numeric($num1)) {
            $num1 = 0;
          }
          if (!is_numeric($num2)) {
            $num2 = 10;
          }
        }
        $ref =$rt->select("SELECT * FROM $tab a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 $ck_me_2 ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC");
      }elseif ($v == "count") {
        $ref = count($rt->select("SELECT * FROM $tab a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 $ck_me_2 ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC"));
      } else{
        $ref =$rt->select("SELECT * FROM $tab where b_id = :bid $ck_me_2",[[":bid",$b_id]]);
      }
      $a = "";
      $bkret = array();
      if (is_array($ref) && count($ref) > 0 && $v != "count") {
        if ($v!="") {
          foreach ($ref as $tk) {
            $size = $tk['b_size'];
            $g_id = $tk['g_id'];
            $link = $tk["b_link"];
            $link2 = $tk["b_link"];
            $name = ucfirst($tk["b_name"]);
            $desc = ucfirst($tk["b_desc"]);
            $pic = $tk["b_pic"];
            $category = $tk['c_id'];
            $elink = trim($tk["b_elink"]);
            $d = $tk["b_id"];
            $vv = $tk["b_views"];
            $ddd = $tk["b_downloads"];
            $brand = $tk['b_brand'];
            $price = $tk['b_price'];
            $link = str_ireplace("/", "...", $link);
            $bb = array("b_size"=>$size,"g_id"=>$g_id,"download"=>$ddd,"views"=>$vv,"d"=>$d,"link"=>$link,"name"=>$name,"icon"=>"fas fa-shopping-bag","desc"=>$desc,"pic"=>$pic,"category"=>$category, "elink"=>$elink,"brand"=>$brand,"price"=>$price,"status"=>$tk['p_status']);
            if ($v == "top" || $v == "*") {
              array_push($bkret, $bb);
            }
          }
          if ($v == "menu") {
            return $bb;
          }elseif ($v == "count") {
            return $ref;
          }elseif ($v == "top" || $v == "*") {
            return $bkret;
          }
        }
      }else{
        return $ref;
      } 
    }
    public static function payment_update($id = "",$tx_id="",$status="")
    {
      $rt = new hdev_db();
      $tab = $rt->table("order_parent");
      $u = hdev_log::uid();
      $payment = hdev_data::order_menu($id,['data2']);
      $price = $payment['total_price'];
      hdev_note::live_sms($payment['tel'],'Dear '.$payment['name'].'your payment of '.$price.' to '.constant('APP_NAME').', has been completed well. your transaction_ID is: '.$tx_id.'. Thank you!');
      $sql = $rt->insert("UPDATE `$tab` SET `tx_id` = :tx_id,`payment_status` = :p_status WHERE `tx_ref` = :id;",[[':tx_id',$tx_id], [':p_status',$status],[':id',$id]]);

      return "ok";
    }
    public static function product_view($id)
    {
      $rt = new hdev_db();
      $tab = $rt->table("products");
      $rt->insert("UPDATE $tab SET b_views=b_views+1 where b_id = :bid",[[":bid",$id]]);
      return "";
    }
    public static function cat_view($id)
    {
      $rt = new hdev_db();
      $tab = $rt->table("category");
      $rt->insert("UPDATE $tab SET views=views+1 where c_id = :bid",[[":bid",$id]]);
      return "";
    }
    public static function brand_view($id)
    {
      $rt = new hdev_db();
      $tab = $rt->table("brand");
      $rt->insert("UPDATE $tab SET views=views+1 where c_id = :bid",[[":bid",$id]]);
      return "";
    }
    public static function product_order_update($id)
    {
      $rt = new hdev_db();
      $tab = $rt->table("products");
      $rt->insert("UPDATE $tab SET b_downloads=b_downloads+1 where b_id = :bid",[[":bid",$id]]);
      return "";
    }

    public static function get_cat_products($cat=[''],$v="menu", $limit=0)
    {
      $order = "";
      if (isset($cat) && is_array($cat) && count($cat) > 1) {
        if (isset($cat['order']) && !empty($cat['order'])) {
          if ($cat['order'] == "date") {
            $order = "date";
          }else{
            $order = "";
          }
        }
      }
      if (isset($cat[0]) && !empty($cat[0])) {
          $cat = $cat[0];
        }
      $rt = new hdev_db();
      $tab2 = $rt->table("products");
      $table_cat = $rt->table("category");
      $table_brand = $rt->table("brand");
      if (is_array($limit) && count($limit)>1) {
        $num0 = $limit[0];
        $num1 = (isset($limit[1]) && !empty($limit[1])) ? $limit[1] : "1" ;
        $num2 = 12;
       // var_dump($limit);exit();

        if (empty($num1) || $num1 == 1) {
          $num1 =0;
        }else{
          $num1 = ($num1*$num2)-$num2; 
        }
        if (!is_numeric($num1)) {
          $num1 = 0;
        }
        if (!is_numeric($num2)) {
          $num2 = 12;
        }
        if ($num0 == "count") {
          if ($cat != "*") {
            $ref2d =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.c_id = :cat ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC",[[":cat",$cat]]);
            $ref2 = "";
          }else{
            $ref2d =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_name != :cat ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC",[[":cat",""]]);
            $ref2 = "";
          }
          return count($ref2d);
        }
      }

      if (is_array($limit) && count($limit)>1 && $limit[0]="value") {
        if ($cat != '*') {
          if ($order == "date") {
            $limit = $limit[1];
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.c_id = :cat ORDER BY a.b_reg  DESC LIMIT ".$num1.",12",[[":cat",$cat]]);
          }else{
            $limit = $limit[1];
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.c_id = :cat ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$num1.",12",[[":cat",$cat]]);
          }
        }else{
          if ($order == "date") {
            $limit = $limit[1];
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_name != :cat ORDER BY a.b_reg DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$num1.",12",[[":cat",""]]);
          }else{
            $limit = $limit[1];
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_name != :cat ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$num1.",12",[[":cat",""]]);
          }
        }
        

      }else{
        if ($cat != "*") {
          if ($order == 'date') {
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.c_id = :cat  ORDER BY a.b_reg DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$limit.",12",[[":cat",$cat]]);
          }else{
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.c_id = :cat  ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$limit.",12",[[":cat",$cat]]);
          }
          
        }else{
          if ($order == "date") {
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_name != :cat ORDER BY a.b_reg DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$limit.",12",[[":cat",""]]);
          }else{
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_name != :cat ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$limit.",12",[[":cat",""]]);
          }
          
        }
        
      }

      if (count($ref2) > 0 && !empty($ref2)) {
        if ($v=="menu") {
          //var_dump($ref2);

          $nm = (!empty(hdev_data::get_cat($cat,"info")["name"])) ? hdev_data::get_cat($cat,"info")["name"] : "";

          $a[0]=array("link"=>"#","name"=>$nm,"icon"=>"fas fa-cart-arrow-down","pic"=>"","d"=>"");
          $b = array(0);
          foreach ($ref2 as $tk) {
            array_push($b, $tk["b_id"]);
            $a[$tk["b_id"]] = hdev_data::get_products($tk["b_id"]);
          }
          $linkog = str_ireplace("/", "... ", hdev_data::get_cat($cat,"info")["link"]);
          array_push($b, "more");
          $a["more"] = array("link"=>$linkog,"name"=>"More...","icon"=>"fas fa-ellipsis-h","pic"=>"","d"=>"");
          $cou = count($b);
          if ($cou > 0 && !empty($b)) {
            $name = "";
            $link = "";
            $icon = "";
            $pic = "";
            $id = "";
            foreach ($b as $ard) {
              if (isset($a[$ard]["name"]) && isset($a[$ard]["link"]) && isset($a[$ard]["icon"]) && isset($a[$ard]["pic"]) && isset($a[$ard]["d"])) {
                $name .=  "^^".$a[$ard]["name"];
                $link .= "^^".$a[$ard]["link"];
                $icon .= "^^".$a[$ard]["icon"];
                $pic .= "^^".$a[$ard]["pic"];
                $id .= "^^".$a[$ard]["d"];
              }
            }

            $name = substr($name, 2);
            $link = substr($link, 2);
            $icon = substr($icon, 2);
            $pic = substr($pic, 2);
            $id = substr($id, 2);
            $getk = array( 
                          "name" => $name, 
                          "trees" => 2,
                          "icon" => $icon,
                          "link" => $link,
                          "pic" => $pic,
                          "id" => $id
                        );
          }
        }else{
          hdev_note::message("error ocurred contact administrator");
        }
      }else{
        //exit("fail");
         $name = (!empty(hdev_data::get_cat($cat,"info")["name"])) ? hdev_data::get_cat($cat,"info")["name"] : "";
            $link = (!empty(hdev_data::get_cat($cat,"info")["link"])) ? hdev_data::get_cat($cat,"info")["link"] : "";
            $link = str_ireplace("/", "...", $link);
            $icon = "fas fa-shopping-cart";
            $getk = array(
                          "name" => $name, 
                          "trees" => 1,
                          "icon" => $icon,
                          "link" => $link
                        );
      } 
      return $getk;
    }
    public static function get_brand_products($cat,$v="menu", $limit=0)
    {
      $order = "";
      if (isset($cat) && is_array($cat) && count($cat) > 1) {
        if (isset($cat['order']) && !empty($cat['order'])) {
          if ($cat['order'] == "date") {
            $order = "date";
          }else{
            $order = "";
          }
        }
      }
      if (isset($cat[0]) && !empty($cat[0])) {
          $cat = $cat[0];
        }
      $rt = new hdev_db();
      $tab2 = $rt->table("products");
      $table_cat = $rt->table("category");;
      $table_brand = $rt->table("brand");
      if (is_array($limit) && count($limit)>1) {
        $num0 = $limit[0];
        $num1 = (isset($limit[1]) && !empty($limit[1])) ? $limit[1] : "1" ;
        $num2 = 12;
       // var_dump($limit);exit();

        if (empty($num1) || $num1 == 1) {
          $num1 =0;
        }else{
          $num1 = ($num1*$num2)-$num2; 
        }
        if (!is_numeric($num1)) {
          $num1 = 0;
        }
        if (!is_numeric($num2)) {
          $num2 = 12;
        }
        if ($num0 == "count") {
          if ($cat != "*") {
            $ref2d =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_brand = :cat ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC",[[":cat",$cat]]);
            $ref2 = "";
          }else{
            $ref2d =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_name != :cat ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC",[[":cat",""]]);
            $ref2 = "";
          }
          return count($ref2d);
        }
      }

      if (is_array($limit) && count($limit)>1 && $limit[0]="value") {
        if ($cat != '*') {
          if ($order == "date") {
            $limit = $limit[1];
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_brand = :cat ORDER BY a.b_reg  DESC LIMIT ".$num1.",12",[[":cat",$cat]]);
          }else{
            $limit = $limit[1];
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_brand = :cat ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$num1.",12",[[":cat",$cat]]);
          }
        }else{
          if ($order == "date") {
            $limit = $limit[1];
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_name != :cat ORDER BY a.b_reg DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$num1.",12",[[":cat",""]]);
          }else{
            $limit = $limit[1];
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_name != :cat ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$num1.",12",[[":cat",""]]);
          }
        }
        

      }else{
        if ($cat != "*") {
          if ($order == 'date') {
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_brand = :cat  ORDER BY a.b_reg DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$limit.",12",[[":cat",$cat]]);
          }else{
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_brand = :cat  ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$limit.",12",[[":cat",$cat]]);
          }
          
        }else{
          if ($order == "date") {
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_name != :cat ORDER BY a.b_reg DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$limit.",12",[[":cat",""]]);
          }else{
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_name != :cat ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$limit.",12",[[":cat",""]]);
          }
          
        }
        
      }
      if (count($ref2) > 0 && !empty($ref2)) {
        if ($v=="menu") {

          $nm = (!empty(hdev_data::get_brand($cat,"info")["name"])) ? hdev_data::get_brand($cat,"info")["name"] : "";

          $a[0]=array("link"=>"#","name"=>$nm,"icon"=>"fa fa-cart-arrow-down","pic"=>"","d"=>"");
          $b = array(0);
          foreach ($ref2 as $tk) {
            array_push($b, $tk["b_id"]);
            $a[$tk["b_id"]] = hdev_data::get_products($tk["b_id"]);
          }
          $linkog = str_ireplace("/", "... ", hdev_data::get_brand($cat,"info")["link"]);
          array_push($b, "more");
          $a["more"] = array("link"=>$linkog,"name"=>"More...","icon"=>"fas fa-ellipsis-h","pic"=>"","d"=>"");
          $cou = count($b);
          if ($cou > 0 && !empty($b) && is_array($b) && count($b) > 0) {
            $name = "";
            $link = "";
            $icon = "";
            $pic = "";
            $id = "";
            //var_dump($a);
            //var_dump($b);

            foreach ($b as $ard) {
              if (isset($a[$ard]["name"]) && isset($a[$ard]["link"]) && isset($a[$ard]["icon"]) && isset($a[$ard]["pic"]) && isset($a[$ard]["d"])) {
                $name .=  "^^".$a[$ard]["name"];
                $link .= "^^".$a[$ard]["link"];
                $icon .= "^^".$a[$ard]["icon"];
                $pic .= "^^".$a[$ard]["pic"];
                $id .= "^^".$a[$ard]["d"];
              }
            }

            $name = substr($name, 2);
            $link = substr($link, 2);
            $icon = substr($icon, 2);
            $pic = substr($pic, 2);
            $id = substr($id, 2);
            $getk = array( 
                          "name" => $name, 
                          "trees" => 2,
                          "icon" => $icon,
                          "link" => $link,
                          "pic" => $pic,
                          "id" => $id
                        );
          }
        }else{
          hdev_note::message("error ocurred contact administrator");
        }
      }else{
        //exit("fail");
         $name = (!empty(hdev_data::get_brand($cat,"info")["name"])) ? hdev_data::get_brand($cat,"info")["name"] : "";
            $link = (!empty(hdev_data::get_brand($cat,"info")["link"])) ? hdev_data::get_brand($cat,"info")["link"] : "";
            $link = str_ireplace("/", "...", $link);
            $icon = "fas fa-shopping-cart";
            $getk = array(
                          "name" => $name, 
                          "trees" => 1,
                          "icon" => $icon,
                          "link" => $link
                        );
      } 
      return $getk;
    }

    public static function get_shop_products($cat,$v="menu", $limit=0)
    {
      $order = "";
      if (isset($cat) && is_array($cat) && count($cat) > 1) {
        if (isset($cat['order']) && !empty($cat['order'])) {
          if ($cat['order'] == "date") {
            $order = "date";
          }else{
            $order = "";
          }
        }
      }
      if (isset($cat[0]) && !empty($cat[0])) {
          $cat = $cat[0];
        }
      $rt = new hdev_db();
      $tab2 = $rt->table("products");
      $table_cat = $rt->table("category");;
      $table_brand = $rt->table("brand");
      if (is_array($limit) && count($limit)>1) {
        $num0 = $limit[0];
        $num1 = (isset($limit[1]) && !empty($limit[1])) ? $limit[1] : "1" ;
        $num2 = 12;
       // var_dump($limit);exit();

        if (empty($num1) || $num1 == 1) {
          $num1 =0;
        }else{
          $num1 = ($num1*$num2)-$num2; 
        }
        if (!is_numeric($num1)) {
          $num1 = 0;
        }
        if (!is_numeric($num2)) {
          $num2 = 12;
        }
        if ($num0 == "count") {
          if ($cat != "*") {
            $ref2d =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.g_id = :cat ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC",[[":cat",$cat]]);
            $ref2 = "";
          }else{
            $ref2d =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_name != :cat ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC",[[":cat",""]]);
            $ref2 = "";
          }
          return count($ref2d);
        }
      }

      if (is_array($limit) && count($limit)>1 && $limit[0]="value") {
        if ($cat != '*') {
          if ($order == "date") {
            $limit = $limit[1];
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.g_id = :cat ORDER BY a.b_reg  DESC LIMIT ".$num1.",12",[[":cat",$cat]]);
          }else{
            $limit = $limit[1];
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.g_id = :cat ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$num1.",12",[[":cat",$cat]]);
          }
        }else{
          if ($order == "date") {
            $limit = $limit[1];
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_name != :cat ORDER BY a.b_reg DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$num1.",12",[[":cat",""]]);
          }else{
            $limit = $limit[1];
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_name != :cat ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$num1.",12",[[":cat",""]]);
          }
        }
        

      }else{
        if ($cat != "*") {
          if ($order == 'date') {
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.g_id = :cat  ORDER BY a.b_reg DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$limit.",12",[[":cat",$cat]]);
          }else{
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.g_id = :cat  ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$limit.",12",[[":cat",$cat]]);
          }
          
        }else{
          if ($order == "date") {
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_name != :cat ORDER BY a.b_reg DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$limit.",12",[[":cat",""]]);
          }else{
            $ref2 =$rt->select("SELECT * FROM $tab2 a,$table_cat b,$table_brand c where a.c_id=b.c_id and a.b_brand=c.c_id and b.c_status=1 and c.b_status=1 and a.p_status=1 and a.b_name != :cat ORDER BY a.b_views DESC, a.b_downloads DESC, a.b_id DESC LIMIT ".$limit.",12",[[":cat",""]]);
          }
          
        }
        
      }
      if (count($ref2) > 0 && !empty($ref2)) {
        if ($v=="menu") {

          $nm = hdev_data::groups($cat,['data'])["g_name"];

          $a[0]=array("link"=>"#","name"=>$nm,"icon"=>"fa fa-cart-arrow-down","pic"=>"","d"=>"");
          $b = array(0);
          foreach ($ref2 as $tk) {
            array_push($b, $tk["b_id"]);
            $a[$tk["b_id"]] = hdev_data::get_products($tk["b_id"]);
          }
          $linkog = str_ireplace("/", "... ", "brand/".$cat);
          array_push($b, "more");
          $a["more"] = array("link"=>$linkog,"name"=>"More...","icon"=>"fas fa-ellipsis-h","pic"=>"","d"=>"");
          $cou = count($b);
          if ($cou > 0 && !empty($b) && is_array($b) && count($b) > 0) {
            $name = "";
            $link = "";
            $icon = "";
            $pic = "";
            $id = "";
            //var_dump($a);
            //var_dump($b);

            foreach ($b as $ard) {
              if (isset($a[$ard]["name"]) && isset($a[$ard]["link"]) && isset($a[$ard]["icon"]) && isset($a[$ard]["pic"]) && isset($a[$ard]["d"])) {
                $name .=  "^^".$a[$ard]["name"];
                $link .= "^^".$a[$ard]["link"];
                $icon .= "^^".$a[$ard]["icon"];
                $pic .= "^^".$a[$ard]["pic"];
                $id .= "^^".$a[$ard]["d"];
              }
            }

            $name = substr($name, 2);
            $link = substr($link, 2);
            $icon = substr($icon, 2);
            $pic = substr($pic, 2);
            $id = substr($id, 2);
            $getk = array( 
                          "name" => $name, 
                          "trees" => 2,
                          "icon" => $icon,
                          "link" => $link,
                          "pic" => $pic,
                          "id" => $id
                        );
          }
        }else{
          hdev_note::message("error ocurred contact administrator");
        }
      }else{
        //exit("fail");
         $name = hdev_data::groups($cat,["data"])["g_name"];
            $link = "brand/".$cat;
            $link = str_ireplace("/", "...", $link);
            $icon = "fas fa-shopping-cart";
            $getk = array(
                          "name" => $name, 
                          "trees" => 1,
                          "icon" => $icon,
                          "link" => $link
                        );
      } 
      return $getk;
    }    

    public static function app_income($l_id="",$param=["1","rec",''])
    {
      $rt = new hdev_db();
      $tab = $rt->table("order_parent");
      $v_ref = array();
      if (isset($param[2]) && $param[2] == "shop") {
        $user = $l_id;
        $funct = 'shop';
      }else{
        $user = hdev_log::uid();
        if (hdev_log::admin()) {
          $user = hdev_log::sid();
          $fid = "shop";
        }elseif (hdev_log::super_admin()) {
          $fid = "admin";
        }else{
          $fid = "shop";
        }
      }

      $from = (isset($_SESSION['from'])) ? $_SESSION['from'] : "" ;
      $to = (isset($_SESSION['to'])) ? $_SESSION['to'] : "" ;
      $p_date = "";
      //var_dump($param);
      if (!empty($to) && !empty($from) && $param["2"] == "") {
        $to = date_format(date_create($to),"Y-m-d");
        $from = date_format(date_create($from),"Y-m-d");
        $p_date = "AND reg_date BETWEEN '".$from."' AND '".$to."'";
      }
      if (isset($param[0]) && $param[0] == "1") {
        switch ($fid) {
          case 'admin':
            switch ($param[1]) {
              case 'rec':
                $v_ref = $rt->select("SELECT *,(round((total_price*5/100),2)) AS inc FROM $tab WHERE payment_status=:st AND tx_ref != '' $p_date ORDER BY reg_date DESC",[[":st",'approved']]);
                break;
              case 'sum':
                $v_ref = 0;
                $v_refk = $rt->select("SELECT sum((round((total_price*5/100),2)))  AS inc FROM $tab WHERE payment_status=:st AND tx_ref != '' $p_date ORDER BY reg_date DESC",[[":st",'approved']]);
                if (isset($v_refk[0]['inc']) && is_numeric($v_refk[0]['inc'])) {
                  $v_ref = $v_refk['0']['inc'];
                }
                break;
              
              default:
                $v_ref = $rt->select("SELECT *, (round((total_price*5/100),2))  AS inc FROM $tab WHERE payment_status=:st AND tx_ref != '' $p_date ORDER BY reg_date DESC",[[":st",'approved']]);
                break;
            }
            break;
          case 'shop':
            $main_shop = $user;
            switch ($param[1]) {
              case 'rec':
                $v_ref = $rt->select("SELECT *,(round((total_price*95/100),2)) AS inc FROM $tab WHERE  payment_status=:st AND tx_ref != '' AND order_shop(tx_ref, $main_shop) > 0 $p_date ORDER BY reg_date DESC",[[":st",'approved']]);
                break;
              case 'sum':
                $v_ref = 0;
                $v_refk = $rt->select("SELECT sum((round((total_price*95/100),2))) AS inc FROM $tab WHERE  payment_status=:st AND tx_ref != '' AND order_shop(tx_ref, $main_shop) > 0 $p_date ORDER BY reg_date DESC",[[":st",'approved']]);
                if (isset($v_refk[0]['inc']) && is_numeric($v_refk[0]['inc'])) {
                  $v_ref = $v_refk['0']['inc'];
                }
                break;
              
              default:
                $v_ref = $rt->select("SELECT *,(round((total_price*95/100),2)) AS inc FROM $tab WHERE  payment_status=:st AND tx_ref != '' AND order_shop(tx_ref, $main_shop) > 0 $p_date ORDER BY reg_date DESC",[[":st",'approved']]);
                break;
            }
          default:
            // code...
            break;
        }
        return $v_ref;
      }
      elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE re_id !='' ORDER BY re_reg_date DESC");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "exist") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE re_id = :re_id AND re_status=1",[[":re_id",$l_id]]);
        if (isset($v_ref[0]['re_id']) && !empty($v_ref[0]['re_id'])) {
          $retur = "yes";
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE re_id = :re_id",[[":re_id",$l_id]]);
        if (isset($v_ref[0]['re_id']) && !empty($v_ref[0]['re_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "valid") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE re_id = :l_id AND re_status=1",[[":re_id",$l_id]]);
        if (isset($v_ref[0]['re_id']) && !empty($v_ref[0]['re_id'])) {
          $retur = $v_ref[0];
        }else{
          $retur = false;
        }
        return $retur;
      }
    }
    public static function shop_account($id='')
    {
      $ret = 0;
      $ret = hdev_data::app_income($id,['1','sum','shop'])-hdev_data::payouts($id,['sum','shop']);
      return $ret;
    }
   public static function payouts($l_id="",$param=[1,''])
    {
      $rt = new hdev_db();
      $tab = $rt->table("payouts");
      $v_ref = array();
      $param[1] = (isset($param[1])) ? $param['1'] : "";
      if (isset($param[1]) && $param[1] == "shop") {
      //exit($param['1']);
        $user = $l_id;
        $fid = 'shop';
      }else{
        $user = hdev_log::uid();
        if (hdev_log::admin()) {
          $user = hdev_log::sid();
          $fid = "shop";
        }elseif (hdev_log::super_admin()) {
          $fid = "admin";
        }else{
          $fid = "shop";
        }
      }

      $from = (isset($_SESSION['from'])) ? $_SESSION['from'] : "" ;
      $to = (isset($_SESSION['to'])) ? $_SESSION['to'] : "" ;
      $p_date = "";
      if (!empty($to) && !empty($from) && $param[1] == "") {
        $to = date_format(date_create($to),"Y-m-d");
        $from = date_format(date_create($from),"Y-m-d");
        $p_date = "AND lp_date BETWEEN '".$from."' AND '".$to."'";
      }
      if (isset($param[0]) && $param[0] == 1) {
        switch ($fid) {

          case 'admin':
          $v_ref = $rt->select("SELECT * FROM $tab WHERE lp_id !='' AND lp_status=1 $p_date ORDER BY lp_date desc");
            break;
          case 'shop':
            $v_ref = $rt->select("SELECT * FROM $tab WHERE lp_id !='' AND lp_status=1 $p_date AND l_id = :lid ORDER BY lp_date desc",[[':lid',$user]]);
            break;
        }
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "sum") {
        switch ($fid) {
          case 'admin':
            $ret = 0;
            $v_ref = $rt->select("SELECT SUM(lp_amount) AS amount FROM $tab WHERE lp_id !='' AND lp_status=1 $p_date ORDER BY lp_date desc");
            if (isset($v_ref[0]['amount']) && is_numeric($v_ref[0]['amount'])) {
              $ret = $v_ref[0]['amount'];
            }
            break;
          case 'shop':
          $ret = 0;
            $v_ref = $rt->select("SELECT SUM(lp_amount) AS amount FROM $tab WHERE lp_id !='' AND lp_status=1 AND l_id = :lid $p_date ORDER BY lp_date desc",[[':lid',$user]]);
            if (isset($v_ref[0]['amount']) && is_numeric($v_ref[0]['amount'])) {
              $ret = $v_ref[0]['amount'];
            }
            break;
        }
        return $ret;
      }
      elseif (isset($param[0]) && $param[0] == "all") {
        $v_ref = $rt->select("SELECT * FROM $tab WHERE c_name !='' ORDER BY lp_date desc");
        return $v_ref;
      }elseif (isset($param[0]) && $param[0] == "exist") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE lp_id = :c_id AND lp_status=1",[[":lp_id",$l_id]]);
        if (isset($v_ref[0]['lp_id']) && !empty($v_ref[0]['lp_id'])) {
          $retur = "yes";
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "data") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE lp_id = :lp_id",[[":lp_id",$l_id]]);
        if (isset($v_ref[0]['lp_id']) && !empty($v_ref[0]['lp_id'])) {
          $retur = $v_ref[0];
        }
        return $retur;
      }elseif (isset($param[0]) && $param[0] == "valid") {
        $retur = false;
        $v_ref = $rt->select("SELECT * FROM $tab WHERE lp_id = :lp_id AND c_status=1",[[":lp_id",$l_id]]);
        if (isset($v_ref[0]['lp_id']) && !empty($v_ref[0]['lp_id'])) {
          $retur = $v_ref[0];
        }else{
          $retur = false;
        }
        return $retur;
      }
    }
    public static function load_view($type="",$support=[])
    {
      $data = new hdev_db;
      $table = $data->table("post");
      switch ($type) {
        case 'service':
          $return = $data->select("SELECT * FROM $table WHERE p_type=:serv",[[':serv','service']]);
          break;
        case 'package':
          $return = $data->select("SELECT * FROM $table WHERE p_type=:serv",[[':serv','package']]);
          break;
        case 'partner':
          $return = $data->select("SELECT * FROM $table WHERE p_type=:serv",[[':serv','partner']]);
          break;
        case 'slide':
          $return = $data->select("SELECT * FROM $table WHERE p_type=:serv",[[':serv','slide']]);
          break;
        case 'days':
          $tab = $data->table("action");
          $return = array();
          if (isset($support['id']) && !empty($support['id']) && isset($support['package']) && !empty($support['package'])) {
            $return = $data->select("SELECT * FROM $tab WHERE d_id=:id and p_id=:p_id ORDER BY d_num,d_id",[[':p_id',$support['package']],[':id',$support['id']]]);
          }
          break;
        default:
          $return = array();
          break;
      }
      return $return;
    }
  }
  /** 
   * 
   */
  class hdev_v
  { 
    public static function login($user,$password)
    {
      $rt = hdev_data::log_user($user,$password);
      //$rt = ($user == "roger" && $password = = "techroger" || $user == "ndinda" && $password == "techndinda") ? "yes" : "no" ;
      if ($rt != "no") {
        //$rt = array("id"=>1);
        if (isset($rt['username'])) { 
          //setcookie("uid", hdev_data::encd($rt['id']), time() + (86400 * 30), "/"); //30 days
          //setcookie("funct", hdev_data::encd($rt['id']), time() + (86400 * 30), "/"); //30 days
          //setcookie("user", hdev_data::encd($rt['name']), time() + (86400 * 30), "/"); //30 days
          if ($rt['post'] == "admin") {
            $_SESSION['user'] = hdev_data::encd($rt['name']);
            $_SESSION['funct'] = hdev_data::encd($rt['post']);
            $_SESSION['uid'] = hdev_data::encd($rt['id']);
            $_SESSION['shop'] = hdev_data::encd($rt['g_id']);
          }else{
            $_SESSION['user'] = hdev_data::encd($rt['name']);
            $_SESSION['funct'] = hdev_data::encd($rt['post']);
            $_SESSION['uid'] = hdev_data::encd($rt['id']);
            $_SESSION['shop'] = hdev_data::encd('+1');
          }
        }
        if (isset($_SESSION['cat_cat']) && !empty($_SESSION['cat_cat'])) {
          $ref = json_decode($_SESSION['cart_product']);
        }else{
          $ref = "";
        }
        $u = hdev_log::uid();
        if ($ref != "") {
          if (isset($ref[0]) && !empty($ref[0])) {
            foreach ($ref as $ik) {
              $rf = hdev_data::get_cart($ik,1);
              if (isset($rf['id']) && !empty($rf["id"])) {
                $p_id = $rf['p_id'];
                $p_qty = $rf['qty'];
                $rtk = new hdev_db();
                  $tab = $rtk->table("cart");
                  
                  $ip = hdev_log::ip();
                  if ($u!="" && !empty($u)) {
                    $po = $rtk->select("SELECT * FROM $tab WHERE ip_add = :uid and user_id = :user and p_id= :pid",[[":uid",$ip],[':user',$u],[':pid',"$p_id"]]);
                    if (isset($po[0]['id'])) {
                      $rtk->insert("DELETE FROM $tab WHERE user_id = :user AND ip_add = :ip AND p_id = :p",[[":user",$u],[':ip',$ip],[':p',$p_id]]);
                    }
                    $rtk->insert("UPDATE $tab SET user_id = :user WHERE ip_add = :ip AND user_id = '-1' AND p_id = :p",[[':user',$u],[':ip',$ip],[':p',$p_id]]);
                  }
              }
            }
          }
          if ($u != "" && !empty($u)) {
            $_SESSION['cart_product'] = "";
            $_SESSION['cat_cat'] = "";
            echo "ok";
          }
          
        }else{
          echo "ok";
        }
      }else{
        hdev_note::server_message("");
      }
    }
  }
  /**
   * 
   */
	/*  $rt = new hdev_db();
      $tab = $rt->table("category");
      $ref =$rt->select("SELECT * FROM $tab");
      $a = "";
      if (count($ref) > 0) {
        if ($v=="menu") {
          foreach ($ref as $tk) {
            $a .= ",".$tk["c_name"];
          }
          $a = substr($a, 1);
          return $a;
        }
      }else{
        return "";
      }
	$ty = new hdev_db('mysqli');
	$yr = $ty->select("SELECT user_id, f_name, s_name FROM u_auth WHERE user_id = :yh AND s_name = :s",[[":yh","1"],[":s","Roger"]]);
	foreach ($yr as $regds) {
		var_dump($regds);
		foreach ($regds as $er) {
			echo $er."<br>";
		}
	}*/
?>