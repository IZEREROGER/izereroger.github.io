<?php 
    $p_ref = hdev_session::get('transaction');
    $payment = hdev_data::order_menu($p_ref,['data2']);
    if (!isset($payment['o_id'])) {
      hdev_note::message('Sorry The order requested You Have requested with trx_ref :['.$p_ref.'] does not Exist! try again with different one');
      hdev_note::redirect(hdev_url::menu('h/order'));
      exit();
    }
    $o_id = $payment['o_id'];

 ?>
 <div class="content">
      <div class="container">
        <div class="card">
            <div class="card-header bg-secondary">
                <div align="center" style="text-align: center;">
                    <h3><i>Your Payment Status</i></h3>
                </div>
            </div>
            <div class="card-body" id="tx_hist_contents">
              <div align="right">
                <button type="button" class="btn btn-secondary" id="rev_o_print" onclick="app_printer('tx_hist_contents','rev_o_print');" ><span class="fa fa-print"></span> Print This Receipt </button>
              </div>
              <div class="row" class="hd_pt">
                <div class="col-sm-12" align="center">
                  <h3><?php echo APP_NAME." Receipt"; ?></h3>
                </div>
              </div>
                <div class="row" id="o_status">
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <table class="table">
                      <tr>
                        <th colspan="2" class="bg-secondary">
                          Personal information
                        </th>
                      </tr>
                      <tr>
                        <td>
                          Names
                        </td>
                        <td>
                          : <span id="o_name"></span>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          Phone number
                        </td>
                        <td>
                          : <span id="o_tel"></span>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          Email
                        </td>
                        <td>
                          : <span id="o_email"></span>
                        </td>
                      </tr>
                    </table>
                  </div>
                  <div class="col-sm-6 border-left">
                    <table class="table">
                      <tr>
                        <th colspan="2" class="bg-secondary">
                          Shipping and Payment info
                        </th>
                      </tr>
                      <tr>
                        <td>
                          Date
                        </td>
                        <td>
                          : <span id="o_date"></span>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          Address
                        </td>
                        <td>
                          : <span id="o_address" class="text-xs"></span>
                        </td>
                      </tr>
                      <tr>
                        <td>
                          Transaction Ref
                        </td>
                        <td>
                          : <span id="o_tx_ref"></span>
                        </td>
                      </tr>
                    </table>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-12">
                    <table class="table table-striped table-bordered">
                      <thead>
                        <tr>
                          <th class="bg-secondary">
                            Product
                          </th>
                          <th class="bg-secondary">
                            Product Details
                          </th>
                          <th class="bg-secondary">
                            Price
                          </th>
                          <th class="bg-secondary">
                            Quantity
                          </th>
                          <th class="bg-secondary">
                            Subtotal
                          </th>
                        </tr>
                      </thead>
                      <tbody id="o_products">
                        <tr>
                          <td>
                            
                          </td>
                          <td>
                            
                          </td>
                          <td>
                            
                          </td>
                          <td>
                            
                          </td>
                          <td>
                            
                          </td>
                        </tr>
                      </tbody>
                      <tfoot>
                        <tr>
                          <th colspan="4">
                            Sub Total
                          </th>
                          <th>
                            <span id="o_sub_total"></span>
                          </th>
                        </tr>
                        <tr>
                          <th colspan="4">
                            Shipping Price
                          </th>
                          <th>
                            <span id="o_shipping"></span>
                          </th>
                        </tr>
                        <tr>
                          <th colspan="4" class="bg-secondary">
                            Total
                          </th>
                          <th class="bg-secondary">
                            <span id="o_total"></span>
                          </th>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              </div>
        </div>
  </div>
</div>
<script type="text/javascript">
    document.addEventListener("DOMContentLoaded", function(event) {
        tx_hist('<?php echo $p_ref; ?>','<?php echo $o_id; ?>');
    });
</script>