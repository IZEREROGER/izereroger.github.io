<?php 
	if (empty($_SESSION["uid"]) || empty($_SESSION["uid"])) {
		if (isset($_COOKIE["uid"]) && isset($_COOKIE["funct"]) && isset($_COOKIE["user"]) && !empty($_COOKIE["uid"]) && !empty($_COOKIE["funct"]) && !empty($_COOKIE["user"])) {
			$_SESSION["uid"] = $_COOKIE["uid"];
			$_SESSION["funct"] = $_COOKIE["funct"];
			$_SESSION["user"] = $_COOKIE["user"];
		}
	}
 ?>