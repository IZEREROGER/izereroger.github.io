<?php 
	$p_ref = hdev_session::get('transaction');
	$payment = hdev_data::order_menu($p_ref,['data2']);
	$paypal = new PaypalExpress; 
    if (!isset($payment['o_id'])) {
      hdev_note::message('Sorry The order You Have requested to with trx_ref :['.$p_ref.'] does not Exist! try again with different one or re start the order');
      hdev_note::redirect(hdev_url::menu('h/order'));
      exit();
    }
	$price = $payment['total_price'];

 ?>
 <div class="content">
      <div class="container">
      	<div class="card">
            <div class="card-header bg-secondary">
             	<div align="center" style="text-align: center;">
             		<h3><i>Payment Info</i></h3>
             	</div>
            </div>
            <!-- /.card-header -->
            <div class="card-body table-responsive p-0" style="height: 300px;">
            	<?php //print_r($payment); ?>
            	<table class="table border-bottom">
            		<tr>
            			<td>
            				Client name : 
            			</td>
            			<td>
            				<?php echo $payment['name']; ?>
            			</td>
            		</tr>
            		<tr>
            			<td>
            				Total amount to pay : 
            			</td>
            			<td>
            				<?php echo $price.APP_CURRENCY; ?>
            			</td>
            		</tr>
            		<tr>
            			<td align="center" colspan="2">
						    <!-- Checkout button -->
						    <div id="paypal-button" class="btn btn-block"></div>
            			</td>
            		</tr>

            	</table>
            </div>
        </div>
  </div>
</div>


<script src="https://www.paypalobjects.com/api/checkout.js"></script>
<!--
JavaScript code to render PayPal checkout button and execute payment
-->
<script>
paypal.Button.render({
    // Configure environment
    env: '<?php echo $paypal->paypalEnv; ?>',
    client: {
        sandbox: '<?php echo $paypal->paypalClientID; ?>',
        production: '<?php echo $paypal->paypalClientID; ?>'
    },
    // Customize button (optional)
    locale: 'en_US',
    style: {
        size: 'small',
        color: 'gold',
        shape: 'pill',
        label:'pay'
    },
    // Set up a payment
    payment: function (data, actions) {
        return actions.payment.create({
            transactions: [{
                amount: {
                    total: '<?php echo $price; ?>',
                    currency: '<?php echo constant('currency'); ?>'
                }
            }]
      });
    },
    // Execute the payment
    onAuthorize: function (data, actions) {
        return actions.payment.execute()
        .then(function () {
            // Show a confirmation message to the buyer
            //window.alert('Thank you for your purchase!');
            
            // Redirect to the payment process page
            window.location = "<?php echo hdev_url::menu('pay/auth'); ?>"+"?paymentID="+data.paymentID+"&token="+data.paymentToken+"&payerID="+data.payerID+"&pid=<?php echo $p_ref; ?>";
        });
    }
}, '#paypal-button');
</script>
