<?php 
	if ($_GET) {
		if (isset($_GET['ref'])) {
			if (!hdev_log::loged() || !hdev_log::super_admin()) {
				hdev_note::message('you mus login first!');
				hdev_note::redirect(hdev_url::menu(''));exit();
			}
			switch ($_GET['ref'] && isset($_GET['hash']) ) {
				case 'slide':
					if (isset($_GET['id']) && isset($_GET['hash']) && md5($_GET['id']) == $_GET['hash']) {
						$data = new hdev_db;
						$table = $data->table("post");
						$id = $_GET['id'];
						$sql = $data->insert("DELETE FROM $table WHERE p_id=:p_id",[[':p_id',$id]]);
						if ($sql == "ok") {
							hdev_note::message($_GET['ref'].' deleted');
							hdev_note::redirect(hdev_url::menu('slide/view'));
						}else {
							hdev_note::message('something went wrong');
							hdev_note::redirect(hdev_url::menu('slide/view'));
						}
					}else{

							hdev_note::message('try again later');
							hdev_note::redirect(hdev_url::menu('slide/view'));
					}
				break;
				
				default:
					echo "error occured please try again";
					hdev_note::message('error occured please try again later');
					hdev_note::redirect(hdev_url::menu('slide/view'));
					break;
			}
			exit();
		}
	}		
	if ($_POST) {
		if (!empty($_POST['ref'])) {
  		switch ($_POST['ref']) {
				case 'slide':
				if (isset($_POST['p_title']) && !empty($_POST['p_title']) && isset($_POST['p_desc']) && !empty($_POST['p_desc']) && $_FILES && is_array($_FILES)) {
					$p_title = $_POST['p_title'];
					$p_desc = $_POST['p_desc'];
					$p_type = $_POST['ref'];
					$rt = new hdev_db();
      				$tab = $rt->table("post"); 

					$up_files_array = $_FILES['p_pic'];
      				$countfiles = 1;
					$files_array = array();
						if (file_exists($up_files_array["tmp_name"])) {
							$file_type = $up_files_array["type"]; //returns the mimetype
							$allowed = array("image/jpeg", "image/gif", "image/png");
							if(!in_array($file_type, $allowed)) {
							}else{
								$ckup="";
								// Check file size
								if ($up_files_array["size"] > 50000000) {
								    $ckup = 1;
								}

								$fileData = pathinfo(basename($up_files_array["name"]));
								$fileName = "post"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
								$regpath = __DIR__;
								$target_path = "./dist/img/upload/".$fileName;
								while(file_exists($target_path))
								{
								    $fileName = "post"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
									$regpath = __DIR__;
									$target_path = "./dist/img/upload/".$fileName;
								}
		 						if ($ckup == "") {
									if (move_uploaded_file($up_files_array["tmp_name"], $target_path))
									{
										array_push($files_array, $fileName);
									}
								}
							}
						}
					$reft = "";
					$reft = $files_array[0];

					if (strlen($reft) > 0) {
							$p_pic = $reft;

		      				$ck = $rt->insert("INSERT INTO `$tab` (`p_id`, `p_title`, `p_pic`, `p_desc`, `p_type`, `p_date`) VALUES (NULL, :p_title, :p_pic, :p_desc, :p_type, current_timestamp())",[[':p_title',$p_title],[':p_pic',$p_pic],[':p_desc',$p_desc],[':p_type',$p_type]]);
		      				if ($ck == "ok") {
		      					hdev_note::message("New ".$p_type." registered");
		      					hdev_note::redirect(hdev_url::menu('slide/view'));
		      					//echo "new service registered";
		      				}else{
		      					echo "error occured try again";
		      				}
	      				}else{
	      					echo "something went wrong try again later";
	      				}
					}else{
						echo "fill all fields";
					}
  			break;
  			case 'cat_v':
  				$menumask = array(); 
				$menumain = array();
				if (!empty(hdev_data::get_cat())) {
				  foreach (hdev_data::get_cat() as $cat) {
				    array_push($menumask, $cat["c_name"]);
				  }
				}
				if (count($menumask) > 0) {
				  foreach (hdev_data::get_cat() as $cat) {
				    $menumain[$cat["c_name"]]=hdev_data::get_cat_products($cat['c_id']);
				  }
				} 
				echo '<li class="nav-header bg-navy">Categories</li>';
				for ($i=0; $i < count($menumask); $i++) { 
	                $mmenu = $menumask;
	                hdevmenu::mainmenu($menumain[$mmenu[$i]]['trees'],$menumain[$mmenu[$i]]['name'],$menumain[$mmenu[$i]]['link'],$menumain[$mmenu[$i]]['icon']);
	              }

	            $menumask = array(); 
				$menumain = array();
				if (!empty(hdev_data::get_brand())) {
				  foreach (hdev_data::get_brand() as $cat) {
				    array_push($menumask, $cat["c_name"]);
				  }
				}
				if (count($menumask) > 0) {
				  foreach (hdev_data::get_brand() as $cat) {
				    $menumain[$cat["c_name"]]=hdev_data::get_brand_products($cat['c_id']);
				  }
				} 
				echo '<li class="nav-header bg-navy">Brands</li>';
				for ($i=0; $i < count($menumask); $i++) { 
	                $mmenu = $menumask;
	                hdevmenu::mainmenu($menumain[$mmenu[$i]]['trees'],$menumain[$mmenu[$i]]['name'],$menumain[$mmenu[$i]]['link'],$menumain[$mmenu[$i]]['icon']);
	              }
  			break; 

			case 'shop_payment':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['l_id']) && !empty($_POST['p_amount'])) {
					//$status = (hdev_log::fid() == "guest") ? "2" : "1" ;
					$l_id = $_POST['l_id'];
					$p_amount = $_POST['p_amount'];
					$account = hdev_data::shop_account($l_id);
					if ($p_amount > $account) {
						exit("Sorry you are trying to pay shop amount greater than its current account balance");
					}
					$rt = new hdev_db();
      				$tab = $rt->table("payouts"); 
      				$user = hdev_log::uid();

      				$ck = $rt->insert("INSERT INTO `$tab` (`lp_id`, `lp_amount`, `a_id`, `l_id`, `lp_date`, `lp_status`) VALUES (NULL, :amount, :a_id, :l_id, current_timestamp(), '1')",[[':l_id',$l_id],[':a_id',$user],[':amount',$p_amount]]);

      				if ($ck == "ok") {
      					$csrf->up_tk();
      						$account = hdev_data::shop_account($l_id);
      						$dtt = hdev_data::groups($l_id,['data']);
      						hdev_note::live_sms($dtt['tell'],"Dear, ".$dtt['g_name'].'shop on '.date('d/m/Y H:i:s').' you have withdrawn '.$p_amount.'Frw From your '.APP_NAME.' Shop Account. your new balance is :'.$account.' Frw.');

      						hdev_note::message("Shop payment Completed Well");

	      					if (!empty($_POST['from'])) {
								hdev_note::redirect(hdev_url::activate($_POST["from"]));
							}else{
								hdev_note::redirect(hdev_url::menu(''));
							}
      				}else{
      					echo "something went wrong try again later";
      				}
				}else{
					echo "all fields are required";
				}
			break;	
			case 'req_ext_shop':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest($_POST['hash']);
				$resp['name'] = "";
				$resp['tel'] = "";
				$resp['email'] =  "";

				if (!empty($_POST['ref_ld'])) {
					$ld = $_POST['ref_ld'];
					if (isset(hdev_data::groups($ld,["data"])["g_id"]) && is_numeric(hdev_data::groups($ld,["data"])["g_id"])) {
						$reff = hdev_data::groups($ld,["data"]);
						$resp['name'] = $reff['g_name'];
						$resp['tel'] = $reff['tell'];
						$resp['email'] =  $reff['email'];
					}
				}
				echo json_encode($resp);
			break;			
			case 'req_shop_account_balance':
				//var_dump($_POST);
				//exit();
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest($_POST['hash']);
				$resp['balance'] = 0;

				if (!empty($_POST['ref_ld'])) {
					$ld = $_POST['ref_ld'];
					$resp['balance'] = hdev_data::shop_account($ld);
				}
				echo json_encode($resp);
			break;	
  			case 'location_select':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest($_POST['cover']);
				if (isset($_POST['type']) && !empty($_POST['type'])) {
      				switch ($_POST['type']) {
      					case 'district':
      						$province = (isset($_POST['prov'])) ? $_POST['prov'] : "" ;
      						echo hdev_data::locations("district",$province);
      					break;
      					case 'sector':
      						$province = (isset($_POST['prov'])) ? $_POST['prov'] : "" ;
      						$district = (isset($_POST['dist'])) ? $_POST['dist'] : "" ;
      						echo hdev_data::locations("sector",$province,$district);
      					break;
						case 'cell':
      						$province = (isset($_POST['prov'])) ? $_POST['prov'] : "" ;
      						$district = (isset($_POST['dist'])) ? $_POST['dist'] : "" ;
							$sector = (isset($_POST['sect'])) ? $_POST['sect'] : "" ;
      						echo hdev_data::locations("cell",$province,$district,$sector);
      					break;
      					case 'village':
      						$province = (isset($_POST['prov'])) ? $_POST['prov'] : "" ;
      						$district = (isset($_POST['dist'])) ? $_POST['dist'] : "" ;
							$sector = (isset($_POST['sect'])) ? $_POST['sect'] : "" ;  
      						$cell = (isset($_POST['cell'])) ? $_POST['cell'] : "" ;
      						echo hdev_data::locations("village",$province,$district,$sector,$cell);
      					break;
      					default:
      						echo "<option>Try again!</option>";
      					break;
      				}
      				
				}else{
					echo "all fields are required";
				}
			break;
			case 'shipping_price':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest($_POST['cover']);
    			$tot = (is_numeric(trim($_POST['sub_tot']))) ? trim($_POST['sub_tot']) : 0 ;
    			$shipping_price=0;
    			if (isset($_POST['loc'])) {
    				$shipping_price = hdev_data::locations('price',$_POST['loc']);
    			}
				$order_total_price=$tot+$shipping_price;

    			$retur = array("shipping_price"=>$shipping_price,"tot"=>$order_total_price);
    			echo json_encode($retur);
    		break;
			case 'shipping_reg':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
    			$us = $_POST;
    			$r = 0;
    			$rt = new hdev_db();
      			$tab = $rt->table("location");
    			$from = (!is_null(trim($_POST['from'])) && !empty(trim($_POST['from']))) ? urldecode(trim($_POST['from'])) : hdev_url::menu('');
    			foreach ($us as $key => $data) {
    				$check = substr($key, 0,4);
    				if ($check == "1_1_" && is_numeric($data) && $data >= 0 && hdev_log::admin()) {
    					$district = substr($key, 4);
      					$ck = $rt->insert("UPDATE `locations` SET `ship_price` = :price WHERE `loc_district` = :district",[[':district',$district],[':price',$data]]);
      					$r = 1;
    				}
    			}
    			if ($r == 1) {
      				$csrf->up_tk();
      				hdev_note::message('Shipping Prices Updated');
      				hdev_note::redirect($from);
      			}else{
      				echo "something went wrong try again later";
      			}
    			
    		break;    		
    		case 'transaction_history':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest($_POST['cover']);
    			$shipping_price=0;
    			$rett = array();
    			$rett['o_name'] = "";
    			$rett['o_status'] = "";
    			$rett['o_tel'] = "";
    			$rett['o_email'] = "";
    			$rett['o_date'] = "";
    			$rett['o_address'] = "";
    			$rett['o_tx_ref'] = "";
    			$rett['o_tx_id'] = "";
    			$rett['o_sub_total'] = "";
    			$rett['o_shipping'] = "";
    			$rett['o_total'] = "";
    			$logo = "";
    			$rett['o_products'] = "<tr><td colspan='5'>No Products Found!</td></tr>";
    			if (isset($_POST['tx_ref']) && isset($_POST['oo_id'])) {
    				$ref = $_POST['tx_ref'];
    				$py = hdev_data::pay_method($ref);
    				if ($py == "paypal") {
    					$logo = '<img src="'.hdev_url::menu('dist/img/paypal.png').'" style="height: 50px;width: 150px;">';
    				}elseif ($py == "momo") {
    					$logo = '<img src="'.hdev_url::menu('dist/img/momo.jpg').'" style="height: 50px;width: 150px;">';
    				}
    				$o_id = $_POST['oo_id'];
    				$refer = hdev_data::get_order(4,$ref);
    				$order_menu = hdev_data::order_menu($o_id,['data']);
    				$rett['o_name'] = $order_menu['name'];
    				$ico = (trim($order_menu['payment_status']) == "approved") ? '<span class="text-xl">'.ucfirst($order_menu['payment_status']).'</span><i class="fa fa-check-circle text-success text-xl"></i>' : '<span class="text-xl">Pending</span><i class="fa fa-exclamation-circle text-warning text-xl"></i>';
    				$ico_2 = (trim($order_menu['payment_status']) == "approved") ? '<div class="bg-secondary p-3"><span class="text-md"><div class="col-sm-6" align="center">Transaction Id : </div><div class="col-sm-6" align="center">'.$order_menu['tx_id'].'</div></span><i class="fa fa-check-circle text-success text-xl"></i></div>' : '<div class="bg-info"><span class="text-md">Waiting For Payment</span><i class="fa fa-exclamation-circle text-warning text-md"></i></div>';
    				$rett['o_status'] = '
		                    <div class="col-sm-12" align="center">
		                        <table class="table">
		                            <tr>
		                                <th class="bg-secondary" align="center">
		                                    Payment Status 
		                                </td>
		                            </tr>
		                            <tr>
		                                <td align="center">
		                                    '.$logo." ".$ico.'
		                                </td>
		                            </tr>
		                            <tr>
		                                <td align="center">
		                                    '.$ico_2.'
		                                </td>
		                            </tr>
		                        </table>
		                    </div>
    				';
    				$rett['o_tel'] = $order_menu['tel'];
    				$rett['o_email'] = $order_menu['email'];
    				$rett['o_date'] = $order_menu['reg_date'];
    				$rett['o_address'] = hdev_data::locations('mini',$order_menu['address']);;
    				$rett['o_tx_ref'] = $order_menu['tx_ref'];
    				$rett['o_tx_id'] = $order_menu['tx_id'];
    				$rett['o_sub_total'] = $order_menu['price'].APP_CURRENCY;
    				$rett['o_shipping'] = $order_menu['shipping_price'].APP_CURRENCY;
    				$rett['o_total'] = $order_menu['total_price'].APP_CURRENCY;
    				$row = "";
    				foreach ($refer as $all_p) {
    					$prod = hdev_data::get_products($all_p['p_id']);
    					$row .= '
    					<tr>
    					  <td>
		                    '.$all_p['b_size'].'
		                  </td>
		                  <td>
		                    <a href="'.hdev_url::menu('book/'.$all_p['p_id']).'">'.$prod['name'].'</a>
		                  </td>
		                  <td>
		                    <a class="btn btn-sm btn-success" href="'.hdev_url::menu('book/'.$all_p['p_id']).'">Product Details</a>
		                  </td>
		                  <td>
		                    '.$all_p['price'].APP_CURRENCY.'
		                  </td>
		                  <td>
		                    '.$all_p['qty'].'
		                  </td>
		                  <td>
		                    '.$all_p['price']*$all_p['qty'].APP_CURRENCY.'
		                  </td>
		                </tr>';
    				}
    				if ($row == "") {
    					$row = "<tr><td colspan='5'>No Products Found!</td></tr>";
    				}else{

    				}
    				$rett['o_products'] = $row;
    			}
    			echo json_encode($rett);
    		break;
  			case 'count_cart':
  			  	$refer = hdev_data::get_cart(2);
  				$ret = array();
  				if (is_array($refer)) {
  					foreach ($refer as $ct) {
  						if (isset($ct['p_id'])) {
  							array_push($ret, $ct['p_id']);
  						}
  					}
  				}
  				$_SESSION['cart_product'] = "";
			    $json_e = json_encode($ret);
			    $_SESSION['cart_product'] = $json_e;
			    $_SESSION['cat_cat'] = "o";
  				echo hdev_data::get_cart(1);
  			break;
  			case 'order':
  				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
  				$rt = new hdev_db();
			    $tab = $rt->table("cart");
			    $tab2 = $rt->table("order");
			    $tab3 = $rt->table("order_parent");
			    $u = hdev_log::uid();
			    $ip = hdev_log::ip();
			    if (hdev_log::admin() || hdev_log::super_admin()) {
			    	hdev_note::message("admin is not allowed to make an order");
			    	exit();
			    }
			    if ($u!="" && !empty($u)) {
	  				$sql = $rt->select("SELECT p_id,b_size,qty FROM $tab WHERE user_id = :user",[[":user",$u]]);
	  				$tot_pp = 0;
	  				foreach ($sql as $prevp) {
	  					$qqty = (is_numeric($prevp['qty'])) ? $prevp['qty'] : 0 ;
	  					$pd = hdev_data::get_products($prevp['p_id']);
	  					$tot_pp += $pd['price']*$qqty;
	  				}
	  				//echo $tot_pp;exit();

	  				if (isset($_POST['pay']) && !empty($_POST['pay'])) {
	  					$pay_m = $_POST['pay'];
	  					if ($pay_m == 1 || $pay_m == 2) {

	  					}else{
	  						exit("selected payment method is invalid");
	  					}
	  				}else{
	  					exit("Select payment method first");
	  				}
	  				$tx_id = $pay_m.strtolower(hdev_data::order_hash(strtoupper(hdev_data::tx_id())));
	  				if (!empty($_POST['name']) && !empty($_POST['nid']) && !empty($_POST['tell']) && !empty($_POST['email']) && !empty($_POST['s_location'])) {
	  					$name = $_POST['name'];
	  					$nid = $_POST['nid'];
	  					//var_dump(hdev_data::id_valid($nid));
	  					if (hdev_data::id_valid($nid)) {
	  						echo hdev_data::id_valid($nid);
	  						exit();
	  					}

	  					$tell = $_POST['tell'];
	  					if (hdev_data::phone_valid($tell)) {
	  						echo hdev_data::phone_valid($tell);
	  						exit();
	  					}
	  					//exit();
	  					$email = $_POST['email'];
	  					$s_location = $_POST['s_location'];
	  					$shipping_price = hdev_data::locations('price',$s_location);
	  					$ttotal_price = $tot_pp+$shipping_price;
	  					$o_dt = $rt->insert("INSERT INTO `$tab3` (`o_id`, `user_id`, `tx_id`, `tx_ref`, `name`, `n_id`, `tel`, `email`, `address`, `price`, `shipping_price`, `total_price`, `payment_status`, `reg_date`) VALUES (NULL, :user,NULL,:hash, :name, :nid, :tell, :email, :address, :price, :ship, :tot_price, 'w', current_timestamp())",[[':user',$u],[':hash',$tx_id],[':name',$name],[':nid',$nid],[':tell',$tell],[':email',$email],[':address',$s_location],[':price',$tot_pp],[':ship',$shipping_price],[':tot_price',$ttotal_price]]);
	  					//echo $o_dt;
	  				}
	  				/*exit;

	  				var_export($_POST);
	  				echo "working";
	  				exit;*/
	  				if (isset($sql[0]['p_id']) && !empty($sql[0]['p_id']) && $o_dt == "ok") {
	  					$product_id = array();
	  					$qty = array();
	  					$size = array();
	  					foreach ($sql as $row) {
	  						array_push($product_id, $row["p_id"]);
	  						array_push($qty, $row["qty"]);
	  						array_push($size, $row["b_size"]);
	  						//$product_id[] = $row["p_id"]; 
							//$qty[] = $row["qty"];
	  					}
	  					if (is_array($product_id) && count($product_id) > 0) {
	  						for ($i=0; $i < count($product_id); $i++) { 
	  							$ck = hdev_data::get_products($product_id[$i]);
	  							if (isset($ck['d']) && !empty($ck['d'])) {
	  								//if (hdev_data::order_hash_ok($tx_id)) {
	  									$vote = hdev_data::product_order_update($product_id[$i]);
	  									$sql = $rt->insert("INSERT INTO $tab2 (user_id,p_id,b_size,price,qty,trx_id,p_status) VALUES (:user,:p,:b_size,:price,:q,:hash,:status)",[[":user",$u],[":p",$product_id[$i]],[":price",$ck['price']],[":q",$qty[$i]],[':b_size',$size],[":hash",$tx_id],[':status',"p"]]);
	  								//}
	  							}
	  						}
	  					}
	  				}
					$sql = $rt->insert("DELETE FROM $tab WHERE user_id = :user ",[[":user",$u]]);
					$csrf->up_tk();
					echo hdev_note::message_2("Order initiated...!<br>check your orders in <i class='bg-primary'> Settings >> Orders </i><br>Redirecting to payment page!",1);
					echo hdev_note::redirect(hdev_url::menu("payment/".$tx_id));
				}else{
					echo hdev_note::message_2("ACCESS DENIED...!",3);
				} 
  			break;
  			case 'removeItemFromCart':
  				$rt = new hdev_db();
			    $tab = $rt->table("cart");
			    $u = hdev_log::uid();
			    $ip = hdev_log::ip();
			    if (hdev_log::admin()) {
			    	hdev_note::message("admin not is not allowed to make order activities! only users can do this");
			    }
  				//Remove Item From cart
				if (isset($_POST["rid"]) && !empty($_POST['rid'])) {
					$remove_id = $_POST["rid"];

					$bk = hdev_data::get_products($remove_id);
  					if (!isset($bk["name"]) || !isset($bk['price'])) {
  						echo hdev_note::message_2("Product not on cart..!",2);
  						exit();
  					}
					if (isset($u) && !empty($u)) {
						$sql =  $rt->insert("DELETE FROM $tab WHERE p_id = :p_id AND user_id = :user",[[':p_id',$remove_id],[':user',$u]]);
					}else{
						$sql =  $rt->insert("DELETE FROM $tab WHERE p_id = :p_id AND ip_add = :user",[[':p_id',$remove_id],[':user',$ip]]);
					}
					if ($sql == "ok") {
						echo hdev_note::message_2("Product removed..!",1);
					}else{
						echo hdev_note::message_2("failed to be removed try using onother browser..!",3);
					}
				}else{
					echo hdev_note::message_2("Product not selected..!",3);
				}
  			break;
  			case 'updateCartItem':
  				$rt = new hdev_db();
			    $tab = $rt->table("cart");
			    $u = hdev_log::uid();
			    $ip = hdev_log::ip();
  				//Remove Item From cart
				if (isset($_POST["update_id"]) && !empty($_POST['update_id'])) {
					$update_id = $_POST["update_id"];
					$qty = $_POST["qty"];

					$bk = hdev_data::get_products($update_id);
  					if (!isset($bk["name"]) || !isset($bk['price'])) {
  						echo hdev_note::message_2("Product not on cart..!",2);
  						exit();
  					}
					if (isset($u) && !empty($u)) {
						$sql =  $rt->insert("UPDATE $tab SET qty=:qty WHERE p_id = :update_id AND user_id = :user" ,[[':qty',$qty],[':update_id',$update_id],[':user',$u]]);
					}else{
						$sql =  $rt->insert("UPDATE $tab SET qty=:qty WHERE p_id = :update_id AND ip_add = :user" ,[[':qty',$qty],[':update_id',$update_id],[':user',$ip]]);
					}
					if ($sql == "ok") {
						echo hdev_note::message_2("Product Updated..!",1);
					}else{
						echo hdev_note::message_2("failed to be updated try using onother browser..!",3);
					}
				}else{
					echo hdev_note::message_2("Product not selected..!",3);
				}
  			break;
  			case 'check_out':
  				$refer = hdev_data::get_cart(2);
  				$ret = "";
  				$o = 0;
  				$pric = 0;
  				$top = "<tr><td colspan='8'><i style='width: 100%;text-align: center;'><h1 class='text-success'>---0---<h1></i></td></tr>";
  				if (is_array($refer)) {
  					foreach ($refer as $ct) {
  						if (isset($ct['p_id'])) {
  							$bk = hdev_data::get_products($ct['p_id']);
  							if (isset($bk["name"]) && isset($bk['price'])) {
  								$o = 1;
  								$head = '<tr><td>#<input type="hidden" name="f_pid[]" value="'.$ct['p_id'].'"/></td><td>'.$ct['b_size'].'</td><td>';
  								$pic = hdev_data::product_images($bk['pic'])[0];
  								$name =  $bk['name'];
  								if (empty($bk['pic']) || $pic=="" || $bk['pic'] == "NULL" || $bk['pic'] == "none") {
  									$pict = "<p style='text-align: center;'><i class='fa fa-box'></i></p></td><td>";
  								}else{
  									$pict = '<img src="'.$pic.'" alt="'.$name.'" class="img-size-50 img-square mr-3"></td><td>';
  								}
  								$names = $name.'</td><td>';
  								$pricet = $bk['price']*$ct['qty'];
  								$price = $bk['price'];
  								$pric += $price;
  								$prices = '<input type="text" class="form-control price" value="'.$price.'" readonly="readonly">'.""."</td><td>";
  								$pricest = '<input type="number" class="form-control qty" value="'.$ct["qty"].'">'."</td><td>";
								$pricestt = '<input type="text" class="form-control total" value="'.$pricet.'" readonly="readonly">'."</td><td>";
								$act = '
									<div class="btn-group">
										<a href="#" update_id="'.$ct['p_id'].'" class="btn btn-primary update"><span class="fa fa-check-circle"></span> Save</a>
										<a href="#" remove_id="'.$ct['p_id'].'" class="btn btn-danger remove"><span class="fa fa-times-circle"></span> </a>
										<input type="hidden" name="f_pid[]" value="'.$ct['id'].'">
									</div>
								'."</td></tr>";
  								$ret .= $head.$pict.$names.$prices.$pricest.$pricestt.$act."";
  							}
  						}
  					}
  				}
  				$ret .= '<tr class="bg-secondary"><th colspan="6"><i class="float-right"><b>Total</b></i></th><th colspan="2"><b class="net_total">'.$pric."</b>".APP_CURRENCY."</th></tr>";
  				if ($o == 0) {
  					$ret= $top;
  				}
  				echo $ret;
  			break;
  			case 'order_out':
  				$refer = hdev_data::get_order(2);
  				$ret = "";
  				$o = 0;
  				$pric = 0;
  				$top = "<tr><td colspan='7'><i style='width: 100%;text-align: center;'><h1 class='text-success'>---0---<h1></i></td></tr>";
  				if (is_array($refer)) {
  					foreach ($refer as $ct) {
  						if (isset($ct['p_id'])) {
  							$bk = hdev_data::get_products($ct['p_id']);
  							if (isset($bk["name"]) && isset($bk['price'])) {
  								$o = 1;
  								$tm = hdev_data::timer($ct['reg_date'],"date")." - ".hdev_data::timer($ct['reg_date'],"time"); 

  								$head = '<tr><td>'.$tm.'</td><td>';
  								$pic = hdev_data::product_images($bk['pic'])[0];
  								$name =  $bk['name'];
  								if (empty($bk['pic']) || $pic=="" || $bk['pic'] == "NULL" || $bk['pic'] == "none") {
  									$pict = "<p style='text-align: center;'><i class='fa fa-box'></i></p></td><td>";
  								}else{
  									$pict = '<img src="'.$pic.'" alt="'.$name.'" class="img-size-50 img-square mr-3"></td><td>';
  								}
  								$names = $name.'</td><td>';
  								$pricet = $bk['price']*$ct['qty'];
  								$price = $bk['price'];
  								$pric += $price;
  								$prices = ''.$price.APP_CURRENCY.''.""."</td><td>";
  								$pricest = ''.$ct["qty"].''."</td><td>";
								$pricestt = ''.$pricet.APP_CURRENCY.''."</td><td>";
								$act = '
									<div class="btn-group">
										'.hdev_data::order_status($ct['p_status']).'
									</div>
								'."</td></tr>";
  								$ret .= $head.$pict.$names.$prices.$pricest.$pricestt.$act."";
  							}
  						}
  					}
  				}
  				$ret .= "";
  				if ($o == 0) {
  					$ret= $top;
  				}
  				echo $ret;
  			break;
  			case 'getCartItem':
  				$refer = hdev_data::get_cart(2);
  				$ret = "";
  				$o = 0;
  				$pric = 0;
  				$top = "<tr><td colspan='5'><i style='width: 100%;text-align: center;'><h1 class='text-success'>---0---<h1></i></td></tr>";
  				if (is_array($refer)) {
  					foreach ($refer as $ct) {
  						if (isset($ct['p_id'])) {
  							$bk = hdev_data::get_products($ct['p_id']);
  							if (isset($bk["name"]) && isset($bk['price'])) {
  								$o = 1;
  								$size = $ct['b_size'];
  								$head = '<tr><td>'.$size.'</td><td>'.$ct['qty'].'</td><td>';
  								$pic = hdev_data::product_images($bk['pic'])[0];
  								$name =  $bk['name'];
  								if (empty($bk['pic']) || $pic=="" || $bk['pic'] == "NULL" || $bk['pic'] == "none") {
  									$pict = "<p style='text-align: center;'><i class='fa fa-box'></i></p></td><td>";
  								}else{
  									$pict = '<img src="'.$pic.'" alt="'.$name.'" class="img-size-50 img-square mr-3"></td><td>';
  								}
  								$names = $name.'</td><td>';
  								$price = $bk['price']*$ct['qty'];
  								$pric += $price;
  								$prices = $price.APP_CURRENCY."</td></tr>";
  								$ret .= $head.$pict.$names.$prices."";
  							}
  						}
  					}
  				}
  				$ret .= '<tr class="bg-secondary"><th colspan="4"><i class="float-right"><b>Total</b></i></th><th><b>'.$pric.APP_CURRENCY."</b></th></tr>";
  				if ($o == 0) {
  					$ret= $top;
  				}
  				echo $ret;
  			break;
  			case 'product view':
  				 
  			break;
  			case 'addToCart':
  				hdev_data::get_cart();////will update cart hash and remove expired cart items
	  			$rt = new hdev_db();
			    $tab = $rt->table("cart");
			    $u = hdev_log::uid();
			    $ip = hdev_log::ip();
			    if (hdev_log::admin() || hdev_log::super_admin()) {
			    	echo hdev_note::message_2("Admin is not allowed to add something to cart! only users can perform this action!",2);
			    	exit();
			    }
		
				$p_id = $_POST["proId"];
				$sizes = $_POST['sizes'];
				if (empty($sizes)) {
					echo hdev_note::message_2("You must select size of product",2);
			    	exit();
				}

				$bk = hdev_data::get_products($p_id);
  				if (!isset($bk["name"]) && !isset($p_id)) {
  					echo hdev_note::message_2("Product Not exist in store",3);
  					exit();
  				}
				if ($u!="" && !empty($u)) {
					$sql = $rt->select("SELECT id FROM $tab WHERE p_id = :p_id AND user_id = :user",[[":p_id",$p_id],[":user",$u]]);
					if (isset($sql[0]['id']) && !empty($sql[0]['id'])) {
						echo hdev_note::message_2("Product is already added into the cart Continue Shopping..!",2);
					}else{
						$tab2 = $rt->table('products');
						$msql = $rt->select("SELECT b.g_id FROM $tab a,$tab2 b WHERE a.p_id = b.b_id AND a.user_id = :user",[[":user",$u]]);
						foreach ($msql as $og_dta) {
							$m_prod = "";
							$check_me = "";
							$check_me = $og_dta['g_id'];
							$m_prod = hdev_data::get_products($p_id)['g_id'];
							if ($m_prod != $check_me) {
								echo hdev_note::message_2("Sorry you are not allowed to shop in multiple shops at once please first make an order in [".hdev_data::groups($check_me,['data'])['g_name']." shop] or remove its items from cart and after continue shopping in other shops !",2);
								exit();
							}

						}
						$sql = $rt->insert("INSERT INTO $tab (`p_id`,`b_size`, `ip_add`, `user_id`, `qty`, `tx_track`) VALUES (:p_id, :b_size, :ip,:user,'1',:hash)",[[':b_size',$sizes],[':p_id',$p_id],['ip',$ip],[':user',$u],[':hash',$_SESSION['cart_hash']]]);
						if ($sql == "ok") {
							echo hdev_note::message_2("Your product is Added Successfully..!",1);
						}
					}
				}else{
					$sql = $rt->select("SELECT id FROM $tab WHERE ip_add = :uid AND p_id = :p_id AND user_id = :user",[[":uid",$ip],[":p_id",$p_id],[':user','-1']]);
					if (isset($sql[0]['id']) && !empty($sql[0]['id'])) {
						echo hdev_note::message_2("Product is already added into the cart Continue Shopping..!",2);
					}else{

						$tab2 = $rt->table('products');
						$msql = $rt->select("SELECT b.g_id FROM $tab a,$tab2 b WHERE a.ip_add = :uid AND  a.p_id = b.b_id AND a.user_id = :user",[[":uid",$ip],[":user",'-1']]);
						foreach ($msql as $og_dta) {
							$m_prod = "";
							$check_me = "";
							$check_me = $og_dta['g_id'];
							$m_prod = hdev_data::get_products($p_id)['g_id'];
							if ($m_prod != $check_me) {
								echo hdev_note::message_2("Sorry you are not allowed to shop in multiple shops at once please first make an order in [".hdev_data::groups($check_me,['data'])['g_name']." shop] or remove its items from cart and after continue shopping in other shops !",2);
								exit();
							}

						}
						$sql = $rt->insert("INSERT INTO $tab (`p_id`, `b_size`, `ip_add`, `user_id`, `qty`, `tx_track`) VALUES (:p_id, :b_size, :ip,'-1','1',:hash)",[[':p_id',$p_id],[':b_size',$sizes],['ip',$ip],[':hash',$_SESSION['cart_hash']]]);
						if ($sql == "ok") {
							echo hdev_note::message_2("Your product is Added Successfully..!",1);
						}
					}
				}
			break;
  			case 'login':
  				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
				if (!empty($_POST['usn']) && !empty($_POST['psw'])) {

					hdev_v::login($_POST["usn"],$_POST['psw']);
				}else{
					hdev_note::message(hdev_lang::on("validation","log_fair"));
	        		hdev_note::redirect(hdev_url::get_url_host()."/h/login");
				}

			break;

			case 'c_reg': 
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
  				$tkn = "no";
				if (!empty($_POST['cat_name']) && !empty($_POST['cat_desc'])) {
					$name = $_POST['cat_name'];
					$desc = $_POST['cat_desc'];
					$rand = hdev_data::single_id("cat");
					if ($rand != "no") {
						$dup = hdev_data::duplication_checker(["type"=>"cat","name"=>$name]);
						if ($dup!='yes') {
							hdev_data::create_category(["name"=>$name,"rand"=>$rand,"desc"=>$desc]);
						}else{
							echo "That category already exist!";
						}
					}else{
						echo "Try again!";
					}
				}else{
					echo hdev_lang::on("validation","all_fields");
					//hdev_note::redirect(hdev_url::activate($_POST["from"]));
				}
			break;
			case 'cat_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
    			if (!empty($_POST['cat_name']) && !empty($_POST['cat_desc']) && !empty($_POST['ed_ref'])) {
					$name = $_POST['cat_name'];
					$desc = $_POST['cat_desc'];
					$id = trim($_POST['ed_ref']);
					$ck = "";
					if (isset(hdev_data::get_cat($id,"info")["name"]) && !empty(isset(hdev_data::get_cat($id,"info")["name"]))) {
						$ck = hdev_data::get_cat($id,"info")["name"]; 
					}
					$rand = hdev_data::single_id("cat");
					if ($rand != "no") {
						if ($ck != $name) {
							$dup = hdev_data::duplication_checker(["type"=>"cat","name"=>$name]);
						}else{
							$dup = "no";
						}
						
						if ($dup!='yes') {
							if (isset($ck) && !empty($ck)) {
								$rt = new hdev_db();
	      						$tab = $rt->table("category");
	      						$update_cart2 = $rt->insert("UPDATE $tab SET c_name = :user WHERE c_id = :p",[[':user',$name],[':p',$id]]);
	      						$update_cart3 = $rt->insert("UPDATE $tab SET c_desc = :user WHERE c_id = :p",[[':user',$desc],[':p',$id]]);
	      						hdev_note::message("Completed !!!");
	      						if (!empty($_POST['from'])) {
									hdev_note::redirect(hdev_url::activate($_POST["from"]));
								}else{
									hdev_note::redirect(hdev_url::menu(''));
								}
								//hdev_data::create_category(["name"=>$name,"rand"=>$rand,"desc"=>$desc]);
							}else{
								echo "refresh page and try again";
							}
						}else{
							echo "That category name already exist!";
						}
					}else{
						echo "Try again!";
					}
				}else{
					echo hdev_lang::on("validation","all_fields");
					//hdev_note::redirect(hdev_url::activate($_POST["from"]));
				}
			break;
			case 'brand_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
    			if (!empty($_POST['cat_name']) && !empty($_POST['cat_desc']) && !empty($_POST['ed_ref'])) {
					$name = $_POST['cat_name'];
					$desc = $_POST['cat_desc'];
					$id = trim($_POST['ed_ref']);
					$ck = "";
					if (isset(hdev_data::get_brand($id,"info")["name"]) && !empty(isset(hdev_data::get_brand($id,"info")["name"]))) {
						$ck = hdev_data::get_brand($id,"info")["name"]; 
					}
					$rand = hdev_data::single_id("brand");
					if ($rand != "no") {
						if ($ck != $name) {
							$dup = hdev_data::duplication_checker(["type"=>"brand","name"=>$name]);
						}else{
							$dup = "no";
						}
						
						if ($dup!='yes') {
							if (isset($ck) && !empty($ck)) {
								$rt = new hdev_db();
	      						$tab = $rt->table("brand");
	      						$update_cart2 = $rt->insert("UPDATE $tab SET c_name = :user WHERE c_id = :p",[[':user',$name],[':p',$id]]);
	      						$update_cart3 = $rt->insert("UPDATE $tab SET c_desc = :user WHERE c_id = :p",[[':user',$desc],[':p',$id]]);
	      						hdev_note::message("Completed !!!");
	      						if (!empty($_POST['from'])) {
									hdev_note::redirect(hdev_url::activate($_POST["from"]));
								}else{
									hdev_note::redirect(hdev_url::menu(''));
								}
								//hdev_data::create_category(["name"=>$name,"rand"=>$rand,"desc"=>$desc]);
							}else{
								echo "refresh page and try again";
							}
						}else{
							echo "That brand name already exist!";
						}
					}else{
						echo "Try again!";
					}
				}else{
					echo hdev_lang::on("validation","all_fields");
					//hdev_note::redirect(hdev_url::activate($_POST["from"]));
				}
			break;
			case 'security_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
    			if (!empty($_POST['ed_ref']) && !empty($_POST['old_p']) && !empty($_POST['n_p']) && !empty($_POST['n_p2'])) {
    				$u = hdev_log::uid();
					$old_p = $_POST['old_p'];
					$n_p = $_POST['n_p'];
					$rn_p = $_POST['n_p2'];
					$id = trim($_POST['ed_ref']);
					if ($u!=$id) {
						echo "refresh the page and try again";
						exit();
					}
					if ($n_p != $rn_p) {
						echo "new passwords does not match";
						exit();
					}
					$rto = hdev_data::log_user($id,$old_p,'id');
					if (isset($rto['username']) && !empty($rto["username"]) || hdev_log::admin() || hdev_log::super_admin()) { 
						$ck = "";
						$rt = new hdev_db();
		      			$tab = $rt->table("user");
		      			$update_cart2 = $rt->insert("UPDATE $tab SET password = :user WHERE id = :p",[[':user',hdev_data::password_enc($n_p)],[':p',$id]]);
		      			if ($update_cart2=="ok") {
		      				hdev_note::message("Paasword changed!!!");

	      					if (!empty($_POST['from'])) {
								hdev_note::redirect(hdev_url::activate($_POST["from"]));
							}else{
								hdev_note::redirect(hdev_url::menu(''));
							}
		      			}else{
		      				echo "Something went wrong!";
		      			}
					}else{
						echo "the old password may be incorrect try again";
					}
				}else{
					echo hdev_lang::on("validation","all_fields");
					//hdev_note::redirect(hdev_url::activate($_POST["from"]));
				}
			break;
			case 'admin_security_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
    			if (!empty($_POST['ed_ref']) && !empty($_POST['n_p']) && !empty($_POST['n_p2'])) {
					$n_p = $_POST['n_p'];
					$rn_p = $_POST['n_p2'];
					$id = trim($_POST['ed_ref']);
					if ($n_p != $rn_p) {
						echo "new passwords does not match";
						exit();
					}
					$rto = hdev_data::log_user($id,"",'id2');
					if (isset($rto['username']) && !empty($rto["username"]) && hdev_log::admin() && isset($rto['post']) && $rto['post'] !='admin' && hdev_log::super_admin()) { 
						$ck = "";
						$rt = new hdev_db();
		      			$tab = $rt->table("user");
		      			$update_cart2 = $rt->insert("UPDATE $tab SET password = :user WHERE id = :p",[[':user',hdev_data::password_enc($n_p)],[':p',$id]]);
		      			if ($update_cart2=="ok") {
		      				hdev_note::message("Paasword changed!!!");

	      					if (!empty($_POST['from'])) {
								hdev_note::redirect(hdev_url::activate($_POST["from"]));
							}else{
								hdev_note::redirect(hdev_url::menu(''));
							}
		      			}else{
		      				echo "Something went wrong!";
		      			}
					}else{
						echo "Access denied may be you are trying to change admin password!";
					}
				}else{
					echo hdev_lang::on("validation","all_fields");
					//hdev_note::redirect(hdev_url::activate($_POST["from"]));
				}
			break;
			case 'b_reg': 
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
    			if (!hdev_log::admin()) {
							echo "not allowed to do this action !!!!";
							exit();
						}
  				$tkn = "no";
				if (!empty($_POST['cat_name']) && !empty($_POST['cat_desc'])) {
					$name = $_POST['cat_name'];
					$desc = $_POST['cat_desc'];
					$rand = hdev_data::single_id("brand");
					if ($rand != "no") {
						$dup = hdev_data::duplication_checker(["type"=>"brand","name"=>$name]);
						if ($dup!='yes') {
							hdev_data::create_brand(["name"=>$name,"rand"=>$rand,"desc"=>$desc]);
						}else{
							echo "That Brand already exist!";
						}
					}else{
						echo "Try again!";
					}
				}else{
					echo hdev_lang::on("validation","all_fields");
					//hdev_note::redirect(hdev_url::activate($_POST["from"]));
				}
			break;
			case 'reg_shop':

				//var_export($_FILES);
				//exit('you are done');
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
    			/*if (!hdev_log::admin()) {
							echo "not allowed to do this action !!!!";
							exit();
						}*/

  				$tkn = "no";
				if (!empty($_POST['name']) && !empty($_POST['tell']) && !empty($_POST['location']) && !empty($_POST['username'])  && !empty($_POST['desc']) && !empty($_POST['email']) && !empty($_POST['psw']) && $_FILES && $_FILES['image']) {
					$name = $_POST['name'];
					$tell = $_POST['tell'];
					$location = $_POST['location'];
					$username = $_POST['username'];
					$descr = $_POST['desc'];
					$psw = $_POST['psw'];
					$email=$_POST['email'];

					$fileData = pathinfo(basename($_FILES["image"]["name"]));
					$fileName = "Shop"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
					$regpath = __DIR__;
					$target_path = "./dist/img/upload/".$fileName;
					
					while(file_exists($target_path))
					{
					    $fileName = $ext."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
						$regpath = __DIR__;
						$target_path = "./dist/img/upload/".$fileName;
					}
					chmod(getcwd()."\dist\img\upload" , 0777);
						//var_dump(is_readable($target_path));exit();
					if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_path))
					{
						////// continue
					}else{
						hdev_note::message("Something went wrong while registering this shop please try again later!");
						exit();
					}
					$rt = new hdev_db();
					$tab = $rt->table("groups");

					$reff =$rt->insert("INSERT INTO `$tab` (`g_id`, `g_name`, `g_desc`, `g_pic`, `g_percentage`, `email`, `tell`, `g_location`, `g_status`, `g_mod_date`, `g_hash`) VALUES (NULL, :name, :descr, :fileName, '10', :email, :tell, :location, '2', current_timestamp(), NULL)",[[":name",$name],[":descr",$descr],[":fileName",$fileName],[":email",$email],[":tell",$tell], [":location",$location]]);

					$id = $rt->last_id();
					$tab2 = $rt->table("user");

					$reff =$rt->insert("INSERT INTO `$tab2` (`id`, `g_id`, `name`, `tell`, `post`, `sex`, `username`, `address`, `password`) VALUES (NULL, $id, :name, :tell, 'admin', 'm', :username, :location, :password)",[[':name',$name],[':tell',$tell],[':username',$username],[':location',$location],[':password',hdev_data::password_enc($psw)]]);
					if ($reff == "ok") {
						hdev_note::live_sms($tell,"Hello ".$name." shop is now registered and is waiting for approval from admin.");
						hdev_note::message("Shop Registered! new user added waiting for approval");
						$csrf->up_tk();
						if (!empty($_POST['from'])) {
							hdev_note::redirect(hdev_url::activate($_POST["from"]));
						}else{
							hdev_note::redirect(hdev_url::menu(''));
						}
					}else{
						hdev_note::server_msg("Registration failed");
					}
				}else{
					echo hdev_lang::on("validation","all_fields");
					//hdev_note::redirect(hdev_url::activate($_POST["from"]));
				}
			break;	
			case 'edit_shop':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
  				$tkn = "no";
				if (!empty($_POST['name']) && !empty($_POST['g_id']) && !empty($_POST['location'])  && !empty($_POST['desc']) && !empty($_POST['email'])) {
					$name = $_POST['name'];
					$g_id = $_POST['g_id'];
					$location = $_POST['location'];
					$descr = $_POST['desc'];
					$psw = $_POST['psw'];
					$email=$_POST['email'];
					$k = "";
					if ($_FILES && isset($_FILES["image"]["name"])) {
						$k = 1;
						$fileData = pathinfo(basename($_FILES["image"]["name"]));
						$fileName = "Shop"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
						$regpath = __DIR__;
						$target_path = "./dist/img/upload/".$fileName;
						
						while(file_exists($target_path))
						{
						    $fileName = $ext."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
							$regpath = __DIR__;
							$target_path = "./dist/img/upload/".$fileName;
						}
						chmod(getcwd()."\dist\img\upload" , 0777);
							//var_dump(is_readable($target_path));exit();
						if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_path))
						{
							////// continue
						}else{
							hdev_note::message("Something went wrong while editing this shop please try again later!");
							exit();
						}
					}
					$rt = new hdev_db();
					$tab = $rt->table("groups");
					if ($k == 1) {
					$reff =$rt->insert("UPDATE `$tab` SET `g_name` = :name, `g_desc` = :descr, `g_pic` = :fileName, `email` = :email, `g_location` = :location WHERE `g_id` = :g_id",[[":name",$name],[":descr",$descr],[":fileName",$fileName],[":email",$email],[":g_id",$g_id], [":location",$location]]);
					}else{
						$reff =$rt->insert("UPDATE `$tab` SET `g_name` = :name, `g_desc` = :descr, `email` = :email, `g_location` = :location WHERE `g_id` = :g_id",[[":name",$name],[":descr",$descr],[":email",$email],[":g_id",$g_id], [":location",$location]]);
					}

					if ($reff == "ok") {
						hdev_note::message("Shop info updated!");
						$csrf->up_tk();
						if (!empty($_POST['from'])) {
							hdev_note::redirect(hdev_url::activate($_POST["from"]));
						}else{
							hdev_note::redirect(hdev_url::menu(''));
						}
					}else{
						hdev_note::server_msg("modification failed");
					}
				}else{
					echo hdev_lang::on("validation","all_fields");
					//hdev_note::redirect(hdev_url::activate($_POST["from"]));
				}
			break;						
			case 'book_reg':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
    			if (!hdev_log::admin()) {
							echo "not allowed to do this action !!!!";
							exit();
						}
				if (!empty($_POST['cat_i']) && !empty($_POST['bo_price']) && !empty($_POST['brand_i']) && !empty($_POST['bo_name']) && is_array($_POST['size']) && count($_POST['size']) > 0 && !empty($_POST['bo_desc']) && !empty($_POST['bo_store']) && $_FILES && count($_FILES['upic_a']['name']) > 0) {
					$category = $_POST['cat_i'];
					$name = $_POST["bo_name"];
					$desc = $_POST["bo_desc"];
					$brand = $_POST["brand_i"];
					$brando = hdev_data::get_brand($brand,"info");
					if (isset($brando['name']) && !empty($brando['name'])) {
						//
					}else{
						exit("invalid brand");
					}
					$price = trim(str_ireplace(" ", "", $_POST["bo_price"]));
					if (!is_numeric($price)) {
						exit("Price must be a number eg: 100000<br>without currency");
					}
					$rand = hdev_data::single_id("book");
					$catveri = hdev_data::get_cat($category,"info");

					if (!empty($catveri) && is_array($catveri) && isset($catveri['name']) && !is_array($catveri['name']) && !empty($catveri['name'])) {

							if (!empty($_POST['bo_link'])) { 
								$link = $_POST['bo_link'];
								$dup = hdev_data::duplication_checker(["type"=>"book","name"=>$name]);
								if ($dup!='yes') {
									$countfiles = count($_FILES['upic_a']['name']);
									$upload_location = "book";
									$files_array = array();

									for($i = 0;$i < $countfiles; $i++){

									if (file_exists($_FILES["upic_a"]["tmp_name"][$i])) {
									$file_type = $_FILES["upic_a"]["type"][$i]; //returns the mimetype
									$allowed = array("image/jpeg", "image/gif", "image/png");
									if(!in_array($file_type, $allowed)) {
									}else{
										$ckup="";
										// Check file size
										if ($_FILES["upic_a"]["size"][$i] > 500000) {
										    $ckup = 1;
										}

										$fileData = pathinfo(basename($_FILES["upic_a"]["name"][$i]));
										$fileName = "Product"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
										$regpath = __DIR__;
										$target_path = getcwd()."\dist\img\products\\".$fileName;
										
										while(file_exists($target_path))
										{
										    $fileName = $ext."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
											$regpath = __DIR__;
											$target_path = getcwd()."\dist\img\products\\".$fileName;
										}
 										if ($ckup == "") {
 											chmod(getcwd()."\dist\img\products" , 0777);
 											//var_dump(is_readable($target_path));exit();
											if (move_uploaded_file($_FILES["upic_a"]["tmp_name"][$i], $target_path))
											{
												array_push($files_array, $fileName);
											}
										}
										}
										}
										}
										$reft = "";
										$exp = ".,*HDEV_prod*.,";
										foreach ($files_array as $key) {
											$reft .= $exp.$key;
										}
										if (strlen($reft) > strlen($exp)) {
											$reft = substr($reft, strlen($exp));
										}
										$upphoto = explode($exp, $reft);
										$var = count($upphoto);
										if (isset($upphoto) && !empty($upphoto) && $var >= 0 && isset($upphoto[0]) && !empty($upphoto[0]) && strlen($upphoto[0]) > 25) {
											$csrf->up_tk();
											$sizes = implode('^^^', $_POST['size']);
											hdev_data::create_products(["size"=>$sizes,"name"=>$name,"cat"=>$category,"rand"=>$rand,"desc"=>$desc,"link"=>$link,"brand"=>$brand,"pic"=>$reft,"price"=>$price]);
										}else{
											echo "Try to upload the images that are below 500 KB in size";
										}

									
								}else{
									echo "That Product already exist! try different name";
								}
							}else{
								echo hdev_lang::on("validation","all_fields");
							}
					}else{
						echo "The selected category is invalid!";
					}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}	
			break;
			case 'book_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
    			if (!hdev_log::admin()) {
							echo "not allowed to do this action !!!!";
							exit();
						}
				if (!empty($_POST['cat_i']) && !empty($_POST['bo_price']) && !empty($_POST['brand_i']) && !empty($_POST['bo_name']) && is_array($_POST['size']) && count($_POST['size']) > 0 && !empty($_POST['bo_desc']) && !empty($_POST['mask'])) {
					$b_nm = hdev_data::get_products($_POST['mask'],"menu")["d"];
					if (isset($b_nm) && !empty($b_nm)) {
						
					}else{
						exit("Edit failed try again later");
					}
					$category = $_POST['cat_i'];
					$name = $_POST["bo_name"];
					$desc = $_POST["bo_desc"];
					$brand = $_POST["brand_i"];
					$brando = hdev_data::get_brand($brand,"info");
					if (isset($brando['name']) && !empty($brando['name'])) {
						//
					}else{
						exit("invalid brand");
					}
					$price = trim(str_ireplace(" ", "", $_POST["bo_price"]));
					if (!is_numeric($price)) {
						exit("Price must be a number eg: 100000<br>without currency");
					}
					$rand = hdev_data::single_id("book");
					$catveri = hdev_data::get_cat($category,"info");

					if (!empty($catveri) && is_array($catveri) && isset($catveri['name']) && !is_array($catveri['name']) && !empty($catveri['name'])) {
							if (!empty($_POST['bo_link'])) { 
								$link = $_POST['bo_link'];
								$dup = "no";
								if ($dup!='yes') {
									if (count($_FILES) > 0) {								$countfiles = count($_FILES['upic_a']['name']);
									}else{
										$countfiles ="";
									}
									$upload_location = "book";
									$files_array = array();

									for($i = 0;$i < $countfiles; $i++){
									if (file_exists($_FILES["upic_a"]["tmp_name"][$i])) {
									$file_type = $_FILES["upic_a"]["type"][$i]; //returns the mimetype
									$allowed = array("image/jpeg", "image/gif", "image/png");
									if(!in_array($file_type, $allowed)) {
									}else{
										$ckup="";
										// Check file size
										if ($_FILES["upic_a"]["size"][$i] > 500000) {
										    $ckup = 1;
										}

										$fileData = pathinfo(basename($_FILES["upic_a"]["name"][$i]));
										$fileName = "Product"."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
										$regpath = __DIR__;
										$target_path = realpath(str_ireplace('\\', "/", $regpath).'/../dist/img/products')."\\".$fileName;
										
										while(file_exists($target_path))
										{
										    $fileName = $ext."_upload_".uniqid() ."_t_".time() .'.' . $fileData['extension'];
											$regpath = __DIR__;
											$target_path = realpath(str_ireplace('\\', "/", $regpath).'/../dist/img/products')."\\".$fileName;
										}
 										if ($ckup == "") {
 											
											if (move_uploaded_file($_FILES["upic_a"]["tmp_name"][$i], $target_path))
											{
												array_push($files_array, $fileName);
											}
										}
										}
										}
										}
										$reft = "";
										$exp = ".,*HDEV_prod*.,";
										foreach ($files_array as $key) {
											$reft .= $exp.$key;
										}

										if (strlen($reft) > strlen($exp)) {
											$reft = substr($reft, strlen($exp));
										}
										$upphoto = explode($exp, $reft);
										$var = count($upphoto);

										if (isset($upphoto) && !empty($upphoto) && $var >= 0 && isset($upphoto[0]) && !empty($upphoto[0]) && strlen($upphoto[0]) > 25) {
											//$csrf->up_tk(); 
											$sizes = implode('^^^', $_POST['size']);
											hdev_data::edit_products(["size"=>$sizes,"name"=>$name,"cat"=>$category,"rand"=>$rand,"desc"=>$desc,"link"=>$link,"brand"=>$brand,"pic"=>$reft,"price"=>$price,"mask"=>$b_nm]);
										}else{
											//$csrf->up_tk();
											$sizes = implode('^^^', $_POST['size']);
											hdev_data::edit_products(["size"=>$sizes,"name"=>$name,"cat"=>$category,"rand"=>$rand,"desc"=>$desc,"link"=>$link,"brand"=>$brand,"pic"=>"","price"=>$price,"mask"=>$b_nm]);
										}
								}else{
									echo "That Product already exist! try different name";
								}
							}else{
								echo hdev_lang::on("validation","all_fields");
							}
					}else{
						echo "The selected category is invalid!";
					}
				}else{
					echo hdev_lang::on("validation","all_fields");
				}	
			break;
			case 'reg_auth':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
    			if (!empty($_POST['name']) && !empty($_POST['sex']) && !empty($_POST['role']) && !empty($_POST['tell']) && !empty($_POST['uname']) && !empty($_POST['psw']) && !empty($_POST['re_psw']) && !empty($_POST['address'])) {
    				$name = $_POST['name'];
					$sex = $_POST['sex'];
					$sexs = array('M','F');
					$role = $_POST['role'];
					$address = $_POST['address'];
					if ($role == "admin") {
						if (!hdev_log::admin()) {
							echo "not allowed to register admin !!!!";
							exit();
						}
					}
					$roles = array('admin',"user");
					$tell = $_POST['tell'];
					$uname = $_POST['uname'];
					$psw = $_POST['psw'];
					$re_psw = $_POST['re_psw'];
					if (hdev_data::username_e($uname) == "yes") {
						if ($psw == $re_psw) {
							if (in_array($role, $roles)) {
								if (in_array($sex, $sexs)) {
									$rt = new hdev_db();
									$tab = $rt->table("user");
									$reff =$rt->insert("INSERT INTO $tab (`id`, `tell`, `post`, `name`, `sex`, `username`, `address`, `password`) VALUES (NULL, :contact, :role, :name, :sex, :username, :address, :password)",[[":contact",$tell],[":role",$role],[":name",$name],[":sex",$sex],[":username",$uname], [":address",$address], [":password",hdev_data::password_enc($psw)]]);
									$id = $rt->last_id();
									$reff =$rt->insert("INSERT INTO `chat_mask` (`chat_id`, `admin_id`, `user_id`, `reg_date`) VALUES (NULL, '2', ".$id.", current_timestamp())");
									if ($reff == "ok") {
										hdev_note::message("Registration successfull !  New user added!");
										$csrf->up_tk();
										if (!empty($_POST['from'])) {
											hdev_note::redirect(hdev_url::activate($_POST["from"]));
										}else{
											hdev_note::redirect(hdev_url::menu(''));
										}
									}else{
										hdev_note::server_msg("Registration failed");
									}
								}else{
									hdev_note::server_msg("Sex must be Male or Female only");
								}
							}else{
								hdev_note::server_msg("Choose a valid role");
							}
						}else{
							hdev_note::server_msg("Those passwords you provided does not match");
						}
					}else{
						hdev_note::server_msg("Username already taken try onother one");
					}
    			}else{
    				hdev_note::server_msg(hdev_lang::on("validation","all_fields"));
    			}
			break;
			case 'reg_auth_edit':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
    			if (!empty($_POST['name']) && !empty($_POST['sex']) && !empty($_POST['tell']) && !empty($_POST['address']) && !empty($_POST['ed_ref'])) {
    				$u = hdev_log::uid();
    				$y = $_POST['ed_ref'];
    				$name = $_POST['name'];
					$sex = $_POST['sex'];
					$sexs = array('M','F');
					$role = '';
					$address = $_POST['address'];
					if ($role == "admin") {
						if (!hdev_log::admin()) {
							echo "not allowed to register admin !!!!";
							exit();
						}
					}
					if (!isset($u) || empty($u) || $u!=$y) {
						echo "refresh page and try again";
						exit();
					}
					$roles = array('');
					$tell = $_POST['tell'];
							if (in_array($role, $roles)) {
								if (in_array($sex, $sexs)) {
									$rt = new hdev_db();
									$tab = $rt->table("user");
									$reff =$rt->insert("UPDATE $tab SET `name` = :name, `tell` = :contact, `sex` = :sex, `address` = :address WHERE `id` = :id",[[":name",$name],[":contact",$tell],[":sex",$sex],[":address",$address],[":id",$u]]);
									if ($reff == "ok") {
										$_SESSION['user'] = hdev_data::encd($name);
										hdev_note::message("Profile updated successfull !!!");
										$csrf->up_tk();
										if (!empty($_POST['from'])) {
											hdev_note::redirect(hdev_url::activate($_POST["from"]));
										}else{
											hdev_note::redirect(hdev_url::menu(''));
										}
									}else{
										hdev_note::server_msg("failed");
									}
								}else{
									hdev_note::server_msg("Sex must be Male or Female only");
								}
							}else{
								hdev_note::server_msg("Try again");
							}
    			}else{
    				hdev_note::server_msg(hdev_lang::on("validation","all_fields"));
    			}
			break;
			case 'app_order':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest($_POST['hash_mask']);
    			if (!hdev_log::admin()) {
							echo "not allowed to do this action !!!!";
							exit();
						}
    			if (isset($_POST['hash']) && !empty($_POST['hash'])) {
    				    $id = trim(hdev_data::decd($_POST['hash']));
  						$refer = hdev_data::get_single_order($id);
  						$refered = $refer[0];
  						if (isset($refered[0]['order_id']) && !empty($refered[0]['order_id'])) {
  							$rt = new hdev_db();
							$tab = $rt->table("order");
							$u = hdev_log::uid();
  							$update_cart = $rt->insert("UPDATE $tab SET p_status = :user WHERE order_id = :p",[[':user','c'],[':p',$id]]);

  							$update_cart2 = $rt->insert("UPDATE $tab SET admin = :user WHERE order_id = :p",[[':user',$u],[':p',$id]]);
  							if ($update_cart == "ok" && $update_cart2 == "ok") {
  								hdev_note::message("approved");
  								hdev_note::redirect(hdev_url::menu("h/order_r/".$_POST['hash']));
  							}
  						}else{
  							hdev_note::server_msg("try again later");
  						}
    			}else{
    				hdev_note::server_msg(hdev_lang::on("validation","all_fields"));
    			}
			break;
			case 'can_order':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest($_POST['hash_mask']);
    			if (hdev_log::admin()) {
    			if (isset($_POST['hash']) && !empty($_POST['hash'])) {
    				    $id = trim(hdev_data::decd($_POST['hash']));
  						$refer = hdev_data::get_single_order($id);
  						$refered = $refer[0];
  						if (isset($refered[0]['order_id']) && !empty($refered[0]['order_id'])) {
  							$rt = new hdev_db();
							$tab = $rt->table("order");
  							$update_cart = $rt->insert("UPDATE $tab SET p_status = :user WHERE order_id = :p",[[':user','x'],[':p',$id]]);

  							$update_cart2 = $rt->insert("UPDATE $tab SET admin = :user WHERE order_id = :p",[[':user',$u],[':p',$id]]);
  							if ($update_cart == "ok" && $update_cart2 == "ok") {
  								hdev_note::message("Canceled");
  								hdev_note::redirect(hdev_url::menu("h/order_r/".$_POST['hash']));
  							}
  						}else{
  							hdev_note::server_msg("try again later");
  						}
    			}else{
    				hdev_note::server_msg(hdev_lang::on("validation","all_fields"));
    			}
    			}else{
    				echo "ACCESS denied ! not an admin.";
    			}
			break;
			case 'chat_msg_initiate':
				if (!empty($_POST['id'])) {
					$chat_msg = hdev_data::order_msg($_POST['id']);
				}else{
					$chat_msg = hdev_data::order_msg();
				}
				$chat_contact = hdev_data::order_sub_msg();
				$cv="";
				if (count($chat_msg) < 1) {
                	$cv. "No messages found<br>Send a message to start chatting";
                }
                ///chat header ////
	                $c = '<div class="direct-chat-messages">';
	            $mg_count = count($chat_msg);
	            $r = 0;
                foreach ($chat_msg as $msg) {
                	$r = ++$r;
                	$to_seen = "";

                	//$to_seen = $r."-".$mg_count;
                	$match = hdev_log::uid();

                	if ($msg['user_id'] != $match) {
                		hdev_data::order_msg_seen($msg['msg_id']);
                	}
                	$t_id = "";
                	$mg_track = "";
                	if ($r == $mg_count) {
                		if ($msg['user_id'] == $match) {
                			$ift = hdev_data::order_msg_seen_alert($msg["msg_id"]);
                			if ($ift == "c") {
                				$to_seen = "<i class='fa'>Seen</i>";
                			}else{
                				$to_seen = "<i class='fa fa-check-circle'>&nbsp;Sent</i>";
                			}
                		}
                		$t_id = $msg['msg_id'];
                		$mg_track = "mg_track";
                	}
                	$user_icon = hdev_data::user_icon($msg['user_id']);

	                $mat = $msg['user_id'];
	                $userm = hdev_data::user(1,$mat)['name'];
	                $tm = hdev_data::timer($msg['msg_reg'],"date")." - ".hdev_data::timer($msg['msg_reg'],"time");
	                $resp = ($mat == $match) ? " right" : "";
	                if ($mat != $match) {
	                	$direct = "left";
	                	$bg = "light";
	                	$direct_opp = "right";
	                }else{
	                	$direct = "right";
	                	$bg = "secondary";
	                	$direct_opp = "left";
	                }
	                
	                $c .= '<div class="direct-chat-msg '.$direct.'">';
	                	$c .= '<div class="direct-chat-infos clearfix">';
	                	  $c .= '<span class="direct-chat-name float-'.$direct.' bg-'.$bg.'">'.ucfirst($userm).'</span>';
	                	  $c .= '<span class="direct-chat-timestamp float-'.$direct_opp.'">'.$tm.'</span>';
	                	$c .= '</div>';
	                	$c .= '<i class="'.$user_icon.' fa-2x direct-chat-img"></i>  ';
	                	$c .= '<div class="direct-chat-text">';
	                	
	                	  $c .= $msg['msg'];
	                	$c .= '</div>';
	                	$c .= '<span class="direct-chat-timestamp float-'.$direct_opp.'" id="'.$mg_track.'" vf="'.$t_id.'" vt="'.$msg['user_id'].'">'.$to_seen.'</span>';
	                  $c .= '</div>';
	                  $c .= '<hr>';
	            }
	            	  $c .= '</div>';

	            	$b = '<div class="direct-chat-contacts">';
	            	  $b .= '<ul class="contacts-list">';


	            	  foreach ($chat_contact as $ctt) {

                      			//$order_info = hdev_data::get_single_order($ctt['user_id']);

								//product extraction
								//$prod_id = $order_info[0][0]['p_id'];
								//$b_nm = hdev_data::get_products($prod_id,"menu")["name"];
							  	//$b_dsc = hdev_data::get_products($prod_id,"menu")["desc"];
							  	//$pic = hdev_data::get_products($prod_id,"menu")["pic"];
							  	//$price = hdev_data::get_products($prod_id,"menu")["price"];
								//var_dump(hdev_data::order_sub_msg());

								//user extraction
								if (hdev_log::admin()) {
									$user_id = $ctt['user_id'];
								}else{
									$user_id = $ctt['admin_id'];
								}
								
								$user = hdev_data::user(1,$user_id);

								// msg news 
								$msgd = hdev_data::last_new_message_menu($ctt['chat_id']);
								$mssg = $msgd['msg'];
								

								$tmm = hdev_data::timer($msgd['msg_reg'],"date")." - ".hdev_data::timer($msgd['msg_reg'],"time");

								$user_icon = hdev_data::user_icon($user_id);
						$b .= '<li>';
						  $b .= '<a href="#" onclick="m_init(\''.$ctt['chat_id'].'\');">';
						    $b .= '<i class="'.$user_icon.' fa-2x  direct-chat-img"></i>  ';
						    $b .= '<div class="contacts-list-info">';
						    $b .= '<span class="contacts-list-name" id="mg_'.''.'">';
						    	$b .= '<span id="mg_'.$ctt['chat_id'].'">'.ucfirst($user['name'])."</span>";
						    	$b .= '<small class="contacts-list-date float-right">'.$tmm.'</small>
                             		 </span>';
                             	$b .= '<span class="contacts-list-msg">'.$mssg.'</span>';
                            $b .= '</div>';
                          $b .= ' </a>
                        		</li>';
                      		}
                      	$b .= '</ul>';
                    $b .= '</div>';
                    $ht = 0;
					if (isset($_POST['ht']) && !empty($_POST['ht'])) {
						$ht = $_POST['ht'];
					}
					$rf = array("msg"=>$cv.$c.$b,"ht"=>$ht);
					$tp = json_encode($rf);
					echo $tp;exit();
			break;
			case 'new_msg_count':
				$ht = 0;
				if (!empty($_POST['ht'])) {
					$ht = $_POST['ht'];
				}
				$u = hdev_log::uid();
				$m = "";
				if (isset(hdev_data::order_msg_new($u)[0]) && is_numeric(hdev_data::order_msg_new($u)[0])) {
					$m = hdev_data::order_msg_new($u)[0];
				}	
				if ($m =="" || $m == 0 || $m < 0) {
					$m = "";
				}
				$kp = "";
				if (isset(hdev_data::order_msg_new($u)[1])) {
					$kp = hdev_data::order_msg_new($u)[1];
				}

				$rf = array("n_msg"=>$m,"ht"=>$ht, "ad"=>$kp);
				
				$tp = json_encode($rf);
				if (isset(hdev_data::order_msg_new($u)[2])) {
				foreach (json_decode(hdev_data::order_msg_new($u)[2]) as $up_me) {
					$rt = new hdev_db();
      				$tab = $rt->table("chat_msg");
      				if (isset($up_me) && !empty($up_me)) {
      					$rt->insert("UPDATE $tab SET status = :st WHERE msg_id = :o",[[':st',"x"],[':o',$up_me]]);
      				}
                    
                 }
             	}
				echo $tp;exit();
			break;
			case 'seen_check':
			$user = "";
			$msg = "";
				if (!empty($_POST['mask2']) && !empty($_POST['mask1'])) {
					$user = trim($_POST['mask1']);
					$msg = trim($_POST['mask2']);
				}
				$u = hdev_log::uid();
				$to_seen = "";

				if ($user == $u) {

                	$ift = hdev_data::order_msg_seen_alert($msg);
                	if ($ift == "c") {
                		$to_seen = "<i class='fa'>Seen</i>";
                	}else{
                		$to_seen = "<i class='fa fa-check-circle'>&nbsp;Sent</i>";
                	}
                }
                echo $to_seen;	
			break;
			case 'chat_msg':
				$csrf = new CSRF_Protect();
    			$csrf->verifyRequest();
    			$u = hdev_log::uid();
    			if (!empty($_POST['message'])) {
    				if (!empty($_POST['parts'])) {
    					if (!empty($_POST['mask']) && !empty($_POST['parts'])) {
    						$chat_mask = $_POST['mask'][0];
    						$sender = $_POST['parts'];
    						if (hdev_data::chat_mask_e($chat_mask)) {
    							if ($sender == $u) {
    								$rt = new hdev_db();
									$tab = $rt->table("chat_msg");
									//$per = "n";
  									$per = $rt->insert("INSERT INTO $tab (`mask_id`, `user_id`, `msg`, `status`) VALUES (:mask_id, :user_id, :msg, :status)",[[':mask_id',$chat_mask],[':user_id',$u],[':msg',$_POST['message']],[':status',"p"]]);
  									if ($per == "ok") {
  										//message sent 
  									}else{
  										echo "message not sent try again later";
  									}
    							}else{
    								echo "access denied try to refresh page and re send message ";
    							}
    						}else{
    							echo "access denied try again later";
    						}
    					}else{
    						echo "Refresh and re try to send this message";
    					}
    				}else{
    					echo "Message not sent please try again later";
    				}
    			}else{
    				hdev_note::server_msg("Message can not be empty");
    			}
			break;
			default:
				hdev_note::server_msg("Try again later");
			break;
		}
		}else{
			hdev_note::server_msg("Connection failed try refresh!");
		}
		//var_dump($_POST);
	}
 ?>