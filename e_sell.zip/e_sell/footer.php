<?php 
  if (!hdev_log::loged()) {
?>


<div class="modal fade modal-reg">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Shop registration request</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
                  <form method="post" id="reg_shop" enctype="multipart/form-data" action="<?php echo hdev_url::menu('up');?>">
                    <?php 
                      $csrf = new CSRF_Protect();
                      $csrf->echoInputField();
                    ?>
                    <input type="hidden" name="ref" value="reg_shop">
                      <div class="form-group">
                      <label for="name">
                        Shop Names :
                      </label>
                      <div class="input-group mb-3">
                        <input type="text" name="name" id="name" class="form-control" placeholder="Shop Names" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-user-tie"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="tell">
                        Telephone :
                      </label>
                      <div class="input-group mb-3">
                        <input type="text" name="tell" id="tell" class="form-control" placeholder="Telephone" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-phone"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="uname"> 
                        Shop Location :
                      </label>
                      <div class="input-group mb-3">
                        <input type="text" name="location" id="location" class="form-control" placeholder="Shop Location" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-user"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="address"> 
                        Shop Image :
                      </label>
                      <div class="input-group mb-3">
                        <input type="file" accept="image" name="image" id="shop_image" class="form-control" placeholder="Image" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-map-marker-alt"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="psw">
                        Shop Username :
                      </label>
                      <div class="input-group mb-3">
                        <input type="text" name="username" id="username" class="form-control" placeholder="Shop Username" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-user-secret"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="psw">
                        Shop Email :
                      </label>
                      <div class="input-group mb-3">
                        <input type="email" name="email" id="email" class="form-control" placeholder="Shop Email" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fa">@</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="psw">
                        Shop Description :
                      </label>
                      <div class="input-group mb-3">
                        <textarea type="text" name="desc" id="desc" class="form-control" placeholder="Shop Description" required="true"></textarea>
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-cubes"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="re_psw">
                        Password :
                      </label>
                      <div class="input-group mb-3">
                        <input type="password" name="psw" id="psw" class="form-control" placeholder="Password" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!--progress bar -->
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="progress">
                            <div class="progress-bar bg-primary progress-bar-striped" role="progressbar" id="progress-bar">
                            </div>
                          </div>

                      </div>
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-12">
                        <i>
                          By clicking submit it means that you accept the terms and conditions of <?php echo APP_NAME; ?>. You will have to wait for admins to approve this registration request. Once approved you will be able to login and start selling. If all done you will be notified.
                        </i>
                      </div>
                    </div>
                    <hr>
                    <div class="form-group">
                      <div class="wait" align="center"></div>
                    </div>
                  </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-secondary" onclick="$('#reg_shop').submit();" id="reg_shops"><i class="fas fa-save"></i> Submit shop registration request</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<?php
  }
 ?>
  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
    </div>
  </aside>
  <!-- /.control-sidebar -->
  <div class="loader" align="center">
    <span style="width: auto;text-align: center;"><img src="<?php echo hdev_url::menu('dist/img/loading2.gif');?>" alt="" /><br><i><?php echo hdev_lang::on("form","load"); ?></i></span>
  </div>

  <!-- Main Footer -->
  <footer class="main-footer bg-dark">
    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-secondary">
        <div class="row px-xl-5">
            <div class="col-lg-4 col-md-12 mb-5 pr-3 pr-xl-5">
                <h5 class="text-secondary text-uppercase mb-4">Get In Touch</h5>
                <p class="mb-4">if you need to buy you are at the right place.<br> Start  by creating account and any thing will be after</p>
                <p class="mb-2"><i class="fa fa-map-marker-alt text-primary mr-3"></i>Kigali,Rwanda</p>
                <p class="mb-2"><i class="fa fa-envelope text-primary mr-3"></i>info@fsell.com</p>
            </div>
            <div class="col-lg-8 col-md-12">
                <div class="row">
                    <div class="col-md-8 mb-5">
                        <h5 class="text-secondary text-uppercase mb-4">Quick Links</h5>
                        <div class="d-flex flex-column justify-content-start">
                            <a class="text-secondary mb-2" href="<?php echo hdev_url::menu(""); ?>"><i class="fa fa-angle-right mr-2"></i>Home</a>
                            <a class="text-secondary mb-2" href="<?php echo hdev_url::menu("h/cartv"); ?>"><i class="fa fa-angle-right mr-2"></i>Shopping Cart</a>
                            <a class="text-secondary" href="<?php echo hdev_url::menu("h/contact"); ?>"><i class="fa fa-angle-right mr-2"></i>Contact Us</a>
                            <a class="text-secondary" href="#"><i class="fa fa-map-marker-alt mr-2"></i>Address: Kigali,Rwanda</a>
                        </div>
                    </div>
                    <div class="col-md-4 mb-5">
                        <h5 class="text-secondary text-uppercase mb-4">Newsletter</h5>
                        <p>New products are arriving <br> Be quick <br> Be ready to buy</p>
                        <h6 class="text-secondary text-uppercase mt-4 mb-3">Follow Us</h6>
                        <div class="d-flex">
                            <a class="btn btn-primary btn-square mr-2" href="#"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-primary btn-square mr-2" href="#"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-primary btn-square mr-2" href="#"><i class="fab fa-linkedin-in"></i></a>
                            <a class="btn btn-primary btn-square" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row border-top mx-xl-5 py-4" style="border-color: rgba(256, 256, 256, .1) !important;">
            <div class="col-md-8 px-xl-0">
                <!-- To the right -->
              <div class="float-right d-none d-sm-inline">
                Powered by <?php echo APP_PROGRAMMER['name']; ?>
              </div>
              <!-- Default to the left -->
              <strong>Copyright &copy; <?php echo date('Y'); ?> <a href="https://free.facebook.com/itizerehirwaroger" class="text-white" target="_blank"><?php echo APP_NAME; ?></a>.</strong> All rights reserved.
            </div>
            <div class="col-md-4 px-xl-0 text-center text-md-right">
                <img class="img-fluid" src="<?php echo hdev_url::menu('dist/img/payments.png');?>" alt="">
            </div>
        </div>
    </div>
    
    <!-- Footer End -->
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src="<?php echo hdev_url::menu('plugins/jquery/jquery.min.js');?>"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo hdev_url::menu('plugins/jquery-ui/jquery-ui.min.js');?>"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!--<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>-->
<!-- Bootstrap 4 -->
<script src="<?php echo hdev_url::menu('plugins/bootstrap/js/bootstrap.bundle.min.js');?>"></script>
<script src="<?php echo hdev_url::menu('plugins/bootstrap/js/bootstrap.min.js');?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo hdev_url::menu('dist/js/adminlte.min.js');?>"></script>
<link rel="stylesheet" type="text/css" href="<?php echo hdev_url::menu('plugins/ajax/select/example-styles.css')?>">
<script href="<?php echo hdev_url::menu('plugins/ajax/select/jquey.multi-select.min.js')?>"></script>

<script src="<?php echo hdev_url::menu('plugins/Smoothproducts/js/jquery-2.1.3.min.js');?>"></script>
<script src="<?php echo hdev_url::menu('plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js');?>"></script>
<script src="<?php echo hdev_url::menu('plugins/Smoothproducts/js/smoothproducts.js');?>"></script>
<script src="<?php echo hdev_url::menu('plugins/ajax/former.js');?>"></script>
<!-- data tables -->
<script src="<?php echo hdev_url::menu('plugins/datatables/jquery.dataTables.js');?>"></script>
<script src="<?php echo hdev_url::menu('plugins/datatables-bs4/js/dataTables.bootstrap4.js');?>"></script>
<script src="<?php echo hdev_url::menu("plugins/datatables-responsive/js/dataTables.responsive.min.js"); ?>"></script>
<script src="<?php echo hdev_url::menu("plugins/datatables-responsive/js/responsive.bootstrap4.min.js"); ?>"></script>
<script src="<?php echo hdev_url::menu('plugins/ajax/sl.js');?>"></script>
<script>
            $(document).ready(function() {
              $('.owl-carousel').owlCarousel({
                loop: true,
                margin: 10,
                autoplay: true,
                autoplayTimeout: 2500,
                autoplayHoverPause: true,
                lazyLoad: true,
                lazyLoadEager: 1,
                responsiveClass: true,
                responsive: {
                  0: {
                    items: 1,
                    nav: true
                  },
                  600: {
                    items: 3,
                    nav: true
                  },
                  1000: {
                    items: 4,
                    nav: true,
                    loop: true,
                    margin: 10
                  }
                }
              });
            })
          </script>
<!-- SweetAlert2 -->
<script src="<?php echo hdev_url::menu('plugins/sweetalert2/sweetalert2.min.js');?>"></script>
  <script type="text/javascript">
    // When the user scrolls the page, execute myFunction
    window.onscroll = function() {myFunction()};

    // Get the header
    var header = document.getElementById("of_head");

    // Get the offset position of the navbar
    var sticky = header.offsetTop;

    // Add the sticky class to the header when you reach its scroll position. Remove "sticky" when you leave the scroll position
    function myFunction() {
      if (window.pageYOffset > sticky) {
        header.classList.add("sticky");
      } else {
        header.classList.remove("sticky");
      }
    } 
    function logout(ur = '') {
    var confim = window.confirm('Are you Sure You Want To logout ?');
    if (confim) {
      window.location.href=ur;
    }
  }
  function load_slider() {
    $('.oww').owlCarousel({
      loop: true,
      margin: 10,
      autoplay: true,
      autoplayTimeout: 2500,
      autoplayHoverPause: true,
      lazyLoad: true,
      lazyLoadEager: 1,
      responsiveClass: true,
      responsive: {
        0: {
          items: 1,
          nav: true
        },
        600: {
          items: 3,
          nav: true
        },
        1000: {
          items: 4,
          nav: true,
          loop: true,
          margin: 10
        }
      }
    });
    $('.oww2').owlCarousel({
      loop: false,
      margin: 10,
      autoplay: true,
      autoplayTimeout: 2500,
      autoplayHoverPause: true,
      lazyLoad: true,
      lazyLoadEager: 1,
      responsiveClass: true,
      responsive: {
        0: {
          items: 1,
          nav: true
        },
        600: {
          items: 3,
          nav: true
        },
        1000: {
          items: 4,
          nav: true,
          loop: true,
          margin: 10
        }
      }
    });    
  }
  function go_action(hash='',main_data='',messages='') {
    var x  = window.confirm(messages);
    if (x) {
      var link = '<?php echo hdev_url::menu('app/core/') ?>'+hash+'/'+main_data
      //alert(link);
      window.location.href=link;
    }else{
      return false;
    }
  }
    function delete_me(ref='',ur='') {
        var cf = window.confirm('Are you sure you want to delete this '+ref);
        if (cf) {
            window.location.href = ur;
        }
    }
  function id_validator(val_text='',input_icon='',message_box='',sub_btn='') {

    if (val_text.length != 16) {
      errors = "id must be 16 digits";
      var a = '<span class="text-danger">'+errors+'</span>';
      $(sub_btn).hide();
      $(message_box).html(a);
      $(input_icon).html('<span class="fa fa-times-circle text-danger"></span>');
    }else{
      $(sub_btn).show();
      $(message_box).html('');
      $(input_icon).html('<span class="fa fa-check-circle text-success"></span>');
    }
  }
  function app_printer(id_t,btnn) {
    $('#'+btnn).hide();
    $("#"+id_t+" .hd_pt").show();
    $("#"+id_t+" .bg-secondary").addClass("dt_b-gg");
    $("#"+id_t+" .dt_b-gg").removeClass("bg-secondary");
    var id_to_print = document.getElementById(id_t);
    var WinPrint = window.open('', '<?php echo APP_NAME." -- PRINTER" ?>', 'left=0,top=0,width='+screen.width+',height='+screen.height+',toolbar=0,scrollbars=0,status=0');
    WinPrint.document.write('<html><head><title><?php echo APP_NAME." -- PRINTER" ?></title>');
    WinPrint.document.write('<link rel="stylesheet" href="<?php echo hdev_url::menu('dist/css/adminlte.min.css');?>">');
    WinPrint.document.write('<style>*{color: #000000 !important;}</style></head><body onload="print();close();">');
    WinPrint.document.write(id_to_print.innerHTML);
    WinPrint.document.write('</body></html>');
    WinPrint.document.close();
    WinPrint.focus();
    $("#"+id_t+" .hd_pt").hide();
    $("#"+id_t+" .dt_b-gg").addClass("bg-secondary");
    $("#"+id_t+" .bg-secondary").removeClass("dt_b-gg");
    $('#'+btnn).show();
  }
  var ldm = "<span><i class='fa fa-spinner fa-spin'></i></span>";
  function shop(ref_dd,prefix) {
      //alert(tx_reff);
      var prefix = "#"+prefix;
      var cv = $(prefix+' #hash').attr('hash');
      var ret = "js"; 
        $.ajax({
        url   : "<?php echo hdev_url::menu('up'); ?>",
        method  : "POST",
        data  : {ref:'req_ext_shop',ref_ld:ref_dd,hash:cv},
        //req_ext_land_lord
        beforeSend: function(){
            $('.ldd').html(ldm);
            //$(".loader").show();
              //var icoo = $('#'+ret).attr(ret+"-ico");
              //$('#'+ret+' input-group-text').html('<div class="process-loader"></div>');
             },
            success:function(data){
              $('.ldd').html("...");
              var jsonData = JSON.parse(data);
              $(prefix+' #name').html(jsonData.name);
              $(prefix+' #email').html(jsonData.email);
              $(prefix+' #tel').html(jsonData.tel);
            }, 
            error: function(){
              alert("refresh a page and try again");
            }
      });
  }

  function shop_account(ref_dd,prefix) {
      //alert(ref_dd);
      var prefix = "#"+prefix;
      var cv = $(prefix+' #hash2').attr('hash2');
      var ret = "js"; 
      var icc = $('#acc_ico').attr('ico');
        $.ajax({
        url   : "<?php echo hdev_url::menu('up'); ?>",
        method  : "POST",
        data  : {ref:'req_shop_account_balance',ref_ld:ref_dd,hash:cv},
        beforeSend: function(){
            $('#acc_ico').html(ldm);
             },
            success:function(data){
              //alert(data);
              if (data == 'Data validation failed.') {
                alert(data+' Try again Later.');
                window.location.href=window.location.href;
              }
              //alert(cv);
              var jsonData = JSON.parse(data);
              $('#acc_ico').html(icc);
              $(prefix+' #acc_bal').html(jsonData.balance);
            }, 
            error: function(){
              alert("refresh a page and try again");
            }
      });
  }       
  function mr_locator(ret='',prov_v="",dist_v="",sect_v="",cel_v="") {
    
      var cv = '<?php $csrf = new CSRF_Protect();echo $csrf->getToken();  ?>';
        $.ajax({
        url   : "<?php echo hdev_url::menu('up'); ?>",
        method  : "POST",
        data  : {ref:'location_select',type:ret,prov:prov_v,dist:dist_v,sect:sect_v,cell:cel_v,cover:cv},
        beforeSend: function(){

          var icoo = $('#'+ret).attr(ret+"-ico");
          $('#'+ret+' input-group-text').html('<div class="process-loader"></div>');
             },
            success:function(html){
              //alert(html);
              var icoo = $('#'+ret).attr(ret+"-ico");
              $('#'+ret+' input-group-text').html('<span class="'+icoo+'" ></span>');
              switch(ret) {
                case 'district':
                  $('#'+ret).html(html); 
                  $('#sector').html('<option value="">---Select---</option>');
                  $('#cell').html('<option value="">---Select---</option>'); 
                  $('#village').html('<option value="">---Select---</option>');
                  break;
                case 'sector':
                  $('#'+ret).html(html); 
                  $('#cell').html('<option value="">---Select---</option>'); 
                  $('#village').html('<option value="">---Select---</option>');
                  break;
                case 'cell':
                  $('#'+ret).html(html); 
                  $('#village').html('<option value="">---Select---</option>'); 
                  break; 
                case 'village':
                  $('#'+ret).html(html); 
                  break;   
              }
            }, 
            error: function(){
              alert("refresh a page and try again");
            }
      });
  }
  function update_shipping_price(location_id) {
    
      var cv = '<?php $csrf = new CSRF_Protect();echo $csrf->getToken();  ?>';
      var sub_tott = $('#order_sub_total_price').html();
      var ret = "js"; 
        $.ajax({
        url   : "<?php echo hdev_url::menu('up'); ?>",
        method  : "POST",
        data  : {ref:'shipping_price',type:ret,loc:location_id,sub_tot:sub_tott,cover:cv},
        beforeSend: function(){
          $(".loader").show();
              //var icoo = $('#'+ret).attr(ret+"-ico");
              //$('#'+ret+' input-group-text').html('<div class="process-loader"></div>');
             },
            success:function(data){
              $(".loader").hide();
              //alert(data);
              var jsonData = JSON.parse(data);
              $('#shipping_price').html(jsonData.shipping_price);
              $('#order_total_price').html(jsonData.tot);
            }, 
            error: function(){
              alert("refresh a page and try again");
            }
      });
  }
  function tx_hist(tx_reff,o_id) {
      //alert(tx_reff);
      var cv = '<?php $csrf = new CSRF_Protect();echo $csrf->getToken();  ?>';
      var tx_hist_contents = $('#tx_hist_contents').html();
      var ret = "js"; 
        $.ajax({
        url   : "<?php echo hdev_url::menu('up'); ?>",
        method  : "POST",
        data  : {ref:'transaction_history',tx_ref:tx_reff,oo_id:o_id,cover:cv},
        beforeSend: function(){
           $('#tx_hist_contents').html($load_status);
            //$(".loader").show();
              //var icoo = $('#'+ret).attr(ret+"-ico");
              //$('#'+ret+' input-group-text').html('<div class="process-loader"></div>');
             },
            success:function(data){
              $('#tx_hist_contents').html(tx_hist_contents);
              //alert(data);
              var jsonData = JSON.parse(data);
              $('#o_name').html(jsonData.o_name);
              $('#o_tel').html(jsonData.o_tel);
              $('#o_email').html(jsonData.o_email);
              $('#o_status').html(jsonData.o_status);
              $('#o_date').html(jsonData.o_date);
              $('#o_address').html(jsonData.o_address);
              $('#o_tx_ref').html(jsonData.o_tx_ref);
              $('#o_tx_id').html(jsonData.o_tx_id);
              $('#o_sub_total').html(jsonData.o_sub_total);
              $('#o_shipping').html(jsonData.o_shipping);
              $('#o_total').html(jsonData.o_total);
              $('#o_products').html(jsonData.o_products);
              //$('#tx_hist_contents').html(data);
            }, 
            error: function(){
              alert("refresh a page and try again");
            }
      });
  }    
  /* wait for images to load */
  $(window).load(function() {
    $(function() {
        //$('body').overlayScrollbars({ }); 
    });
    
    $('.sp-wrap').smoothproducts();
      
  });
  </script>
<script type="text/javascript">
  //setTimeout(function(){ $("#body .skiptranslate:first-child").css("background-color","red"); }, 5000);*/
  setInterval( "msg_init_newc()", 10000);
  <?php 
    if (isset($msgin) && !empty($msgin) && $msgin=="1") {
  ?>
  function m_init(a) {
    $("#chat_mask").val(a);
    msg_init();
    $('#recover_mask').click();
    var head = $('#mg_'+a).html();
    $('#ct_head').html(head);

  }
  //setInterval( "msg_init()", 2000 );
  setInterval( "seen_check()", 10000);
  //setTimeout(function(){ msg_init(); }, 5000);
  <?php
   }
  ?>
  //<![CDATA[
  $(document).ready(function(){
      $('#status').fadeOut(); // will first fade out the loading animation 
            $('#preloader').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website. 
            $('body').delay(350).css({'overflow':'visible'});
            msg_init_newc();
            <?php 
              if (isset($msgin) && !empty($msgin) && $msgin=="1") {
            ?>
            msg_init();
            seen_check();
            //var myDiv = $(".direct-chat-messages").get(0);
            //myDiv.scrollTop = myDiv.scrollHeight;
            <?php
              }
             ?>
  });
  //]]>
  $load_status= $('<span><img src="<?php echo hdev_url::menu('dist/img/loading2.gif');?>"/></span><i>&nbsp;&nbsp;wait...!!!</i>');
  $saved = $('<span class="text-success"><?php echo hdev_lang::on("validation","saved"); ?></span>');
  $min_wait = $('<span class="text-success"><?php echo hdev_lang::on("validation","loading"); ?></span>');
  function sdcol() {
    $("body").addClass('sidebar-collapse');
  }
    <?php 
    if (isset($msgin) && !empty($msgin) && $msgin=="1") {
  ?>
  function msg_init(){
    var lpid = $('#chat_mask').val();
    var myDiv = $(".direct-chat-messages").get(0);
    var op = myDiv.scrollTop;
    $.ajax({
      url : "<?php echo hdev_url::menu('up');?>",
      method: "POST",
      data  : {ref:"chat_msg_initiate",id:lpid,ht:op},
      beforeSend: function(){
            $('#chat_div').append($load_status);
      },
      success : function(data){
        var jsonData = JSON.parse(data);

        var jsonLength = jsonData.length;
        var html = "";

        //for (var i = 0; i < jsonLength; i++) {
        var result = jsonData;

        $("#chat_div").html(result.msg);

        var r = $('#chat_mask').val();
        var head = $('#mg_'+r).html();
        $('#ct_head').html(head);
        
        var myDiv = $(".direct-chat-messages").get(0);
        //alert(myDiv.scrollHeight);

          myDiv.scrollTop = result.ht;

      }
    }); 
  }
<?php } ?>
  function msg_init_newc(){
    //var lpid = $('#chat_mask').val();
    $.ajax({
      url : "<?php echo hdev_url::menu('up');?>",
      method: "POST",
      data  : {ref:"new_msg_count",ht:0,kp:0},
      beforeSend: function(){
            //$('#chat_div').html($load_status);
      },
      success : function(data){
       /* $("#chat_div").html(data);
        var r = $('#chat_mask').val();
        var head = $('#mg_'+r).html();*/
        
        var jsonData = JSON.parse(data);

        var jsonLength = jsonData.length;
        var html = "";

        //for (var i = 0; i < jsonLength; i++) {
          var result = jsonData;
          $('.ctmg').html(result.n_msg);
          if (result.n_msg > 0 && result.n_msg != "") {
            //alert(result.ad);
              <?php 
                if (isset($msgin) && !empty($msgin) && $msgin=="1") {
              ?>
            msg_init();
              <?php } ?>
              //alert(result.ad);
            if (result.ad == "yes") {
              var audio = new Audio('<?php echo hdev_url::menu("dist/audio/alert.mp3") ?>');
              audio.play();
            }
            
          }
        //}
        
      }
    });
  }
  function seen_check(){

    var pk = $('#mg_track');
    var maskb = pk.attr('vf');
    var maska = pk.attr('vt');
    $.ajax({
      url : "<?php echo hdev_url::menu('up');?>",
      method: "POST",
      data  : {ref:"seen_check",mask1:maska,mask2:maskb},
      beforeSend: function(){
        //
      },
      success : function(data){
        $('#mg_track').html(data);
      }
    }); 
  }
    $(document).on('click','#shop_payment_btn',function(e) {
      e.preventDefault();
      var formData = jQuery('#shop_payment').serialize();
      $.ajax({ 
            type: "POST",
            url: "<?php echo hdev_url::menu('up');?>",
            data: formData,
            beforeSend: function(){
              $('.wait').html($load_status);
              $('#shop_payment_btn').hide();
             },
            success:function(html){
                a = '<span class="text-danger">'+html+'</span>';
                $('.wait').html(a);
                setTimeout(function(){
                  $('.wait').html('');
                  $('#shop_payment_btn').show();
                }, 4000);
            },
            error: function(){
              $('.wait').html('<span class"text-warning">Error ocured</span>');
              $('#shop_payment_btn').show();
            }
          });
        return false; 
    }); 
  $(document).on('click','.prod_recover',function(e) {
      var p_price=$(this).attr("p_price");
      var p_id=$(this).attr("p_id");
      var p_name=$(this).attr("p_name");
      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");
      $('.modal-recover #p_price').html(p_price);
      $('.modal-recover #p_id').html(p_id);
      $('.modal-recover #p_name').html(p_name);
      $('.modal-recover #prod_recover').attr("data","");
      $('.modal-recover #prod_recover').attr("hash","");      
      $('.modal-recover #prod_recover').attr("href",'<?php echo hdev_url::menu("app/core"); ?>'+'/'+hs+'/'+dt);
      //alert(dt);
    }); 
  $(document).on('click','.prod_delete',function(e) {
      var p_price=$(this).attr("p_price");
      var p_id=$(this).attr("p_id");
      var p_name=$(this).attr("p_name");
      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");
      $('.modal-delete #p_price').html(p_price);
      $('.modal-delete #p_id').html(p_id);
      $('.modal-delete #p_name').html(p_name);
      $('.modal-delete #prod_delete').attr("data","");
      $('.modal-delete #prod_delete').attr("hash","");      
      $('.modal-delete #prod_delete').attr("href",'<?php echo hdev_url::menu("app/core"); ?>'+'/'+hs+'/'+dt);
      //alert(dt);
    }); 
  $(document).on('click','.brand_recover',function(e) {
      var b_name=$(this).attr("b_name");
      var b_id=$(this).attr("b_id");
      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");
      $('.modal-recover #b_name').html(b_name);
      $('.modal-recover #b_id').html(b_id);
      $('.modal-recover #brand_recover').attr("data","");
      $('.modal-recover #brand_recover').attr("hash","");      
      $('.modal-recover #brand_recover').attr("href",'<?php echo hdev_url::menu("app/core"); ?>'+'/'+hs+'/'+dt);
      //alert(dt);
    }); 
  $(document).on('click','.brand_delete',function(e) {
      var b_name=$(this).attr("b_name");
      var b_id=$(this).attr("b_id");
      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");
      $('.modal-delete #b_name').html(b_name);
      $('.modal-delete #b_id').html(b_id);
      $('.modal-delete #brand_delete').attr("data","");
      $('.modal-delete #brand_delete').attr("hash","");      
      $('.modal-delete #brand_delete').attr("href",'<?php echo hdev_url::menu("app/core"); ?>'+'/'+hs+'/'+dt);
      //alert(dt);
    }); 

    $(document).on('click','.cat_recover',function(e) {
      var c_name=$(this).attr("c_name");
      var c_id=$(this).attr("c_id");
      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");
      $('.modal-recover #c_name').html(c_name);
      $('.modal-recover #c_id').html(c_id);
      $('.modal-recover #cat_recover').attr("data","");
      $('.modal-recover #cat_recover').attr("hash","");      
      $('.modal-recover #cat_recover').attr("href",'<?php echo hdev_url::menu("app/core"); ?>'+'/'+hs+'/'+dt);
      //alert(dt);
    }); 

  $(document).on('click','.cat_delete',function(e) {
      var c_name=$(this).attr("c_name");
      var c_id=$(this).attr("c_id");
      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");
      $('.modal-delete #c_name').html(c_name);
      $('.modal-delete #c_id').html(c_id);
      $('.modal-delete #cat_delete').attr("data","");
      $('.modal-delete #cat_delete').attr("hash","");      
      $('.modal-delete #cat_delete').attr("href",'<?php echo hdev_url::menu("app/core"); ?>'+'/'+hs+'/'+dt);
      //alert(dt);
    });  

    $(document).on('click','.user_recover',function(e) {
      var u_name=$(this).attr("u_name");
      var u_id=$(this).attr("u_id");
      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");
      $('.modal-recover #u_name').html(u_name);
      $('.modal-recover #u_id').html(u_id);
      $('.modal-recover #user_recover').attr("data","");
      $('.modal-recover #user_recover').attr("hash","");      
      $('.modal-recover #user_recover').attr("href",'<?php echo hdev_url::menu("app/core"); ?>'+'/'+hs+'/'+dt);
      //alert(dt);
    }); 

  $(document).on('click','.user_delete',function(e) {
      var u_name=$(this).attr("u_name");
      var u_id=$(this).attr("u_id");
      var dt = $(this).attr("data");
      var hs = $(this).attr("hash");
      $('.modal-delete #u_name').html(u_name);
      $('.modal-delete #u_id').html(u_id);
      $('.modal-delete #user_delete').attr("data","");
      $('.modal-delete #user_delete').attr("hash","");      
      $('.modal-delete #user_delete').attr("href",'<?php echo hdev_url::menu("app/core"); ?>'+'/'+hs+'/'+dt);
      //alert(dt);
    });  
  $('#shipping_form_btn').click(function(){
    var formData = jQuery('#shipping_form').serialize();
    $.ajax({ 
          type: "POST",
          url: "<?php echo hdev_url::menu('up');?>",
          data: formData,
          beforeSend: function(){
            $('#shipping_form_btn').hide();
            $('.wait').html($load_status);
           },
          success:function(html){
            if (html == 'ok'){
              
            }else{
              a = '<span class="text-danger">'+html+'</span>';
              
              setTimeout(function(){
                $('.wait').html(a);
              }, 1500);
              setTimeout(function(){
                $('#shipping_form_btn').show();
                $('.wait').html('');
              }, 4000);
            }
          }, 
          error: function(){
            $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
            setTimeout(function(){
                $('#shipping_form_btn').show();
                $('.wait').html('');
              }, 3000);
          }
        });
    });
  $('#cat_reg_btn').click(function(){
    var formData = jQuery('#c_rg_form').serialize();
    $.ajax({ 
          type: "POST",
          url: "<?php echo hdev_url::menu('up');?>",
          data: formData,
          beforeSend: function(){
            $('.wait').html($load_status);
            $('#cat_reg_btn').hide();
            // Show image container
            //$("#fsave").hide();
            //$(".wait").show();
           // alert('hiiiiiiii');
           },
          success:function(html){
            if (html == 'ok'){
              setTimeout(function(){
                 $('.wait').html($saved);
              }, 1000);
              setTimeout(function(){
                 $('#c_close').click();
              }, 1500);
              setTimeout(function(){
                 $('#cat_reg_btn').show();
                 $('input[type!=hidden]').val('');
                 $('textarea[type!=hidden]').val('');
                 $('#refresh-enngine').click();
                 sdcol();
              }, 2500);
            }else{
              setTimeout(function(){
                a = '<span class="text-danger">'+html+'</span>';
                $('.wait').html(a);
                $('#cat_reg_btn').show();
              }, 1000);
            }
          },
          error: function(){
            $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
            $('#cat_reg_btn').show();
          }
        });
    });

    $(document).ready(function() { 
     $('#book_reg_form').submit(function(e) {  
      if($('#upic_a').val()) {
        e.preventDefault();

        $(this).ajaxSubmit({  
          target:   '.wait',  
          beforeSubmit: function() {
            $("#progress-bar").width('0%');
            $('.wait').html($load_status);
            $('#book_reg_btn').hide();
          },
          uploadProgress: function (event, position, total, percentComplete){ 
            $("#progress-bar").width(percentComplete + '%');
            $("#progress-bar").html('<div id="progress-status">' + percentComplete +' %</div>');

          },
          success:function (){
              $('#book_reg_btn').show();

            setTimeout(function(){
              $('.wait').html('');
            }, 9000);
          },
          resetForm: false 
        }); 
        return false; 
      }else{
        a = '<span class="text-danger">Choose what to upload first</span>';
        $('.wait').html(a);
        setTimeout(function(){
          $('.wait').html('');
        }, 3000);
        return false;
      }
    });
  }); 
    $(document).ready(function() { 
     $('#book_edit_form').submit(function(e) {  
      if($('#upic_a').val()) {
        e.preventDefault();

        $(this).ajaxSubmit({  
          target:   '.wait',  
          beforeSubmit: function() {
            $("#progress-bar").width('0%');
            $('.wait').html($load_status);
            $('#book_edit_btn').hide();
          },
          uploadProgress: function (event, position, total, percentComplete){ 
            $("#progress-bar").width(percentComplete + '%');
            $("#progress-bar").html('<div id="progress-status">' + percentComplete +' %</div>');

          },
          success:function (){
              $('#book_edit_btn').show();

            setTimeout(function(){
              $('.wait').html('');
            }, 9000);
          },
          resetForm: false 
        }); 
        return false; 
      }else{
       var formData = jQuery('#book_edit_form').serialize();
       e.preventDefault();
        $.ajax({ 
              type: "POST",
              url: "<?php echo hdev_url::menu('up');?>",
              data: formData,
              beforeSend: function(){
                $('#book_reg_btn').hide();
                $('.wait').html($load_status);
               },
              success:function(html){
                if (html == 'ok'){
                  
                }else{
                  a = '<span class="text-danger">'+html+'</span>';
                  
                  setTimeout(function(){
                    $('.wait').html(a);
                  }, 1500);
                  setTimeout(function(){
                    $('#book_reg_btn').show();
                    $('.wait').html('');
                  }, 4000);
                }
              }, 
              error: function(){
                $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
                setTimeout(function(){
                    $('#reg_auths').show();
                    $('.wait').html('');
                  }, 3000);
              }
            });
      }
    });
  }); 
  $('#reg_auths').click(function(){
    var formData = jQuery('#reg_auth').serialize();
    $.ajax({ 
          type: "POST",
          url: "<?php echo hdev_url::menu('up');?>",
          data: formData,
          beforeSend: function(){
            $('#reg_auths').hide();
            $(".wait").html('<button type="button" class="btn btn-block btn-outline-warning btn-lg"><i class="fa fa-spin fa-life-ring fa-3x"></i>&nbsp;&nbsp;&nbsp;<i class="fa fa-edit fa-3x"></i></button>');
            $('#fink').show();
           },
          success:function(html){
            if (html == 'ok'){
              
            }else{
              a = '<span class="text-danger">'+html+'</span>';
              
              setTimeout(function(){
                $('.wait').html(a);
              }, 1500);
              setTimeout(function(){
                $('#reg_auths').show();
                $('.wait').html('');
              }, 4000);
            }
          }, 
          error: function(){
            $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
            setTimeout(function(){
                $('#reg_auths').show();
                $('.wait').html('');
              }, 3000);
          }
        });
    });
    $(document).ready(function() { 
     $('#reg_shop').submit(function(e) {  
      if($('#shop_image').val()) {
        e.preventDefault();

        $(this).ajaxSubmit({  
          target:   '.wait',  
          beforeSubmit: function() {
            $("#progress-bar").width('0%');
            $('.wait').html($load_status);
            $('#reg_shops').hide();
          },
          uploadProgress: function (event, position, total, percentComplete){ 
            $("#progress-bar").width(percentComplete + '%');
            $("#progress-bar").html('<div id="progress-status">' + percentComplete +' %</div>');

          },
          success:function (){
              $('#reg_shops').show();

            setTimeout(function(){
              $('.wait').html('');
            }, 9000);
          },
          resetForm: false 
        }); 
        return false; 
      }else{
        a = '<span class="text-danger">Choose what to upload first</span>';
        $('.wait').html(a);
        setTimeout(function(){
          $('.wait').html('');
        }, 3000);
        return false;
      }
    });
     $('#edit_shop').submit(function(e) {  
      if($('#shop_image').val()) {
        e.preventDefault();

        $(this).ajaxSubmit({  
          target:   '.wait',  
          beforeSubmit: function() {
            $("#progress-bar").width('0%');
            $('.wait').html($load_status);
            $('#reg_shops').hide();
          },
          uploadProgress: function (event, position, total, percentComplete){ 
            $("#progress-bar").width(percentComplete + '%');
            $("#progress-bar").html('<div id="progress-status">' + percentComplete +' %</div>');

          },
          success:function (){
              $('#reg_shops').show();

            setTimeout(function(){
              $('.wait').html('');
            }, 9000);
          },
          resetForm: false 
        }); 
        return false; 
      }else{
       var formData = jQuery('#edit_shop').serialize();
       e.preventDefault();
        $.ajax({ 
              type: "POST",
              url: "<?php echo hdev_url::menu('up');?>",
              data: formData,
              beforeSend: function(){
                $('#reg_shops').hide();
                $('.wait').html($load_status);
               },
              success:function(html){
                if (html == 'ok'){
                  
                }else{
                  a = '<span class="text-danger">'+html+'</span>';
                  
                  setTimeout(function(){
                    $('.wait').html(a);
                  }, 1500);
                  setTimeout(function(){
                    $('#reg_shops').show();
                    $('.wait').html('');
                  }, 4000);
                }
              }, 
              error: function(){
                $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
                setTimeout(function(){
                    $('#reg_shops').show();
                    $('.wait').html('');
                  }, 3000);
              }
            });
      }
    });
  }); 
$(document).ready(function(){

    $(document).on('click','.pager_control',function(e) {
        var urr=$(this).attr("url");
        var pgg=$(this).attr("page");
        var lcc = urr+'/'+pgg;
        $('.loader').show();
        window.location.href=lcc;
        //attach(lcc);
    }); 
  checkOutDetails();
  net_total();
  cat();
  order_check();
  count_item();
  getCartItem();
  //cat() is a funtion fetching category record from database whenever page is load
  function cat(){
    $.ajax({
      url : "<?php echo hdev_url::menu('up'); ?>",
      method: "POST",
      data  : {ref:'cat_v'},
      success : function(data){
        $("#get_category").html(data);
        
      }
    })
  }
  /*  when page is load successfully then there is a list of categories when user click on category we will get category id and 
    according to id we will show products
  */

  <?php 
  if (hdev_log::loged()) {
  ?>
    $('#reg_auth_edit_save').click(function(){
    var formData = jQuery('#reg_auth_edit').serialize();
    $.ajax({ 
          type: "POST",
          url: "<?php echo hdev_url::menu('up');?>",
          data: formData,
          beforeSend: function(){
            $('.wait1').html($load_status);
            $('#reg_auth_edit_save').hide();
           },
          success:function(html){
            if ('ok' == 'oklk'){
              
            }else{
              a = '<span class="text-danger">'+html+'</span>';
              $('.wait1').html(a);
              setTimeout(function(){
                $('.wait1').html('');
                $('#reg_auth_edit_save').show();
              }, 4000);
            }
          },
          error: function(){
            $('.wait1').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
            $('#c_track').show();
          }
        });
    });
    // chatoooooooooo//////////////////////
    $("#chat_fm").on("submit",function(event){

    event.preventDefault();
    var formData = jQuery('#chat_fm').serialize();
    $.ajax({ 
          type: "POST",
          url: "<?php echo hdev_url::menu('up');?>",
          data: formData,
          beforeSend: function(){
            $('.wait').html($load_status);
            $('#ct_msg').hide();
           },
          success:function(html){
            $("#msgh").val("");
            if ('ok' == 'oklk'){
            }else{
              a = '<span class="text-danger">'+html+'</span>';
              $('.wait').html(a);

              setTimeout(function(){
                $('.wait').html('');
              }, 6000);
               $('#ct_msg').show();
            }
            msg_init();
          },
          error: function(){
            $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
            $('#ct_msg').show();
          }
        });
    });

    $('#sec_update').click(function(){
    var formData = jQuery('#security').serialize();
    $.ajax({ 
          type: "POST",
          url: "<?php echo hdev_url::menu('up');?>",
          data: formData,
          beforeSend: function(){
            $('.wait').html($load_status);
            $('#sec_update').hide();
           },
          success:function(html){
            if ('ok' == 'oklk'){
              
            }else{
              a = '<span class="text-danger">'+html+'</span>';
              $('.wait').html(a);
              setTimeout(function(){
                $('.wait').html('');
                $('#sec_update').show();
              }, 4000);
            }
          },
          error: function(){
            $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
            $('#c_track').show();
          }
        });
    });  
  <?php
  }
  if (hdev_log::admin()) {
    ?>
    $(document).on('click','.edit_accb',function(e) {
      var a=$(this).attr("d-i");
      var b=$(this).attr("d-n");
      var c=$(this).attr("d-desc");
      $('#re_track').val(b);
      $('#track').val(a);
      $('#desc').val(c);
    });

    $(document).on('click','.prof_edit',function(e) {
      var a=$(this).attr("d-i");
      var b=$(this).attr("d-name");
      $('#track').val(a);
      $('#re_track').val(b);
    });

    $('.profd').click(function(){
    var yh = $(this).attr("kl");
    var formData = jQuery('#profd_form'+yh).serialize();
    $.ajax({ 
          type: "POST",
          url: "<?php echo hdev_url::menu('up');?>",
          data: formData,
          beforeSend: function(){
            $('.waitp'+yh).html($load_status);
            $('.profd').hide();
           },
          success:function(html){
            if ('ok' == 'oklk'){
              
            }else{
              a = '<span class="text-danger">'+html+'</span>';
              $('.waitp'+yh).html(a);
              setTimeout(function(){
                $('.waitp'+yh).html('');
                $('.profd').show();
              }, 4000);
            }
          },
          error: function(){
            $('.waitp'+yh).html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
            $('.profd').show();
          }
        });
    });
    $('#c_track').click(function(){
    var formData = jQuery('#edit_cat').serialize();
    $.ajax({ 
          type: "POST",
          url: "<?php echo hdev_url::menu('up');?>",
          data: formData,
          beforeSend: function(){
            $('.wait').html($load_status);
            $('#c_track').hide();
           },
          success:function(html){
            if ('ok' == 'oklk'){
              
            }else{
              a = '<span class="text-danger">'+html+'</span>';
              $('.wait').html(a);
              setTimeout(function(){
                $('.wait').html('');
                $('#c_track').show();
              }, 4000);
            }
          },
          error: function(){
            $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
            $('#c_track').show();
          }
        });
    });

    $('#admin_sec').click(function(){
    var formData = jQuery('#sec_p').serialize();
    $.ajax({ 
          type: "POST",
          url: "<?php echo hdev_url::menu('up');?>",
          data: formData,
          beforeSend: function(){
            $('.wait').html($load_status);
            $('#admin_sec').hide();
           },
          success:function(html){
            if ('ok' == 'oklk'){
              
            }else{
              a = '<span class="text-danger">'+html+'</span>';
              $('.wait').html(a);
              setTimeout(function(){
                $('.wait').html('');
                $('#admin_sec').show();
              }, 4000);
            }
          },
          error: function(){
            $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
            $('#admin_sec').show();
          }
        });
    });

  $("body").delegate("#app_order","click",function(event){
    event.preventDefault();
    var hashq = $(this).attr('o_hash'); 
    var msk = $(this).attr('o_v_hash');
    
      $.ajax({
      url   : "<?php echo hdev_url::menu('up'); ?>",
      method  : "POST",
      data  : {ref:'app_order',hash:hashq,hash_mask:msk},
      beforeSend: function(){
            $('.auths').hide();
            $(".wait").html($load_status);
           },
          success:function(html){
            var k='o';
            if (k == 'pnm'){
              alert('approved');
              window.location.href ='<?php echo hdev_url::menu("h/order_r/") ?>'+hashq;
            }else{
              a = '<span class="text-danger">'+html+'</span>';
              setTimeout(function(){
                $('.wait').html(a);
              }, 1500);
              setTimeout(function(){
                $('.auths').show();
                $('.wait').html('');
              }, 4000);
            }
          }, 
          error: function(){
            $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
            setTimeout(function(){
                $('.auths').show();
                $('.wait').html('');
              }, 3000);
          }
    })
  
  });
    $("body").delegate("#can_order","click",function(event){
    event.preventDefault();
    var hashq = $(this).attr('o_hash'); 
    var msk = $(this).attr('o_v_hash');
    
      $.ajax({
      url   : "<?php echo hdev_url::menu('up'); ?>",
      method  : "POST",
      data  : {ref:'can_order',hash:hashq,hash_mask:msk},
      beforeSend: function(){
            $('.auths').hide();
            $(".wait").html($load_status);
           },
          success:function(html){
            var k='o';
            if (k == 'pnm'){
              alert('approved');
              window.location.href ='<?php echo hdev_url::menu("h/order_r/") ?>'+hashq;
            }else{
              a = '<span class="text-danger">'+html+'</span>';
              setTimeout(function(){
                $('.wait').html(a);
              }, 1500);
              setTimeout(function(){
                $('.auths').show();
                $('.wait').html('');
              }, 4000);
            }
          }, 
          error: function(){
            $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
            setTimeout(function(){
                $('.auths').show();
                $('.wait').html('');
              }, 3000);
          }
    })
  
  });

  <?php
  }

   ?>

    //Add Product into Cart End Here
  //Count user cart items funtion
  function count_item(check_login=''){
    $(".cart_parent").hide();
    $.ajax({
      url : "<?php echo hdev_url::menu('up'); ?>",
      method : "POST",
      data : {ref:'count_cart'},
      success : function(data){
        if (data == "1") {
          <?php if (!hdev_log::loged()): ?>
            if (check_login != '') {
              //var confirm_login = window.confirm('You are shopping as guest,\n Do you want to login now?');
              /*if (confirm_login) { 
                window.location.href='<?php echo hdev_url::menu('h/login'); ?>';
              }*/
            }
          <?php endif ?>
        }
        //alert(data);
        if (data <= 0 ) {
          $(".cart_parent").hide();
          $(".cart_parent_2").hide();
        }else{
          $(".cart_parent").show();
          $(".cart_parent_2").attr("style","");
        }
        $(".badge_cart").html(data);
        //alert(data.length);
      }
    })
  }
  window.onpopstate =function (event) {
    window.location.href = document.location;
  } ;
   $("body").delegate(".liftk","click",function(event){
    $("#get_product").html("<h6>Loading...</h6>");
    $(".loader").show();
    event.preventDefault();
    var cid = $(this).attr('href');
    var fh = $(this).attr('title');
    //alert(fh);
    var jn = $(".sub_head").html(fh);
    var po = document.title;
    
      $.ajax({
      url   : ""+cid+"/a/b/c",
      method  : "POST",
      data  : {get_seleted_Category:1,cat_id:cid},
      success : function(data){
        cat();
        if (fh != "" && fh != "undefined") {
          var po = fh;
        }
        if (po === "undefined") {
          var po = "<?php echo APP_NAME; ?>";
        }
        /*changedgoogleTranslateElementInit();*/
        //alert(fh);
        document.title = po; 
        //alert(po);
        window.history.pushState(""+cid+"", "<?php echo APP_NAME; ?>" , ""+cid+"");
        window.onpopstate =function (event) {
            document.title = po; 
            window.location.href = document.location;
            /*changedgoogleTranslateElementInit();*/
            //alert ("location: " + d + ", state: " + JSON.stringify (event.state)) ;
            // based on the event.state values, restore buttons visibility here...
        } ;
         //window.location.replace(cid);
        $("#get_product").html(data);
        if($("body").width() < 480){
          $("body").scrollTop(683);
        }
        load_slider();
        $('.sp-wrap').smoothproducts();
        $(".loader").hide();
      }
    })
  
  })
    //Add Product into Cart
  $("body").delegate(".add_to_cart","click",function(event){
    var pid = $(this).attr("pid");
    var ogg_size = $(this).attr('sizes');
    //undefined
    //if () {}
    event.preventDefault();
    var ck_var = '1';
    if(typeof ogg_size === 'undefined') {
        alert('You must select size first');
        og_size = "";
        ck_var = '2';
    } else if(ogg_size === null){
        alert('You must select size first');
        og_size = "";
        ck_var = '2';
    } else if(ogg_size === ''){
        alert('You must select size first');
        og_size = "";
        ck_var = '2';
    }else{
      og_size = ogg_size
    }
    if (ck_var == 1) {
      $(".loader").show();
      $.ajax({
        url : "<?php echo hdev_url::menu('up'); ?>",
        method : "POST",
        data : {ref:'addToCart',proId:pid,sizes:og_size},
        success : function(data){
          count_item('1');
          getCartItem();
          $('#product_msg').html(data);
          if($("body").width() < 480){
            $("body").scrollTop(683);
          }
          $(".loader").hide();
        }
      });
    }
    //alert(og_size.length);

  });

    //Get User Information before checkout end here
  //Count user cart items funtion end

  //Fetch Cart item from Database to dropdown menu
  function getCartItem(){
    $(".loader").show();
    $.ajax({
      url : "<?php echo hdev_url::menu('up'); ?>",
      method : "POST",
      data : {ref:'getCartItem'},
      success : function(data){
        //alert(data);
        $(".cart_product").html(data);
        $(".loader").hide();
      }
    })
  }


  /*
    checkOutDetails() function work for two purposes
    First it will enable php isset($_POST["Common"]) in action.php page and inside that
    there is two isset funtion which is isset($_POST["getCartItem"]) and another one is isset($_POST["checkOutDetials"])
    getCartItem is used to show the cart item into dropdown menu 
    checkOutDetails is used to show cart item into Cart.php page
  */
  function checkOutDetails(){
   $('.loader').show();
    $.ajax({
      url : "<?php echo hdev_url::menu('up'); ?>",
      method : "POST",
      data : {ref:'check_out'},
      success : function(data){
        $('.loader').hide();
        $(".cart_check").html(data);
        net_total();
      }
    })
  }

  function order_check(){
   $('.loader').show();
    $.ajax({
      url : "<?php echo hdev_url::menu('up'); ?>",
      method : "POST",
      data : {ref:'order_out'},
      success : function(data){
        $('.loader').hide();
        $(".cart_checkd").html(data);
        net_total();
        setTimeout(function(){
          $('#order_view').DataTable({
            "responsive": true,
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true, 
            "autoWidth": true
          });
        }, 10);
      }
    })
  }  

    /*
    Whenever user change qty we will immediate update their total amount by using keyup funtion
    but whenever user put something(such as ?''"",.()''etc) other than number then we will make qty=1
    if user put qty 0 or less than 0 then we will again make it 1 qty=1
    ('.total').each() this is loop funtion repeat for class .total and in every repetation we will perform sum operation of class .total value 
    and then show the result into class .net_total
  */
  $("body").delegate(".qty","keyup",function(event){
    event.preventDefault();
    var row = $(this).parent().parent();
    var price = row.find('.price').val();
    var qty = row.find('.qty').val();
    if (isNaN(qty)) {
      qty = 1;
    };
    if (qty < 1) {
      qty = 1;
    };
    var total = price * qty;
    row.find('.total').val(total);
    var net_total=0;
    $('.total').each(function(){
      net_total += ($(this).val()-0);
    })
    $('.net_total').html("" +net_total);

  });
  $("body").delegate(".qty","change",function(event){
    event.preventDefault();
    var row = $(this).parent().parent();
    var price = row.find('.price').val();
    var qty = row.find('.qty').val();
    if (isNaN(qty)) {
      qty = row.find('.qty').val(1);
    };
    if (qty < 1) {
      qty = row.find('.qty').val(1);
    };
    var total = price * qty;
    row.find('.update').click();
    row.find('.total').val(total);
    var net_total=0;
    $('.total').each(function(){
      net_total += ($(this).val()-0);
    })
    $('.net_total').html("" +net_total);
  });  
  //Ch
    /*
    net_total function is used to calcuate total amount of cart item
  */
  function net_total(){
    var net_total = 0;
    $('.qty').each(function(){
      var row = $(this).parent().parent();
      var price  = row.find('.price').val();
      var total = price * $(this).val()-0;
      row.find('.total').val(total);
    })
    $('.total').each(function(){ 
      net_total += ($(this).val()-0);
    })
    $('.net_total').html("" +net_total);
  }

    /*
    whenever user click on .remove class we will take product id of that row 
    and send it to action.php to perform product removal operation
  */
  $("body").delegate(".remove","click",function(event){
    var remove = $(this).parent().parent().parent();
    var remove_id = remove.find(".remove").attr("remove_id");
    $.ajax({
      url : "<?php echo hdev_url::menu('up'); ?>",
      method  : "POST", 
      data  : {ref:'removeItemFromCart',rid:remove_id},
      success : function(data){
        $("#product_msg").html(data);
        checkOutDetails();
        getCartItem();
        count_item();
        if($("body").width() < 480){
          $("body").scrollTop(683);
        }

      }
    })
  })


  /*
    whenever user click on .update class we will take product id of that row 
    and send it to action.php to perform product qty updation operation
  */
  $("body").delegate(".update","click",function(event){
    var update = $(this).parent().parent().parent();
    var update_id = update.find(".update").attr("update_id");
    var qty = update.find(".qty").val();
    $.ajax({
      url : "<?php echo hdev_url::menu('up'); ?>",
      method  : "POST",
      data  : {ref:'updateCartItem',update_id:update_id,qty:qty},
      success : function(data){
        $("#product_msg").html(data);
        checkOutDetails();
        getCartItem();
        count_item();
        if($("body").width() < 480){
          $("body").scrollTop(683);
        }
      }
    })


  })
/*
    Here #login is login form id and this form is available in index.php page
    from here input data is sent to login.php page
    if you get login_success string from login.php page means user is logged in successfully and window.location is 
    used to redirect user from home page to profile.php page
  */
  $("#auto_order").on("submit",function(event){
    event.preventDefault();
     //$('.loader').show(); 
     var formData = jQuery('#auto_order').serialize(); 
    $.ajax({
      url : "<?php echo hdev_url::menu('up'); ?>",
      method: "POST",
      data  : formData,
      beforeSend: function(){
        $('.wait').html($load_status);
        $('#oorder_reg').hide();
      },
      success :function(html){
        /*$("#product_msg").html(data);
        setTimeout(function(){
          //alert("ok");
          window.location.href='<?php echo hdev_url::menu("h/order"); ?>';
        }, 1000);
        $('.loader').hide();*/
        a = '<span class="text-danger">'+html+'</span>';
        $('.wait').html(a);
        setTimeout(function(){
          $('.wait').html('');
          $('#oorder_reg').show();
        }, 4000);
      },
      error: function(){
        $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
        $('#oorder_reg').show();
      }
    })
  })
  //end

  //end
<?php if (isset($var_slide)) {
  ?>
    var $load_status= '<span><i class="fa fa-spinner fa-spin"></i></span><i>&nbsp;&nbsp;wait...!!!</i>';
    $(document).on('submit','#form_reg',function(e) {
        e.preventDefault();
      if($('#form_reg #p_pic').val()) {

        $(this).ajaxSubmit({  
          target:   '#form_reg .wait',  
          beforeSubmit: function() {
            $("#form_reg #progress-bar").width('0%');
            $('#form_reg .wait').html($load_status);
            $('#form_reg #form_reg_btn').hide();
          },
          uploadProgress: function (event, position, total, percentComplete){ 
            $("#form_reg #progress-bar").width(percentComplete + '%');
            $("#form_reg #progress-bar").html('<div id="progress-status">' + percentComplete +' %</div>');

          },
          success:function (){
              $('#form_reg_btn').show();

            setTimeout(function(){
              $('#form_reg .wait').html('');
            }, 4000);
          },
          resetForm: false 
        }); 
        return false; 
      }else{
              $('#form_reg .wait').html('Select what to upload first');
      }
    });
  <?php
} ?>
  //Get User Information before checkout
  $("#signup_form").on("submit",function(event){
    event.preventDefault();
    $(".overlay").show();
    $.ajax({
      url : "register.php",
      method : "POST",
      data : $("#signup_form").serialize(),
      success : function(data){
        $(".overlay").hide();
        if (data == "register_success") {
          window.location.href = "cart.php";
        }else{
          $("#signup_msg").html(data);
        }
      }
    })
  })
    $('.dttable2').DataTable({
      "responsive": true,
          "paging": false,
          "lengthChange": true,
          "searching": true,
          "ordering": true,
          "info": true, 
          "autoWidth": true
        });  
     $('#rasms_all_tables2').DataTable({
      "responsive": true,
          "paging": false,
          "lengthChange": true,
          "searching": true,
          "ordering": true,
          "info": true, 
          "autoWidth": true
        });   
    $('#dttable').DataTable({
      "responsive": true,
          "paging": true,
          "lengthChange": true,
          "searching": true,
          "ordering": true,
          "info": true, 
          "autoWidth": true
        });
    $('.dttable').DataTable({
      "responsive": true,
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true, 
      "autoWidth": true
    });
  //Fetch Cart item from Database to dropdown menu

})
</script> 
</body>
</html>
