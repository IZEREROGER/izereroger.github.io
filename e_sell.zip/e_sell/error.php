<section class="content">
      <div class="error-page">
        <h2 class="headline text-warning"> <i class="fa fa-lock"></i><br>404</h2>

        <div class="error-content">
          <h3><i class="fas fa-exclamation-triangle text-warning"></i> Oops! Network failure.</h3>

          <p>
            We could not find the page you were looking for.<br>
            PLEASE TRY AGAIN LATER<br><br>
            Ibyo mwasabye ntibibashije kuboneka mwongere mukanya!<br>
            havutse ikibazo cya murandasi turimo kugerageza kugikemura
          </p>

          </form>
        </div>
        <!-- /.error-content -->
      </div>
      <!-- /.error-page -->
    </section>