<div class="content">
      <div class="container">
  <?php 
  $ppg = (isset($_SESSION['act_url']['3']) && is_numeric($_SESSION['act_url']['3'])) ? $_SESSION['act_url']['3'] : "1" ;
  $btnv = ceil(hdev_data::get_cat("","ex",['type'=>"count",'pg'=>"1"])/12);
  if ($ppg > $btnv || $ppg<0) {
    $ppg=1;
  }
  $category = hdev_data::user("*","*");
  $rfer = 1; 
   ?> 

    <div class="card card-primary card-outline">
      <div class="card-header">
        <div class="user-block">
          <span class="text"> <i class="fa fa-folder-open"></i> Profiles Info</span>
          <span class="description">All Profiles in a system</span>
        </div>
        <!-- /.user-block -->
        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Mark as read">
            <i class="far fa-circle"></i></button>
          <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
          <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
          </button>
        </div>
        <!-- /.card-tools -->
      </div>
      <div class="card-body table-responsive p-3" style="background: #aaa !important;">
        <div class="btn-group">
          <!--<button class="btn btn-primary ftb" data-toggle="modal" data-target=".modal-reg"><i class="fas fa-plus-circle"></i> Register new Admin</button>&nbsp;-->
        </div>
        <?php   if (isset($category[0]['name']) && !empty($category[0]['name'])) { ?>
        <table id="dttable" class="table table-hover table-bordered table-striped text-sm">
          <thead>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Username</th>
            <th>Sex</th>
            <th>Role</th>
            <th>Tell.</th>
            <th>Address</th>
            <th>Action</th>
          </tr>
          </thead>
          <tbody>
          <?php $acc_num=1; if (1==1) :?>
          <?php foreach ($category as $cata): ?>
            <?php $rfer = 0; 
              if ($cata['id'] == hdev_log::uid()) {
                continue;
              }
              $csrf = new CSRF_Protect();
              $tkn = $csrf->getToken();
              $build = "ref:user_recover;id:".$cata['id'].";src:1;from:".urlencode(hdev_url::get_url_full());
              $build2 = "ref:user_delete;id:".$cata['id'].";src:1;from:".urlencode(hdev_url::get_url_full());
              $delete = hdev_data::encd("mod_close:#;app:".$tkn.";".$build2);
              $recover = hdev_data::encd("mod_close:#;app:".$tkn.";".$build);
            ?>
          <tr>
            <td><i><?php echo $cata['id']; ?></i></td>
            <td><?php echo ucfirst($cata["name"]); ?></td>
            <td><?php echo $cata["username"]; ?></td>
            <td><?php echo $cata["sex"]; ?></td>
            <td><?php echo $cata['post']; ?></td>
            <td><?php echo $cata['tell']; ?></td>
            <td><?php echo $cata['address']; ?></td>
            <td>
              <div class="btn-group btn-group-sm">
                
                <?php 
                  $t_user = hdev_data::user_st("view",$cata['id']);
                  if ($t_user == "on") {
                ?>
                <!--<button type="button" class="prof_edit btn btn-success" data-toggle="modal" data-target="#modal-default2" d-i="<?php echo $cata["id"]; ?>" d-name="<?php echo $cata["username"]; ?>">
                        <span class="fas fa-edit"></span>
                        <?php echo hdev_lang::on("form","edit"); ?>
                </button>-->

                  <button hash="<?php echo $tkn; ?>" data="<?php echo $delete; ?>" rel="external" class="btn btn-danger user_delete" u_id="<?php echo $cata['id'] ?>" u_name="<?php echo $cata["name"]; ?>" data-toggle="modal" data-target=".modal-delete"><i class="fas fa-trash"></i> <?php echo hdev_lang::on("form","delete"); ?> </button>
                <?php
                  }else{
                ?>
                <button hash="<?php echo $tkn; ?>" data="<?php echo $recover; ?>" rel="external" class="btn btn-secondary user_recover" u_id="<?php echo $cata['id'] ?>" u_name="<?php echo $cata["name"]; ?>" data-toggle="modal" data-target=".modal-recover"><i class="fas fa-recycle"></i> Recover </button>
                <?php
                  }
                 ?> 
              </div>
            </td>
          </tr>  
          <?php $acc_num++; endforeach ?>
          <?php endif ?>
          </tbody>
          <tfoot>
            <th>Id</th>
            <th>Name</th>
            <th>Username</th>
            <th>Sex</th>
            <th>Role</th>
            <th>Tell.</th>
            <th>Address</th>
            <th>Action</th>
          </tr>
          </tfoot>
        </table>
      <?php } ?>
    <?php
    if ($rfer == 1){
    ?>
        <div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                <div class="card card-default" style="border: 4px red solid;">
                  <div class="card-body">
                    <div align="center">
                        <i class="fa fa-folder-open fa-5x"></i>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                          <div align="center" style="text-align: center;">
                            <b style="color: red;">No Profiles available</b><br>
                          </div>
                        </div>
                    </div>
                    <hr>
                    <div align="center">
                           <button class="btn btn-warning" disabled="disabled">these Profiles will be available soon</button>
                    </div>
                  </div>
                </div>
            </div>
        </div> 
    <?php
         }
    ?>
            </div>
        </div>
    </div>
</div>


<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Confirm</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Delete This User?</th>
                </tr>
                <tr>
                  <td>User Id</td>
                  <td id="u_id"> :</td>
                </tr>
                <tr>
                  <td>User Name : </td>
                  <td id="u_name"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="md_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <a class="btn btn-danger" id="user_delete" hash=""><i class="fas fa-trash"></i> Delete This User</a>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>

<div class="modal fade modal-recover" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Confirm</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Recover This User?</th>
                </tr>
                <tr>
                  <td>User Id</td>
                  <td id="u_id"> :</td>
                </tr>
                <tr>
                  <td>User Name : </td>
                  <td id="u_name"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="md_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <a class="btn btn-secondary" id="user_recover" hash=""><i class="fas fa-recycle"></i> Recover This User</a>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>

<!--
<div class="modal fade" id="modal-default2">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Change user password</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
            Change user password when he/she forget it !<hr>
            <form method="post" id="sec_p">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <input type="hidden" name="from" value="<?php echo hdev_url::next(hdev_url::get_url_full()); ?>">
              <input type="hidden" name="ref" value="admin_security_edit">
              <input type="hidden" name="ed_ref" value="" id="track">
              <div class="form-group">
              <label for="r_acc_name">
                Username :
              </label>
              <div class="input-group mb-3">
                <input type="text" id="re_track" class="form-control" required="true" readonly>
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-user-cog"></span>
                  </div>
                </div>
              </div>
            </div>
              <div class="form-group">
              <label for="r_acc_name">
                New password :
              </label>
              <div class="input-group mb-3">
                <input type="password" name="n_p" id="re_track" class="form-control" placeholder="New password" required="true">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-pen"></span>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <label for="r_acc_name">
                Re-type new password :
              </label>
              <div class="input-group mb-3">
                <input type="password" name="n_p2" id="desc" class="form-control" placeholder="Re-type new password" required="true">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-pen"></span>
                  </div>
                </div>
              </div>
            </div>
            <div class="wait" align="center"></div>
            </form>
          </div>
        </div>
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="c_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="admin_sec"><i class="fas fa-save"></i> <?php echo hdev_lang::on("data","save_change"); ?></button>
      </div>
    </div>
  </div>
</div>-->



<div class="modal fade modal-reg">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Register New Admin</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
                  <form method="post" id="reg_auth">
                    <?php 
                      $csrf = new CSRF_Protect();
                      $csrf->echoInputField();
                    ?>
                    <input type="hidden" name="ref" value="reg_auth">
                      <div class="form-group">
                      <label for="name">
                        Names :
                      </label>
                      <div class="input-group mb-3">
                        <input type="text" name="name" id="name" class="form-control" placeholder="Names" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-user-tie"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="sex">
                        Sex :
                      </label>
                      <div class="input-group mb-3">
                        <select name="sex" id="sex" class="form-control" required="true">
                          <option value="">select sex</option>
                          <option value="M">Male</option>
                          <option value="F">Female</option>
                        </select>
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-user-friends"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="role">
                        Role :
                      </label>
                      <div class="input-group mb-3">
                        <select name="role" id="role" class="form-control" required="true" readonly>
                          <option value="">select Role</option>
                          <option value="admin" selected="selected">Admin</option>
                        </select>
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-user-shield"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="tell">
                        Telephone :
                      </label>
                      <div class="input-group mb-3">
                        <input type="text" name="tell" id="tell" class="form-control" placeholder="Telephone" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-phone"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="uname"> 
                        Userame :
                      </label>
                      <div class="input-group mb-3">
                        <input type="text" name="uname" id="uname" class="form-control" placeholder="Userame" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-user"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="address"> 
                        Address :
                      </label>
                      <div class="input-group mb-3">
                        <input type="text" name="address" id="address" class="form-control" placeholder="Address" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-map-marker-alt"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="psw">
                        Password :
                      </label>
                      <div class="input-group mb-3">
                        <input type="text" name="psw" id="psw" class="form-control" placeholder="Password" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="re_psw">
                        Re-type Password :
                      </label>
                      <div class="input-group mb-3">
                        <input type="text" name="re_psw" id="re_psw" class="form-control" placeholder="Re-type Password" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="wait" align="center"></div>
                    </div>
                  </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-secondary" id="reg_auths"><i class="fas fa-save"></i> Register Admin</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>