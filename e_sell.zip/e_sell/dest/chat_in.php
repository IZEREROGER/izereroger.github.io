<?php 
  if (!hdev_log::loged()) {
    hdev_note::message("login first!");
    hdev_note::redirect(hdev_url::menu('h/login'));
    exit();
  }
	$chat_contact = hdev_data::order_sub_msg();
	//$chat_msg = hdev_data::order_msg(1);

	$chat_contact = array();
	//$chat_msg = array();

	//var_dump($chat_msg);
 ?> 
<div class="content">
    <div class="container">
    	<!-- DIRECT CHAT -->
                <div class="card direct-chat direct-chat-secondary">
                  <div class="card-header">
                    <h3 class="card-title">Direct Chat&nbsp;[&nbsp;<span id="ct_head"></span>&nbsp;]</h3>

                    <div class="card-tools">
                      <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                      </button>
                      <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Contacts"
                              data-widget="chat-pane-toggle" id="recover_mask">
                              All messages
                        <i class="fas fa-comments"></i><span data-toggle="tooltip" title="New Messages" class="badge badge-secondary ctmg"></span></button>
                      <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
                      </button>
                    </div>
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body" id="chat_div">
                    <div class="direct-chat-messages">
                      
                    </div>
                    <!-- conv are loaded here -->
                    <div class="direct-chat-contacts">
                      
                    </div>
                  </div>
                  <!-- /.card-body -->
                  <div class="card-footer">
                    <form action="#" method="post" id="chat_fm">
                     <div class="chat_msg_cover">
                      <?php 
		                  $csrf = new CSRF_Protect();
		                  $csrf->echoInputField();
		                  $u = hdev_log::uid();
		                ?>
                     </div>
                     <input type="hidden" name="ref" value="chat_msg">
                     <input type="hidden" name="mask" value="<?php echo hdev_data::last_new_message(); ?>" id="chat_mask" onchange="//msg_init();">
                     <input type="hidden" name="parts" value="<?php echo $u; ?>" >
                     <div class="">
                     	<div align="center" class="wait">
                     	</div>
                     </div>
                      <textarea name="message" placeholder="Type Message ..." class="form-control" value="" id="msgh"></textarea>
                      <div class="input-group">
                          <button type="submit" class="btn btn-block btn-secondary" id="ct_msg">Send</button>
                      </div>
                    </form>
                  </div>
                  <!-- /.card-footer-->
                </div>
    </div>
</div>
<?php $msgin = "1"; ?> 