<div class="content">
      <div class="container">
      	<form method="post" id="ck_form" action="<?php echo hdev_url::menu('h/login'); ?>">
            <input type="hidden" id="acc_ref" name="acc" value="yes">
      	    <div class="card">
              <div class="card-header bg-secondary">
                	<div align="center" style="text-align: center;">
                		<h3><i>Your Shopping cart</i></h3>
                	</div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 300px;">
              	
                <table class="table table-head-fixed table-footer-fixed table-bordered text-nowrap">
                  <thead>
                      <th class="bg-secondary">#</th>
                      <th class="bg-secondary">Size</th>
                      <th class="bg-secondary">Product Image</th>
                      <th class="bg-secondary">Product Name</th>
                      <th class="bg-secondary">Price/unit</th>
                      <th class="bg-secondary">Quantity</th>
                      <th class="bg-secondary">Total Price</th>
                      <th class="bg-secondary">Action</th>
                  </thead>
                  <tbody class="cart_check">
                    <tr>
                      <td colspan="4">
                        #
                      </td> 
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
              <div class="card-footer"> 
                <?php if (hdev_log::loged()): ?>
                <button type="button" class="btn btn-block btn-outline-secondary" onclick="$('#acc_ref').val('yes');$('#ck_form').submit();">
                  <i class="fa fa-check-circle"></i>
                  Make an order
                  <i class="fa fa-shipping-fast"></i>
                </button>

                <?php else: ?>
                <button type="button" class="btn btn-block btn-outline-secondary" data-toggle="modal" data-target="#modal-default">
                  <i class="fa fa-check-circle"></i>
                  Make an order
                  <i class="fa fa-shipping-fast"></i>
                </button>
                <?php endif ?>
              </div>
            </div>
            <!-- /.card -->
        </form>
   	  </div>
</div> 



<div class="modal fade" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Choose check out account</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button> 
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
            <p>
              <table class="table">
                <tr>
                  <td>
                    <button type="button" onclick="$('#acc_ref').val('yes');$('#ck_form').submit();" class="btn btn-block btn-secondary">I have an account! i need to log in.</button>
                  </td>
                </tr>
                <tr>
                  <td>
                    <button type="button" onclick="$('#acc_ref').val('reg');$('#ck_form').submit();" class="btn btn-block btn-primary">I need to create an account</button>
                  </td>
                </tr>
                <tr>
                  <td>
                    <button type="button" onclick="$('#acc_ref').val('no');$('#ck_form').submit();" class="btn btn-block btn-success">I need to make an order as a guest!</button>
                  </td>
                </tr>
              </table>
            </p>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-block btn-secondary" data-dismiss="modal" id="c_close"><i class="fas fa-times-circle"></i>&nbsp;Close </button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>