<?php 
  $c_p = hdev_data::get_products($_SESSION['act_url'][3],"menu");
  $link_1 = hdev_url::menu(hdev_data::get_cat($c_p["category"],"info")["link"]);
  $llink_1 = hdev_url::menu(hdev_data::get_brand($c_p["brand"],"info")["link"]);
  $link3 = $c_p["elink"];
  $link_2 = urldecode($link3);
  $cat = hdev_data::get_cat($c_p["category"],"info")["name"];
  $brand = hdev_data::get_brand($c_p["brand"],"info")["name"];
  $b_nm = $c_p["name"];
  $b_dsc = $c_p["desc"];
  $pic = $c_p["pic"];
  $price = $c_p["price"];
  $vote = hdev_data::product_view($_SESSION['act_url'][3]);
  $counter = 1;
?>
<div class="content">
      <div class="container">
       <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline">
              <div class="card-header">
                <div class="user-block">
                  <span class="username"> Product preview </span>
                </div>
                <!-- /.user-block -->
                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Mark as read">
                    <i class="far fa-circle"></i></button>
                  <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
                  </button>
                </div>
                <!-- /.card-tools -->
              </div>
              <div class="card-body">
              <div class="row">
                <div class="col-sm-6">
                  <div style="height: 30% !important;">
                    <div class="sp-loading"><img src="<?php echo hdev_url::menu('dist/img/sp-loading.gif');?>" alt=""><br>LOADING IMAGES</div>
                    <div class="sp-wrap">

                      <?php foreach (hdev_data::product_images($pic) as $key): ?>
                      <a href="<?php echo $key ?>"><img src="<?php echo $key ?>"></a><?php endforeach ?>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6">
                  <p>Product category : <a style="color: black;" href="<?php echo $link_1; ?>"><b><i><?php echo $cat; ?> Category</i></b></a></p>
                  <p>Product brand : <a style="color: black;" href="<?php echo $llink_1; ?>"><b><i><?php echo $brand; ?> Brand</i></b></a></p>
                  <p></p>
                  <p>Product name : <b><i><?php echo $b_nm; ?></i></b></p>
                  <p></p>
                  <p>Product description : <b><i><?php echo $b_dsc; ?></i></b></p>
                  <p></p>
                  <p>Product Price : <b><i><?php echo $price.APP_CURRENCY; ?></i></b></p>
                  <?php 
                    $sized1 = explode('^^^',hdev_data::get_products($_SESSION['act_url'][3])['b_size']);
                   ?>
                              
                    <select class="form-control" onchange="$('.mr_cart_<?php echo $counter; ?>').attr('sizes',$(this).val());">
                      <option value="">Select size</option>
                   <?php foreach ($sized1 as $sizedv): ?>
                    <option value="<?php echo $sizedv; ?>"><?php echo $sizedv; ?></option>
                   <?php endforeach ?>    
                    </select>  
                </div>
              </div>
              <hr>
              <div class="row">
                <div class="col-sm-6">
                  <div align="center">
                    <i style="font-weight: bold;">
                      <?php echo $b_nm; ?> Product
                    </i>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div align="center">
                    <div class="btn-group">
                      <i class="bg-info" style="padding: 5px;"><?php echo $price; ?> Frw</i>
                      <?php if (!hdev_log::admin() && !hdev_log::super_admin()) { ?>
                          <button type="button" class="btn btn-outline-danger btn-sm add_to_cart mr_cart_<?php echo $counter; ?>" pid="<?php echo $_SESSION['act_url'][3]; ?>"><i class="fa fa-cart-plus"></i> Add to cart</button>
                      <?php 
                      } ?>
                      <?php
                        if (hdev_log::admin()) {
                      ?>
                      <a href="<?php echo hdev_url::menu('prod_edit/'.hdev_data::encd(trim($_SESSION['act_url'][3]))) ?>" class="memb_up btn btn-outline-success btn-sm">
                        <span class="fas fa-edit"></span>
                        <?php echo hdev_lang::on("form","edit"); ?>
                      </a>
                      <?php
                        }
                       ?>
                    </div>
                  </div>
                </div>
              </div>
                <?php if (hdev_log::loged() && !hdev_log::admin()): ?>
              <hr>
              Related Products
              <hr>
              <div class="row">
                <?php 
                  $get = hdev_data::get_cat_products($c_p["category"]);
                  $vate = hdev_data::cat_view($c_p['category']);
                  $rfer = 1;
                  if (is_array($get) && count($get)> 2 && isset($get['pic'])) {
                  $name1 = explode("^^", $get["name"]);
                  $icon1 = explode("^^", $get["icon"]);
                  $link1 = explode("^^", $get["link"]);
                  $pic1 = explode("^^", $get["pic"]); 
                  $id1 = explode("^^", $get["id"]); 
                  $var = array();
                  if (is_array($name1) && count($name1) > 2) {
                      $rfer = 0; 
                  }
                  for ($i=0; $i < count($name1); $i++) { 
                      $name = $name1[$i];
                      $icon = $icon1[$i];
                      $link = $link1[$i];
                      $pic = $pic1[$i];
                      $id = $id1[$i];
                      if (substr($link, 0,5) == "book.") {
                          $linko = str_ireplace("...", "/", $link);
                          array_push($var, array("name"=>$name,"link"=>hdev_url::menu($linko),"icon"=>$icon,"pic"=>$pic,"id"=>$id));
                      }
                  }}
                  //var_dump($var);
                 ?> 
                  <div class="col-sm-1"></div>
                  <div class="col-sm-10">
                    <div class="owl-carousel owl-theme">
                    <?php foreach ($var as $cata): ?>
                    <div class="item border-secondary border-top border-right border-left border-bottom card-body">
                          <div class="ribbon-wrapper">
                            <div class="ribbon bg-danger" style="font-size: 10px;">
                              New
                            </div>
                          </div> 
                          <div>
                            <?php if (isset(hdev_data::product_images($cata['pic'])[0]) && !empty(hdev_data::product_images($cata['pic'])[0])) {
                              $key = hdev_data::product_images($cata['pic'])[0];
                              ?>
                              <a href="<?php echo $cata['link']; ?>" title="<?php echo $cata["name"]; ?>" class="liftk"><img src="<?php echo $key ?>" alt="<?php echo $cata['name'] ?>" class="img-fluid"></a>
                            <?php
                            } ?>
                          </div>
                            <i style="text-align: center;"><h5 class="" style="text-align: center;"><div class="btn btn-block bg-gradient-secondary btn-flat"><span><?php echo $cata["name"]; ?></span></div></h5></i>
                            <p class="card-text btn btn-block btn-outline-secondary btn-flat" align="center"><?php echo hdev_data::get_products($cata['id'])['price'].APP_CURRENCY; ?></p>
                              <button type="button" href="<?php echo $cata['link']; ?>" class="btn btn-primary btn-sm btn-block liftk" title="<?php echo $cata["name"]; ?>"><i class="fa fa-eye"></i> Read more &nbsp;<i class="fas fa-angle-double-right"></i></button>
                    </div> 
                      <?php endforeach ?>
                    </div>   
                    <!-- /.card-body -->
                  </div>
                  <!-- /.card -->         
                </div>
                <?php endif ?>
              </div>
            </div>
          </div>
        </div>
  </div>
</div>