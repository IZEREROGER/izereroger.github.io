<?php 
    $new = new hdev_pager(hdev_session::get("pager_url"));
  $new->set(hdev_session::get("page"),6);//(current page,limit records)
  $all_rec = hdev_data::order_menu("",['custom','ref'=>"count"]);
 ?>
<div class="content">
      <div class="container">
            <div class="card">
              <div class="card-header bg-secondary">
                  <div>
                    <h3>Transaction History</h3>
                    <form method="GET" action="<?php echo hdev_url::get_url_part(); ?>">
                        <div class="panel-heading" style="font-weight: bold;">
                            <div style="text-transform: capitalize;"> 
                                
                                <?php 
                                if ($_GET) {
                                  if (isset($_GET['to']) && isset($_GET['from'])) {
                                    $to = $_GET['to'];
                                    $from = $_GET['from'];
                                    if (!empty($to) && !empty($from)) {
                                      $_SESSION['to'] = $to;
                                      $_SESSION['from'] = $from;
                                    }
                                  }elseif (isset($_GET['all_rep'])) {
                                    $_SESSION['to'] = "";
                                    $_SESSION['from'] = "";
                                  }
                                }
                                $from = (isset($_SESSION['from'])) ? $_SESSION['from'] : "" ;
                                $to = (isset($_SESSION['to'])) ? $_SESSION['to'] : "" ;
                                if (!empty($to) && !empty($from)) {
                                  echo "viewing report from : ";
                                  echo date_format(date_create($from),"d/m/Y"); 
                                  echo " - to : "; 
                                  echo date_format(date_create($to),"d/m/Y"); 
                                }
                                ?> 
                            </div><br>
                            <input type="hidden" name="root" value="custom_based">
                            From :
                            <input style="width: 15%;" type="date" name="from" class="btn btn-default"> 
                            To :
                            <input style="width: 15%;" type="date" name="to" class="btn btn-default"> 
                            
                            <button type="submit" class="btn btn-default">Generate report</button>
                            <a href="?all_rep=1"><button type="button" class="btn btn-default">View all days report</button></a> 
                        </div>
                    </form>
                  </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-3">
                <table class="table table-hover table-bordered dttable">
                  <thead>
                      <th class="bg-secondary">N<sup><u>O</u></sup></th>
                      <th class="bg-secondary">Client Name</th>
                      <th class="bg-secondary">Amount</th>
                      <th class="bg-secondary">Transaction Id</th>
                      <th class="bg-secondary">Transaction Ref.</th>
                      <th class="bg-secondary">Order Date</th>
                      <th class="bg-secondary">Details</th>
                  </thead>
                  <tbody>
                    <?php
                      $i = 1;
                      foreach (hdev_data::order_menu("",['custom','ref'=>"pg"]) as $orders) {

                      $ico_2 =  (trim($orders['payment_status']) == "approved") ? '<i class="fa fa-check-circle text-success text-sm"></i>' : '<i class="fa fa-exclamation-circle text-warning text-sm"></i>';
                    ?>
                    <tr>
                      <td>
                        <?php echo $orders['o_id']."&nbsp;".$ico_2; ?>
                      </td>
                      <td>
                        <?php echo $orders['name']; ?>
                      </td>
                      <td>
                        <?php echo $orders['total_price'].APP_CURRENCY; ?>
                      </td>
                      <td>
                        <?php echo $orders['tx_id']; ?>
                      </td>
                      <td>
                        <?php echo $orders['tx_ref']; ?>
                      </td>
                      <td>
                        <?php echo $orders['reg_date']; ?>
                      </td>
                      <td>
                        <button type="button" class="btn btn-flat btn-sm btn-primary tx_hist" data-toggle="modal" data-target=".modal-reg" detail-tx_ref="<?php echo $orders['tx_ref']; ?>" onclick="tx_hist($(this).attr('detail-tx_ref'),'<?php echo $orders['o_id']; ?>');"><i class="fa fa-eye"></i> View</button>
                      </td> 

                    </tr>
                    <?php
                      }
                    ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                <div align="center">
                  <h3>Total transactions amount: <?php echo hdev_data::order_menu("",['custom','ref'=>"amount"])." ".APP_CURRENCY; ?> </h3>
                </div>
                <?php 
                    $new->page_row($all_rec);//all records
                 ?>       
              </div>
            </div>
            <!-- /.card -->
      </div>
</div> 
<div class="modal fade modal-reg">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Transaction Full Details</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="tx_hist_contents">
        <div align="right">
          <button type="button" class="btn btn-secondary" id="rev_o_print" onclick="app_printer('tx_hist_contents','rev_o_print');" ><span class="fa fa-print"></span> Print This Receipt </button>
        </div>
        <div class="row" class="hd_pt">
          <div class="col-sm-12" align="center">
            <h3><?php echo APP_NAME." Receipt"; ?></h3>
          </div>
        </div>
        <div class="row" id="o_status">
          
        </div>
        <div class="row">
          <div class="col-sm-6">
            <table class="table">
              <tr>
                <th colspan="2" class="bg-secondary">
                  Personal information
                </th>
              </tr>
              <tr>
                <td>
                  Names
                </td>
                <td>
                  : <span id="o_name"></span>
                </td>
              </tr>
              <tr>
                <td>
                  Phone number
                </td>
                <td>
                  : <span id="o_tel"></span>
                </td>
              </tr>
              <tr>
                <td>
                  Email
                </td>
                <td>
                  : <span id="o_email"></span>
                </td>
              </tr>
            </table>
          </div>
          <div class="col-sm-6 border-left">
            <table class="table">
              <tr>
                <th colspan="2" class="bg-secondary">
                  Shipping and Payment info
                </th>
              </tr>
              <tr>
                <td>
                  Date
                </td>
                <td>
                  : <span id="o_date"></span>
                </td>
              </tr>
              <tr>
                <td>
                  Address
                </td>
                <td>
                  : <span id="o_address" class="text-xs"></span>
                </td>
              </tr>
              <tr>
                <td>
                  Transaction Ref
                </td>
                <td>
                  : <span id="o_tx_ref"></span>
                </td>
              </tr>
            </table>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12">
            <table class="table table-striped table-bordered">
              <thead>
                <tr>
                  <th class="bg-secondary">
                    Size
                  </th>
                  <th class="bg-secondary">
                    Product
                  </th>
                  <th class="bg-secondary">
                    Product Details
                  </th>
                  <th class="bg-secondary">
                    Price
                  </th>
                  <th class="bg-secondary">
                    Quantity
                  </th>
                  <th class="bg-secondary">
                    Subtotal
                  </th>
                </tr>
              </thead>
              <tbody id="o_products">
                <tr>
                  <td>
                    
                  </td>
                  <td>
                    
                  </td>
                  <td>
                    
                  </td>
                  <td>
                    
                  </td>
                  <td>
                    
                  </td>
                </tr>
              </tbody>
              <tfoot>
                <tr>
                  <th colspan="4">
                    Sub Total
                  </th>
                  <th>
                    <span id="o_sub_total"></span>
                  </th>
                </tr>
                <tr>
                  <th colspan="4">
                    Shipping Price
                  </th>
                  <th>
                    <span id="o_shipping"></span>
                  </th>
                </tr>
                <tr>
                  <th colspan="4" class="bg-secondary">
                    Total
                  </th>
                  <th class="bg-secondary">
                    <span id="o_total"></span>
                  </th>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-block btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>