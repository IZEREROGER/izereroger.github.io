<div class="content">
      <div class="container">
    <div class="card card-primary card-outline">
      <div class="card-header">
        <div class="user-block">
          <span class="text"> <i class="fa fa-folder-open"></i> Create category</span>
          <span class="description">Category creation</span>
        </div>
        <!-- /.user-block -->
        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Mark as read">
            <i class="far fa-circle"></i></button>
          <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
          <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
          </button>
        </div>
        <!-- /.card-tools -->
      </div>
      <div class="card-body" style="background: transparent !important;">
        <div class="row">
          <div class="col-sm-3"></div>
            <div class="col-sm-6">
              <form method="post" id="c_rg_form">
                <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
                <input type="hidden" name="ref" value="c_reg">
               <div class="card-primary card-outline border-right border-left border-bottom">
                  <div class="card-body">
                    <div align="center">
                        <i class="fa fa-shopping-cart fa-3x"></i>
                    </div>
                      <div class="form-group">
                      <label for="cata">
                        Category name
                      </label>
                      <div class="input-group mb-3">
                        <input type="text" name="cat_name" placeholder="Category name" class="form-control">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-shopping-cart"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="cata">
                        Category Description
                      </label>
                      <div class="input-group mb-3">
                        <textarea type="text" name="cat_desc" placeholder="Category Description" class="form-control" rows="1"></textarea>
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-fa-shopping-cart"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="wait" align="center"></div>
                      <button type="button" id="cat_reg_btn" class="btn btn-secondary btn-block">
                        <i class="fa fa-save"></i>
                        Create Category
                      </button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
            <div class="col-sm-3"></div>
            </div>
            </div>
        </div>
    </div>
</div>