<div class="content">
      <div class="container">
  <?php 
  $ppg = (isset($_SESSION['act_url']['3']) && is_numeric($_SESSION['act_url']['3'])) ? $_SESSION['act_url']['3'] : "1" ;
  $btnv = ceil(hdev_data::get_cat("","ex",['type'=>"count",'pg'=>"1"])/12);
  if ($ppg > $btnv || $ppg<0) {
    $ppg=1;
  }
  $category = hdev_data::groups("",['reject']);
  $rfer = 1; 
   ?> 

    <div class="card card-primary card-outline">
      <div class="card-header">
        <div class="user-block">
          <span class="text"> <i class="fa fa-folder-open"></i> Shops Info</span>
          <span class="description">Shops requests Rejected</span>
        </div>
        <!-- /.user-block -->
        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Mark as read">
            <i class="far fa-circle"></i></button>
          <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
          <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
          </button>
        </div>
        <!-- /.card-tools -->
      </div>
      <div class="card-body table-responsive p-3" style="background: #aaa !important;">
        <?php   if (isset($category[0]['g_name']) && !empty($category[0]['g_name'])) { ?>
        <table id="dttable" class="table table-hover table-bordered table-striped text-sm">
          <thead>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Tell</th>
            <th>Email</th>
            <th>Location</th>
          </tr>
          </thead>
          <tbody>
          <?php $acc_num=1; if (1==1) :?>
          <?php foreach ($category as $cata): ?>
            <?php $rfer = 0; 
              $csrf = new CSRF_Protect();
              $tkn = $csrf->getToken();
              $build = "ref:shop_recover;id:".$cata['g_id'].";src:1;from:".urlencode(hdev_url::get_url_full());
              $build2 = "refshop_delete;id:".$cata['g_id'].";src:1;from:".urlencode(hdev_url::get_url_full());
              $delete = hdev_data::encd("mod_close:#;app:".$tkn.";".$build2);
              $recover = hdev_data::encd("mod_close:#;app:".$tkn.";".$build);
            ?>
          <tr>
            <td><i><?php echo $cata['g_id']; ?></i></td>
            <td><?php echo ucfirst($cata["g_name"]); ?></td>
            <td><?php echo $cata["tell"]; ?></td>
            <td><?php echo $cata["email"]; ?></td>
            <td><?php echo $cata['g_location']; ?></td>
          </tr>  
          <?php $acc_num++; endforeach ?>
          <?php endif ?>
          </tbody>
          <tfoot>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Tell</th>
            <th>Email</th>
            <th>Location</th>
          </tr>
          </tfoot>
        </table>
      <?php } ?>
    <?php
    if ($rfer == 1){
    ?>
        <div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                <div class="card card-default" style="border: 4px red solid;">
                  <div class="card-body">
                    <div align="center">
                        <i class="fa fa-folder-open fa-5x"></i>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                          <div align="center" style="text-align: center;">
                            <b style="color: red;">No Shops available</b><br>
                          </div>
                        </div>
                    </div>
                    <hr>
                    <div align="center">
                           <button class="btn btn-warning" disabled="disabled">these Shops will be available soon</button>
                    </div>
                  </div>
                </div>
            </div>
        </div> 
    <?php
         }
    ?>
            </div>
        </div>
    </div>
</div>