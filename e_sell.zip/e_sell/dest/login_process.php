<?php 
    $all_products_in_cart = hdev_data::get_cart(1); 
    if ($all_products_in_cart > 0) {
      hdev_note::redirect(hdev_url::menu("h/login"));
    }else{
      hdev_note::redirect(hdev_url::menu(""));
    }
 ?>