<div class="content">
      <div class="container">
      	    <div class="card">
              <div class="card-header bg-secondary">
                  <div>
                    <h3>All Shipping Prices</h3>
                  </div>
              </div>
              <form method="POST" id="shipping_form">
                     <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
                <input type="hidden" name="from" value="<?php echo hdev_url::get_url_full(); ?>">
                    <input type="hidden" name="ref" value="shipping_reg">
              <!-- /.card-header -->
              <div class="card-body table-responsive p-3">
                <table class="table table-hover table-bordered dttable2">
                  <thead>
                      <th class="bg-secondary">N<sup><u>O</u></sup></th>
                      <th class="bg-secondary">Province</th>
                      <th class="bg-secondary">District</th>
                      <th class="bg-secondary">Shipping Price</th>
                  </thead>
                  <tbody>
                    <?php
                      $i = 1;
                      //var_dump(hdev_data::locations("all_districts"));
                      foreach (hdev_data::locations("all_districts") as $loc) {
                        $btn = str_ireplace(" ", "__", $loc['loc_district']);
                        $btn = "1_1_".$btn;
                    ?>
                    <tr>
                      <td>
                        <?php echo $i++; ?>
                      </td>
                      <td>
                        <?php echo $loc['loc_province']; ?>
                      </td>
                      <td>
                        <?php echo $loc['loc_district']; ?>
                      </td>
                      <td>
                        <div class="form-group">
                          <div class="input-group mb-3">
                            <input class="form-control" type="text" name="<?php echo $btn; ?>" placeholder="0" value="<?php echo $loc['ship_price']; ?>">
                            <div class="input-group-append">
                              <div class="input-group-text">
                                <?php echo APP_CURRENCY; ?>&nbsp;
                                <span class="fas fa-money-check-alt"></span>
                              </div>
                            </div>
                          </div>
                        </div>  
                      </td>

                    </tr>
                    <?php
                      }
                    ?>
                  </tbody>
                </table>
              </div>
              </form>
              <!-- /.card-body -->
              <div class="card-footer">
                <div class="row">
                  <div class="col-sm-12" align="center">
                    <div class="wait"></div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-12" align="center">
                    <button type="button" class="btn bg-gradient-secondary btn-block" id="shipping_form_btn">
                      <i class="fa fa-save"></i>&nbsp;
                      Save Prices
                      <i class="fa fa-shipping-fast"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <!-- /.card -->
   	  </div>
</div>