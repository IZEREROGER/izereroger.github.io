<?php 
$csrf = new CSRF_Protect();
$tkn = $csrf->getToken();
  switch (hdev_log::sid()) {
    case 'admin':
      $url = hdev_url::menu('app/report/'.$tkn.'/admin-payments');
      break;
    case 'agent':
      $url = hdev_url::menu('app/report/'.$tkn.'/admin-payments');
      break;      
    case 'land_lord':
      $url = hdev_url::menu('app/report/'.$tkn.'/land_lord-payments');
      break;    
    default:
      $url = hdev_url::menu('app/report/'.$tkn.'/land_lord-payments');
      break;
  }
 ?>
<div id="app_data">
      <div class="row">
          <div class="col-sm-12">
            <div class="card card-primary card-outline" style="height: 100%;">
              <div class="card-header"><?php echo $_SESSION['act_url'][0] ?></h5>
              </div>
              <div class="card-body table-responsive p-2">
                <div class="row">
                  <div class="col-sm-12" align="center" style="display: none!important;">
                    <a href="<?php echo $url ?>" ext_link="ok" target="_blank" class="btn btn-success"><span class="fa fa-print"></span> Print This Report</a><br>
                  </div>
                </div>
                <br>
                <div class="row">
                  <div class="col-sm-12" align="center">
                    <?php 
                      if ($_GET) {
                        if (isset($_GET['to']) && isset($_GET['from'])) {
                          $to = $_GET['to'];
                          $from = $_GET['from'];
                          if (!empty($to) && !empty($from)) {
                            $_SESSION['to'] = $to;
                            $_SESSION['from'] = $from;
                          }
                        }elseif (isset($_GET['all_rep'])) {
                          $_SESSION['to'] = "";
                          $_SESSION['from'] = "";
                        }
                      }
                      $from = (isset($_SESSION['from'])) ? $_SESSION['from'] : "" ;
                      $to = (isset($_SESSION['to'])) ? $_SESSION['to'] : "" ;
                      if (!empty($to) && !empty($from)) {
                        echo "viewing Transaction history from : ";
                        echo date_format(date_create($from),"d/m/Y"); 
                        echo " - to : "; 
                        echo date_format(date_create($to),"d/m/Y");
                        echo "<hr>"; 
                      }
                    ?> 
                  </div>
                </div>
                <form action="#">
                  <div class="row">
                    <div class="col-sm-4">
                      <div class="form-group">
                        <div class="input-group mb-1">
                          <div class="input-group-prepend">
                            <div class="input-group-text">
                              <span class="">From : </span>
                            </div>
                          </div>
                          <input type="date" name="from" id="t_username" class="form-control" placeholder="Agent Username" required="true">
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-4">
                      <div class="form-group">
                        <label for="to">
                        <div class="input-group mb-0">
                          <div class="input-group-prepend">
                            <div class="input-group-text">
                              <span>To : </span>
                            </div>
                          </div>
                          <input type="date" name="to" id="to" class="form-control">
                        </div>
                      </div>
                    </div>
                    <div class="col-sm-4" align="right">
                      <button type="submit" class="btn btn-secondary">Generate report</button>
                      <a href="?all_rep=1" ext_link="ok" class="btn btn-default">View all days report</a> 
                    </div>
                  </div>
                </form>
                <hr>
                <div class="btn-group">
                  <?php if (hdev_log::super_admin()): ?>
                  <button class="btn btn-warning ftb" data-toggle="modal" data-target=".modal-reg"><i class="fas fa-plus-circle"></i> Pay Shop <span class="fa fa-coins"></span></button>&nbsp;
                  <?php endif ?>
                </div>
                <?php //var_dump(hdev_data::get_student('',['year'])); ?>
                  <table class="table table-bordered table-hover table-striped text-nowrap" id="rasms_all_tables2">
                  <thead class="border-top">
                    <tr>
                      <th>Reg no.</th>
                      <th>Shop Id</th>
                      <th>Shop Name</th> 
                      <th>Total Amount</th>
                      <th>Payment Status</th>
                      <th>Payment Date</th>
                    </tr> 
                  </thead>
                  <tbody>
                    <?php
                      $csrf = new CSRF_Protect();
                      $tkn = $csrf->getToken(); 
                      foreach (hdev_data::payouts() AS $payout) { 
                      
                      $build = "ref:my_rent;id:".$payout['lp_id'].";src:".$payout["lp_status"].";from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $delete = "app/delete/".$tkn."/".hdev_data::encd($build);
                      $build2 = "ref:my_rent;id:".$payout['lp_id'].";src:".$payout["lp_status"].";from:".urlencode(hdev_url::get_url_host().$_SESSION['act_url'][2]);
                      $recover = "app/delete/".$tkn."/".hdev_data::encd($build2);
                    ?>

                    <tr>
                      <td>
                        <?php echo $payout["lp_id"];//.'--'.hdev_data::payouts(2,['sum','shop']); ?>
                      </td>
                      <td>
                        <?php echo $payout["l_id"]; ?>
                      </td>
                      <td>
                        <?php echo hdev_data::groups($payout["l_id"],['data'])['g_name']; ?>
                      </td>
                      <td>
                        <?php echo $payout["lp_amount"]; ?> frw
                      </td>
                      <td>
                        Successful
                      </td>
                      <td>
                        <?php echo hdev_data::date($payout["lp_date"],"date_time"); ?>
                      </td>
                    </tr>
                  <?php } ?>
                  </tbody>
                </table>
              </div>
              <div class="card-fotter">
                <div align="center" class="text-success">
                  <h3>Total Amount Paid to the Shops : <?php echo hdev_data::payouts("",['sum']); ?> Rwf</h3>
                </div>
              </div>
            </div>
          </div>
          <!-- /.col -->
      </div>
</div>



<?php if (hdev_log::super_admin()): ?> 
<div class="modal fade modal-reg" id="modal-default">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Shop Payment Registration</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <form method="POST" id="shop_payment">
            <input type="hidden" name="from" value="<?php echo hdev_url::get_url_full(); ?>">
          <div class="card-body register-card-body table-responsive p-3">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <input type="hidden" name="ref" value="shop_payment">
              <div class="row">
                <div class="col-sm-6" id="hs_data">
                  <span id="hash2" hash2="<?php echo $tkn; ?>"></span>
                  <div class="form-group">
                    <label for="l_id">
                      Shop Reg No.
                    </label>
                    <div class="input-group mb-3">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <span class="fas fa-user-secret"></span>
                        </div>
                      </div>
                      <input type="text" name="l_id" id="l_id" class="form-control" placeholder="Shop Reg No." required="true" oninput="shop($(this).val(),'hs_reg');shop_account($(this).val(),'hs_data');">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="sex">
                      Current Shop Balance
                    </label>
                    <div class="input-group mb-3">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <span class="fa fa-coins"></span>
                        </div>
                      </div>
                      <span class="form-control" id="acc_bal"></span>
                      <div class="input-group-append">
                        <div class="input-group-text">
                          <span id="acc_ico" ico="Frw">Frw</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="p_amount">
                      Amount to be Payed :
                    </label>
                    <div class="input-group mb-3">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <span class="fa fa-coins"></span>
                        </div>
                      </div>
                      <input type="text" name="p_amount" id="p_amount" class="form-control" placeholder="Amount to be Payed" required="true">
                      <div class="input-group-append">
                        <div class="input-group-text">
                          <span>Frw</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-6 border-left">
                  <table class="table border-bottom" id="hs_reg">
                    <tr>
                      <th class="bg-secondary" colspan="2"><span id="hash" hash="<?php echo $tkn; ?>"></span>Shop Info</th>
                    </tr>
                    <tr>
                      <td>Names</td>
                      <td> : <span id="name" class="ldd"></span></td>
                    </tr>
                    <tr>
                      <td>Email</td>
                      <td> : <span id="email" class="ldd"></span></td>
                    </tr>
                    <tr>
                      <td>Tell</td>
                      <td> : <span id="tel" class="ldd"></span></td>
                    </tr>
                  </table>
                </div>
              </div>
            <div class="wait" align="center"></div>
            <input type="hidden" name="mod_close" value="#ld_pay_close">
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="ld_pay_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="submit" class="btn btn-success" id="shop_payment_btn"><i class="fas fa-check-circle"></i> Pay Shop <span class="fa fa-coins"></span></button>
      </div>
    </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>
<?php endif ?>