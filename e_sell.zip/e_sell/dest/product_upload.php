<?php 
	$cat = hdev_data::get_cat();
	$brand = hdev_data::get_brand();
 ?>
<div class="content">
      <div class="container">
    <div class="card card-primary card-outline">
      <div class="card-header">
        <div class="user-block">
          <span class="text"> <i class="fa fa-plus-circle"></i> Product Upload</span>
          <span class="description">upload a new product on system</span>
        </div>
        <!-- /.user-block -->
        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Mark as read">
            <i class="far fa-circle"></i></button>
          <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
          <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
          </button>
        </div>
        <!-- /.card-tools -->
      </div>
      <div class="card-body" style="background: transparent !important;">
        <div class="row">
            <div class="col-sm-4">
                <div class="card-primary card-outline border-right border-left border-bottom">
                  <div class="card-body">
                    <div align="center">
                        <i class="fa fa-shopping-cart fa-3x"></i>
                    </div>
                    <form method="post" id="book_reg_form"  enctype="multipart/form-data" action="<?php echo hdev_url::menu('up');?>">
                    	 <?php 
						      $csrf = new CSRF_Protect();
						      $csrf->echoInputField();
						    ?>
                    	<input type="hidden" name="bo_store" value="ext">
                    	<input type="hidden" name="bo_link" value="1">
                    	<input type="hidden" name="ref" value="book_reg">

                    	<div class="form-group">
			                <label for="cata">
			                  Select category :
			                </label>
			                <div class="input-group mb-3">
			                  <select  class="form-control" name="cat_i" id='cata' required="true">
			                  	<option value="" selected>--select category--</option>
			                    <?php foreach ($cat as $p): ?>
			                    	<option value="<?php echo $p["c_id"]; ?>"><?php echo $p["c_name"]; ?></option>
			                	<?php endforeach ?>
			                  </select>
			                  <div class="input-group-append">
			                    <div class="input-group-text">
			                      <span class="fa fa-shopping-cart"></span>
			                    </div>
			                  </div>
			                </div>
			              </div> 
			            <div class="form-group">
			                <label for="cata">
			                  Select Brand :
			                </label>
			                <div class="input-group mb-3">
			                  <select  class="form-control" name="brand_i" id='cata' required="true">
			                  	<option value="" selected>--select Brand--</option>
			                    <?php foreach ($brand as $pp): ?>
			                    	<option value="<?php echo $pp["c_id"]; ?>"><?php echo $pp["c_name"]; ?></option>
			                	<?php endforeach ?>
			                  </select>
			                  <div class="input-group-append">
			                    <div class="input-group-text">
			                      <span class="fa fa-shopping-cart"></span>
			                    </div>
			                  </div>
			                </div>
			              </div>
                  </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="card-primary card-outline border-right border-left border-bottom">
                  <div class="card-body">
                    <div align="center">
                        <i class="fa fa-shopping-bag fa-3x"></i>
                    </div>
                    	<div class="form-group">
			                <label for="cata">
			                  Product name
			                </label>
			                <div class="input-group mb-3">
			                  <input type="text" name="bo_name" placeholder="Product name" class="form-control">
			                  <div class="input-group-append">
			                    <div class="input-group-text">
			                      <span class="fas fa-pen-alt"></span>
			                    </div>
			                  </div>
			                </div>
			              </div>
			              <div class="form-group">
											<label>Select Available Sizes : </label><br>
											<fieldset class="border-top border-bottom">
												<input type="checkbox" name="size[]" value="S"> S &nbsp;
												<input type="checkbox" name="size[]" value="M"> M &nbsp;
												<input type="checkbox" name="size[]" value="L"> L &nbsp;
												<input type="checkbox" name="size[]" value="XL"> XL &nbsp;
											</fieldset>
										</div>
			              <div class="form-group">
			                <label for="cata">
			                  Product Description
			                </label>
			                <div class="input-group mb-3">
			                	<textarea type="text" name="bo_desc" placeholder="Product Description" class="form-control" rows="1"></textarea>
			                  <div class="input-group-append">
			                    <div class="input-group-text">
			                      <span class="fas fa-address-book"></span>
			                    </div>
			                  </div>
			                </div>
			              </div>
                  </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="card-primary card-outline border-right border-left border-bottom">
                  <div class="card-body">
                    <div align="center">
                    	<i class="fa fa-file-image fa-3x"></i>
                    	<i class="fa fa-cloud-upload-alt fa-3x"></i>    
                    </div>
                          <div class="form-group">
			                <label for="cata2">
			                  Choose Product pictures to upload :
			                </label>
			                <div class="input-group mb-3">
			                  <input type="file" name="upic_a[]" class="form-control" id="upic_a" multiple required>
			                  <div class="input-group-append">
			                    <div class="input-group-text">
			                      <span class="fas fa-file-image"></span>
			                    </div>
			                  </div>
			                </div>
			              </div>
			              <div class="form-group">
			                <label for="cata2">
			                  Product price :
			                </label>
			                <div class="input-group mb-3">
			                  <input class="form-control" id="cata2" type="text" name="bo_price" placeholder="Product Price">
			                  <div class="input-group-append">
			                    <div class="input-group-text">
			                      <span class="fas fa-money-check-alt"></span>
			                    </div>
			                  </div>
			                </div>
			              </div>
                  </div>
                </div>
            </div>
            </div>
            <div class="row">
            	<div class="col-sm-12">
            		<div class="progress">
	                  <div class="progress-bar bg-primary progress-bar-striped" role="progressbar" id="progress-bar">
	                  </div>
	                </div>

            	</div>
            </div>
            <br>
            <div class="row">
            	<div class="col-sm-1"></div>
            	<div class="col-sm-10"> 
            		<div class="wait" align="center"></div>
            		<button type="submit" class="btn btn-secondary btn-block" id="book_reg_btn">
            			<i class="fa fa-cloud-upload-alt fa-2x"></i>
            			Upload Product
            			<i class="fa fa-book fa-2x"></i>
            		</button>
            	</div>
            	<div class="col-sm-1"></div>
            </div>
            </form>
            </div>
        </div>
    </div>
</div>