<?php 
$all_products = hdev_data::get_cart(2);
$ret = "";
$o = 0;
$pric = 0;
 ?>

<div class="content">
      <div class="container">
      	<?php
      		if (hdev_data::get_cart(1) > 0) {
      		}else{
      			hdev_note::redirect(hdev_url::menu("h/cartv"));
      			exit();
      		} 
      	 ?>
      	<div align="">
      	<form method="POST" id="auto_order">
            <div class="card">
              <div class="card-header bg-secondary">
                  <div align="center" style="text-align: center;">
                    <h3><i>Checkout</i></h3>
                  </div> 
              </div>
              <!-- /.card-header -->
              <div class="card-body p-0">
                <div class="row">
                  <div class="col-sm-6 p-3">
                    <div class="" align="center">
                      Personal Information
                    </div>
                    <hr>
                    <div class="form-group">
                      <label for="name">
                        Names : 
                      </label>
                      <div class="input-group mb-0">
                        <input type="text" id="name" name="name" placeholder="Names" class="form-control" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-shopping-cart"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="nid">
                        National Identity Card Number : 
                      </label>
                      <div class="input-group mb-0">
                        <input type="number" id="nid" name="nid" maxlength="16" oninput="id_validator($(this).val(),'#input_icon_id','#message_box_id','#oorder_reg')" placeholder="National Identity Card Number" class="form-control" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text" id="input_icon_id">
                            <span class="fas fa-shopping-cart"></span>
                          </div>
                        </div>
                      </div>
                      <div class="input-group mb-3" id="message_box_id">
                      </div>                      
                    </div>
                    <div class="form-group">
                      <label for="tell">
                        Phone Number : 
                      </label>
                      <div class="input-group mb-3">
                        <input type="text" id="tell" name="tell" placeholder="Phone Number" class="form-control" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-shopping-cart"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="email">
                        Email : 
                      </label>
                      <div class="input-group mb-3">
                        <input type="text" id="email" name="email" placeholder="Email" class="form-control" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-shopping-cart"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="" align="center">
                      Shipping address
                    </div>
                    <hr>
                    <div class="row">
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="province">
                            Province :
                          </label>
                          <div class="input-group mb-3">
                            <select id="province" class="form-control" required="true" onchange="mr_locator('district',$(this).val())">
                              <?php echo hdev_data::locations("province"); ?>
                            </select>
                            <div class="input-group-append">
                              <div class="input-group-text" province-ico="fas fa-user-tag">
                                <span class="fas fa-user-tag"></span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="h_location">
                            District :
                          </label>
                          <div class="input-group mb-3">
                            <select id="district" class="form-control" required="true" onchange="mr_locator('sector',$('#province').val(),$(this).val())">
                              <option value="">Select</option>
                            </select>
                            <div class="input-group-append">
                              <div class="input-group-text" district-ico="fas fa-user-tag">
                                <span class="fas fa-user-tag" ></span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="h_location">
                            Sector :
                          </label>
                          <div class="input-group mb-3">
                            <select id="sector" class="form-control" required="true" onchange="mr_locator('cell',$('#province').val(),$('#district').val(),$(this).val())">
                              <option value="">Select</option>
                            </select>
                            <div class="input-group-append">
                              <div class="input-group-text" sector-ico="fas fa-user-tag">
                                <span class="fas fa-user-tag" ></span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-6">
                          <div class="form-group">
                            <label for="h_location">
                              Cell :
                            </label>
                            <div class="input-group mb-3">
                              <select id="cell" class="form-control" required="true" onchange="mr_locator('village',$('#province').val(),$('#district').val(),$('#sector').val(),$(this).val())">
                                <option value="">Select</option>
                              </select>
                              <div class="input-group-append">
                                <div class="input-group-text" cell-ico="fas fa-user-tag">
                                  <span class="fas fa-user-tag" ></span>
                                </div>
                              </div>
                            </div>
                          </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="form-group">
                          <label for="h_location">
                            Village :
                          </label>
                          <div class="input-group mb-3">
                            <select id="village" name="s_location" class="form-control" onchange="update_shipping_price($(this).val())" required="true">
                              <option value="">Select</option>
                            </select>
                            <div class="input-group-append">
                              <div class="input-group-text" village-ico="fas fa-user-tag">
                                <span class="fas fa-user-tag" ></span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>  
                  <div class="col-sm-6 border-left p-3">
                    <div align="center">
                      Product information & Shipping Price
                    </div>
                    <hr>
                    <table class="table table-responsive table-bordered">
                      <thead>
                          <th class="bg-secondary">No</th>
                          <th class="bg-secondary">Size</th>
                          <th class="bg-secondary">Product Image</th>
                          <th class="bg-secondary">Product Name</th>
                          <th class="bg-secondary">Quantity</th>
                          <th class="bg-secondary">Total Price</th>
                      </thead>
                      <tbody>
                        <?php 
                          foreach ($all_products as $all) {
                            $bk = hdev_data::get_products($all['p_id']);
                            $o = 1;
                            $pic = hdev_data::product_images($bk['pic'])[0];
                            $name =  $bk['name'];
                            if (empty($bk['pic']) || $pic=="" || $bk['pic'] == "NULL" || $bk['pic'] == "none") {
                              $pict = "<p style='text-align: center;'><i class='fa fa-box'></i></p>";
                            }else{
                              $pict = '<img src="'.$pic.'" alt="'.$name.'" class="img-size-50 img-square mr-3">';
                            }
                            $price = $bk['price']*$all['qty'];
                            $pric += $price;
                        ?>                        
                        <tr>
                          <td><?php echo $all['p_id']; ?></td>
                          <td><?php echo $all['b_size']; ?></td>
                          <td><?php echo $pict; ?></td>
                          <td><?php echo $name ?> </td>
                          <td><?php echo $all['qty']; ?></td>
                          <td><?php echo $price.APP_CURRENCY; ?> </td>
                        </tr>
                        <?php
                          }
                         ?>
                        <tr>
                          <td colspan="5" align="right">
                            Sub Total
                          </td>
                          <td>
                            <span id="order_sub_total_price">
                              <?php echo $pric; ?>
                            </span>
                            <?php echo APP_CURRENCY; ?>
                          </td>
                        </tr>
                        <tr>
                          <td colspan="5" align="right">
                            Shipping Price
                          </td>
                          <td>
                            <span id="shipping_price">
                              <?php echo "0"." "; ?>
                            </span>
                            <?php echo APP_CURRENCY; ?>
                          </td>
                        </tr>
                      </tbody>
                      <tfoot class="bg-secondary">
                        <tr>
                          <td colspan="5" align="right">
                            Total
                          </td>
                          <td>
                            <span id="order_total_price">
                              <?php echo $pric; ?>
                            </span>
                            <?php echo APP_CURRENCY; ?>
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                    <div>
                      Payment Method
                    </div>
                    <hr>
                    <!--<h5><input type="radio" name="pay" value="1">&nbsp;<img src="<?php echo hdev_url::menu('dist/img/paypal.png');?>" style="height: 50px;width: 150px;">&nbsp;PayPal</h5>
                    <hr>-->
                    <h5><input type="radio" name="pay" value="2" checked="checked">&nbsp;<img src="<?php echo hdev_url::menu('dist/img/momo.jpg');?>" style="height: 50px;width: 150px;">&nbsp;Mobile Money</h5>
                    <hr>
                  </div>                
                </div>
              </div>
              <!-- /.card-body -->
              <div class="card-footer" align="center"> 
                <?php 
                    $csrf = new CSRF_Protect();
                    $csrf->echoInputField();
                ?>
                <input type="hidden" name="ref"  value="order">
                <div class="wait"></div>
                <button type="submit" style="display: none;" class="btn bg-gradient-secondary btn-lg" id="oorder_reg">
                  <i class="fa fa-shipping-fast"></i>&nbsp;
                  CLICK HERE TO COMPLETE ORDER &nbsp;
                  <i class="fa fa-shipping-fast"></i>
                </button>
              </div>
            </div>
      	</form>
      	</div>
      </div>
</div>