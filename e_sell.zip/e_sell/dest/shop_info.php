<div class="content">
      <div class="container">
  <?php 
  $ppg = (isset($_SESSION['act_url']['3']) && is_numeric($_SESSION['act_url']['3'])) ? $_SESSION['act_url']['3'] : "1" ;
  $btnv = ceil(hdev_data::get_cat("","ex",['type'=>"count",'pg'=>"1"])/12);
  if ($ppg > $btnv || $ppg<0) {
    $ppg=1;
  }
  $gp = hdev_data::groups(hdev_log::sid(),['data']);
  $category[0] = hdev_data::groups(hdev_log::sid(),['data']);
  $rfer = 1; 
   ?> 

    <div class="card card-primary card-outline">
      <div class="card-header">
        <div class="user-block">
          <span class="text"> <i class="fa fa-folder-open"></i> Shop Info</span>
          <span class="description">Current Shop info</span>
        </div>
        <!-- /.user-block -->
        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Mark as read">
            <i class="far fa-circle"></i></button>
          <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
          <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
          </button>
        </div>
        <!-- /.card-tools -->
      </div>
      <div class="card-body table-responsive p-3" style="background: #aaa !important;">
        <?php   if (isset($category[0]['g_name']) && !empty($category[0]['g_name'])) { ?>
        <table id="dttable" class="table table-hover table-bordered table-striped text-sm">
          <thead>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Tell</th>
            <th>Email</th>
            <th>Location</th>
            <th>Action</th>
          </tr>
          </thead>
          <tbody>
          <?php $acc_num=1; if (1==1) :?>
          <?php foreach ($category as $cata): ?>
            <?php $rfer = 0; 
              $csrf = new CSRF_Protect();
              $tkn = $csrf->getToken();
              $build = "ref:shop_recover;id:".$cata['g_id'].";src:1;from:".urlencode(hdev_url::get_url_full());
              $build2 = "ref:shop_delete;id:".$cata['g_id'].";src:1;from:".urlencode(hdev_url::get_url_full());
              $delete = hdev_data::encd("mod_close:#;app:".$tkn.";".$build2);
              $recover = hdev_data::encd("mod_close:#;app:".$tkn.";".$build);
            ?>
          <tr>
            <td><i><?php echo $cata['g_id']; ?></i></td>
            <td><?php echo ucfirst($cata["g_name"]); ?></td>
            <td><?php echo $cata["tell"]; ?></td>
            <td><?php echo $cata["email"]; ?></td>
            <td><?php echo $cata['g_location']; ?></td>
            <td>
              <button class="btn btn-success ftb" data-toggle="modal" data-target=".modal-reg"><i class="fas fa-plus-circle"></i> Edit Shop info</button>&nbsp;
            </td>
          </tr>  
          <?php $acc_num++; endforeach ?>
          <?php endif ?>
          </tbody>
          <tfoot>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Tell</th>
            <th>Email</th>
            <th>Location</th>
            <th>Action</th>
          </tr>
          </tfoot>
        </table>
      <?php } ?>
    <?php
    if ($rfer == 1){
    ?>
        <div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                <div class="card card-default" style="border: 4px red solid;">
                  <div class="card-body">
                    <div align="center">
                        <i class="fa fa-folder-open fa-5x"></i>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                          <div align="center" style="text-align: center;">
                            <b style="color: red;">No Shops available</b><br>
                          </div>
                        </div>
                    </div>
                    <hr>
                    <div align="center">
                           <button class="btn btn-warning" disabled="disabled">These Shops will be available soon</button>
                    </div>
                  </div>
                </div>
            </div>
        </div> 
    <?php
         }
    ?>
            </div>
        </div>
    </div>
</div>

<div class="modal fade modal-reg">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Shop info</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
                  <form method="post" id="edit_shop" enctype="multipart/form-data" action="<?php echo hdev_url::menu('up');?>">
                    <?php 
                      $csrf = new CSRF_Protect();
                      $csrf->echoInputField();
                    ?>
                    <input type="hidden" name="ref" value="edit_shop">
                    <input type="hidden" name="g_id" value="<?php echo hdev_log::sid(); ?>">
                      <div class="form-group">
                      <label for="name">
                        Shop Names :
                      </label>
                      <div class="input-group mb-3">
                        <input type="text" name="name" id="name" class="form-control" placeholder="Shop Names" required="true" value="<?php echo $gp['g_name']; ?>">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-user-tie"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="uname"> 
                        Shop Location :
                      </label>
                      <div class="input-group mb-3">
                        <input type="text" name="location" id="location" class="form-control" placeholder="Shop Location" required="true" value="<?php echo $gp['g_location']; ?>">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-user"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="address"> 
                        Shop Image :
                      </label>
                      <div class="input-group mb-3">
                        <input type="file" accept="image" name="image" id="shop_image" class="form-control" placeholder="Image" required="true">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-map-marker-alt"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="psw">
                        Shop Email :
                      </label>
                      <div class="input-group mb-3">
                        <input type="email" name="email" id="email" class="form-control" placeholder="Shop Email" required="true" value="<?php echo $gp['email']; ?>">
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fa">@</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="psw">
                        Shop Description :
                      </label>
                      <div class="input-group mb-3">
                        <textarea type="text" name="desc" id="desc" class="form-control" placeholder="Shop Description" required="true" ><?php echo $gp['g_desc']; ?></textarea>
                        <div class="input-group-append">
                          <div class="input-group-text">
                            <span class="fas fa-cubes"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!--progress bar -->
                    <div class="row">
                      <div class="col-sm-12">
                        <div class="progress">
                            <div class="progress-bar bg-primary progress-bar-striped" role="progressbar" id="progress-bar">
                            </div>
                          </div>

                      </div>
                    </div>
                    <div class="form-group">
                      <div class="wait" align="center"></div>
                    </div>
                  </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-outline-danger" data-dismiss="modal" id="reg_close"><span class="fa fa-times"></span> <?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-secondary" onclick="$('#edit_shop').submit();" id="reg_shops"><i class="fas fa-save"></i> Save Shop info</button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>