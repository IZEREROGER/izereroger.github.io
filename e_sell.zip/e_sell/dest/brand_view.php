<div class="content">
      <div class="container">
  <?php 
  $ppg = (isset($_SESSION['act_url']['3']) && is_numeric($_SESSION['act_url']['3'])) ? $_SESSION['act_url']['3'] : "1" ;
  $btnv = ceil(hdev_data::get_cat("","ex",['type'=>"count",'pg'=>"1"])/6);
  if ($ppg > $btnv || $ppg<0) {
    $ppg=1;
  }
  $category = hdev_data::get_brand("","menu",['type'=>"all",'pg'=>$ppg]);
  //var_dump(hdev_data::get_cat("","menu",['type'=>"all",'pg'=>'1']));exit();
  $rfer = 1; 
   ?> 

    <div class="card card-primary card-outline">
      <div class="card-header">
        <div class="user-block">
          <span class="text"> <i class="fa fa-folder-open"></i> brand Info</span>
          <span class="description">All brand in a system</span>
        </div>
        <!-- /.user-block -->
        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Mark as read">
            <i class="far fa-circle"></i></button>
          <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
          <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
          </button>
        </div>
        <!-- /.card-tools -->
      </div>
      <div class="card-body table-responsive p-3" style="background: transparent !important;">
        <?php   if (isset($category[0]['c_name']) && !empty($category[0]['c_name'])) { ?>
        <table class="table table-hover table-bordered table-striped text-sm">
          <thead>
          <tr>
            <th>icon</th>
            <th>Brand name</th>
            <th>Brand Description</th>
            <th>Brand views</th>
            <th>Brand products</th>
            <th>Action</th>
          </tr>
          </thead>
          <tbody>
          <?php $acc_num=1; if (1==1) :?>
          <?php foreach ($category as $cata): ?>
            <?php $rfer = 0; 
              $csrf = new CSRF_Protect();
              $tkn = $csrf->getToken();
              $build = "ref:brand_recover;id:".$cata['c_id'].";src:1;from:".urlencode(hdev_url::get_url_full());
              $build2 = "ref:brand_delete;id:".$cata['c_id'].";src:1;from:".urlencode(hdev_url::get_url_full());
              $delete = hdev_data::encd("mod_close:#;app:".$tkn.";".$build2);
              $recover = hdev_data::encd("mod_close:#;app:".$tkn.";".$build);
            ?>
          <tr>
            <td><i class="fas fa-cart-arrow-down"></i></td>
            <td><?php echo ucfirst($cata["c_name"]); ?></td>
            <td><?php echo ucfirst($cata["c_desc"]); ?></td>
            <td><?php echo $cata["views"]; ?></td>
            <td><?php echo hdev_data::get_brand_products($cata['c_id'],"menu",['count','1']) ?></td>
            <td>
              <div class="btn-group btn-group-sm">
              <?php //echo $cata['status'] ?>
                <?php 
                  if ($cata['b_status'] == 1) {
                ?>
                <button type="button" class="edit_accb btn btn-success" data-toggle="modal" data-target="#modal-default" d-n="<?php echo ucfirst($cata["c_name"]); ?>" d-desc="<?php echo ucfirst($cata["c_desc"]); ?>" d-i="<?php echo ucfirst($cata["c_id"]); ?>" >
                        <span class="fas fa-edit"></span>
                        <?php echo hdev_lang::on("form","edit"); ?>
                </button>

                  <button hash="<?php echo $tkn; ?>" data="<?php echo $delete; ?>" rel="external" class="btn btn-danger brand_delete" b_id="<?php echo $cata['c_id'] ?>" b_name="<?php echo $cata["c_name"]; ?>" data-toggle="modal" data-target=".modal-delete"><i class="fas fa-trash"></i> <?php echo hdev_lang::on("form","delete"); ?> </button>
                <?php
                  }else{
                ?>
                <button hash="<?php echo $tkn; ?>" data="<?php echo $recover; ?>" rel="external" class="btn btn-secondary brand_recover" b_id="<?php echo $cata['c_id'] ?>" b_name="<?php echo $cata["c_name"]; ?>" data-toggle="modal" data-target=".modal-recover"><i class="fas fa-recycle"></i> Recover </button>
                <?php
                  }
                 ?>    
              </div>
            </td>
          </tr> 
          <?php $acc_num++; endforeach ?>
          <?php endif ?>
          </tbody>
          <tfoot>
            <th>icon</th>
            <th>Brand name</th>
            <th>Brand Description</th>
            <th>Brand views</th>
            <th>Brand products</th>
            <th>Action</th>
          </tr>
          </tfoot>
        </table>
      <?php } ?>

    <?php
    if ($rfer == 1){
    ?>
        <div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                <div class="card card-default" style="border: 4px red solid;">
                  <div class="card-body">
                    <div align="center">
                        <i class="fa fa-folder-open fa-5x"></i>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                          <div align="center" style="text-align: center;">
                            <b style="color: red;">No brands available</b><br>
                          </div>
                        </div>
                    </div>
                    <hr>
                    <div align="center">
                           <button class="btn btn-warning" disabled="disabled">these Brands will be available soon</button>
                    </div>
                  </div>
                </div>
            </div>
        </div> 
    <?php
         }
    ?>
            </div>
            <div class="card-footer">
                <div class="row">
                     <?php if ($btnv != 0): ?>
                    <div class="col-sm-2">
                      <span class="btn btn-secondary">Page <?php echo $ppg." in ".$btnv; ?> pages</span>
                    </div>
                    <div class="col-sm-8">
                      <div class="btn-group iii_menu">
                        <?php 
                            $pg = $ppg;
                            $prev = $pg-1;
                            $next = $pg+1;
                            if ($pg != 1) {
                        ?>
                        <a href="<?php echo trim(hdev_url::get_url_host().$_SESSION['act_url'][2]); ?>/1" class="btn btn-success">First</a>
                        <?php
                            }
                            if ($prev > 0) {
                        ?>
                        <a href="<?php echo trim(hdev_url::get_url_host().$_SESSION['act_url'][2]); ?>/<?php echo($prev) ?>" class="btn btn-success">Previous</a>
                        <?php
                            }

                         ?>
                        
                        <?php 
                          for ($i=1; $i <= $btnv; $i++) { 
                            $gg = ($i==$pg) ? "btn-primary " : "btn-secondary" ;
                            $tg = $i-$pg;
                            if ($tg > 3 || $tg < -3) {
                            }else{
                        ?>
                        <a href="<?php echo trim(hdev_url::get_url_host().$_SESSION['act_url'][2]); ?>/<?php echo($i) ?>" class="btn <?php echo($gg) ?>"><b>Page <?php echo ($i); ?></b></a>
                        <?php
                          }
                          }
                         ?>


                        <?php
                            if ($next <= $btnv) {
                        ?>
                        <a href="<?php echo trim(hdev_url::get_url_host().$_SESSION['act_url'][2]); ?>/<?php echo($next) ?>" class="btn btn-success">Next</a>
                        <?php
                            }
                            if ($pg != $btnv) {
                        ?>
                        <a href="<?php echo trim(hdev_url::get_url_host().$_SESSION['act_url'][2]); ?>/<?php echo($btnv) ?>" class="btn btn-success">Last</a>
                        <?php
                            }
                         ?>
                     </div>
                    </div>
                    <div class="col-sm-2">
                      <?php if ($pg != $btnv) {
                          $ptt = $pg*6;
                          echo "Showing ".$ptt." brand, <br>In ".hdev_data::get_brand("","ext",['type'=>"count",'pg'=>'1'])." brand.";
                      }elseif ($pg == $btnv) {
                          echo "Showing ".hdev_data::get_brand("","ext",['type'=>"count",'pg'=>'1'])." brand, <br>In ".hdev_data::get_brand("","ext",['type'=>"count",'pg'=>'1'])." brand.";
                      }
                       ?>
                    </div>
                    <?php else: ?>
                      <div class="col-sm-12">
                        --
                      </div>
                     <?php endif ?>
                  </div>
            </div>
        </div>
    </div>
</div>





<div class="modal fade" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Brand </h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">

            <form method="post" id="edit_cat">
              <?php 
                  $csrf = new CSRF_Protect();
                  $csrf->echoInputField();
                ?>
              <input type="hidden" name="from" value="<?php echo hdev_url::next(hdev_url::get_url_full()); ?>">
              <input type="hidden" name="ref" value="brand_edit">
              <input type="hidden" name="ed_ref" value="" id="track">
              <div class="form-group">
              <label for="r_acc_name">
                Brand name :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="cat_name" id="re_track" class="form-control" placeholder="Brand name " required="true">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-pen"></span>
                  </div>
                </div>
              </div>
            </div>
            <div class="form-group">
              <label for="r_acc_name">
                Brand Description :
              </label>
              <div class="input-group mb-3">
                <input type="text" name="cat_desc" id="desc" class="form-control" placeholder="Brand Description " required="true">
                <div class="input-group-append">
                  <div class="input-group-text">
                    <span class="fas fa-pen"></span>
                  </div>
                </div>
              </div>
            </div>
            <div class="wait" align="center"></div>
            </form>
          </div>
          <!-- /.form-box -->
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="c_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <button type="button" class="btn btn-primary" id="c_track"><i class="fas fa-save"></i> <?php echo hdev_lang::on("data","save_change"); ?></button>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>




<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Confirm</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Delete This Brand?</th>
                </tr>
                <tr>
                  <td>Brand Id</td>
                  <td id="b_id"> :</td>
                </tr>
                <tr>
                  <td>Brand Name : </td>
                  <td id="b_name"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="md_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <a class="btn btn-danger" id="brand_delete" hash=""><i class="fas fa-trash"></i> Delete This Brand</a>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>

<div class="modal fade modal-recover" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Confirm</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Recover This Brand?</th>
                </tr>
                <tr>
                  <td>Brand Id</td>
                  <td id="b_id"> :</td>
                </tr>
                <tr>
                  <td>Brand Name : </td>
                  <td id="b_name"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="md_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <a class="btn btn-secondary" id="brand_recover" hash=""><i class="fas fa-recycle"></i> Recover This Brand</a>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>