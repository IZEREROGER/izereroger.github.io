<div class="content">
      <div class="container">
  <?php 
  $ppg = (isset($_SESSION['act_url']['3']) && is_numeric($_SESSION['act_url']['3'])) ? $_SESSION['act_url']['3'] : "1" ;
  $category = hdev_data::get_products("","top");

  //var_dump($category);
  $rfer = 0;
  //var_dump(hdev_data::get_cat("","menu",['type'=>"all",'pg'=>'1']));exit();
   ?>
    <div class="card card-primary card-outline">
      <div class="card-header">
        <div class="user-block">
          <span class="text"> <i class="fa fa-folder-open"></i> Top 10 Products</span>
          <span class="description">Most viewed 10 Products</span>
        </div>
        <!-- /.user-block -->
        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Mark as read">
            <i class="far fa-circle"></i></button>
          <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
          <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
          </button>
        </div>
        <!-- /.card-tools -->
      </div>
      <div class="card-body" style="background: transparent !important;">
        <div class="row">
            <?php   if (isset($category[0]['name']) && !empty($category[0]['name'])) {
              foreach ($category as $cata): ?>
              <?php $rfer = 1; ?>
            <div class="col-sm-4">
                <div class="card-primary card-outline border-right border-left border-bottom">
                  <div class="card-body">
                    <div align="center">
                        <div style="height: 30% !important;">
                          <div class="sp-loading"><img src="<?php echo hdev_url::menu('dist/img/sp-loading.gif');?>" alt=""><br>LOADING IMAGES</div>
                          <div class="sp-wrap">

                            <?php foreach (hdev_data::product_images($cata['pic']) as $key): ?>
                            <a href="<?php echo $key ?>"><img src="<?php echo $key ?>" alt="<?php echo $cata['name'] ?>"></a><?php endforeach ?>
                          </div>
                        </div>
                    </div>
                    
                  </div>
                  <div class="card-footer">
                    <div class="row">
                        <div class="col-sm-12">
                          <div align="center" style="text-align: center;">
                            <?php echo ucfirst($cata["name"]); ?><br>
                            Views : <b><?php echo $cata["views"]; ?></b><br>
                            Orders : <b><?php echo $cata["download"]; ?></b>
                          </div>
                          <hr>
                          <b><i>Description :</i></b> <?php echo ucfirst($cata["desc"]); ?>
                        </div>
                    </div>
                    <hr>
                    <div align="center">
                        <a href="<?php echo hdev_url::menu($cata['link']); ?>">
                            <button class="btn btn-secondary"><i class="fa fa-eye"></i> view Details</button>
                        </a>
                    </div>
                  </div>
                </div>
            </div>
            <?php endforeach ?>
            <?php 
              }else{
              } ?>
            </div>
    <?php
    if ($rfer == 0){
    ?>
        <div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                <div class="card card-default" style="border: 4px red solid;">
                  <div class="card-body">
                    <div align="center">
                        <i class="fa fa-folder-open fa-5x"></i>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                          <div align="center" style="text-align: center;">
                            <b style="color: red;">No Products available</b><br>
                          </div>
                        </div>
                    </div>
                    <hr>
                    <div align="center">
                           <button class="btn btn-warning" disabled="disabled">These Products will be available soon</button>
                    </div>
                  </div>
                </div>
            </div>
        </div> 
    <?php
         }
    ?>
            </div>
            <div class="card-footer">
                <div class="row">
                    <div class="col-sm-12">
                      Most 10 Viewed products at <?php echo APP_NAME; ?>
                    </div>
                  </div>
            </div>
        </div>
    </div>
</div>