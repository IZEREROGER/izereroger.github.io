<?php 
if (isset($_SESSION["act_url"][3]["id"]) && is_array($_SESSION["act_url"][3])) {
    if (isset($_SESSION["act_url"][3]["id"]) && is_numeric($_SESSION["act_url"][3]["id"])) {
        $catk = $_SESSION["act_url"][3]["id"];
    }else{
        $catk = 1; 
    }
    if (isset($_SESSION["act_url"][3]["pg"]) && is_numeric($_SESSION["act_url"][3]["pg"])) {
        $cat_pg = $_SESSION["act_url"][3]["pg"];
    }
}elseif (!isset($_SESSION["act_url"][3]["id"])) { 
    $catk = "";
    $cat_pg = 1;
}
$var = hdev_data::get_products("*" ,"*",["value",$cat_pg]);

//var_dump($var);

 ?> 
<div class="content">
      <div class="container">
    <div class="card card-primary card-outline">
      <div class="card-header">
        <div class="user-block">
          <span class="text"> <i class="fa fa-folder-open"></i> Products Info</span>
          <span class="description">All products in a system</span>
        </div>
        <!-- /.user-block -->
        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Mark as read">
            <i class="far fa-circle"></i></button>
          <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
          <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
          </button>
        </div>
        <!-- /.card-tools -->
      </div>
      <div class="card-body table-responsive p-3" style="background: transparent !important;">
        <table id="" class="table table-hover table-bordered table-striped text-sm">
          <thead>
          <tr>
            <th>Id</th>
            <th>Product  name</th>
            <th>Photo</th>
            <th>Price</th>
            <th>Brand</th>
            <th>Category</th>
            <th>Action</th>
          </tr>
          </thead>
          <tbody>
          <?php foreach ($var as $cata): ?>
            <?php
            //var_dump($cata);exit();
            $rfer = 0; 
            $csrf = new CSRF_Protect();
            $tkn = $csrf->getToken();
            $build = "ref:product_recover;id:".$cata['d'].";src:1;from:".urlencode(hdev_url::get_url_full());
            $build2 = "ref:product_delete;id:".$cata['d'].";src:1;from:".urlencode(hdev_url::get_url_full());
            $delete = hdev_data::encd("mod_close:#;app:".$tkn.";".$build2);
            $recover = hdev_data::encd("mod_close:#;app:".$tkn.";".$build);
            ?>
          <tr>
            <td><?php echo $cata['d']; ?></td>
            <td><?php echo $cata["name"]; ?></td>
            <td>
              <div>
                  <div class="sp-loading"><img src="<?php echo hdev_url::menu('dist/img/sp-loading');?>" alt=""><br>LOADING IMAGES</div>
                  <div class="sp-wrap">
                      <?php 
                        if (isset(hdev_data::product_images($cata['pic'])[0]) && !empty(hdev_data::product_images($cata['pic'])[0])) {
                          $key = hdev_data::product_images($cata['pic'])[0];
                        ?>
                          <a href="<?php echo $key ?>"><img src="<?php echo $key ?>" class="img-size-50 img-square mr-3" alt="<?php echo $cata['name'] ?>"></a>
                        <?php
                        }
                       ?>
                  </div>
                </div>
            </td>
            <td><?php echo hdev_data::get_products($cata['d'])['price'].APP_CURRENCY; ?></td>
            <td>
              <?php echo hdev_data::get_brand(hdev_data::get_products($cata['d'])['brand'],"info")["name"]; ?>
            </td>
            <td>
              <?php echo hdev_data::get_cat(hdev_data::get_products($cata['d'])['category'],"info")["name"]; ?>
            </td>
            <td>
              <div class="btn-group btn-group-sm">
                <?php //echo $cata['status'] ?>
                <a href="<?php echo hdev_url::menu(str_replace("...", "/",$cata['link'])); ?>" class="btn btn-info">
                  <i class="fas fa-eye"></i> <?php echo hdev_lang::on("form","view"); ?>
                </a>
                <?php 
                  if ($cata['status'] == 1) {
                ?>
                <a href="<?php echo hdev_url::menu('prod_edit/'.hdev_data::encd(trim($cata['d']))) ?>" class="memb_up btn btn-success">
                  <span class="fas fa-edit"></span>
                  <?php echo hdev_lang::on("form","edit"); ?>
                </a>
                  <button hash="<?php echo $tkn; ?>" data="<?php echo $delete; ?>" rel="external" class="btn btn-danger prod_delete" p_id="<?php echo $cata['d'] ?>" p_name="<?php echo $cata["name"]; ?>" p_price="<?php echo $cata["price"]; ?>" data-toggle="modal" data-target=".modal-delete"><i class="fas fa-trash"></i> <?php echo hdev_lang::on("form","delete"); ?> </button>
                <?php
                  }else{
                ?>
                <button hash="<?php echo $tkn; ?>" data="<?php echo $recover; ?>" rel="external" class="btn btn-secondary prod_recover" p_id="<?php echo $cata['d'] ?>" p_name="<?php echo $cata["name"]; ?>" p_price="<?php echo $cata["price"]; ?>" data-toggle="modal" data-target=".modal-recover"><i class="fas fa-recycle"></i> Recover </button>
                <?php
                  }
                 ?>
              </div>
            </td>
          </tr> 
          <?php endforeach ?>
          </tbody>
          <tfoot>
            <tr>
            <th>Id</th>
            <th>Product  name</th>
            <th>Photo</th>
            <th>Description</th>
            <th>Brand</th>
            <th>Category</th> 
            <th>Action</th>
          </tr>
          </tfoot>
        </table>
      </div>
            <div class="card-footer">
                <div class="row">
                    <?php  
                    //var_dump(hdev_data::get_products("*","count",['count',$cat_pg]));exit();
                      $btnv = ceil(hdev_data::get_products("*","count",['count',$cat_pg])/10);
                    //  var_dump($btnv);
                     ?>
                     <?php if ($btnv != 0): ?>
                    <div class="col-sm-2">
                      <span class="btn btn-secondary">Page <?php echo $cat_pg." in ".$btnv; ?> pages</span>
                    </div>
                    <div class="col-sm-8">
                      <div class="btn-group iii_menu">
                        <?php 
                            $pg = $cat_pg;
                            $prev = $pg-1;
                            $next = $pg+1;
                            if ($pg != 1) {
                        ?>
                        <a href="<?php echo trim(hdev_url::get_url_host().$_SESSION['act_url'][2]); ?>/1" class="btn btn-success liftk">First</a>
                        <?php
                            }
                            if ($prev > 0) {
                        ?>
                        <a href="<?php echo trim(hdev_url::get_url_host().$_SESSION['act_url'][2]); ?>/<?php echo($prev) ?>" class="btn btn-success liftk">Previous</a>
                        <?php
                            }
                         ?>
                        <?php 
                          for ($i=1; $i <= $btnv; $i++) { 
                            $gg = ($i==$pg) ? "btn-primary " : "btn-secondary" ;
                            $tg = $i-$pg;
                            if ($tg > 3 || $tg < -3) {
                            }else{
                        ?>
                        <a href="<?php echo trim(hdev_url::get_url_host().$_SESSION['act_url'][2]); ?>/<?php echo($i) ?>" class="btn liftk <?php echo($gg) ?>"><b>Page <?php echo ($i); ?></b></a>
                        <?php
                          }
                          }
                         ?>


                        <?php
                            if ($next <= $btnv) {
                        ?>
                        <a href="<?php echo trim(hdev_url::get_url_host().$_SESSION['act_url'][2]); ?>/<?php echo($next) ?>" class="btn btn-success liftk">Next</a>
                        <?php
                            }
                            if ($pg != $btnv) {
                        ?>
                        <a href="<?php echo trim(hdev_url::get_url_host().$_SESSION['act_url'][2]); ?>/<?php echo($btnv) ?>" class="btn btn-success liftk">Last</a>
                        <?php
                            }
                         ?>
                     </div>
                    </div>
                    <div class="col-sm-2">
                      <?php if ($pg != $btnv) {
                          $ptt = $pg*10;
                          echo "Showing ".$ptt." Products, <br>In ".hdev_data::get_products("*","count",['count',$cat_pg])." Products.";
                      }elseif ($pg == $btnv) {
                          echo "Showing ".hdev_data::get_products("*","count",['count',$cat_pg])." Products, <br>In ".hdev_data::get_products("*","count",['count',$cat_pg])." Products.";
                      }
                       ?>
                    </div>
                    <?php else: ?>
                      <div class="col-sm-12">
                        --
                      </div>
                     <?php endif ?>
                  </div>
            </div>
        </div>

    </div>
</div>



<div class="modal fade modal-delete" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Confirm</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Delete This Product?</th>
                </tr>
                <tr>
                  <td>Product Id</td>
                  <td id="p_id"> :</td>
                </tr>
                <tr>
                  <td>Product Name : </td>
                  <td id="p_name"></td>
                </tr>
                <tr>
                  <td>Product Price : </td>
                  <td id="p_price"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="md_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <a class="btn btn-danger" id="prod_delete" hash=""><i class="fas fa-trash"></i> Delete This Product</a>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>

<div class="modal fade modal-recover" id="modal-default">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Confirm</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="<?php echo hdev_lang::on("form","close"); ?>">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <div class="card">
          <div class="card-body register-card-body table-responsive p-3">
              <table class="table border-bottom">
                <tr>
                  <th colspan="2">Are you Sure That You Want To Recover This Product?</th>
                </tr>
                <tr>
                  <td>Product Id</td>
                  <td id="p_id"> :</td>
                </tr>
                <tr>
                  <td>Product Name : </td>
                  <td id="p_name"></td>
                </tr>
                <tr>
                  <td>Product Price : </td>
                  <td id="p_price"></td>
                </tr>
              </table>
            <div class="wait" align="center"></div>
          </div>
          <!-- /.form-box --> 
        </div><!-- /.card -->
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal" id="md_close"><?php echo hdev_lang::on("form","close"); ?></button>
        <a class="btn btn-secondary" id="prod_recover" hash=""><i class="fas fa-recycle"></i> Recover This Product</a>
      </div>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog --> 
</div>