<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?php echo APP_NAME; ?> </title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
</head>
<body>
<?php 
  if (!hdev_log::loged()) {
    hdev_note::message("login first!");
    hdev_note::redirect(hdev_url::menu('h/login'));
    exit();
  }
  $chat_contact = hdev_data::order_sub_msg();
  //$chat_msg = hdev_data::order_msg(1);

  $chat_contact = array();
  //$chat_msg = array();

  //var_dump($chat_msg);
 ?> 
<div class="content">
    <div class="container">
      <!-- DIRECT CHAT -->
                <div class="card direct-chat direct-chat-secondary">
                  <div class="card-header">
                    <h3 class="card-title">Direct Chat&nbsp;[&nbsp;<span id="ct_head"></span>&nbsp;]</h3>

                    <div class="card-tools">
                      <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                      </button>
                      <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Contacts"
                              data-widget="chat-pane-toggle" id="recover_mask">
                              All messages
                        <i class="fas fa-comments"></i><span data-toggle="tooltip" title="New Messages" class="badge badge-secondary ctmg"></span></button>
                      <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
                      </button>
                    </div>
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body" id="chat_div">
                    <div class="direct-chat-messages">
                      
                    </div>
                    <!-- conv are loaded here -->
                    <div class="direct-chat-contacts">
                      
                    </div>
                  </div>
                  <!-- /.card-body -->
                  <div class="card-footer">
                    <form action="#" method="post" id="chat_fm">
                     <div class="chat_msg_cover">
                      <?php 
                      $csrf = new CSRF_Protect();
                      $csrf->echoInputField();
                      $u = hdev_log::uid();
                    ?>
                     </div>
                     <input type="hidden" name="ref" value="chat_msg">
                     <input type="hidden" name="mask" value="<?php echo hdev_data::last_new_message(); ?>" id="chat_mask" onchange="//msg_init();">
                     <input type="hidden" name="parts" value="<?php echo $u; ?>" >
                     <div class="">
                      <div align="center" class="wait">
                      </div>
                     </div>
                      <textarea type="text" name="message" placeholder="Type Message ..." class="jjj" value="" id="msgh"></textarea>
                      <div class="input-group">
                          <button type="submit" class="btn btn-block btn-secondary" id="ct_msg">Send</button>
                      </div>
                    </form>
                  </div>
                  <!-- /.card-footer-->
                </div>
    </div>
</div>
<?php $msgin = "1"; ?> 
  <script>
    $(document).ready(function() {
        $('#msgh').summernote();
        // chatoooooooooo//////////////////////
    $("#chat_fm").on("submit",function(event){

    event.preventDefault();
    var formData = jQuery('#chat_fm').serialize();
    $.ajax({ 
          type: "POST",
          url: "<?php echo hdev_url::menu('up');?>",
          data: formData,
          beforeSend: function(){
            $('.wait').html($load_status);
            $('#ct_msg').hide();
           },
          success:function(html){
            $("#msgh").val("");
            if ('ok' == 'oklk'){
            }else{
              a = '<span class="text-danger">'+html+'</span>';
              $('.wait').html(a);

              setTimeout(function(){
                $('.wait').html('message sent');
              }, 6000);
               $('#ct_msg').show();
            }
          },
          error: function(){
            $('.wait').html('<span class"text-warning"><?php echo hdev_lang::on("validation","check_conn"); ?></span>');
            $('#ct_msg').show();
          }
        });
    });
    });
  </script>
</body>
</html>