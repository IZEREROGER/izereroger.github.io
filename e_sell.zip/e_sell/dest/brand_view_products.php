<!-- my start -->
<div class="content">
      <div class="container">
<?php 
if (is_array($_SESSION["act_url"][3])) {
    if (isset($_SESSION["act_url"][3]["id"]) && is_numeric($_SESSION["act_url"][3]["id"])) {
        $catk = $_SESSION["act_url"][3]["id"];
    }else{
        $catk = 1;
    }
    if (isset($_SESSION["act_url"][3]["pg"]) && is_numeric($_SESSION["act_url"][3]["pg"])) {
        $cat_pg = $_SESSION["act_url"][3]["pg"];
    }
}elseif (!is_array($_SESSION["act_url"][3])) {
    $catk = $_SESSION['act_url'][3];
    $cat_pg = 1;
}
$get = hdev_data::get_shop_products($catk ,"menu",["value",$cat_pg]);
//var_dump($get);
$rfer = 1;
if (is_array($get) && count($get)> 2 && isset($get['pic'])) {
  $name1 = explode("^^", $get["name"]);
  $icon1 = explode("^^", $get["icon"]);
  $link1 = explode("^^", $get["link"]);
  $pic1 = explode("^^", $get["pic"]); 
  $id1 = explode("^^", $get["id"]); 
  $var = array();
  if (is_array($name1) && count($name1) > 2) {
      $rfer = 0; 
  }
  for ($i=0; $i < count($name1); $i++) { 
      $name = $name1[$i];
      $icon = $icon1[$i];
      $link = $link1[$i];
      $pic = $pic1[$i];
      $id = $id1[$i];
      if (substr($link, 0,5) == "book.") {
          $linko = str_ireplace("...", "/", $link);
          array_push($var, array("name"=>$name,"link"=>hdev_url::menu($linko),"icon"=>$icon,"pic"=>$pic,"id"=>$id));
      }
  }
 ?> 
    <div class="card card-primary card-outline">
      <div class="card-header">
        <div class="user-block">
          <span class="text"> <i class="fa fa-folder-open"></i> <?php echo hdev_data::groups($catk,['data'])["g_name"]; ?> Products</span>
          <span class="description"><?php echo hdev_data::groups($catk,['data'])["g_name"]; ?></span>
        </div>
        <!-- /.user-block -->
        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Mark as read">
            <i class="far fa-circle"></i></button>
          <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
          <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
          </button>
        </div>
        <!-- /.card-tools -->
      </div>
      <div class="card-body" style="background: transparent !important;">
        <hr>
          <div class="card-group mb-30">
            <?php 
              $counter = 0;
              $counter_group = 1;
              $maxer = (is_array($var)) ? count($var) : 0 ;
              $maxer_rec = ($maxer%3);
              $countt = 1;
              foreach ($var as $cata) {
                $countt++;
                $counter++;
             ?>
                    <div class="border-secondary border-top border-right border-left border-bottom card">
                      
                          <div class="ribbon-wrapper">
                            <div class="ribbon bg-gradient-secondary" style="font-size: 10px;">
                              Fashion
                            </div>
                          </div> 
                            <?php if (isset(hdev_data::product_images($cata['pic'])[0]) && !empty(hdev_data::product_images($cata['pic'])[0])) {
                              $key = hdev_data::product_images($cata['pic'])[0];
                              ?>
                              <img src="<?php echo $key ?>" alt="<?php echo $cata['name'] ?>" style="height: 45vh;" class="card-img-top">
                            <?php
                            } ?>
                          <div class="card-body">
                            <i style="text-align: center;" class="card-text"><h5 class="" style="text-align: center;"><div class="btn btn-block bg-gradient-secondary btn-flat"><span><?php echo $cata["name"]; ?></span></div></h5></i>
                            <p class="card-text" align="center">
                              <?php 
                                $sized1 = explode('^^^',hdev_data::get_products($cata['id'])['b_size']);
                               ?>
                              
                                <select class="form-control" onchange="$('.mr_cart_<?php echo $counter; ?>').attr('sizes',$(this).val());">
                                  <option value="">Select size</option>
                               <?php foreach ($sized1 as $sizedv): ?>
                                <option value="<?php echo $sizedv; ?>"><?php echo $sizedv; ?></option>
                               <?php endforeach ?>    
                                </select>                                
                            </p>
                            <p class="card-text btn btn-block btn-outline-secondary btn-flat" align="center"><?php echo hdev_data::get_products($cata['id'])['price'].APP_CURRENCY; ?></p>
                           <p class="card-text btn btn-block btn-success btn-flat" align="center"><?php echo hdev_data::groups(hdev_data::get_products($cata['id'])['g_id'],['data'])['g_name']; ?></p>



                              <div align="btn-group btn-block"> 
                                <?php if (!hdev_log::admin() && !hdev_log::super_admin()) {
                                ?>

                                <button type="button" class="btn btn-outline-danger btn-sm mr_cart_<?php echo $counter; ?> add_to_cart" pid="<?php echo $cata['id']; ?>"><i class="fa fa-cart-plus"></i> Add to cart</button>
                                <?php
                                } ?>
                                <?php
                                  if (hdev_log::admin()) {
                                ?>
                                <a href="<?php echo hdev_url::menu('prod_edit/'.hdev_data::encd(trim($cata['id']))) ?>" class="memb_up btn btn-outline-success btn-sm">
                                  <span class="fas fa-edit"></span>
                                  <?php echo hdev_lang::on("form","edit"); ?>
                                </a>
                                <?php
                                  }
                                 ?>
                                <button type="button" href="<?php echo $cata['link']; ?>" class="btn btn-outline-primary btn-sm liftk"><i class="fa fa-eye"></i> Read more &nbsp;<i class="fas fa-angle-double-right"></i></button>                            
                                </div> 
                    </div> 
                  </div>
        <?php
            if (($counter%3) == 0) {
              echo '</div><div class="card-group mb-30">';
              $counter_group++;
            }
          }
         ?>
        <?php 
          if ($counter == $maxer) {
            //echo $maxer_rec;
            if ($maxer_rec == 1) {
              echo '<div class="card card-box"></div>';
              echo '<div class="card card-box"></div>';
            }elseif ($maxer_rec == 2) {
              echo '<div class="card card-box"></div>';
            }
          }
         ?>
        </div>
                <hr>
    <?php
         }else{
            $rfer == 1;
         }
    if ($rfer == 1){
    ?>
        <div class="card card-primary card-outline">
        <div class="row">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                <div class="card card-default" style="border: 4px red solid;">
                  <div class="card-body">
                    <div align="center">
                        <i class="fa fa-folder-open fa-5x"></i>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                          <div align="center" style="text-align: center;">
                            <b style="color: red;">No Products available in this Shop</b><br>
                          </div>
                        </div>
                    </div>
                    <hr>
                    <div align="center">
                           <button class="btn btn-warning" disabled="disabled">these Products will be available soon</button>
                    </div>
                  </div>
                </div>
            </div>
        </div> 
    <?php 
         }
    ?>
            </div>
            <div class="card-footer">
                <div class="row">
                    <?php  
                      $btnv = ceil(hdev_data::get_shop_products($catk,"menu",['count',$cat_pg])/24);
                     ?>
                     <?php if ($btnv != 0): ?>
                    <div class="col-sm-2">
                      <span class="btn btn-secondary">Page <?php echo $cat_pg." in ".$btnv; ?> pages</span>
                    </div>
                    <div class="col-sm-8">
                      <div class="btn-group iii_menu">
                        <?php 
                            $pg = $cat_pg;
                            $prev = $pg-1;
                            $next = $pg+1;
                            if ($pg != 1) {
                        ?>
                        <a href="<?php echo trim(hdev_url::get_url_host().$_SESSION['act_url'][2]); ?>/1" class="btn btn-success liftk">First</a>
                        <?php
                            }
                            if ($prev > 0) {
                        ?>
                        <a href="<?php echo trim(hdev_url::get_url_host().$_SESSION['act_url'][2]); ?>/<?php echo($prev) ?>" class="btn btn-success liftk">Previous</a>
                        <?php
                            }
                         ?>
                        <?php 
                          for ($i=1; $i <= $btnv; $i++) { 
                            $gg = ($i==$pg) ? "btn-primary " : "btn-secondary" ;
                            $tg = $i-$pg;
                            if ($tg > 3 || $tg < -3) {
                            }else{
                        ?>
                        <a href="<?php echo trim(hdev_url::get_url_host().$_SESSION['act_url'][2]); ?>/<?php echo($i) ?>" class="btn liftk <?php echo($gg) ?>"><b>Page <?php echo ($i); ?></b></a>
                        <?php
                          }
                          }
                         ?>


                        <?php
                            if ($next <= $btnv) {
                        ?>
                        <a href="<?php echo trim(hdev_url::get_url_host().$_SESSION['act_url'][2]); ?>/<?php echo($next) ?>" class="btn btn-success liftk">Next</a>
                        <?php
                            }
                            if ($pg != $btnv) {
                        ?>
                        <a href="<?php echo trim(hdev_url::get_url_host().$_SESSION['act_url'][2]); ?>/<?php echo($btnv) ?>" class="btn btn-success liftk">Last</a>
                        <?php
                            }
                         ?>
                     </div>
                    </div>
                    <div class="col-sm-2">
                      <?php if ($pg != $btnv) {
                          $ptt = $pg*4;
                          echo "Showing ".$ptt." Products, <br>In ".hdev_data::get_shop_products($catk,"menu",['count',$cat_pg])." Products.";
                      }elseif ($pg == $btnv) {
                          echo "Showing ".hdev_data::get_shop_products($catk,"menu",['count',$cat_pg])." Products, <br>In ".hdev_data::get_shop_products($catk,"menu",['count',$cat_pg])." Products.";
                      }
                       ?>
                    </div>
                    <?php else: ?>
                      <div class="col-sm-12">
                        --
                      </div>
                     <?php endif ?>
                  </div>
            </div>
        </div>
</div>
<!--my end -->