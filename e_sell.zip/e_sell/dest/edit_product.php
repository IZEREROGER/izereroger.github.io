<?php 
	$cato = hdev_data::get_cat();
	$brando = hdev_data::get_brand();  

	if (isset($_SESSION['act_url'][3]) && !empty($_SESSION['act_url'][3])) {
	}else{
		hdev_note::redirect(hdev_url::menu(""));
	}
	if (hdev_log::super_admin()) {
		hdev_note::redirect(hdev_url::menu(''));
	}
  $product_edit = $_SESSION['act_url'][3];
  $link_1 = hdev_url::menu(hdev_data::get_cat(hdev_data::get_products($product_edit,"menu")["category"],"info")["link"]);
  $llink_1 = hdev_url::menu(hdev_data::get_brand(hdev_data::get_products($product_edit,"menu")["brand"],"info")["link"]);
  $link3 = hdev_data::get_products($product_edit,"menu")["elink"];
  $link_2 = urldecode($link3);
  $cat = hdev_data::get_cat(hdev_data::get_products($product_edit,"menu")["category"],"info")["name"];
  $cat_id = hdev_data::get_products($product_edit,"menu")["category"];
  $bra_id = hdev_data::get_products($product_edit,"menu")["brand"];
  $brand = hdev_data::get_brand(hdev_data::get_products($product_edit,"menu")["brand"],"info")["name"];
  $b_nm = hdev_data::get_products($product_edit,"menu")["name"];
  $b_dsc = hdev_data::get_products($product_edit,"menu")["desc"];
  $pic = hdev_data::get_products($product_edit,"menu")["pic"];
  $price = hdev_data::get_products($product_edit,"menu")["price"];
  //var_dump(hdev_data::get_products($product_edit,"menu"));
  $size = explode('^^^',hdev_data::get_products($product_edit,"menu")['b_size']);
  $vote = hdev_data::product_view($product_edit);
  if (hdev_data::get_products($product_edit,"menu")["g_id"] != hdev_log::sid()) {
  	hdev_note::redirect(hdev_url::menu(""));exit();
  }
 ?>
<div class="content">
      <div class="container">
    <div class="card card-primary card-outline">
      <div class="card-header">
        <div class="user-block">
          <span class="text"> <i class="fa fa-plus-circle"></i> Edit Product</span>
          <span class="description">Edit product info</span>
        </div>
        <!-- /.user-block -->
        <div class="card-tools">
          <button type="button" class="btn btn-tool" data-toggle="tooltip" title="Mark as read">
            <i class="far fa-circle"></i></button>
          <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
          <button type="button" class="btn btn-tool" data-card-widget="remove"><i class="fas fa-times"></i>
          </button>
        </div>
        <!-- /.card-tools -->
      </div>
      <div class="card-body" style="background: transparent !important;">
        <div class="row">
            <div class="col-sm-4">
                <div class="card-primary card-outline border-right border-left border-bottom">
                  <div class="card-body">
                    <div align="center">
                        <i class="fa fa-shopping-cart fa-3x"></i>
                    </div>
                    <form method="post" id="book_edit_form"  enctype="multipart/form-data" action="<?php echo hdev_url::menu('up');?>">
                    	 <?php 
						      $csrf = new CSRF_Protect();
						      $csrf->echoInputField();
						    ?> 
                    	<input type="hidden" name="bo_store" value="ext">
                    	<input type="hidden" name="bo_link" value="1">
                    	<input type="hidden" name="ref" value="book_edit">
                    	<input type="hidden" name="mask" value="<?php echo $product_edit; ?>">

                    	<div class="form-group">
			                <label for="cata">
			                  Select category :
			                </label>
			                <div class="input-group mb-3">
			                  <select  class="form-control" name="cat_i" id='cata' required="true">
			                  	<option value="" selected>--select category--</option>
			                    <?php foreach ($cato as $p): ?>
			                    	<option value="<?php echo $p["c_id"]; ?>"<?php if ($p['c_id'] == $cat_id) {
			                    		echo ' selected=selected';
			                    	} ?>><?php echo $p["c_name"]; ?></option>
			                	<?php endforeach ?>
			                  </select>
			                  <div class="input-group-append">
			                    <div class="input-group-text">
			                      <span class="fa fa-shopping-cart"></span>
			                    </div>
			                  </div>
			                </div>
			              </div> 
			            <div class="form-group">
			                <label for="cata">
			                  Select Brand :
			                </label>
			                <div class="input-group mb-3">
			                  <select  class="form-control" name="brand_i" id='cata' required="true">
			                  	<option value="" selected>--select Brand--</option>
			                    <?php foreach ($brando as $pp): ?>
			                    	<option value="<?php echo $pp["c_id"]; ?>"<?php if ($pp['c_id'] == $bra_id) {
			                    		echo ' selected=selected';
			                    	} ?>><?php echo $pp["c_name"]; ?></option>
			                	<?php endforeach ?>
			                  </select>
			                  <div class="input-group-append">
			                    <div class="input-group-text">
			                      <span class="fa fa-shopping-cart"></span>
			                    </div>
			                  </div>
			                </div>
			              </div>
                  </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="card-primary card-outline border-right border-left border-bottom">
                  <div class="card-body">
                    <div align="center">
                        <i class="fa fa-shopping-bag fa-3x"></i>
                    </div>
                    	<div class="form-group">
			                <label for="cata">
			                  Product name
			                </label>
			                <div class="input-group mb-3">
			                  <input type="text" name="bo_name" placeholder="Product name" class="form-control" value="<?php echo $b_nm ?>">
			                  <div class="input-group-append">
			                    <div class="input-group-text">
			                      <span class="fas fa-pen-alt"></span>
			                    </div>
			                  </div>
			                </div>
			              </div>
			              <div class="form-group">
											<label>Select Available Sizes : </label><br>
											<fieldset class="border-top border-bottom">
												<input type="checkbox" name="size[]" value="S" <?php if (in_array('S', $size)): ?> checked='checked'<?php endif ?>> S &nbsp;
												<input type="checkbox" name="size[]" value="M" <?php if (in_array('M', $size)): ?> checked='checked'<?php endif ?>> M &nbsp;
												<input type="checkbox" name="size[]" value="L" <?php if (in_array('L', $size)): ?> checked='checked'<?php endif ?>> L &nbsp;
												<input type="checkbox" name="size[]" value="XL" <?php if (in_array('XL', $size)): ?> checked='checked'<?php endif ?>> XL &nbsp;
											</fieldset>
										</div>
			              <div class="form-group">
			                <label for="cata">
			                  Product Description
			                </label>
			                <div class="input-group mb-3">
			                	<textarea type="text" name="bo_desc" placeholder="Product Description" class="form-control" rows="1"><?php echo $b_dsc ?></textarea>
			                  <div class="input-group-append">
			                    <div class="input-group-text">
			                      <span class="fas fa-address-book"></span>
			                    </div>
			                  </div>
			                </div>
			              </div>
                  </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="card-primary card-outline border-right border-left border-bottom">
                  <div class="card-body">
                    <div align="center">
                    	<i class="fa fa-file-image fa-3x"></i>
                    	<i class="fa fa-cloud-upload-alt fa-3x"></i>    
                    </div>
                          <div class="form-group">
			                <label for="cata2">
			                  Choose Product pictures to upload :
			                </label>
			                <div class="input-group mb-3">
			                  <input type="file" name="upic_a[]" class="form-control" id="upic_a" multiple>
			                  <div class="input-group-append">
			                    <div class="input-group-text">
			                      <span class="fas fa-file-image"></span>
			                    </div>
			                  </div>
			                </div>
			              </div>
			              <div class="form-group">
			                <label for="cata2">
			                  Product price :
			                </label>
			                <div class="input-group mb-3">
			                  <input class="form-control" id="cata2" type="text" name="bo_price" placeholder="Product Price" value="<?php echo $price; ?>" onchange="alert('if you change this price it will affect all orders related to this product');">
			                  <div class="input-group-append">
			                    <div class="input-group-text">
			                      <span class="fas fa-money-check-alt"></span>
			                    </div>
			                  </div>
			                </div>
			              </div>
                  </div>
                </div>
            </div>
            </div>
            <div class="row">
            	<div class="col-sm-12">
            		<div class="progress">
	                  <div class="progress-bar bg-primary progress-bar-striped" role="progressbar" id="progress-bar">
	                  </div>
	                </div>

            	</div>
            </div>
            <br>
            <div class="row">
            	<div class="col-sm-1"></div>
            	<div class="col-sm-10"> 
            		<div class="wait" align="center"></div>
            		<button type="submit" class="btn btn-secondary btn-block" id="book_edit_btn">
            			<i class="fa fa-cloud-upload-alt fa-2x"></i>
            			Upload Product
            			<i class="fa fa-book fa-2x"></i>
            		</button>
            	</div>
            	<div class="col-sm-1"></div>
            </div>
            </form>
            </div>
        </div>
    </div>
</div>