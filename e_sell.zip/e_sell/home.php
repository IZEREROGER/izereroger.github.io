<?php 
  $load_reg_shop = 1;
 ?>
<style type="text/css">
  
    .carousel-item {
    height: 70% !important;
    border-radius: 20px;
    }
    main{
      padding-right: 10px;
      padding-left: 10px;
    }
    #myCarousel div,#mn_cnt{
      border-radius: 10px;
    }
    .carousel-item img{
      width: 100%!important;
      height: auto!important;
    }   
</style>
<div class="content">
      <div class="" style="padding: ;">
      <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <div class="carousel-indicators">
      <?php
          $m_data = hdev_data::load_view("slide");
          $num = count($m_data); 
           for ($i=0; $i < $num; $i++) { 
        $now2 = $i+1;
        if ($i == 0) {
          $indic = 'class="active" aria-current="true" aria-label="Slide 1"';
        }else{
          $indic = 'aria-label="Slide '.$now2.'"';
        }

      ?>
        <button type="button" data-target="#myCarousel" data-slide-to="<?php echo $i; ?>" <?php echo $indic; ?>></button>
      <?php
      } ?>
      </div>
      <div class="carousel-inner">
        <?php 
          $ct = 0;
          foreach ($m_data as $slide) {
            //var_dump($ct);
            $ct++;
            if ($ct == 1) {
              $start1 = "active";
              $start2 = "text-start";
            }elseif ($ct == $num) {
              $start1 = "";
              $start2 = "text-end";
            }else{
              $start1 = "";
              $start2 = "";
            }
        ?>
        <div class="carousel-item <?php echo $start1 ?>">
          <img class="bd-placeholder-img" src="<?php echo hdev_url::menu('dist/img/upload/'.$slide['p_pic']); ?>" aria-hidden="true">

          <div class="container">
            <div class="carousel-caption <?php echo $start2 ?>" style="background-color: rgba(71, 104, 107, 0.4)!important;">
              <h1><?php echo $slide['p_title']; ?></h1>
              <p><?php echo $slide['p_desc'] ?></p>
            </div>
          </div>
        </div>
        <?php
          }
         ?>
      </div>
      <button class="carousel-control-prev" type="button" data-target="#myCarousel" data-slide="prev" style="background: transparent;border: none;">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">.</span>
      </button>
      <button class="carousel-control-next" type="button" data-target="#myCarousel" data-slide="next" style="background: transparent;border: none;">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">.</span>
      </button>
    </div>
    <hr>

    <hr>
    <div style="width: 100%;text-align: center; color: white;" id="services">
      <h2>
        Our Available shops
      </h2>
    </div>          
          <div class="card-group owl-carousel owl-theme" style="padding: 1%;">
            <?php 
            //var_dump(main_data::load_view('service'));
              foreach (hdev_data::groups() as $service) {
            ?>
              <div class="card card-box item">
                 <img class="card-img-top" src="<?php echo hdev_url::menu('dist/img/upload/'.$service['g_pic']); ?>" alt="image" style="height: 300px !important;">
                <div class="card-body">
                  <h5><?php echo $service['g_name'] ?></h5>
                  <p>
                    <?php //echo $service['g_desc']; ?>
                  </p>
                </div>
                <div class="card-footer" align="center">
                  <button class="btn btn-secondary" type="button" onclick="window.location.href='<?php echo hdev_url::menu('brand/'.$service['g_id']) ?>'"><i class="fa fa-cubes"></i> View Products</button>
                </div>
              </div>
            <?php
              }
             ?>
             <?php /////////////////this is prod owl/////////// ?>
        </div>

    </div>
</div>