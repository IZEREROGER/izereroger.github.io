<?php
error_reporting(0);
// Use this namespace
use e_sell\hdev_route;
use e_sell\cfg;
// Include router class
$regpath = __DIR__;
//$regd = str_ireplace('\\', "/", $regpath).'/executor/exp.php';

$regpath = __DIR__;
$regd = str_ireplace('\\', "/", $regpath).'/executor/hdev_parse.php';

include $regd;


function hdev_vd()
{
  $regpath = __DIR__;
  $regd = str_ireplace('\\', "/", $regpath).'/executor/exec_v.php';
  include $regd;
}
$valid = array('login_i','up','memb_reg','memb_edit');
foreach ($valid as $vd) {
  hdev_route::add('/'.$vd, function() {
    hdev_vd();
    exit();
  });
}
if (!hdev_log::loged()) {
//add login page
hdev_route::add('/h/login', function() {
  include 'l_header.php';
  include 'login.php';
  include 'l_footer.php';
  exit();
});  
//add login page
hdev_route::add('/h/register', function() {
  include 'l_header.php';
  include 'register.php';
  include 'l_footer.php';
  exit();
}); 
}else{
//add login page
hdev_route::add('/h/login', function() {
  $csrf = new CSRF_Protect();
  $reqford = $csrf->getToken();
  if (hdev_log::admin() || hdev_log::super_admin()) {
    hdev_note::redirect(hdev_url::menu(""));
  }else{
    hdev_note::redirect('/cart/checkout/'.$reqford);
  }
  
  exit();
});   
hdev_route::add('/pay/shop', function() {
  if (hdev_log::super_admin() || hdev_log::admin()) {
    hdev_menu_url::body(["Shop payments","dest/shop_payment","/pay/shop"]);
  }else{
      hdev_note::redirect(hdev_url::menu(""));
  }  
});
hdev_route::add('/slide/view', function() {
  if (hdev_log::super_admin()) {
    hdev_menu_url::body(["Edit Slide","dest/slides","/slide/view"]);
  }else{
      hdev_note::redirect(hdev_url::menu(""));
  }  
});
hdev_route::add('/info/shop', function() {
  if (hdev_log::admin()) {
    hdev_menu_url::body(["Shop payments","dest/shop_info","/info/shop"]);
  }else{
      hdev_note::redirect(hdev_url::menu(""));
  }  
});
hdev_route::add('/my/shop', function() {
  if (hdev_log::super_admin()) {
    hdev_menu_url::body(["My shop payments","dest/shop_payment","/my/shop"]);
  }else{
      hdev_note::redirect(hdev_url::menu(""));
  }  
});

hdev_route::add('/admin/income', function() { 
  if (hdev_log::admin()) {
    $fid = "shop";
  }elseif (hdev_log::super_admin()) {
    $fid = "admin";
  }
  switch ($fid) {
    case 'admin':
      hdev_menu_url::body(["System income","dest/app_income","/admin/income"]);
    break;
    case 'shop':
      hdev_menu_url::body(["Shop income","dest/shop_income","/admin/income"]);
      break;
  }
});
hdev_route::add('/all/shop', function() {
  if (hdev_log::super_admin()) {
    hdev_menu_url::body(["All Shops On System","dest/shops","/all/shop"]);
  }else{
      hdev_note::redirect(hdev_url::menu(""));
  }  
});
hdev_route::add('/request/shop', function() {
  if (hdev_log::super_admin()) {
    hdev_menu_url::body(["Shops waiting For Approval","dest/shops_request","/request/shop"]);
  }else{
      hdev_note::redirect(hdev_url::menu(""));
  }  
});
hdev_route::add('/reject/shop', function() {
  if (hdev_log::super_admin()) {
    hdev_menu_url::body(["Shops requests rejected","dest/shops_reject","/reject/shop"]);
  }else{
      hdev_note::redirect(hdev_url::menu(""));
  }  
});
hdev_route::add('/deleted/shop', function() {
  if (hdev_log::super_admin()) {
    hdev_menu_url::body(["Shops Deleted","dest/shops_deleted","/deleted/shop"]);
  }else{
      hdev_note::redirect(hdev_url::menu(""));
  }  
});
hdev_route::add('/h/success', function() {
  hdev_menu_url::body(["Login Success","dest/login_process","/h/success"]);
});

hdev_route::add('/cart/checkout/(.*)', function($hash) {
  if (hdev_log::admin() || hdev_log::super_admin()) {
    hdev_note::redirect(hdev_url::menu(""));
  }else{
  hdev_menu_url::body(["Order","dest/order","/h/cart","hash"=>$hash]);
  }  
});
hdev_route::add('/h/success', function() {
  hdev_menu_url::body(["Login Success","dest/login_process","/h/success"]);
});

if (hdev_log::admin() || hdev_log::super_admin()) {
hdev_route::add('/app/core/(.*)/(.*)', function($auth,$data) {
  $csrf = new CSRF_Protect();
  $csrf->verifyRequest($auth);
  $data = hdev_data::decd($data);
  $regd = getcwd().DIRECTORY_SEPARATOR.'executor'.DIRECTORY_SEPARATOR.'exec_d.php';
  include $regd;
  $csrf->up_tk();
  hdev_log::close();
});
}
}


hdev_route::add('/s', function() {
      include 's.php';
  exit();
});

// Add base route (startpage)
hdev_route::add('/', function() {
  hdev_menu_url::body([$_SESSION['exp']["menu"][$_SESSION['lang']]["home"],"home","/h/home","*"]);
});
// Add base route (startpage)
hdev_route::add('/ss', function() {
  hdev_menu_url::body([$_SESSION['exp']["menu"][$_SESSION['lang']]["home"],"search","/h/home"]);
});

hdev_route::add('/h/about', function() {
  hdev_menu_url::body(["About ","about","/h/about"]);
});
hdev_route::add('/h/contact', function() {
  hdev_menu_url::body(["Contact Us ","about","/h/contact"]);
});

//full home page 
hdev_route::add('', function() {
  hdev_menu_url::body([$_SESSION['exp']["menu"][$_SESSION['lang']]["home"],"home","/h/home"]);
});

//full home page 
hdev_route::add('/v/b', function() {//view as admin if loged as admin
  if (hdev_log::loged()) {
    $_SESSION['mtkn'] = hdev_data::encd('11');
    hdev_menu_url::body([$_SESSION['exp']["menu"][$_SESSION['lang']]["home"],"home","/h/home"]);
  }else{ 
    $_SESSION['mtkn'] = '';
    hdev_menu_url::body([$_SESSION['exp']["menu"][$_SESSION['lang']]["home"],"home","/h/home"]);
  }
});

//full home page 
hdev_route::add('/a/v', function() { // view as customer if loged in as admin
    $_SESSION['mtkn'] = '';
    hdev_menu_url::body([$_SESSION['exp']["menu"][$_SESSION['lang']]["home"],"home","/h/home"]);
});
 
//full home page 
hdev_route::add('/h/home', function() {
  hdev_menu_url::body(["All products","home","/h/home","*"]);
});

hdev_route::add('/h/home/(.*)/a/b/c', function($booki) {
  hdev_menu_url::body(["All products","home","/h/home",["id"=>"*","pg"=>$booki]]);
  include 'home.php';
  exit();
});

hdev_route::add('/h/home/(.*)', function($booki) {
  hdev_menu_url::body(["All products","home","/h/home",["id"=>"*","pg"=>$booki]]);
});

hdev_route::add('/h/cartv', function() {
  hdev_menu_url::body(["Cart","dest/cart","/h/cartv"]);
});

hdev_route::add('/h/order', function() {
  hdev_menu_url::body(["Orders","dest/order_view","/h/order"]);
});
// Add base route (startpage)
hdev_route::add('/h/v', function() {
  hdev_menu_url::body([$_SESSION['exp']["form"][$_SESSION['lang']]["signin"],"v_profile","/h/v"]);
});
if (hdev_log::admin() || hdev_log::super_admin()) {
hdev_route::add('/prod_edit/(.*)', function($booki) {
  $booki = trim(hdev_data::decd(trim($booki)));
  hdev_menu_url::body([hdev_data::get_products($booki,"menu")["name"]." Product edit ","dest/edit_product","/prod_edit/".$booki,$booki]);
});

hdev_route::add('/h/profile_info', function() {
  hdev_menu_url::body(["All Users info","dest/profiles","/h/profile_info"]);
});  
//full home page 
hdev_route::add('/h/products', function() {
  hdev_menu_url::body(["All products","dest/all_products","/h/products","*"]);
});

hdev_route::add('/h/products/(.*)/a/b/c', function($booki) {
  hdev_menu_url::body(["All products","dest/all_products","/h/products",["id"=>"*","pg"=>$booki]]);
  include 'dest/all_products.php';
  exit();
});

hdev_route::add('/h/products/(.*)', function($booki) {
  hdev_menu_url::body(["All products","dest/all_products","/h/products",["id"=>"*","pg"=>$booki]]);
});


$_SESSION['mtkn'] = hdev_data::encd('11');
hdev_route::add('/h/book_u', function() { 
  hdev_menu_url::body(["Upload products","dest/product_upload","/h/book_u"]);
});

hdev_route::add('/h/cat_reg', function() {
  $_SESSION['mtkn'] = hdev_data::encd('11');
  hdev_menu_url::body(["Create category","dest/category_reg","/h/cat_reg"]);
});

hdev_route::add('/h/brand_reg', function() {
  $_SESSION['mtkn'] = hdev_data::encd('11');
  hdev_menu_url::body(["Create Brand","dest/brand_reg","/h/brand_reg"]);
});

hdev_route::add('/h/order_r/(.*)/(.*)/(.*)/a/b/c', function($v,$ref,$pg) {
  $_SESSION['mtkn'] = hdev_data::encd('11');
  hdev_session::set("return",$v);
  hdev_session::set("pager_url","h/order_r/".$v."/".$ref);
  hdev_session::set("page",$pg);
  hdev_menu_url::body(["Customer orders","dest/order_review","/h/order_r",['ref'=>$ref,'v'=>$v,'pg'=>$pg,"call"=>"/h/order_r"]]);
  include 'dest/order_review.php';
  exit();
});

hdev_route::add('/h/order_r/(.*)/(.*)/(.*)', function($v,$ref,$pg) {
  $_SESSION['mtkn'] = hdev_data::encd('11');
  hdev_session::set("return",$v);
  hdev_session::set("pager_url","h/order_r/".$v."/".$ref);
  hdev_session::set("page",$pg);
  hdev_menu_url::body(["Customer orders","dest/order_review","/h/order_r/".$v."/".$ref,["call"=>"/h/order_r"]]);
});

hdev_route::add('/h/order_r/(.*)/(.*)', function($v,$ref) {
  $_SESSION['mtkn'] = hdev_data::encd('11');
  hdev_session::set("return",$v);
  hdev_session::set("pager_url","h/order_r/".$v."/".$ref);
  hdev_session::set("page",1);
  hdev_menu_url::body(["Customer orders","dest/order_review","/h/order_r/".$v."/".$ref,["call"=>"/h/order_r"]]);
});


hdev_route::add('/h/order_r/(.*)', function($order) {
  $_SESSION['mtkn'] = hdev_data::encd('11');
  hdev_menu_url::body(["Customer order","dest/order_review_one","/h/order_r","order_id"=>$order,"call"=>"/h/order_r"]);
});

hdev_route::add('/h/order_r', function() {
  $_SESSION['mtkn'] = hdev_data::encd('11');
  hdev_session::set("return",'all');
  hdev_session::set("pager_url","h/order_r/".'all'."/".'pg');
  hdev_session::set("page",1);
  hdev_menu_url::body(["Customer order","dest/order_review","/h/order_r",["call"=>"/h/order_r"]]);
});

hdev_route::add('/h/shipping', function() {
  $_SESSION['mtkn'] = hdev_data::encd('11');
  hdev_menu_url::body(["Shipping Prices Info","dest/shipping_prices","/h/shipping"]);
});

hdev_route::add('/h/cat_info', function() {

  $_SESSION['mtkn'] = hdev_data::encd('11');
  hdev_menu_url::body(["Category Info","dest/category_view","/h/cat_info"]);
});

hdev_route::add('/h/brand_info', function() {
  $_SESSION['mtkn'] = hdev_data::encd('11');
  hdev_menu_url::body(["Brand Info","dest/brand_view","/h/brand_info"]);
}); 
hdev_route::add('/h/brand_info/(.*)', function($pg) {
  $_SESSION['mtkn'] = hdev_data::encd('11');
  hdev_menu_url::body(["Create category","dest/brand_view","/h/brand_info",$pg]);
}); 
hdev_route::add('/h/cat_info/(.*)', function($pg) {
  $_SESSION['mtkn'] = hdev_data::encd('11');
  hdev_menu_url::body(["Create category","dest/category_view","/h/cat_info",$pg]);
});

hdev_route::add('/h/books_top', function() {
  $_SESSION['mtkn'] = hdev_data::encd('11');
  hdev_menu_url::body(["Top ten Books","dest/top_products","/h/books_top"]);
});

}else{
  $_SESSION['mtkn'] = hdev_data::encd('90');
}
hdev_route::add('/book/(.*)/a/b/c', function($booki) {
  hdev_menu_url::body([hdev_data::get_products($booki,"menu")["name"],"dest/product_view","/book/".$booki,$booki]);
  include 'dest/product_view.php';
  exit();
});
hdev_route::add('/book/(.*)', function($booki) {
  hdev_menu_url::body([hdev_data::get_products($booki,"menu")["name"],"dest/product_view","/book/".$booki,$booki]);
});

hdev_route::add('/cat/(.*)/(.*)/a/b/c', function($booki,$pg) {
  hdev_note::redirect(hdev_url::menu(''));exit();
  hdev_menu_url::body([hdev_data::get_cat($booki,"info")["name"],"dest/category_view_products","/cat/".$booki,["id"=>$booki,"pg"=>$pg]]);
  include 'dest/category_view_products.php';
  exit();
});

hdev_route::add('/cat/(.*)/a/b/c', function($booki) {
  hdev_note::redirect(hdev_url::menu(''));exit();
  hdev_menu_url::body([hdev_data::get_cat($booki,"info")["name"],"dest/category_view_products","/cat/".$booki,$booki,"body"=>"only"]);
  include 'dest/category_view_products.php';
  exit();
});
hdev_route::add('/cat/(.*)/(.*)', function($booki,$pg) {
  hdev_note::redirect(hdev_url::menu(''));exit();
  hdev_menu_url::body([hdev_data::get_cat($booki,"info")["name"],"dest/category_view_products","/cat/".$booki,["id"=>$booki,"pg"=>$pg]]);
});

hdev_route::add('/cat/(.*)', function($booki) {
  hdev_note::redirect(hdev_url::menu(''));exit();
  hdev_menu_url::body([hdev_data::get_cat($booki,"info")["name"],"dest/category_view_products","/cat/".$booki,$booki]);
});

hdev_route::add('/brand/(.*)/(.*)/a/b/c', function($booki,$pg) {
  hdev_menu_url::body([hdev_data::groups($booki,['data'])["g_name"],"dest/brand_view_products","/brand/".$booki,["id"=>$booki,"pg"=>$pg]]);
  include 'dest/brand_view_products.php';
  exit();
});

hdev_route::add('/brand/(.*)/a/b/c', function($booki) {
  hdev_menu_url::body([hdev_data::groups($booki,['data'])["g_name"],"dest/brand_view_products","/brand/".$booki,$booki,"body"=>"only"]);
  include 'dest/brand_view_products.php';
  exit();
});
hdev_route::add('/brand/(.*)/(.*)', function($booki,$pg) {
  hdev_menu_url::body([hdev_data::groups($booki,['data'])["g_name"],"dest/brand_view_products","/brand/".$booki,["id"=>$booki,"pg"=>$pg]]);
});

hdev_route::add('/brand/(.*)', function($booki) {
  hdev_menu_url::body([hdev_data::groups($booki,['data'])["g_name"],"dest/brand_view_products","/brand/".$booki,$booki]);
});

hdev_route::add('/h/msg', function() {
  hdev_note::redirect(hdev_url::menu(''));exit();
  hdev_menu_url::body(["Messenger","dest/chat_in","/h/msg"]);
});

hdev_route::add('/h/msg/advanced', function() {
    hdev_note::redirect(hdev_url::menu(''));exit();include "dest/chat_msg.php";exit();
  hdev_menu_url::body(["Messenger","dest/chat_msg","/h/msg"]);
});
hdev_route::add('/pay/auth', function() { 
  $r2 = getcwd().DIRECTORY_SEPARATOR."executor".DIRECTORY_SEPARATOR;
  include($r2.'pay.php');
  exit();
});
hdev_route::add('/payment/(.*)', function($tx) {
  hdev_session::set("transaction",$tx); 
  $py = hdev_data::pay_method($tx);
  if ($py == "paypal") {
    hdev_menu_url::body(["Payment","executor/payment_init","/payment"]);
  }elseif ($py == "momo") {
    //print_r(hdev_session::get("tx_dta"));
    $r2 = getcwd().DIRECTORY_SEPARATOR."executor".DIRECTORY_SEPARATOR."control".DIRECTORY_SEPARATOR;
    include($r2.'pay_engine.php');
    exit();
  }
  
});
hdev_route::add('/receipt/(.*)', function($tx) {
  hdev_session::set("transaction",$tx);
  hdev_menu_url::body(["Receipt","executor/payment_receipt","/receipt"]);
});
// Add a 404 not found route
hdev_route::pathNotFound(function($path) { 
  // Do not forget to send a status header back to the client
  // The router will not send any headers by default
  // So you will have the full flexibility to handle this case
  header('HTTP/1.0 404 Not Allowed');
  hdev_menu_url::body(["error","error","/error"]);
});

// Add a 405 method not allowed route
hdev_route::methodNotAllowed(function($path, $method) {
  // Do not forget to send a status header back to the client
  // The router will not send any headers by default
  // So you will have the full flexibility to handle this case
  header('HTTP/1.0 405 Method Not Allowed');
  echo 'Error 405 :-(<br>';
  echo 'The requested path "'.$path.'" exists. But the request method "'.$method.'" is not allowed on this path!';
});

// Run the Router with the given Basepath
// If your script lives in the web root folder use a / or leave it empty
hdev_route::run('/');
cfg::check();

// If your script lives in a subfolder you can use the following example
// Do not forget to edit the basepath in .htaccess if you are on apache
// hdev_route::run('/api/v1');

// Enable case sensitive mode, trailing slashes and multi match mode by setting the params to true
// hdev_route::run('/', true, true, true);
?>