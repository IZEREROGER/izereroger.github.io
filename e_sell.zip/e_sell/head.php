<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">

  <title><?php echo APP_NAME; ?> <?php if (!empty($_SESSION["act_url"][0]) && $_SESSION["act_url"][0] !="error") {
    echo "---".$_SESSION["act_url"][0];
  } ?></title>

  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/fontawesome-free/css/all.min.css'); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo hdev_url::menu('dist/css/adminlte.min.css');?>">
  <!--<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">-->
  <link rel="stylesheet" href="<?php echo hdev_url::menu('dist/css/main.css?v='.rand());?>">
    <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/summernote/summernote-bs4.min.css');?>">
    <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/datatables-bs4/css/dataTables.bootstrap4.css');?>">
    <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/datatables-responsive/css/responsive.bootstrap4.min.css') ?>">
  <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css');?>">
  <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/select2/css/select2.min.css');?>">
  <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/Smoothproducts/css/smoothproducts.css');?>">
  <link rel="ICON" type="ICON/png" href="<?php echo hdev_url::menu('dist/img/hdev_app2.png');?>">
   <link rel="stylesheet" href="<?php echo hdev_url::menu('plugins/overlayScrollbars/css/OverlayScrollbars.min.css');?>">
  <!-- Google Font: Source Sans Pro -->
  <!--<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">-->
  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-E0DS2FBS5N"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-E0DS2FBS5N');
</script>
</head>

<?php 
  if (isset($_SESSION['mtkn']) && !empty($_SESSION['mtkn'])) {
    if (hdev_data::decd($_SESSION['mtkn'])=="11" && hdev_log::admin()) {
      echo '<body class="hold-transition sidebar-mini layout-fixed sidebar-collapse layout-fixed" style="top:0px !important;" id="body">';
    }elseif (hdev_log::loged() && hdev_log::super_admin()) {
      echo '<body class="hold-transition sidebar-mini layout-fixed sidebar-collapse layout-fixed" style="top:0px !important;" id="body">';
    }else{ 
      echo '<body class="hold-transition layout-top-nav">';
    }
  }else{
    echo '<body class="hold-transition layout-top-nav">';
  }
 ?>


<!-- Preloader -->
<div class="skiptranslate" style="display: none;"></div>
<div id="preloader">
  <div id="status">&nbsp;
  <br><i><?php echo hdev_lang::on("form","load"); ?></i></div>
  <div align="center"></div>
</div>
<div class="wrapper"> 
