  <!--<div class="content-wrapper" style="background : url('<?php echo hdev_url::menu('dist/img/bg.jpg');?>');background-attachment: fixed;background-size: cover;">-->
    <div class="content-wrapper" style="background : url('<?php echo hdev_url::menu('dist/img/always_grey.png'); ?>') repeat rgba(68, 68, 68, 0.9);">
  <!-- Content Wrapper. Contains page content -->
    <!-- Content Header (Page header) -->
    <?php if (1==2) {?>
    <div class="content-header">
      <div class="container">
        <div class="row mb-2">
          <div class="col-sm-6">
            <i class="breadcrumb-item text-white"><?php echo $_SESSION['act_url'][0]; ?></i>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo hdev_url::get_url_host(); ?>"><?php echo hdev_lang::on("menu",'home') ?></a></li>
              <li class="breadcrumb-item text-white"><?php echo $_SESSION['act_url'][0]; ?></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
        <hr>
      </div><!-- /.container-fluid -->
    </div>
    <?php
    } ?>

    <div class="content"><div class="container">
      <div class="row">
        <div class="col-md-12 col-xs-12" id="product_msg">
        </div>
      </div>
    </div>
  </div>
    <!-- /.content-header -->
<div id="get_product">
<?php 
  if (!empty($_SESSION['act_url'])) {
    if (!empty($_SESSION['act_url'][0]) && !empty($_SESSION['act_url'][1])) {
      if (file_exists($_SESSION['act_url'][1].".php")) {
        if (hdev_menu_url::url_req($_SESSION['act_url'][0],"user") == "y") {
          include $_SESSION['act_url'][1].".php";
        }else{
          include 'error.php';
        }
      }else{
        include 'error.php';
      }
    }else{
      include 'error.php';
    }
  }else{
    include 'error.php';
  }
   ?>
 </div>
 </div>