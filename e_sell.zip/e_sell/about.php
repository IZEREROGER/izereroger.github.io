    <!-- Main content -->
<div class="content">
  <div class="container">		  
            <!-- Default box -->
      <div class="card card-solid">
        <div class="card-body pb-0">
                  <div class="row">
          <div class="col-lg-12">
            <div class="card card-primary card-outline">
              <div class="card-body">
                <h5 class="card-title">About <?php echo APP_NAME; ?></h5>
                <br>
                <hr>
                <p class="card-text">
                  SHOP NOW!
                </p>
              </div>
            </div><!-- /.card -->
          </div>
          <div class="row d-flex align-items-stretch">
            <div class="col-12 col-sm-6 col-md-6 d-flex align-items-stretch">
              <div class="card bg-light">
                <div class="card-header text-muted border-bottom-0">
                  <?php echo APP_NAME; ?> PROJECT 
                </div>
                <div class="card-body pt-0">
                  <div class="row">
                    <div class="col-7">
                      <h2 class="lead"><b><?php echo APP_NAME; ?></b></h2>
                      <p class="text-muted text-sm">We sell all made in rwanda fashion creativities</p>
                      <br><hr>
                      <h6>All products are original</h6>
                    </div>
                    <div class="col-5 text-center">
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-12 col-sm-6 col-md-6 d-flex align-items-stretch">
              <div class="card bg-light">
                <div class="card-header text-muted border-bottom-0">
                  <?php echo APP_NAME; ?> DEVELOPER
                </div>
                <div class="card-body pt-0">
                  <div class="row">
                    <div class="col-9">
                      <h2 class="lead"><b><?php echo APP_PROGRAMMER['name']; ?></b></h2>
                      <p class="text-muted text-sm"><b>About: </b> Web Developer</p>
                      <ul class="ml-4 mb-0 fa-ul text-muted">
                        <li class="small"><span class="fa-li"><i class="fas fa-lg fa-building"></i></span> Address: Kigali, Rwanda</li><br>
                        <li class="small"><span class="fa-li"><i class="fas fa-lg fa-phone"></i></span> Phone #: </li>
                      </ul>
                      <br><hr>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
          <nav aria-label="Contacts Page Navigation">
            <ul class="pagination justify-content-center m-0">
              <li class="page-item"><a target="_blank" class="page-link" href="mailto:<?php echo APP_PROGRAMMER['email'] ?>">&copy; <?php echo APP_NAME; ?>.</a></li>
            </ul>
          </nav>
        </div>
        <!-- /.card-footer -->
      </div>


  </div>
  <!-- /.content-->
</div>