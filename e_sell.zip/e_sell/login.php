<style type="text/css">
  .box{
position:absolute;
top:50%;
left:50%;
transform:translate(-50%, -50%);
width: 400px;
padding:40px;
background:gray;
opacity: .8;
box-sizing: border-box;
box-shadow:0 15px 25px rgba(0,0,0,.5);
border-radius:10px;
}
.box h3{
margin:0;
padding:o;
color:#fff;
text-align:center;
}
.box .inputBox{
position:relative;
}
.box .inputBox input{
width:100%;
padding:10px;
font-size:16px;
color:#fff;
margin-bottom:30px;
border:none;
border-bottom:1px solid #FFFFFF;
outline:none;
background:transparent;
}
.box .inputBox label{
position:absolute;
top:0;
left:0;
padding:10px 0;
font-size:16px;
color:#fff;
pointer-events:none;
transition: .5s;
}
.box .inputBox input:focus ~label,
.box .inputBox input:valid ~label
{
top:-20px;
left:0;
color:#0000ee;
font-size:18px;
}
.box input[type="submit"]{
background:transparent;
border:none;
outline:none;
background:#0000FF;
padding:10px;
color:#FFFFFF;
cursor:pointer;
border-radius:5px;

}

.box a{
background:transparent;
border:none;
outline:none;
background:#0000FF;
padding:10px;
color:#FFFFFF;
cursor:pointer;
border-radius:5px;

}
#frm{
  width:30%;
  border:solid gray 1px;
  border-radius:5px;
  margin:100px auto;
  background:transparent !important;
}
.header{
  width:100%;
  height:35px;
  background-color:green;
  margin-top:-30px;
  border-radius:5px;
  text-align:center;
  color:#fff;
  font-size:24px;
  }
  
#frm input[type="submit"]{
background:transparent;
border:none;
outline:none;
background:#0000FF;
padding:10px;
color:#FFFFFF;
cursor:pointer;
border-radius:5px;

}
.from input[type="text"]{

width:100%;
padding:10px;
font-size:16px;
color:#fff;
margin-bottom:30px;
border:none;
border-bottom:1px solid #FFFFFF;
outline:none;
background:transparent;
}

.from input[type="password"]{

width:100%;
padding:10px;
font-size:16px;
color:#fff;
margin-bottom:30px;
border:none;
border-bottom:1px solid #FFFFFF;
outline:none;
background:transparent;
}


#login .form-signin{
  background: url("../../images/pixel-60fff.png") repeat scroll 0 0 rgba(0, 0, 0, 0) !important;
  -webkit-box-shadow: 2px 2px 5px rgba(0, 0, 6, 0.75) !important;
  -moz-box-shadow:    2px 2px 5px rgba(0, 0, 6, 0.75) !important;
  box-shadow:         2px 2px 5px rgba(0, 0, 6, 0.75) !important;
    box-shadow: 0 1px 3px rgba(15, 15, 15, 0.2) !important;

}
</style>

<div class="box">
  <div align="center">
  </div>
  
  <h3>Login at <?php echo APP_NAME; ?></h3>
  
  <form id="login_form" class="form-signin" method="POST">
       <?php 
          if ($_POST) {
            if (isset($_POST['f_pid'])) {
              $_SESSION['cart_product'] = "";
              $json_e = json_encode($_POST['f_pid']);
              $_SESSION['cart_product'] = $json_e;
              $_SESSION['cat_cat'] = "o";
            }
            if (isset($_POST['acc']) && !empty($_POST['acc'])) {
              switch ($_POST['acc']) {
                case 'yes':
                  //echo "with account";
                  break;
                case 'reg':
                  hdev_note::redirect(hdev_url::menu('h/register'));
                  break;
                default:
                  $csrf = new CSRF_Protect();
                  $tk = $csrf->getToken(); 
                  $username = $tk.rand();
                  while (hdev_data::username_e($username) == "no") {
                    $tk = $csrf->getToken(); 
                    $username = $tk.rand().rand();
                  }
                  $rt = new hdev_db();
                  $tab = $rt->table("user");
                  $reff =$rt->insert("INSERT INTO $tab (`id`, `tell`, `post`, `name`, `sex`, `username`, `address`, `password`) VALUES (NULL, :contact, :role, :name, :sex, :username, :address, :password)",[[":contact","0788888888"],[":role",'user'],[":name",'guest user'],[":sex",'f'],[":username",$username], [":address",'98'], [":password",hdev_data::password_enc($username)]]);
                  if ($reff == "ok") {
                    hdev_v::login($username,$username);
                    hdev_note::redirect(hdev_url::menu('h/success'));
                  }
                  exit();
                  break;
              }
            }
          }
         ?>
         <?php 
          $csrf = new CSRF_Protect();
          $csrf->echoInputField();
        ?>
    <input type="hidden" name="ref" value="login">
    <div class="inputBox">
      <input type="text" name="usn" onkeyup="login();" required/>
      <label>Username</label>
    </div>

    <div class="inputBox">
      <input type="password" name="psw" onkeyup="login();" required/>
      <label>Password</label>
    </div>
    <div class="wait" align="center" style="display: none;color: #ffffff;">
        <span><img src="<?php echo hdev_url::img(hdev_url::menu('dist/img/loading2.gif'));?>" alt="" /></span>
        <br>
        <i>Processing ... please wait!!!</i>
    </div>
    <div id="fsave">
      <div style="display: none !important;">
        
      <button type="submit" class="btn bg-gradient-primary btn-block" title="Click to Login" name="ok" value="Submit"><i class="fa fa-unlock"></i> Login</button>
      </div>
    </div>
    <br>
    <i style="color: #fff;">&copy;- <?php echo date("Y"); ?> - <?php echo APP_NAME; ?> --- All rights reserved</i>
  </form>
</div>

